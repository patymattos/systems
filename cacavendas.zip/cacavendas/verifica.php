<?
session_start();
if (!isset($_SESSION["login"]))
{
    echo "<script>location.href='noticias.php'</script>";	
	exit();
}
?>