<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>-= ALAMEDA PNEUS - SISTEMA ADMINISTRATIVO =-</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style13 {font-size: 13px}
.style16 {font-family: Arial, Helvetica, sans-serif}
.style19 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; }
.style21 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #000066; }
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<form  action="valida_pedido.php" enctype="multipart/form-data" method="post" target="_blank">
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="215" border="0" align="right">
      <tr>
        <td width="98">&nbsp;</td>
        <td width="107"><span class="style10"><input type="hidden" name="id" value="<?=$radioId?>"><input type="image" src="img/finalizar-pedido.gif" height="30" border="0"></span></td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="550" border="0">
      <tr>
        <td width="226" colspan="7"><div align="left" class="style12 style13"><span class="style16"><strong>:: INFORMA&Ccedil;&Otilde;ES GERAIS::</strong><br>
          ----------------------------------------------------------------------------------------------------------------------------------------                  
          <br />
        </span></div></td>
      </tr>
    </table>    
      <table width="550" border="0" align="center" bordercolor="#000000" bgcolor="#000000">
        <tr bgcolor="#333333">
          <td width="20%"><span class="style13"><span class="style29">DATA</span></span></td>
          <td width="80%"><span class="style13"><span class="style29">NOME</span></span></td>
        </tr>
<?php

		$sql = "SELECT vd.*, c.CLI_NOME, f.FUN_NOME FROM vendas_direta vd, clientes c, funcionario f WHERE vd.id_cliente = c.CLI_ID AND vd.id = '$radioId'";   
		//echo $sql;
		$qr = mysql_query($sql);   
		$row = mysql_fetch_array($qr); 
			
			$valor_p = 0;
			$valor_s = 0;
			$total_ser = 0;
			$total_p = 0;
			$produto_ver = "";
			$servico_ver = "";
			
			$data_final = new DateTime($row['data']);  
			$data_final = $data_final->format('d/m/Y');
			
			echo'<tr bgcolor="#FFFFFF">';
          	echo'<td><span class="style13"><span class="style10">'.$data_final.'</span></span></td>';
          	echo'<td><span class="style13"><span class="style10">'.$row['CLI_NOME'].'</span></span></td>';
		  	echo'</tr></table>';
			
			echo'<br />';
			
			echo'<table width="550" border="0" align="center" bordercolor="#000000" bgcolor="#000000">';
			echo'<tr bgcolor="#333333">';
			echo'<td width="87"><span class="style13"><span class="style29">PRODUTO/SERVI�O</span></span></td>';
			echo'<td width="45"><span class="style13"><span class="style29">QT.</span></span></td>';
			echo'<td width="64"><span class="style13"><span class="style29">VALOR</span></span></td>';
			echo'<td width="53"><span class="style13"><span class="style29">TOTAL(R$)</span></span></td>';
			echo'</tr>';
			
			$quant 			= explode("/",$row['qtde_produtos']);
			$produto_vp 	= explode("/",$row['valor_produto']);
			$cont_vp		= count($produto_vp);
			
			$servico_sv 	= explode("/",$row['valor_servico']);
			$cont_sv		= count($servico_sv);
			
			$produto_ver2 	= explode("/",$row['id_produtos']);
			$cont_ver2		= count($produto_ver2);
			
			$servico_ver2 	= explode("/",$row['id_servicos']);
			$cont_ser2		= count($servico_ver2);
			
			
			for($i=0;$i<($cont_ver2-1);$i++){
			
				$produto_ver 	= $produto_ver2[$i];
				$valor_p 		= $produto_vp[$i];
				
				
				$select 		= "SELECT * FROM produtos WHERE PRD_ID = '$produto_ver'";
				//echo "<br>".$select;
				
				$sql 			= mysql_query($select);
				$a 				= mysql_fetch_array($sql);
				
				echo '<tr bgcolor="#FFFFFF">';
				echo '<td><span class="style13"><span class="style10">'.$a['PRD_NOME'].'</span></sapan></td>';
				echo '<td><span class="style13"><span class="style10">'.$quant[$i].'</span></sapan></td>';
				echo '<td><span class="style13"><span class="style10">'.($valor_p/$quant[$i]).'</span></sapan></td>';
				echo '<td><span class="style13"><span class="style10">'.$valor_p.'</span></sapan></td>';
				echo '</tr>';
				
				$total_p = $total_p + $valor_p;
			}
			for($i=0;$i<($cont_ser2-1);$i++){
				$servico_ver 	= $servico_ver2[$i];
				$valor_s 		= $servico_sv[$i];			
				
				$select 		= "SELECT * FROM servicos WHERE SER_ID = '$servico_ver'";
				//echo "<br>".$select;
				
				$sql 			= mysql_query($select);
				
				$a				= mysql_fetch_array($sql);
				
				echo '<tr bgcolor="#FFFFFF">';
				echo '<td colspan="2"><span class="style13"><span class="style10">'.$a['SER_NOME'].'</span></sapan></td>';
				echo '<td><span class="style13"><span class="style10">'.$valor_s.'</span></sapan></td>';
				echo '<td><span class="style13"><span class="style10">'.$valor_s.'</span></sapan></td>';
				echo '</tr>';
				
				$total_ser = $total_ser + $valor_s;
			}
			
			$total = ($total_p+$total_ser);

?>
      </table>      <p>&nbsp;</p>
      <table width="550" border="0">
        <tr>
          <td width="437" colspan="5"><span class="style12 style13"><span class="style16"><strong>:: FORMA DE PAGAMENTO ::</strong><br>
---------------------------------------------------------------------------------------------------------------------------------------- </span></span></td>
        </tr>
      </table>
<?php
$select_final 	= "SELECT * FROM pagamentos WHERE id = '$radioId'";
//echo $select_final;
$query_final	= mysql_query($select_final);
$result_final	= mysql_fetch_array($query_final);
$rows_final		= mysql_num_rows($query_final);
if($rows_final > 0){
	$pagamento_final= "<option value='".$result_final['formpagamento']."' selected='selected'>".$result_final['formpagamento']."</option>";
	$parcelas		= $result_final['parcelas'];
	$taxa_cartao	= $result_final['taxa_cartao'];
	$nota_vendedor	= $result_final['nota_vendedor'];
}
else{
	$pagamento_final= "";
	$parcelas		= "";
	$taxa_cartao	= "";
	$nota_vendedor	= "";
}
?>
    <table width="550" border="0">
      <tr>
        <td width="116"><span class="style13"><span class="style10">Tipo de Pagamento:</span></span></td>
        <td><select name="select">
        	<?=$pagamento_final?>
          <option value="Cheque">Cheque</option>
          <option value="Dinheiro">Dinheiro</option>
          <option value="Master">Master</option>
          <option value="Visa">Visa</option>
          <option value="RedeShop">RedeShop</option>
          <option value="Visa Eletron">Visa Eletron</option>
          <option value="Outros">Outros</option>
        </select></td>
        <td><span class="style13"><span class="style10">N&ordm; Parcelas:</span></span></td>
        <td><input name="textfield2" type="text" value="<?=$parcelas?>" size="5"></td>
        <td>% Cart&atilde;o:</td>
        <td><input name="textfield4" type="text" value="<?=$taxa_cartao?>" size="5"></td>
      </tr>
      <tr>
        <td><span class="style13"><span class="style10">N&ordm; Nota Vendedor:</span></span></td>
        <td><input name="textfield" type="text" size="12" value="<?=$nota_vendedor?>">          </td>
        <td width="73"><span class="style13"><span class="style10">Valor Bruto:</span></span></td>
        <td width="65"><span class="style13"><span class="style21">R$: <?=$total?>,00 </span></span></td>
        <td width="80"><span class="style13"><span class="style10">Valor Liquido:</span></span></td>
        <td width="94"><span class="style13"><span class="style21">R$: <?=$total?>,00 </span></span></td>
      </tr>
    </table>    
    <p>&nbsp;</p></td>
  </tr>
</table>
<br>
</form>
</body>
</html>
