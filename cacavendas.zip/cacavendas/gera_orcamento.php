<?php
include_once "php/config.php";
$id_pre = $_POST['id_pre_venda'];

		$sql = "SELECT pv.*, c.CLI_NOME, f.FUN_NOME FROM pre_vendas pv, clientes c, funcionario f, produtos p WHERE  id = '$id_pre' AND pv.id_cliente = c.CLI_ID AND pv.id_vendedor = f.FUN_ID ";   
		$qr = mysql_query($sql);   
		$row = mysql_fetch_array($qr);   
		$valor_p = "";
		$valor_s = "";
		$produto_ver = "";
		$servico_ver = "";
		$mecanico_s = "";
		$borracheiro_s = "";
		
		#################
		$quant = explode("/",$row['qtde_produtos']);
		$quant = $quant[0];
		
		$select_me = "SELECT * FROM funcionario WHERE FUN_ID = '$row[id_mecanico]'";
		$sql_me = mysql_query($select_me);
		$b = mysql_fetch_array($sql_me);
		$nome_mecanico = $b['FUN_NOME'];
		
		$select_bor = "SELECT * FROM funcionario WHERE FUN_ID = '$row[id_borracheiro]'";
		$sql_bor = mysql_query($select_bor);
		$c = mysql_fetch_array($sql_bor);
		$nome_borracheiro = $c['FUN_NOME'];
		#################
		
		$produto_vp 	= explode("/",$row['valor_produto']);
		$cont_vp		= count($produto_vp);
		
		$servico_sv 	= explode("/",$row['valor_servico']);
		$cont_sv		= count($servico_sv);
		
		$produto_ver2 	= explode("/",$row['id_produtos']);
		$cont_ver2		= count($produto_ver2);
		
		$servico_ver2 	= explode("/",$row['id_servicos']);
		$cont_ser2		= count($servico_ver2);
		
		$mecanico_sv 	= explode("/",$row['id_mecanico']);
		$cont_mec2 		= count($mecanico_sv); 

		$borracheiro_sv	= explode("/",$row['id_borracheiro']);
		$cont_bor2 		= count($borracheiro_sv); 

		$valor_total = $valor_p + $valor_s;
		$data_final = new DateTime($row['data']);  
		$data_final = $data_final->format('d/m/Y');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= KAKA PNEUS - SISTEMA ADMINISTRATIVO =-</title>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
    <script src="js/fs.js" type="text/javascript"></script>
    <script src="js/fsprint.js" type="text/javascript"></script>
    <script type="text/javascript">
	window.print('conteudo');
	</script>
    <link href="css/imprime.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="conteudo">
<table width="600" border="0" bgcolor="#FFFFFF" align="center">
	<tr>
    	<td align="center" colspan="5"><h2>OR�AMENTO</h3></td>
    </tr>
    <tr>
    	<td colspan="4">Nome Cliente: <b><?=$row['CLI_NOME']?></b></td>
        <td>Nome Vendedor: <b><?=$row['FUN_NOME'];?></b></td>
    </tr>
        	<?php
		for($i=0;$i<($cont_ver2-1);$i++){
		
			$produto_ver 	= $produto_ver2[$i];
			$valor_p 		= $produto_vp[$i];
			
			$select 		= "SELECT * FROM produtos WHERE PRD_ID = '$produto_ver'";

			$sql 			= mysql_query($select);
			$a 				= mysql_fetch_array($sql);
			echo "<tr>";
			echo "<td colspan='5'>";
			echo "Produto: <b>".$a['PRD_NOME']."</b>&nbsp;&nbsp;&nbsp;";
			echo "Qtde.: <b>$quant</b>&nbsp;&nbsp;&nbsp;";
			echo "<b>R$ $valor_p</b>";
			echo "</td>";
			echo "</tr>";
			
			$valor_p 		= $valor_p + $produto_vp[$i];
		}
		for($i=0;$i<($cont_ser2-1);$i++){
			$servico_ver 	= $servico_ver2[$i];
			$mecanico_s 	= $mecanico_sv[$i];				
			$borracheiro_s 	= $borracheiro_sv[$i];
			$valor_s 		= $servico_sv[$i];			
			
			$select 		= "SELECT * FROM servicos WHERE SER_ID = '$servico_ver'";
			$select_mec 	= "SELECT * FROM funcionario WHERE FUN_ID = '$mecanico_s'";
			$select_bor 	= "SELECT * FROM funcionario WHERE FUN_ID = '$borracheiro_s'";
			
			$sql 			= mysql_query($select);
			$sql_mec		= mysql_query($select_mec);
			$sql_bor		= mysql_query($select_bor);
			
			$a				= mysql_fetch_array($sql);
			$a_mec			= mysql_fetch_array($sql_mec);
			$a_bor			= mysql_fetch_array($sql_bor);
			
			echo "<tr>";
			echo "<td colspan='5'>";
			echo "Servi�o: <b>".$a['SER_NOME']."</b>&nbsp;&nbsp;&nbsp;";
			echo "Mec�nico: <b>".$a_mec['FUN_NOME']."</b>&nbsp;&nbsp;&nbsp;";
			echo "Borracheiro: <b>".$a_bor['FUN_NOME']."</b>&nbsp;&nbsp;&nbsp;";
			echo "<b>R$ " .$valor_s."</b>";
			echo "</td>";
			echo "</tr>";
			
			$total_ser = $valor_s + $servico_sv[$i];
		}
		?>
    <tr>
    	<td colspan="4">&nbsp;</td>
    </tr>
</table>
</div>
<div align="center"><a href="cad_vendas.php" target="_self">Voltar</a></div>
</body>
</html>