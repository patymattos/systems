<link rel="stylesheet" type="text/css" href="css/sddm.css" >
<br />
<div class="navbar">
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >SITE</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:inline;">
        <div class="subItem"><a href="adm_noticias.php">Noticias</a></div>
        <div class="subItem"><a href="adm_aempresa.php">A Empresa</a></div>
		<div class="subItem"><a href="#">Galeria</a></div>
        <div class="subItem"><a href="adm_pri_clientes.php">Principais Clientes</a></div>
        <div class="subItem"><a href="adm_depoimentos.php">Depoimentos</a></div>
        <div class="subItem"><a href="adm_servicos.php">Servi�os</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >EVENTOS/INSCRI��O</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
        <div class="subItem"><a href="adm_eventos.php">Administrar Eventos</a></div>
		<div class="subItem"><a href="menu_principal.php">Nome do Menu</a></div>
        <div class="subItem"><a href="adm_menu.php">Conte�do do Menu</a></div>
        <div class="subItem"><a href="administrar_inscricoes.php">Administrar Inscri��es</a></div>
        <div class="subItem"><a href="adm_titulo.php">Titulo da Inscri��o</a></div>
		<div class="subItem"><a href="adm_termo.php">Termo de Compromisso</a></div>
		<div class="subItem"><a href="adm_formulario.php">Formulario Online</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >CERTIFICADOS</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
        <div class="subItem"><a href="adm_certificados.php">Cadastrar Certificados I.</a></div>
		<div class="subItem"><a href="adm_certificados2.php">Administrar Certificados I.</a></div>
        <div class="subItem"><a href="adm_certificados_trabalhos.php">Cadastrar Certificados T.</a></div>
		<div class="subItem"><a href="adm_certificados_trabalhos2.php">Administrar Certificados T.</a></div>
        <div class="subItem"><a href="adm_etiquetas.php">Emitir Etiquetas</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >RELAT�RIOS</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
        <div class="subItem"><a href="adm_rela_inscr.php">Relat�rio de Inscri��es</a></div>
		<div class="subItem"><a href="adm_rela_eventos.php">Relat�rio de Eventos</a></div>
        <div class="subItem"><a href="adm_rela_trab.php">Relat�rio de Trabalhos</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem"  >SISTEMA</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
		<div class="subItem"><a href="adm_usuarios.php">Usu�rios ADM</a></div>
		<div class="subItem"><a href="adm_usuarios_eventos.php">Usu�rios Eventos</a></div>
		<div class="subItem"><a href="php/sair.php">Sair</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<script type="text/javascript" src="js/xpmenuv21.js"></script>
</div>
<br />