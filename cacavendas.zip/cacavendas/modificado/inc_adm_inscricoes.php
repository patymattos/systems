<?php
include ("config.php");
session_start();
//echo $_SESSION['eventos'];
if (strlen($_GET["buscar"])>0){
		include ("config.php");
	    $buscar = ucwords($_POST["buscar"]);
		//$buscar  = strtolower($buscar);
		//$buscar = ucwords($buscar);
		//$buscar3 = strtoupper($buscar);

		// se ele n�o encontrar resultados, ele ir� verificar se com a primeira letra em mai�scula
		$sql = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '".$_SESSION['eventos']."' and (familyname REGEXP '^".$buscar."' OR givenname REGEXP '^".$buscar."' OR email REGEXP '^".$buscar."' OR nome_evento REGEXP '^".$buscar."')");
		$total = mysql_num_rows($sql);
		
		// se ele n�o encontrar resultados, ele ir� verificar com todas as letras em mai�sculas
		if ($total == 0){
			$buscar = strtoupper($_POST["buscar"]);
			$sql = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '".$_SESSION['eventos']."' and ( familyname REGEXP '^".$buscar."' OR givenname REGEXP '^".$buscar."' OR email REGEXP '^".$buscar."' OR nome_evento REGEXP '^".$buscar."')");
			$total = mysql_num_rows($sql);
		}
		// se ele n�o encontrar resultados, ele ir� verificar com todas as letras em min�sculas
		if ($total == 0){
			$buscar = strtolower($_POST["buscar"]);
			$sql = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '".$_SESSION['eventos']."' and ( familyname REGEXP '^".$buscar."' OR givenname REGEXP '^".$buscar."' OR email REGEXP '^".$buscar."' OR nome_evento REGEXP '^".$buscar."')");
			$total = mysql_num_rows($sql);
		}
		
		$geti = $_GET['pagina'];
		if ($geti>0){
			$inicio = 10*$geti; // Especifique quantos resultados voc� quer por p�gina
			$lpp= 10; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
		}else{
			$inicio = 0;
			$lpp	= 10;
		}
		//$total = mysql_num_rows($sql); // Esta fun��o ir� retornar o total de linhas na tabela
		$paginas = ceil($total / 10); // Retorna o total de p�ginas
		if(!isset($pagina)) { 
			$pagina = 0; 
		} // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
		
		$sql = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '".$_SESSION['eventos']."' and ( familyname REGEXP '^".$buscar."' OR givenname REGEXP '^".$buscar."' OR email REGEXP '^".$buscar."' OR nome_evento REGEXP '^".$buscar."') ORDER BY email DESC LIMIT $inicio, $lpp");
		$num = mysql_num_rows($sql);
		if ($num > 0){
			echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
			echo "<tr>";
			echo "<td class=titulo colspan=4>:: Administrar Inscri��es ::</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td class='texto' width='105'><b>Usu�rios</b></td>";
			echo "<td class='texto' width='100'><b>E-Mail</b></td>";
			echo "<td class='texto' width='300'><b>Evento</b></td>";
			echo "<td class='texto' width='45'><b>Excluir</b></td>";
			echo "</tr>";
			while ($linha = mysql_fetch_array($sql)){
				//$id_evento = $linha["id"];
				$id_inscricoes = $linha["id"];
				$familyname = $linha["familyname"];
				$givenname = $linha["givenname"];
				$email = $linha["email"];
				$nome_evento = $linha["nome_evento"];
				echo "<tr>";
				echo "<td class='texto'><a href='vis_inscricoes.php?id_inscricoes=$id_inscricoes'>".$familyname.' '.$givenname."</a></td>";
				echo "<td class='texto'><a href='vis_inscricoes.php?id_inscricoes=$id_inscricoes'>".$email."</a></td>";
				echo "<td class='texto'><a href='vis_inscricoes.php?id_inscricoes=$id_inscricoes'>".substr ($nome_evento,0,60)."...</a></td>";
				echo "<td align='center'><a href='php/excluir_inscricoes.php?id_inscricoes=$id_inscricoes'><img src='img/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
				echo "</tr>";		
			}
			echo "</table>";
			if ($total > 10){
				echo "<span class='texto'>Mais registros</span>";
				echo "<br />";
				if($pagina > 0) {
					$menos = $pagina - 1;
					$url = "$PHP_SELF?buscar=".$buscar."&pagina=$menos";
					echo "<a class=\"destaque\" href=\"$url\">&laquo;</a>"; // Vai para a p�gina anterior
				}
				for($i=0;$i<$paginas;$i++) { // Gera um loop com o destaque para as p�ginas
					$url = "$PHP_SELF?buscar=".$buscar."&pagina=$i";
					echo " | <a class=\"destaque\" href=\"$url\">$i</a>";
				}
				if($pagina < ($paginas - 1)) {
					$mais = $pagina + 1;
					$url = "$PHP_SELF?buscar=".$buscar."&pagina=$mais";
					echo " | <a href=\"$url\">&raquo;</a>";
				}
			}
		}else{
			echo "Nenhum registro foi encontrado.";
		}
		
}else{
		$select_query = "SELECT * FROM inscricoes WHERE  nome_evento = '".$_SESSION['eventos']."'";
		//echo $select_query;
		//exit();
		$sql = mysql_query($select_query);
		$geti = $_GET['pagina'];
		if ($geti>0){
			$inicio = 10*$geti; // Especifique quantos resultados voc� quer por p�gina
			$lpp= 10; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
		}else{
			$inicio = 0;
			$lpp	= 10;
		}
		$total = mysql_num_rows($sql); // Esta fun��o ir� retornar o total de linhas na tabela
		$paginas = ceil($total / 10); // Retorna o total de p�ginas
		if(!isset($pagina)) { 
			$pagina = 0; 
		} // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
		
		$select_paginacao = "SELECT * FROM inscricoes WHERE  nome_evento = '".$_SESSION['eventos']."' ORDER BY nome_evento DESC LIMIT $inicio, $lpp";
		echo $select_paginacao;
		$sql = mysql_query($select_paginacao); // Executa a query no MySQL com o limite de linhas.
		echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
		echo "<tr>";
		echo "<td class=titulo colspan=4>:: Administrar Inscri��es ::</td>";
		echo "</tr>";
		echo "<tr>";
		echo "<td class='texto' width='105'><b>Usu�rios</b></td>";
		echo "<td class='texto' width='100'><b>E-Mail</b></td>";
		echo "<td class='texto' width='300'><b>Evento</b></td>";
		echo "<td class='texto' width='45'><b>Excluir</b></td>";
		echo "</tr>";
		while ($linha = mysql_fetch_array($sql)){
			//$id_evento = $linha["id"];
			$id_inscricoes = $linha["id"];
			$familyname = $linha["familyname"];
			$givenname = $linha["givenname"];
			$email = $linha["email"];
			$nome_evento = $linha["nome_evento"];
			echo "<tr>";
			echo "<td class='texto'><a href='vis_inscricoes.php?id_inscricoes=$id_inscricoes'>".$familyname.' '.$givenname."</a></td>";
			echo "<td class='texto'><a href='vis_inscricoes.php?id_inscricoes=$id_inscricoes'>".$email."</a></td>";
			echo "<td class='texto'><a href='vis_inscricoes.php?id_inscricoes=$id_inscricoes'>".substr ($nome_evento,0,60)."...</a></td>";
			echo "<td align='center'><a href='php/excluir_inscricoes.php?id_inscricoes=$id_inscricoes'><img src='img/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
			echo "</tr>";		
		}
		echo "</table>";
		echo "<span class='texto'>Mais registros</span>";
		echo "<br />";
		if($pagina > 0) {
			$menos = $pagina - 1;
			if($menos > 0){
				$url = "$PHP_SELF?pagina=$menos";
				echo "<a class=\"destaque\" href=\"$url\">&laquo;</a>"; // Vai para a p�gina anterior
			}
		}
		for($i=0;$i<$paginas;$i++) { // Gera um loop com o destaque para as p�ginas
			$url = "$PHP_SELF?pagina=$i";
			echo " | <a class=\"destaque\" href=\"$url\">$i</a>";
		}
		if($pagina < ($paginas - 1)) {
			$mais = $pagina + 1;
			$url = "$PHP_SELF?pagina=$mais";
			echo " | <a href=\"$url\">&raquo;</a>";
		}
}
?>