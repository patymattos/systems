<?php
session_start();
include ("php/valida_sessao.php");
include"php/config.php";
	$resultado = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
	$xx = mysql_fetch_array($resultado);
	$id_evento  = $xx['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<title>-= Meta Marketing e Eventos =-</title>
</head>
<body>

<?php include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><?php include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>
		 <form action="" method="post" name="form">
	 	  <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
	       <tr>
    	      <td align="center" bgcolor="#FFFFFF" colspan="2">
          	  </td>
	       </tr>
	       <tr>
      	  		<td align="center" class="titulo" colspan="3">:: Campo Obrigat�rio ::</td>
           </tr>
		   <tr>
 			  <td width="500" align="center"> 
			  </td>
             <td align="center">Excluir</td>
		   </tr>

		    <?php
			$sqlll	= mysql_query("SELECT * FROM campo_obrigatorio WHERE id_evento='$id_evento' ORDER BY id");
			//Se o tipo tiver sido selecionado e for diferente de texto e senha, ele mostrar� os resultados
			$i = 1;
			while($fetch = mysql_fetch_array($sqlll)){
			 $nome 				= $fetch['nome'];
			 $nome_campo_input	= $fetch['nome_campo_input'];
			 $id				= $fetch['id'];
				echo '<tr>
 			  		<td width="500">';
						if (($nome != "") and ($nome_campo_input == "")){
							echo 'Nome do Campo ' .$i.': <input type="text" name="nome" size="40" value="'.$nome.'"/><input type="hidden" name="id" size="2" value="'.$id.'"/><br />';
						}
						if ($nome_campo_input != ""){
							echo 'Nome do campo ' .$i.': <input type="text" name="nome_campo_input" size="40" value="'.$nome_campo_input.'"/><br />';
						}	
              		echo '</td>';
				
				  echo '</td>';
				  echo '<td align="center">';
   	 				 echo "<a href='php/excluir_campo_obrigatorio.php?id=$id'><img src='images/ico_excluir.jpg' border='0'/></a>";
				  echo '</td>';
           		echo '</tr>';
			$i++;
			}		
			?>
            </td>
		  </tr>
		</table>
        <input type="hidden" name="id" value="<?=$id_evento;?>" />
       </form>
      </td>
     </tr>
  <tr>
   <td>
   		<a href="javascript:history.go(-1)">Voltar</a>
   </td>
  </tr>
    </table>
   </td>
  </tr>
 </table> 
<? 
include_once "inc_rodape.php";
echo '</body>';
echo '</html>';

?>