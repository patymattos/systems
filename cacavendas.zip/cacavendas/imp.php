<html>
 <head>
  <title>Exibir dados com PHP/MySql</title>
 </head>
<body>

<h1>Exibir dados com PHP/MySql</h1>

<?php   
mysql_connect("localhost", "swcenter_autocen", "k0k9p8n7u6");   
mysql_select_db("swcenter_kakapneus");   
$sql = "SELECT PRD_DATA, PRD_REFERENCIA, PRD_NOME FROM produtos";   
$qr = mysql_query($sql);   
  
/*  
08. * Aqui iremos passar para row a linha atual a ser exibida,  
09. * por�m, quando o mysql_fetch_array retornar false  
10. * o while ser� encerrado.  
11. */  
echo "<table border:"1"><tr><td>Login</td><td>Nome do Usu�rio</td><td>Senha do Usu�rio</td></tr>";


while($row = mysql_fetch_array($qr)) {   
    //Exibe os dados da linha atual separados por -   
    echo "<tr><td>  " .$row['PRD_DATA']."</td><td> ".$row['PRD_REFERENCIA']." </td><td> ".$row['PRD_NOME']."</td></td> ";   
}   
echo "</table>"; 
?>   
</body>
</html>


