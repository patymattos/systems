<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	$FR_ID =$_POST['F_ID'];
	
	$FR_NOME =$_POST['F_NOME'];
	
	$FR_MARCA =$_POST['F_MARCA'];
  	
	$FR_END =$_POST['F_END'];
  	
	$FR_CIDADE =$_POST['F_CIDADE'];
	
	$FR_ESTADO =$_POST['F_ESTADO'];
	
	$FR_CEP =$_POST['F_CEP'];
	 	
	$FR_EMAIL =$_POST['F_EMAIL'];

	$FR_TEL =$_POST['F_TEL'];

	$FR_CEL =$_POST['F_CEL'];

	$FR_PRODUTO =$_POST['F_PROD'];
 	


	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO fonecedor (FOR_ID,FOR_NOME,FOR_MARCA,FOR_END,FOR_CIDADE,FOR_ESTADO,FOR_CEP,FOR_EMAIL,FOR_TEL,FOR_CEL,FOR_PRODUTO)
	VALUES ('$FR_ID','$FR_NOME','$FR_MARCA','$FR_END','$FR_CIDADE','$FR_ESTADO','$FR_CEP','$FR_EMAIL','$FR_TEL','$FR_CEL','$FR_PRODUTO')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_forn.php");



?>	

 