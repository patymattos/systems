<?php
session_start();
include"php/config.php";
$resultado 				= mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
$xx 					= mysql_fetch_array($resultado);
$id_evento  			= $xx['id'];
$tipo					= $_POST['tipo'];
$nome2					= $_POST['nome2'];
$linha					= $_POST['linha'];
$coluna					= $_POST['coluna'];
$titulo_tabela			= $_POST['titulo_tabela'];
$negrito_titulo			= $_POST['negrito_titulo'];
$alinhamento_titulo		= $_POST['alinhamento_titulo'];
$fonte_titulo			= $_POST['fonte_titulo'];
$tamanho_tabela			= $_POST['tamanho_tabela'];
$borda_tabela			= $_POST['borda_tabela'];
$cor_borda_tabela		= $_POST['cor_borda_tabela'];
$tamanho_fonte_titulo	= $_POST['tamanho_fonte_titulo'];
$cor_tabela				= $_POST['cor_tabela'];
$cor_cedula				= $_POST['cor_cedula'];
$cellpadding			= $_POST['cellpadding'];
$cellspacing			= $_POST['cellspacing'];

$k=1;
for($i=1;$i<=$linha;$i++){
	$j=1;
	$table1= "<tr>";
	while($j<=$coluna){
		$n="negrito".$i."colunas".$j."_linhas".$i;
		$negrito		= $_POST[$n];

		$r				= "real".$i."colunas".$j."_linhas".$i;
		$real			= $_POST[$r];

		$a				= "alinhamento".$i."colunas".$j."_linhas".$i;
		$alinhamento	= $_POST[$a];

		$chec			= "checkbox".$i."colunas".$j."_linhas".$i;
		$checkbox		= $_POST[$chec];

		$tf				= "tamanho_fonte".$i."colunas".$j."_linhas".$i;
		$tamanho_fonte	= $_POST[$tf];

		$tipof			= "tipo_fonte".$i."colunas".$j."_linhas".$i;
		$tipo_fonte		= $_POST[$tipof];

		$soma			= "somatorio".$i."colunas".$j."_linhas".$i;
		$somatorio		= $_POST[$soma];

		$l				= "colunas".$j."_linhas".$i;
		$linhas			= $_POST[$l];
	
		$cols			= "colspan".$i."colunas".$j."_linhas".$i;
		$colspan		= $_POST[$cols];
		if ($colspan != 0){
			$j	= $colspan;
		}
		if($checkbox == "sim"){
			$checkbox2 = "<input type=\'checkbox\' name=\'check".$k."\' value=\'".$linhas."\' onclick=\"checar()\"/>";
			$k++;
		}else{
			$checkbox2 = "";
		}	

		if(($negrito == "negrito") and ($somatorio == "nao")){
			$table2=$table2.'<td align=\"'.$alinhamento.'\" colspan=\"'.$colspan.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\";>'.$checkbox2.'<strong>'.$real.''.$linhas.'</strong></td>';

		}elseif(($negrito == "italico") and ($somatorio == "nao")){
			$table2=$table2.'<td align=\"'.$alinhamento.'\" colspan=\"'.$colspan.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\";>'.$checkbox2.'<i>'.$real.''.$linhas.'</i></td>';

		}elseif(($negrito == "negrito_italico") and ($somatorio == "nao")){
			$table2=$table2.'<td align=\"'.$alinhamento.'\" colspan=\"'.$colspan.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\";>'.$checkbox2.'<strong><i>'.$real.''.$linhas.'</i></strong></td>';

		}elseif(($negrito == " ") and ($somatorio == "nao")){
			$table2=$table2.'<td align=\"'.$alinhamento.'\" colspan=\"'.$colspan.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\";>'.$checkbox2.''.$real.' '.$linhas.'</td>';
		}

		if($somatorio == "sim"){
			$table2=$table2.'<td align=\"'.$alinhamento.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\";><input type="button" name=\"'.$linhas.'\" class="valor" size="5" /></td>';
		}	
			//echo 'coluna'.$i.' : '.$colunas.'<br>';
			//echo 'linha'.$j.' : '.$linhas.'<br>';
	$j= ($j+1);
	}
	$table1=$table1.$table2."</tr>";
	$table2="";
	//echo '<br><br>';
	$table=$table.$table1;
}
if($titulo_tabela != ""){	
	if($negrito_titulo == "negrito"){
		$table1='<table width=\"'.$tamanho_tabela.'\" border=\"'.$borda_tabela.'\" bordercolor=\"'.$cor_borda_tabela.'\" bgcolor=\"'.$cor_tabela.'\" cellpadding=\"'.$cellpadding.'\" cellspacing=\"'.$cellspacing.'\"><br>
		<tr><br>
		 <td colspan=\"'.$coluna.'\" align=\"'.$alinhamento_titulo.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\"; bgcolor=\"'.$cor_cedula.'\"><strong>'.$titulo_tabela.'</strong>
		 </td><br>
		</tr><br>';
	}else{
		$table1='<table width=\"'.$tamanho_tabela.'\" border=\"'.$borda_tabela.'\" bordercolor=\"'.$cor_borda_tabela.'\" bgcolor=\"'.$cor_tabela.'\" cellpadding=\"'.$cellpadding.'\" cellspacing=\"'.$cellspacing.'\"><br><br>
		<tr><br>
		 <td colspan=\"'.$coluna.'\" align=\"'.$alinhamento_titulo.'\" style=\"font-family:'.$tipo_fonte.'; font-size:'.$tamanho_fonte.'\"; bgcolor=\"'.$cor_cedula.'\">'.$titulo_tabela.'</td><br>
		</tr><br>';
	}
}else{
	$table1='<table width=\"'.$tamanho_tabela.'\" border=\"'.$borda_tabela.'\" bordercolor=\"'.$cor_borda_tabela.'\" bgcolor=\"'.$cor_tabela.'\" cellpadding=\"'.$cellpadding.'\" cellspacing=\"'.$cellspacing.'\">';
}		
$table=$table1.$table."</table>";
echo $table."<br>";
	/*
	echo "linha = ".$linha."<br>";
	echo "coluna = ".$coluna."<br>";
	echo "id_evento = ".$id_evento."<br>";
	echo "tipo = ".$tipo."<br>";
	echo "nome2 = ".$nome2."<br>";
	exit();*/
if($nome2 != ""){
	//$sql   	= mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo' AND nome='$nome2'");
	//$x 		= mysql_fetch_array($sql);
	//$campo	= $x['nome_campo']."/".$nome_input_mais;
	$insert	= mysql_query("UPDATE formulario SET  nome_campo='$table' where id_evento='$id_evento' and tipo='$tipo' and nome='$nome2'")or die(mysql_error());
}else{
	$insert	= mysql_query("INSERT INTO formulario(id_evento, tipo, nome, nome_campo) VALUES('$id_evento', '$tipo', '$nome2', '$table')");	
}
?>