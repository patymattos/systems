<?php

session_start();

include_once "php/valida_sessao.php";

include_once "php/config.php";



$dia_inicial	= $_POST['dia_ini'];

$mes_inicial	= $_POST['mes_ini'];

$ano_inicial	= $_POST['ano_ini'];



$dia_final 		= $_POST['dia_fim'];

$mes_final 		= $_POST['mes_fim'];

$ano_final 		= $_POST['ano_fim'];



$data_inicio = $ano_inicial."-".$mes_inicial."-".$dia_inicial;

$data_fim = $ano_final."-".$mes_final."-".$dia_final;



?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>-= KAKA PNEUS - SISTEMA ADMINISTRATIVO =-</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css">

<!--

.style1 {

	font-family: Arial, Helvetica, sans-serif;

	font-weight: bold;

	font-size: 24px;

}

.style2 {

	font-family: Arial, Helvetica, sans-serif;

	font-size: 14px;

}

.style13 {font-size: 13px}

.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }

.style4 {font-family: Arial, Helvetica, sans-serif}

.style10 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; }

-->

</style>

</head>



<body>

<span class="style1">PHAXECCO PNEUS - Despesas da Di&aacute;ria </span>

<hr>

<div align="left"></div>

<table width="784" border="0" align="left" bordercolor="#000000" bgcolor="#000000">

  <tr bgcolor="#333333">

    <td width="63"><div align="center"><span class="style13"><span class="style29">DATA</span></span></div></td>

    <td width="102"><div align="center"><span class="style13"><span class="style29">TIPO</span></span></div></td>

    <td width="93"><div align="center"><span class="style13"><span class="style29">MOTIVO</span></span></div></td>

    <td width="161"><div align="center"><span class="style13"><span class="style29">TOTAL</span></span></div></td>

    <td width="91"><div align="center"><span class="style13"><span class="style29">DINHEIRO</span></span></div></td>

    <td width="119"><div align="center"><span class="style13"><span class="style29">CART&Atilde;O</span></span></div></td>

    <td width="125"><div align="center"><span class="style13"><span class="style29">CHEQUE</span></span></div></td>

  </tr>

  <?php

	$select = "SELECT pg.*, fun.FUN_NOME FROM pagamentos pg, funcionario fun WHERE (pg.data >= '$data_inicio' AND pg.data <= '$data_fim') AND (fun.FUN_ID = pg.id_vendedor)";

	//echo $select."<br>";

	$query  = mysql_query($select);

	$rows = mysql_num_rows($query);

	//echo "<br>".$rows;

	while($x = mysql_fetch_array($query)){

		$valor_total_p = 0;

		//$valor_total_s = 0;

		if($x['formpagamento'] == "Cheque"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$cheque  = $valor_total_p;//+$valor_total_s;

		}

		elseif($x['formpagamento'] == "Dinheiro"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$dinheiro  = $valor_total_p;//+$valor_total_s;

		}

		elseif($x['formpagamento'] == "Master"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$master  = $valor_total_p;//+$valor_total_s;

		}

		elseif($x['formpagamento'] == "Visa"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$visa  = $valor_total_p;//+$valor_total_s;

		}

		elseif($x['formpagamento'] == "RedeShop"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$redshop  = $valor_total_p;//+$valor_total_s;

		}

		elseif($x['formpagamento'] == "Visa Eletron"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$visaeletron  = $valor_total_p;//+$valor_total_s;

		}

		elseif($x['formpagamento'] == "Outros"){

			$valor_p = explode("/",$x['valor_produto']);

			$cont 	 = count($valor_p);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_p = $valor_total_p+$valor_p[$i];

			}

			$valor_s = explode("/",$x['valor_servico']);

			$cont 	 = count($valor_s);

			for($i=0;$i<$cont-1;$i++){

				$valor_total_s = $valor_total_s+$valor_s[$i];

			}

			$outros  = $valor_total_p;//+$valor_total_s;

		}

		

		$prod 	= explode("/",$x['id_produtos']);

		$cont	= count($prod);

		for($i=0;$i<$cont-1;$i++){

			$select_nome_p 	= "SELECT PRD_NOME, PRD_MARCA, PRD_CUSTO FROM produtos WHERE PRD_ID = '$prod[$i]'";

			$query_nome_p	= mysql_query($select_nome_p);

			$z = mysql_fetch_array($query_nome_p);

			if($i==0){

				$produto_nome = $z['PRD_NOME'];

				$produto_marca = $z['PRD_MARCA'];

				$produto_custo = $z['PRD_CUSTO'];

			}

			

			else{

				$produto_nome .= "/".$z['PRD_NOME'];

				$produto_marca .= "/".$z['PRD_MARCA'];

				$produto_custo .= "/".$z['PRD_CUSTO'];

			}

			

		}

		$qtde_produtos = explode("/",$x['qtde_produtos']);

		$cont = count($qtde_produtos);

		for($i=0;$i<$cont-1;$i++){

			if($i==0){

				$qtde_p = $qtde_produtos[$i];

			}

			else{

				$qtde_p .= "/".$qtde_produtos[$i];

			}

		}

		$valor_p2 = explode("/",$x['valor_produto']);

		$cont2 	 = count($valor_p2);

		for($i=0;$i<$cont2-1;$i++){

			if(eregi("/",$produto_custo)){

				$custo = explode("/",$produto_custo);

				if($i == 0){

					$lucro = ($valor_p2[$i]-$custo[$i]);

					$custo_liquido = $custo[$i]; 

				}

				else{

					$lucro .= "/".($valor_p2[$i]-$custo[$i]);

					$custo_liquido = $custo_liquido+$custo[$i];

				}

			}

			else{

				$lucro = ($valor_p2[$i]-$custo[$i]);

				//echo "teste 3";

			}

		}

		$vp = explode("/",$x['valor_produto']);

		$cont3 = count($vp);

		for($i=0;$i<$cont3-1;$i++){

			if($i==0){

				$vp_v = $vp[$i];

				$bruto = $vp_v;

			}

			else{

				$vp_v .= "/".$vp[$i];

				$bruto = number_format($bruto+$vp[$i],2,',',''); 

			}

		}

		

		

		

		$liquido = number_format(($bruto-$custo_liquido),2,',','');

		$liquido_geral = number_format($liquido_geral+($bruto-$custo_liquido),2,',','');

		

  ?>

  <tr bgcolor="#FFFFFF">

    <td><?=$x['nota_vendedor']?></td>

    <td><?=$x['FUN_NOME']?></td>

    <td width="93"><?=$dinheiro?></td>

    <td width="161"><?=$master?></td>

    <td width="91"><?=$visa?></td>

    <td width="119"><?=$redeshop?></td>

    <td width="125"><?=$visaeletron?></td>

  </tr>

  <?

}

 ?>

</table>

<br>

<br>

<br>

<br>

<table width="782" border="0">

  <tr>

    <td width="313"><div align="left"><span class="style10">SOBROU EM ESPECIE - R$ 
        <?=$liquido_geral?>
    </span></div></td>

    <td width="218"><span class="style10">TOTAL VALE - R$
      
    </span></td>

    <td width="222"><span class="style10">TOTAL DESPESA - R$
        
    </span></td>

    <td width="11">&nbsp;</td>

  </tr>
</table>

</body>

</html>

