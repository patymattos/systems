<? 
session_start();
include_once "php/valida_sessao.php";
include_once "php/config.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style13 {font-size: 13px}
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
.style32 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; color: #FFFFFF; }
.style34 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; color: #000000; }
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="215" border="0" align="right">
      <tr>
        <td width="98"><img src="img/imprimir.jpg" width="30" height="30" /><span class="style10"> Or&ccedil;amento</span></td>
        <td width="107"><span class="style10"><img src="img/finalizar-pedido.gif" height="30" /></span></td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<table width="550" border="0" bordercolor="#333333" bgcolor="#FFFFFF">
  <tr>
    <td colspan="4" bgcolor="#000000"><span class="style12 style13"><span class="style32">: CLIENTE :: </span></span></td>
  </tr>
  <form name="frmBusca" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?a=buscar" >
  <tr>

    <td width="99"><span class="style13"><span class="style10">Telefone / Nome:</span></span></td>
    <td width="144"><input name="palavra" type="text" id="palavra" /></td>
    <td width="230"><img src="img/icone4.gif" width="24" height="22" onclick="document.forms[0].submit()"  style="cursor:pointer"/></td>
    <td width="59">&nbsp;</td>
  </tr>
</form>
<?
include_once "php/config.php";
 
// Recuperamos a a��o enviada pelo formul�rio
$a = $_GET['a'];
 
// Verificamos se a a��o � de busca
if ($a == "buscar") {
 
	// Pegamos a palavra
	$palavra = trim($_POST['palavra']);
 
	// Verificamos no banco de dados produtos equivalente a palavra digitada
	$sql = mysql_query("SELECT * FROM clientes WHERE CLI_TEL LIKE '%".$palavra."%' ORDER BY CLI_NOME");
 
	// Descobrimos o total de registros encontrados
	$numRegistros = mysql_num_rows($sql);
 


// Se houver pelo menos um registro, exibe-o
	if ($numRegistros != 0) {
		// Exibe os produtos e seus respectivos pre�os
		while ($produto = mysql_fetch_object($sql)) {
		?>
 	     <tr bgcolor="#FFFFFF">
        <td></td>
        <td colspan="2"><span class="style13"><span class="style10"> <? echo " Nome Completo: ".$produto->CLI_NOME. " Telefone: ".$produto->CLI_TEL;  ?> </span></span></td>
		<td><img src="img/add44.png" width="31" height="30" /></td>
		<?  
		}
	// Se n�o houver registros
	} else {?>
 	     <tr bgcolor="#FFFFFF">
        <td></td><td colspan="2"><? echo "Cliente n�o localizado. Para cadastrar clique no bot�o adicionar -->"; ?>
		<td><a href="cad_clientes.php" target="_blank"><img src="img/add44.png" width="31" height="30" border="0" /></a></td>
			<? }
}
?>       
  
  </tr>
</table>
<br>
<table width="550" border="0">
  <tr bordercolor="#000000" bgcolor="#000000">
    <td colspan="8"><span class="style12 style13"><span class="style32">:: PRODUTO :: </span></span></td>
  </tr>
   <form name="frmBusca2" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?b=buscar2" >

  <tr>
    <td width="79"><span class="style13"><span class="style10">Refer&ecirc;ncia:</span></span></td>
    <td width="152"><input name="palavra2" type="text" id="palavra2"></td>
    <td width="31"><img src="img/icone4.gif" width="24" height="22" onclick="document.frmBusca2.submit()"  style="cursor:pointer"/></td>
    <td width="126"><span class="style13">
      <select name="select3">
        <option selected="selected">---Vendedor---</option>
        <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='VENDEDOR'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FUN_NOME]'>".substr ($sql[FUN_NOME],0,50)."...</option>'";

				}

			?>
      </select>
    </span></td>
    <td width="38"><span class="style13"><span class="style10">Valor:</span></span></td>
    <td width="36"><span class="style13"><span class="style10">
      <input name="textfield32" type="text" size="5">
    </span></span></td>
    <td width="17"><span class="style13"><span class="style10">Qt:</span></span></td>
    <td width="37"><span class="style13"><span class="style10">
      <input name="textfield322" type="text" size="5">
    </span></span></td>
  </tr>
  </form>
<?
include_once "php/config.php";
 
// Recuperamos a a��o enviada pelo formul�rio
$b = $_GET['b'];
 
// Verificamos se a a��o � de busca
if ($b == "buscar2") {
 
	// Pegamos a palavra
	$palavra2 = trim($_POST['palavra2']);
 
	// Verificamos no banco de dados produtos equivalente a palavra digitada
	$sql = mysql_query("SELECT * FROM produtos WHERE PRD_REFERENCIA LIKE '%".$palavra2."%' ORDER BY PRD_DATA");
 
	// Descobrimos o total de registros encontrados
	$numRegistros = mysql_num_rows($sql);
 


// Se houver pelo menos um registro, exibe-o
	if ($numRegistros != 0) {
		// Exibe os produtos e seus respectivos pre�os
		while ($produto2 = mysql_fetch_object($sql)) {
		?>
 	     <tr bgcolor="#FFFFFF">
        <td></td>
        <td colspan="5"><span class="style13"><span class="style10"> <? echo "Refer�ncia: ".$produto2->PRD_REFERENCIA. " / Produto: ".$produto2->PRD_NOME. " / Qt: ".$produto2->PRD_QUANTIDADE;  ?> </span></span></td>
		<td colspan="2"><img src="img/add44.png" width="31" height="30" /></td>
		<?  
		}
	// Se n�o houver registros
	} else {?>
 	     <tr bgcolor="#FFFFFF">
        <td></td><td colspan="5"><? echo "Produto n�o localizado. Consulte o Estoque."; ?>
		<td colspan="2"><a href="cad_produtos.php" target="_blank"><img src="img/add44.png" width="31" height="30" border="0" /></a></td>
  		<? }
}
?>       


  </table>
<br>

<table width="550" border="0">
  <tr bordercolor="#000000" bgcolor="#000000">
    <td colspan="5"><span class="style12 style13"><span class="style32">:: SERVI&Ccedil;O :: </span></span></td>
  </tr>
  <tr>
    <td width="75"><span class="style13"><span class="style10">Servi&ccedil;o:</span></span></td>
    <td width="106"><select name="sv">
      <option selected="selected">---Servi&ccedil;o---</option>
      <?

				$resultado = mysql_query("SELECT DISTINCT SER_NOME FROM servicos ORDER BY SER_NOME ASC");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[SER_NOME]'>".substr ($sql[SER_NOME],0,50)."...</option>'";

				}

			?>
    </select></td>
    <td width="104"><div align="right"><span class="style13"><span class="style10">Valor:</span></span></div></td>
    <td width="184"><input name="textfield3" type="text" size="16"></td>
    <td width="59">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style13"><span class="style10">Funcion&aacute;rios</span></span>:</td>
    <td><span class="style13">
      <select name="fvendedor">
        <option selected="selected">---Vendedor---</option>
        <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='VENDEDOR'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FUN_NOME]'>".substr ($sql[FUN_NOME],0,50)."...</option>'";

				}

			?>
      </select>
    </span></td>
    <td><span class="style13">
      <select name="fmec" id="fmec">
        <option selected="selected">---Mec&acirc;nico---</option>
        <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='MEC&Acirc;NICO'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FU_NOME]'>".substr ($sql[FU_NOME],0,50)."...</option>'";

				}

			?>
      </select>
    </span></td>
    <td><span class="style13">
      <select name="fbor" id="fbor">
        <option selected="selected">---Borracheiro---</option>
        <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='BORRACHEIRO'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FU_NOME]'>".substr ($sql[FU_NOME],0,50)."...</option>'";

				}

			?>
      </select>
    </span></td>
    <td><img src="img/add44.png" width="31" height="30" /></td>
  </tr>
</table>
<br>
<br>
<table width="550" border="0">
  <tr>
    <td bgcolor="#FFFFFF"><span class="style12 style13"><span class="style34">:: INFORMA&Ccedil;&Otilde;ES GERAIS::<br>
      -----------------------------------------------------------------------------------------------------------------------------------------
    </span></span></td>
  </tr>
  <tr>
    <td><table width="550" border="0" align="center" bordercolor="#000000" bgcolor="#000000">
      <tr bgcolor="#333333">
        <td width="73"><span class="style13"><span class="style29">DATA</span></span></td>
        <td width="118"><span class="style13"><span class="style29">NOME</span></span></td>
        <td width="87"><span class="style13"><span class="style29">PRODUTO</span></span></td>
        <td width="45"><span class="style13"><span class="style29">QT.</span></span></td>
        <td width="80"><span class="style13"><span class="style29">SERVI&Ccedil;O</span></span></td>
        <td width="64"><span class="style13"><span class="style29">VALOR</span></span></td>
        <td width="53"><span class="style13"><span class="style29">TOTAL</span></span></td>
      </tr>
	  <?

		$sql = "SELECT * FROM vendas";   
		$qr = mysql_query($sql);   
		while($row = mysql_fetch_array($qr)) {   
		
		?>
     <tr bgcolor="#FFFFFF">
      <td><? echo $row['V_DATA']; ?></td>
      <td><? echo $row['V_NOME']; ?></td>
      <td><? echo $row['V_PRODUTO']; ?></td>
      <td><? echo $row['V_QUANTIDADE']; ?></td>
      <td><? echo $row['V_SERVICO']; ?></td>
      <td><? echo $row['V_VALOR']; ?></td>
      <td><? echo $row['V_TOTAL']; ?></td>

   </tr>
   <?
}
 ?>
    </table>
    <blockquote>&nbsp;</blockquote></td>
  </tr>
</table>
<br>
</body>
</html>
