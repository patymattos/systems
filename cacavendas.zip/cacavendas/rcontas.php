<?php

session_start();

include_once "php/valida_sessao.php";

include_once "php/config.php";



$dia_inicial	= $_POST['dia_ini'];

$mes_inicial	= $_POST['mes_ini'];

$ano_inicial	= $_POST['ano_ini'];



$dia_final 		= $_POST['dia_fim'];

$mes_final 		= $_POST['mes_fim'];

$ano_final 		= $_POST['ano_fim'];



$data_inicio = $ano_inicial."-".$mes_inicial."-".$dia_inicial;

$data_fim = $ano_final."-".$mes_final."-".$dia_final;



?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>-= KAKA PNEUS - SISTEMA ADMINISTRATIVO =-</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css">

<!--

.style1 {

	font-family: Arial, Helvetica, sans-serif;

	font-weight: bold;

	font-size: 24px;

}

.style2 {

	font-family: Arial, Helvetica, sans-serif;

	font-size: 14px;

}

.style13 {font-size: 13px}

.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }

.style4 {font-family: Arial, Helvetica, sans-serif}

.style10 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; }

-->

</style>

</head>



<body>

<span class="style1">PHAXECCO PNEUS - Relat&oacute;rio de Contas a Pagar </span>

<hr>

<div align="left"></div>

<table width="701" border="0" align="left" bordercolor="#000000" bgcolor="#000000">
  <tr bgcolor="#333333">
    <td width="78"><div align="left"><span class="style13"><span class="style29">DATA</span></span></div></td>
    <td width="61"><span class="style13"><span class="style29">REF.</span></span></td>
    <td width="131"><span class="style13"><span class="style29">NOME</span></span></td>
    <td width="70"><span class="style13"><span class="style29">VALOR</span></span></td>
    <td width="61"><span class="style13"><span class="style29">BANCO </span></span></td>
    <td width="71"><span class="style13"><span class="style29">N CHEQUE </span></span></td>
    <td width="76"><span class="style13"><span class="style29">STATUS </span></span></td>
    <td width="119"><span class="style13"><span class="style29">OBS</span></span></td>
  </tr>
  <?
		$sql = "SELECT * FROM contas WHERE CP_ATIVO = '1'";   

		$qr = mysql_query($sql);   

		while($row = mysql_fetch_array($qr)) {   

		?>
  <tr bgcolor="#FFFFFF">
    <td><? echo date('d/m/Y', strtotime( $row['CP_DATA'])); ?></td>
    <td><? echo $row['CP_REF']; ?></td>
    <td><? echo $row['CP_NOME']; ?></td>
    <td><? echo number_format($row['CP_VALOR'],2,",",".") ; ?></td>
    <td align="center"><? echo $row['CP_BANCO']; ?> </td>
    <td align="center"><? echo $row['CP_CHEQUE']; ?> </td>
    <td align="center"><? echo $row['CP_STATUS']; ?> </td>
    <td align="center"><? echo $row['CP_OBS']; ?> </td>
  </tr>
  <?

}
 ?>
</table>
</body>

</html>

