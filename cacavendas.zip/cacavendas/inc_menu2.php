<link rel="stylesheet" type="text/css" href="css/sddm.css" >

<br />

<div class="navbar">

<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem" >CONTROLE FINANCEIRO</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

         <div class="subItem"><a href="cad_controles.php">Lan�amentos</a></div>
        <div class="subItem"><a href="adm_relatorio.php">Relat�rios</a></div>
        
      
	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->

<br>
<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem"  >CADASTRAR</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

		<div class="subItem"><a href="adm_usuarios.php">Cadastro Discipulos</a></div>

		<div class="subItem"><a href="adm_usuarios_projetos.php">Escola de Lider</a></div>
		
		<div class="subItem"><a href="adm_usuarios_projetos.php">Criar Minist�rio</a></div>
		
		<div class="subItem"><a href="adm_usuarios_projetos.php">Criar C�lula</a></div>

	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->
<br>

<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem"  >SISTEMA</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

		<div class="subItem"><a href="adm_usuarios_projetos.php">Usu�rios Lider de Rede</a></div>

		<div class="subItem"><a href="php/sair.php">Sair</a></div>

	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->

<script type="text/javascript" src="js/xpmenuv21.js"></script>

</div>

<br />