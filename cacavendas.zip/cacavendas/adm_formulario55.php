<?php
session_start();
include"php/config.php";
$resultado 				= mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
$xx 					= mysql_fetch_array($resultado);
$tipo					= $_POST['tipo'];
$nome2					= $_POST['tipo2'];
$linha					= $_POST['linhas_tabela'];
$coluna					= $_POST['colunas_tabela'];
$id_evento  			= $xx['id'];
$nome_input				= $_POST['nome_input'];
$titulo_tabela			= $_POST['titulo_tabela'];
$negrito_titulo			= $_POST['negrito_titulo'];
$alinhamento_titulo		= $_POST['alinhamento_titulo'];
$fonte_titulo			= $_POST['fonte_titulo'];
$tamanho_fonte_titulo	= $_POST['tamanho_fonte_titulo'];
$tamanho_tabela			= $_POST['tamanho_tabela'];
$borda_tabela			= $_POST['borda_tabela'];
$cor_borda_tabela		= $_POST['cor_borda_tabela'];
$cor_tabela				= $_POST['cor_tabela'];
$cor_cedula				= $_POST['cor_cedula'];
$cellpadding			= $_POST['cellpadding'];
$cellspacing			= $_POST['cellspacing'];

if($nome_input != ""){
	$insert	= mysql_query("INSERT INTO formulario(id_evento, tipo, nome) VALUES('$id_evento', '$tipo', '$nome_input')");	
	header("location:adm_formulario2.php");
}else{

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<title>-= Meta Marketing e Eventos =-</title>
	<script type="text/javascript" src="js/funcoes.js"></script>
  <script language="javascript">
	function selecao() {
	  tipo=document.form.tipo.value;
	  if ((tipo == 'select') || (tipo == 'radio') || (tipo == 'checkbox') || (tipo == 'text') || (tipo == 'password')){
      location.href='adm_formulario2.php?tipo='+tipo;
	  }else
	  	if (tipo == 'tabela') {
		location.href='adm_formulario5.php?tipo='+tipo;
	  }	
    }
  </script>
  <script language="javascript">
	function selecao2() {
	  nome=document.form.tipo2.value;
	  selecao()
      location.href='adm_formulario5.php?tipo='+tipo+'&nome='+nome;
    }
  </script>    
</head>
<body>

<?php include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><?php include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>
		 <form action="adm_formulario555.php" method="post" name="form">
	 	  <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
	       <tr>
    	      <td align="center" bgcolor="#FFFFFF" colspan="2">
				<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" />
          	  </td>
	       </tr>
	       <tr>
              <?php
			  //se algum input tiver sido selecionado, ele aumentar� o tamanho da parte da tabela
				if($nome2!= ""){
    	          	echo '<td align="center" class="titulo" colspan="3">:: Alterar Participante ::</td>';
		     //sen�o houver nenhum, ele n�o altera o tamanho
				 }else{
          	  		echo '<td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>';
				 }	
				 ?>
           </tr>
		   <tr>
 			  <td width="296"> Escolha o tipo:</td>
	 		  <td width="505" align="center">
               <select name="tipo">
                <option value="tabela">Tabela</option>
			   </select>
			  </td>
              <?php
			    //se algum input tiver sido selecionado, ele mostrar� os campos para alterar e excluir
				if($nome2!= ""){
    	          echo '<td align="center">Excluir</td>';
				 }
			  ?> 
		   </tr>

		    <?php
		  	//se a verifica��o do tipo do select j� tiver sido escolhida ele verificar� se o nome do select j� foi escolhido tamb�m
 	  		if($nome2 != ""){
	  			$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo' AND nome='$nome2'");
				$x 	= mysql_fetch_array($sql);
				$nome3= $x['nome'];
	    		$num=mysql_num_rows($sql);
		    }else{  
		  		$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo'");	
	   	  	    $num2=mysql_num_rows($sql);
		  	}
			//Se o tipo tiver sido selecionado e for diferente de texto e senha, ele mostrar� os resultados
			if((($num2 != 0) or ($num != 0)) and ((($tipo != "text") and ($tipo != "password") and ($tipo != "")))){
			  echo '<tr>';
				echo '<td width="505">Select(s) j� criado(s):</td>';
                echo '<td  align="center"><select name="tipo2" onblur="selecao2()" onchange="selecao2()">';
					if($nome3!= ""){
   	 					echo '<option value="'.$nome3.'">'.$nome3.'';
					}else{  
						echo '<option value="">-= Selecione o tipo do campo =-</option>';
					}
					// faz um loop para pegar todos os atributos da array nome do select/radio/checkbox selecionado
					while ($fetch = mysql_fetch_array($sql)){
						$nome = $fetch['nome'];
		    			echo '<option value="'.$nome.'">'.$nome.'</option>';
					}
			    echo '</select>';
				//se o nome do input tiver sido selecionado, ele mostrar� os campos para editar e excluir
					if($nome3!= ""){
				echo '</td>';
				echo '<td align="center">';
   	 				echo "<a href='php/excluir_input.php?id=$nome3'><img src='images/ico_excluir.jpg' border='0'/></a>";
				echo '</td>';
					}else{
				echo '</td>';
				}					
			  echo '</tr>';


			}

	 		//se o resultado for diferente de zero, aparecer� o select com o nome desejado
			if(($num != 0)and (($tipo != "text") and ($tipo != "password"))){

			  echo '<tr>';
				echo '<td valign="top" width="10%" colspan="3">Quais ser�o os nomes dos campos das Linha?</td>';
			 echo '</tr>';	
			 echo '<tr>';
				echo '<td colspan="3">';
				for($j=1;$j<=$coluna;$j++){
				  for($i=1;$i<=$linha;$i++){
					echo ' <strong>Coluna'.$j.': Linha'.$i.':</strong><br>';
					echo ' Nome do campo: <input type="text" name="colunas'.$j.'_linhas'.$i.'" size="15" style="margin:2px 0 0 60px;"/><br>';
					echo ' Tipo de Fonte: <input type="text" name="tipo_fonte'.$i.'colunas'.$j.'_linhas'.$i.'" value="verdana" size="15" style="margin:2px 0 0 75px;"><br>';
					echo ' Tamanho da Fonte: <input type="text" name="tamanho_fonte'.$i.'colunas'.$j.'_linhas'.$i.'" value="10" size="3" style="margin:2px 0 0 43px;"><br>';
					echo 'Acrescentar: <select name="real'.$i.'colunas'.$j.'_linhas'.$i.'" style="margin:2px 0 0 87px;">';
						echo '<option value=" ">-= =-</option>';
						echo '<option value="R$">R$</option>';
					echo '</select><br>';
					echo 'Estilo da Fonte: <select name="negrito'.$i.'colunas'.$j.'_linhas'.$i.'" style="margin:2px 0 0 67px;">';
						echo '<option value=" ">Normal</option>';
						echo '<option value="negrito">Negrito</option>';
						echo '<option value="italico">It�lico</option>';
						echo '<option value="negrito_italico">Negrito / It�lico</option>';
					echo '</select><br>';
					echo 'Alinhamento: <select name="alinhamento'.$i.'colunas'.$j.'_linhas'.$i.'" style="margin:2px 0 0 83px;">';
						echo '<option value="left">Esquerda</option>';
						echo '<option value="center">Centro</option>';
						echo '<option value="right">Direita</option>';
					echo '</select><br>';
					echo 'Checkbox:<select name="checkbox'.$i.'colunas'.$j.'_linhas'.$i.'" style="margin:2px 0 0 105px;">';
						echo '<option value="nao">N�o</option>';
						echo '<option value="sim">Sim</option>';
					echo '</select><br>';
					echo 'Somat�rio:<select name="somatorio'.$i.'colunas'.$j.'_linhas'.$i.'" style="margin:2px 0 0 102px;">';
						echo '<option value="nao">N�o</option>';
						echo '<option value="sim">Sim</option>';
					echo '</select><br>';
					echo 'Colspan:<select name="colspan'.$i.'colunas'.$j.'_linhas'.$i.'" style="margin:2px 0 0 115px;">';
					echo '<option value="0">0</option>';
					for($m=1;$m<=$coluna;$m++){
						echo '<option value="'.$m.'">'.$m.'</option>';
					}	
					echo '</select><br>';
					echo '<br><br><br>';
				  }	echo '<br><br>';
				}  
				  echo '</td>';

			  echo '</tr>';
		    }

		    if(($nome2 == "") and (($tipo != "text") and ($tipo != "password")) and ($tipo != "")){
				echo '<tr>';
				 echo '<td width="505">Escreva o nome do novo campo:</td>';
				 echo '<td><input type="text" name="nome_input" /> </td>';
				echo '</tr>';
		   }
		  ?>
		</table>
        <input type="hidden" name="tipo" value="<?=$tipo;?>" />
        <input type="hidden" name="nome2" value="<?=$nome2;?>" />
        <input type="hidden" name="linha" value="<?=$linha;?>" />
        <input type="hidden" name="coluna" value="<?=$coluna;?>" />	
        <input type="hidden" name="titulo_tabela" value="<?=$titulo_tabela;?>" />
        <input type="hidden" name="alinhamento_titulo" value="<?=$alinhamento_titulo;?>" />
        <input type="hidden" name="negrito_titulo" value="<?=$negrito_titulo;?>" />
        <input type="hidden" name="cor_tabela" value="<?=$cor_tabela;?>" />
        <input type="hidden" name="cor_borda_tabela" value="<?=$cor_borda_tabela;?>" />
        <input type="hidden" name="borda_tabela" value="<?=$borda_tabela;?>" />
        <input type="hidden" name="tamanho_tabela" value="<?=$tamanho_tabela;?>" />
        <input type="hidden" name="fonte_titulo" value="<?=$fonte_titulo;?>" />
        <input type="hidden" name="tamanho_fonte_titulo" value="<?=$tamanho_fonte_titulo;?>" />
        <input type="hidden" name="cor_cedula" value="<?=$cor_cedula;?>" />
        <input type="hidden" name="cellspacing" value="<?=$cellspacing;?>" />
        <input type="hidden" name="cellpadding" value="<?=$cellpadding;?>" />
       </form>
      </td>
     </tr>
  <tr>
   <td>
   		<a href="javascript:history.go(-1)">Voltar</a>
   </td>
  </tr>
    </table>
   </td>
  </tr>
 </table> 
<? 
include_once "inc_rodape.php";
echo '</body>';
echo '</html>';
}
?>