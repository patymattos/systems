<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

  </head>
  <body>
  <div id="box2" style="width: 800px; float:right;">
  <?php
   @include ("verifica.php");
   @include "php/config.php";
   $id = $_GET['id'];
   $mode = $_GET['mode'];
   $query = mysql_query("UPDATE noticias SET ativo = '$mode' WHERE id = '$id'") or die(mysql_error());
   $excluir = $_GET['excluir'];
   if($excluir=="sim"){
     $delete = mysql_query("DELETE FROM noticias WHERE id = '$id'") or die(mysql_error());
   }
	  $sql=mysql_query("SELECT * from noticias WHERE ativo = '0' ORDER BY id ASC");
	  $num_rows = mysql_num_rows($sql);
	  if ($num_rows > 0){
	  $i=1;
	  while ($i <= $num_rows){
       $x = mysql_fetch_array($sql);
       $cod = $x["id"];
	   $noticias = $x["noticias"];
	   $ativo = $x["ativo"];
      ?>
  <form action="alterarnot.php" method="post">
   <fieldset>
     <legend>Sistema de Not�cias Inativas</legend>
       <dt><label for=nome><?php echo $cod;?></label></dt>
	   <dd><textarea name="noticias" cols="40" rows="5"><?php echo $noticias; ?></textarea></dd>
	  <?php echo ($ativo) ? "<a href='?mode=0&id=".$cod."'><img src='../../imagem/close.gif' border='0'> Desativar</a>" : "<a href='?mode=1&id=".$cod."'><img src='../../imagem/teste.gif' border='0' width='26' height='26'> Ativar</a>&nbsp;&nbsp;";
	   echo ($ativo) ? "<a href='?excluir=nao&id=".$cod."'><img src='../../imagem/close.gif' border='0'> N�o Excluir</a>" : "<a href='?excluir=sim&id=".$cod."'><img src='../../imagem/close.gif' border='0' width='26' height='26'> excluir</a>&nbsp;&nbsp;";
      echo ('<input type="hidden" name="id" value="'.$cod.'"/>');
	   ?>
	   <input type='submit' value='Alterar'>
	   <br>
	   <br>

     </fieldset>
   </form>
<?php
	  $i++; 
      }
	  }elseif ($num_rows == 0){
	    echo "N�o h� not�cias inativas";
	  }
	  ?>   
</div>
  <div id="box1" style="width: 170px;">
    <fieldset>
     <legend>Menu</legend>
       <a href="noticiasativas.php">Not�cias Ativas</a><br>
       <a href="noticiasinativas.php">Not�cias Inativas</a><br>       
       <a href="incluirnot.php">Nova Not�cias</a> 
    </fieldset>
  </div>  
</div>
 </body>
</html>