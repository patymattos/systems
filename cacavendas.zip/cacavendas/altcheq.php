<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
-->
</style>
<form name="alterarcli" action="alt_cheques.php" method="post">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td colspan="2"><table width="396" border="0" align="right">
                <tr>
                  
                </tr>
              </table></td>
            </tr>
            <tr>
              <td width="115"><span class="style4">Data:</span></td>
              <td width="415"><input name="Q_DATA" <?=$CQ_DATA?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Nome: </span></td>
              <td><input name="Q_NOME" <?=$CQ_NOME?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">N�mero:</span></td>
              <td><input name="Q_NUM" <?=$CQ_NUM?> type="text" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">Valor:</span></td>
              <td><input name="Q_VALOR" <?=$CQ_VALOR?> type="text" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">Destino:</span></td>
              <td><input name="Q_DES" <?=$CQ_DES?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Data de Troca:</span></td>
              <td><input name="Q_DT" <?=$CQ_DT?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Descri��o:</span></td>
              <td><input name="Q_DESC" <?=$CQ_DESC?> type="text" size="65" /></td>
            </tr>
                       <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br><input type="hidden" name="id_produto" value="<?=$cli?>">

                                  <input name="enviar" type="image" img src="images/ico_salvar.jpg" value="enviar" border="0">

                      </div></td>

                    </tr>

  </table>
</form>
</body>
</html>