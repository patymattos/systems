<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          
         
		   //validar C_ID
           if (d.CO_DATA.value == ""){
                     alert("Informe  a data da conta.");
                     d.CO_DATA.focus();
                     return false;
           }
		    if (d.CO_REF.value == ""){
                     alert("Informe a refer�ncia da conta.");
                     d.CO_REF.focus();
                     return false;
           }
                
					  if (d.CO_NOME.value == ""){
                     alert("Informe o nome da conta.");
                     d.CO_NOME.focus();
                     return false;
           }
         
		 //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.FU_TEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_TEL.focus();
                   return false;
         }
         
		 if (isNaN(d.FU_CEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_CEL.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvarcontas.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td width="115"><span class="style4">Data:</span></td>
              <td width="415"><input name="CO_DATA" type="text" id="CO_DATA" size="40" /> <span class="style4">(yyyy-mm-aa)</span></td>
            </tr>
            <tr>
              <td><span class="style4">Refer&ecirc;ncia:</span></td>
              <td><input name="CO_REF" type="text" id="CO_REF" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Nome: </span></td>
              <td><input name="CO_NOME" type="text" id="CO_NOME" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Valor:</span></td>
              <td><input name="CO_VALOR" type="text" id="CO_VALOR" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Banco:</span></td>
              <td><input name="CO_BANCO" type="text" id="CO_BANCO" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">N&ordm; do Cheque:</span></td>
              <td><input name="CO_CHEQUE" type="text" id="CO_CHEQUE" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Status:</span></td>
              <td><input name="CO_STATUS" type="text" id="CO_STATUS" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Observa&ccedil;&atilde;o:</span></td>
              <td><input name="CO_OBS" type="text" id="CO_OBS" size="40" /></td>
            </tr>
            <tr>
              <td colspan="2"><div align="center">
                <br>
                <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
              </div></td>
            </tr>
  </table>
</form>
</body>
</html>