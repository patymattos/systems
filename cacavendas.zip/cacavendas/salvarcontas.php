<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	
	$CT_DATA =$_POST['CO_DATA'];

	$CT_REF =$_POST['CO_REF'];
	
	$CT_NOME =$_POST['CO_NOME'];
	
	$CT_VALOR =$_POST['CO_VALOR'];
	
	$CT_BANCO =$_POST['CO_BANCO'];
	
	$CT_CHEQUE =$_POST['CO_CHEQUE'];
	
	$CT_STATUS =$_POST['CO_STATUS'];

	$CT_OBS =$_POST['CO_OBS'];



	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO contas (CP_ID,CP_DATA,CP_REF,CP_NOME,CP_VALOR,CP_BANCO,CP_CHEQUE,CP_STATUS,CP_OBS)
	VALUES ('','$CT_DATA','$CT_REF','$CT_NOME','$CT_VALOR','$CT_BANCO','$CT_CHEQUE','$CT_STATUS','$CT_OBS')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_contas.php");



?>	

 