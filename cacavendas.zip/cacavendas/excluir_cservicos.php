<?php

include_once "php/config.php";

$id_serv = $_GET['ex'];



$sql	= "UPDATE comissao SET CM_ATIVO = '0' WHERE CM_ID = '$id_serv'";

$resultado = mysql_query($sql);



echo "<script>location.href='cad_cmservicos.php';</script>";

?>