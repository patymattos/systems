<html>

<style type="text/css">

<!--

.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }

.style11 {font-family: Arial, Helvetica, sans-serif}

.style12 {font-size: 14px}

-->

</style>

<form name="alteracs" action="alt_despesas.php" method="post" enctype="multipart/form-data">

          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">

            <tr>

              <td width="115"><span class="style4">Tipo: </span></td>

              <td width="415"><input name="D_TIPO" type="text" <?=$DS_TIPO?> size="26" /></td>

            </tr>

            <tr>

              <td><span class="style4">Data:</span></td>

              <td><input name="D_DATA" type="text" <?=$DS_DATA?> size="26" /></td>
            </tr>

            <tr>

              <td><span class="style4">Motivo:</span></td>

              <td><input name="D_MOTIVO" type="text" <?=$DS_MOTIVO?> size="26" /></td>

            </tr>
            <tr>
              <td><span class="style4">Valor:</span></td>
              <td><input name="D_VALOR" type="text" <?=$DS_VALOR?> size="26" /></td>
            </tr>
            <tr>
              <td><span class="style4">Dinheiro:</span></td>
              <td><input name="D_DIM" type="text" id="D_DIM" size="26" <?=$DS_DIM?> />
                  <span class="style4">Nenhum pagamento = 0</span> </td>
            </tr>

            <tr>
              <td><span class="style4">Cheque:</span></td>
              <td><input name="D_CHEQ" type="text" id="D_CHEQ" size="26" <?=$DS_CHEQ?> />
              <span class="style4">Nenhum pagamento = 0</span> </td>
            </tr>

                    <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br>

                                  <input type="hidden" name="id_serv" value="<?=$des?>"><input name="enviar" type="image" img src="servi&#231;os/images/ico_cadastrar.jpg" value="enviar" border="0">

                      </div></td>

                    </tr>

  </table>

</form>

</body>

</html>