<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
-->
</style>
<form name="alterarfor" action="alt_fornecedor.php" method="post">
          <table width="564" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td colspan="2"><table width="396" border="0" align="right">
                <tr>
                  
                </tr>
              </table></td>
            </tr>
            <tr>
              <td width="154"><span class="style4">C&oacute;digo:</span></td>
              <td width="390"><input name="F_COD" <?=$FR_COD?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Nome/Raz&atilde;o social: </span></td>
              <td><input name="F_NOME" <?=$FR_NOME?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">CPF/CNPJ:</span></td>
              <td><input name="F_CC" type="text" id="F_CC" size="65" <?=$FR_CC?>></td>
            </tr>
            <tr>
              <td><span class="style4">Marca:</span></td>
              <td><input name="F_MARCA" type="text" id="F_MARCA" size="65" <?=$FR_MARCA?>></td>
            </tr>
            <tr>
              <td><span class="style4">Endere&ccedil;o:</span></td>
              <td><input name="F_END" type="text" id="F_END" size="65" <?=$FR_END?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Cidade:</span></td>
              <td><input name="F_CIDADE" type="text" id="F_CIDADE" size="65" <?=$FR_CIDADE?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Estado:</span></td>
              <td><input name="F_ESTADO" type="text" id="F_ESTADO" size="65" <?=$FR_ESTADO?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Cep:</span></td>
              <td><input name="F_CEP" type="text" id="F_CEP" size="65" <?=$FR_CEP?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Email:</span></td>
              <td><input name="F_EMAIL" type="text" id="F_EMAIL" size="65" <?=$FR_EMAIL?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Telefone:</span></td>
              <td><input name="F_TEL" type="text" id="F_TEL" size="65" <?=$FR_TEL?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Celular:</span></td>
              <td><input name="F_CEL" type="text" id="F_CEL" size="65" <?=$FR_CEL?> /></td>
            </tr>
                       <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br><input type="hidden" name="id_produto" value="<?=$for?>">

                                  <input name="enviar" type="image" img src="images/ico_salvar.jpg" value="enviar" border="0">

                      </div></td>

                    </tr>
  </table>
</form>
</body>
</html>