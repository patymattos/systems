<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style13 {font-size: 13px}
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="234" border="0" align="right">
      <tr>
        <td width="139"><img src="img/contas.png" width="30" height="30"> <span class="style10">Todas as Contas</span></td>
        <td width="85"><img src="img/imprimir.jpg" width="30" height="30" /><span class="style10"> Imprimir </span></td>
        </tr>
    </table></td>
  </tr>
</table>
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="550" border="0">
      <tr>
        <td width="516" colspan="8"><span class="style13"></span>          <div align="left">
              <br>
              <table width="497" border="0" align="left">
                <tr>
                  <td width="477" colspan="2" align="center" bgcolor="#FFFFFF">
                    <div align="left"><strong><span class="style3">Periodo </span><span class="style4">
                      <input name="textfield4" type="text" size="2" />
        / </span><span class="style4">
        <input name="textfield5" type="text" size="2" />
        </span><span class="style4"> /
        <input name="textfield6" type="text" size="4" />
        </span> -- <span class="style4">
        <input name="textfield42" type="text" size="2" />
        / </span><span class="style4">
        <input name="textfield52" type="text" size="2" />
        </span><span class="style4"> /
        <input name="textfield62" type="text" size="4" />
        </span>
        <input name="OK" type="submit" id="OK" value="Enviar" />
        <br />
                    </strong></div></td>
                </tr>
              </table>
              <p>&nbsp;</p>
              <table width="550" border="0" align="center" bordercolor="#000000" bgcolor="#000000">
                <tr bgcolor="#333333">
                  <td width="62"><span class="style13"><span class="style29">DATA</span></span></td>
                  <td width="70"><span class="style13"><span class="style29">REFER&Ecirc;NCIA</span></span></td>
                  <td width="81"><span class="style13"><span class="style29">NOME</span></span></td>
                  <td width="42"><span class="style13"><span class="style29">VALOR</span></span></td>
                  <td width="41"><span class="style13"><span class="style29">BANCO</span></span></td>
                  <td width="69"><span class="style13"><span class="style29">N&ordm; CHEQUE</span></span></td>
                  <td width="62"><span class="style13"><span class="style29">OBS.</span></span></td>
                  <td width="51"><span class="style13"><span class="style29">STATUS</span></span></td>
                </tr>
				<?

		$sql = "SELECT * FROM contas";   
		$qr = mysql_query($sql);   
		while($row = mysql_fetch_array($qr)) {   
		
		?>
    <tr bgcolor="#FFFFFF">
      <td><? echo $row['CP_DATA']; ?></td>
      <td><? echo $row['CP_REF']; ?></td>
      <td><? echo $row['CP_NOME']; ?></td>
      <td><? echo $row['CP_VALOR']; ?></td>
      <td><? echo $row['CP_BANCO']; ?></td>
      <td><? echo $row['CP_CHEQUE']; ?></td>
      <td><? echo $row['CP_OBS']; ?></td><br>
      <td><? echo $row['CP_STATUS']; ?></td>


   </tr>
   <?
}
 ?>
              </table>
              </div>
          <div align="center"></div>
          <div align="center"></div></td>
        </tr>
    </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>
