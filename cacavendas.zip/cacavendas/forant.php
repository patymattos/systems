<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          
         
		   //validar C_ID
           if (d.F_NOME.value == ""){
                     alert("Informe  o c�digo para o cliente.");
                     d.F_NOME.focus();
                     return false;
           }
                
         
		 //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.C_TEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.C_TEL.focus();
                   return false;
         }
         
		 if (isNaN(d.C_CEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.C_CEL.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvarforn.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td colspan="2"><table width="396" border="0" align="right">
                <tr>
                  <td><input name="textfield11" type="text" size="60" /></td>
                  <td><img src="img/icone4.gif" width="24" height="22" /></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td width="115"><span class="style4">Nome Completo: </span></td>
              <td width="415"><input name="F_NOME" type="text" id="F_NOME" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">CPF/CNPJ:</span></td>
              <td><input name="F_CC" type="text" id="F_CC" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">RG:</span></td>
              <td><input name="F_RG" type="text" id="F_RG" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">Endere&ccedil;o:</span></td>
              <td><input name="F_END" type="text" id="F_END" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Cidade:</span></td>
              <td><input name="F_CIDADE" type="text" id="F_CIDADE" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Estado:</span></td>
              <td><input name="F_ESTADO" type="text" id="F_ESTADO" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Cep:</span></td>
              <td><input name="C_CEP" type="text" id="C_CEP" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Email:</span></td>
              <td><input name="C_EMAIL" type="text" id="C_EMAIL" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Telefone:</span></td>
              <td><input name="C_TEL" type="text" id="C_TEL" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Celular:</span></td>
              <td><input name="C_CEL" type="text" id="C_CEL" size="65" /></td>
            </tr>
                    <tr> 
                              <td colspan="2">                                <div align="center">
                                  <br>
                                  <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
                      </div></td>
                    </tr>
  </table>
</form>
</body>
</html>