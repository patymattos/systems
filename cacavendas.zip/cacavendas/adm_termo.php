<?
session_start();
include ("php/valida_sessao.php");
include ("php/config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
<script type="text/javascript" src="js/funcoes.js"></script>
<script type="text/javascript" src="js/fckeditor.js"></script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

</head>


<body>
<? include_once "inc_topo.php";

$eventos = $_POST['eventos'];

 ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578">
	<form action="adm_termo2.php" method="post" enctype="multipart/form-data" name="frm" id="frm">
	<table width="570" border="0" align="center">
      <tr>
        <td>Selecione o Evento para modificar o Termo de Compromisso:</td>
      </tr>
	  <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF">
			<select name="eventos">
          <option selected="selected">---Escolha um Evento---</option>
          <?
		
		
		$resultado = mysql_query("SELECT * FROM eventos WHERE ativo = '1' ORDER BY nome_evento ASC");
		while($sql = mysql_fetch_array($resultado))
		{
		echo "<option value='$sql[nome_evento]'>".substr ($sql[nome_evento],0,50)."...</option>'";
		}
		
		?>
        </select>        </td>
      </tr>
      <tr>
      	<td><input name="OK" type="submit"  value="OK"/></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
	</form>
	</td>
  </tr>
</table>
<? include_once "inc_rodape.php"; ?>
</body>
</html>
