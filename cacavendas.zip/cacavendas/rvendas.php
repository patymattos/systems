<?php
session_start();
include_once "php/valida_sessao.php";
include_once "php/config.php";

$dia_inicial	= $_POST['dia_ini'];
$mes_inicial	= $_POST['mes_ini'];
$ano_inicial	= $_POST['ano_ini'];

$dia_final 		= $_POST['dia_fim'];
$mes_final 		= $_POST['mes_fim'];
$ano_final 		= $_POST['ano_fim'];

$data_inicio = $ano_inicial."-".$mes_inicial."-".$dia_inicial;
$data_fim = $ano_final."-".$mes_final."-".$dia_final;

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
}
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.style13 {font-size: 13px}
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
.style4 {font-family: Arial, Helvetica, sans-serif}
.style10 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; }
-->
</style>
</head>

<body>
<span class="style1">PHAXECCO PNEUS - Relat&oacute;rio de Venda </span>
<hr>
<div align="left"></div>
<table width="1000" border="0" align="left" bordercolor="#000000" bgcolor="#000000">
  <tr bgcolor="#333333">
    <td width="55"><div align="center"><span class="style13"><span class="style29">N&ordm; NOTA</span></span></div></td>
    <td width="75"><div align="center"><span class="style13"><span class="style29">VENDEDOR</span></span></div></td>
    <td width="64"><div align="center"><span class="style13"><span class="style29">DINHEIRO</span></span></div></td>
    <td width="64"><div align="center"><span class="style13"><span class="style29">MASTER</span></span></div></td>
    <td width="39"><div align="center"><span class="style13"><span class="style29">VISA</span></span></div></td>
    <td width="70"><div align="center"><span class="style13"><span class="style29">REDSHOP</span></span></div></td>
    <td width="97"><div align="center"><span class="style13"><span class="style29">VISA ELETRON </span></span></div></td>
    <td width="60"><div align="center"><span class="style13"><span class="style29">CHEQUE</span></span></div></td>
    <td width="60"><div align="center"><span class="style13"><span class="style29">OUTROS</span></span></div></td>
    <td width="60"><div align="center"><span class="style13"><span class="style29">SERVI&Ccedil;OS</span></span></div></td>
    <td width="60"><div align="center"><span class="style13"><span class="style29">VALOR</span></span></div></td>
    <td width="54"><div align="center"><span class="style13"><span class="style29">CUSTO</span></span></div></td>
    <td width="79"><div align="center"><span class="style13"><span class="style29">LUCRO</span></span></div></td>
    <td width="49"><div align="center"><span class="style13"><span class="style29">PNEUS</span></span></div></td>
    <td width="16"><div align="center"><span class="style13"><span class="style29">M</span></span></div></td>
    <td width="17"><div align="center"><span class="style13"><span class="style29">Q</span></span></div></td>
    <td width="54"><div align="center"><span class="style13"><span class="style29">VALOR</span></span></div></td>
    <td width="54"><div align="center"><span class="style13"><span class="style29">CUSTO</span></span></div></td>
    <td width="79"><div align="center"><span class="style13"><span class="style29">LUCRO</span></span></div></td>
    <td width="76"><div align="center"><span class="style13"><span class="style29">BRUTO</span></span></div></td>
    <td width="65"><div align="center"><span class="style13"><span class="style29">L&Iacute;QUIDO</span></span></div></td>
  </tr>
  <?php
	$select = "SELECT pg.*, fun.FUN_NOME FROM pagamentos pg, funcionario fun WHERE (pg.data >= '$data_inicio' AND pg.data <= '$data_fim') AND (fun.FUN_ID = pg.id_vendedor)";
	//echo $select."<br>";
	$query  = mysql_query($select);
	$rows = mysql_num_rows($query);
	//echo "<br>".$rows;
	while($x = mysql_fetch_array($query)){
	    $dinheiro_total 	= 0; 
    	$master_total 		= 0;
    	$visa_total			= 0;
    	$redeshop_total		= 0;
    	$visaeletron_total	= 0;
    	$cheque_total		= 0;
    	$outros_total		= 0;
		$valor_total_p = 0;
		//$valor_total_s = 0;
		if($x['formpagamento'] == "Cheque"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$cheque  = $valor_total_p;//+$valor_total_s;
			$cheuque2= $valor_total_s;
			$cheque_total = $cheque+$valor_total_s;
		}
		elseif($x['formpagamento'] == "Dinheiro"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$dinheiro  = $valor_total_p;//+$valor_total_s;
			$dinheiro2  = $valor_total_s;
			$dinheiro_total = $dinheiro+$valor_total_s;
		}
		elseif($x['formpagamento'] == "Master"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$master  = $valor_total_p;//+$valor_total_s;
			$master2  = $valor_total_s;
			//if($x['taxa_cartao'] != ""){
				//$master_total = ($master+$valor_total_s)-((($master+$valor_total_s)*$x['taxa_cartao'])/100);
			//}
			//else{
				$master_total = $master+$valor_total_s;
			//}
		}
		elseif($x['formpagamento'] == "Visa"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$visa  = $valor_total_p;//+$valor_total_s;
			$visa2  = $valor_total_s;
			//if($x['taxa_cartao'] != ""){
				//$visa_total = ($visa+$valor_total_s)-((($visa+$valor_total_s)*$x['taxa_cartao'])/100);
			//}
			//else{
				$visa_total = $visa+$valor_total_s;
			//}
		}
		elseif($x['formpagamento'] == "RedeShop"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$redeshop  = $valor_total_p;//+$valor_total_s;
			$redeshop2  = $valor_total_s;
			$redeshop_total = $redeshop+$valor_total_s;
		}
		elseif($x['formpagamento'] == "Visa Eletron"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$visaeletron  = $valor_total_p;//+$valor_total_s;
			$visaeletron2  = $valor_total_s;
			$visaeletron_total = $visaeletron+$valor_total_s;
		}
		elseif($x['formpagamento'] == "Outros"){
			$valor_p = explode("/",$x['valor_produto']);
			$cont 	 = count($valor_p);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_p = $valor_total_p+$valor_p[$i];
			}
			$valor_s = explode("/",$x['valor_servico']);
			$cont 	 = count($valor_s);
			for($i=0;$i<$cont-1;$i++){
				$valor_total_s = $valor_total_s+$valor_s[$i];
			}
			$outros  = $valor_total_p;//+$valor_total_s;
			$outros2  = $valor_total_s;
			$outros_total = $outros+$valor_total_s;
		}
################################################################################################		
		$prod 	= explode("/",$x['id_produtos']);
		$cont	= count($prod);
		for($i=0;$i<$cont-1;$i++){
			$select_nome_p 	= "SELECT PRD_NOME, PRD_MARCA, PRD_CUSTO FROM produtos WHERE PRD_ID = '$prod[$i]'";
			$query_nome_p	= mysql_query($select_nome_p);
			$z = mysql_fetch_array($query_nome_p);
			if($i==0){
				$produto_nome = $z['PRD_NOME'];
				$produto_marca = $z['PRD_MARCA'];
				$produto_custo = $z['PRD_CUSTO'];
			}
			
			else{
				$produto_nome .= "/".$z['PRD_NOME'];
				$produto_marca .= "/".$z['PRD_MARCA'];
				$produto_custo .= "/".$z['PRD_CUSTO'];
			}
			if($produto_nome == "/"){$produto_nome="";}
			if($produto_marca == "/"){$produto_marca="";}
			if($produto_custo == "/"){$produto_custo="";}
			
		}
		
		$qtde_produtos = explode("/",$x['qtde_produtos']);
		$cont = count($qtde_produtos);
		for($i=0;$i<$cont-1;$i++){
			if($i==0){
				$qtde_p = $qtde_produtos[$i];
			}
			else{
				$qtde_p .= "/".$qtde_produtos[$i];
			}
		}
		$valor_p2 = explode("/",$x['valor_produto']);
		//echo "<br>".$x['valor_produto'];
		$cont2 	 = count($valor_p2);
		//echo "<br>".$cont2 ." = ".($cont2-1);
		//echo "<br> $produto_custo";
		for($i=0;$i<($cont2-1);$i++){
			if(eregi("/",$produto_custo)){
				$custo = explode("/",$produto_custo);
				if($i == 0){
					$lucro = ($valor_p2[$i]-$custo[$i]);
					$custo_liquido = $custo[$i]; 
					//echo "<br> custo $i ". $custo[$i];
				}
				else{
					$lucro .= "/".($valor_p2[$i]-$custo[$i]);
					$custo_liquido = $custo_liquido+$custo[$i];
					//echo "<br> custo $i ". $custo[$i];
				}
			}
			else{
				$lucro = ($valor_p2[$i]-$custo[$i]);
				$custo_liquido = $produto_custo;
			}
		}
		//echo "<br> custo geral = ". $custo_liquido;
		$vp = explode("/",$x['valor_produto']);
		$cont3 = count($vp);
		for($i=0;$i<$cont3-1;$i++){
			if($i==0){
				$vp_v = $vp[$i];
				$bruto = $vp_v;
			}
			else{
				$vp_v .= "/".$vp[$i];
				$bruto = $bruto+$vp[$i]; 
			}
		}
############################################################################################		
		$serv 	= explode("/",$x['id_servicos']);
		$cont	= count($serv);
		for($i=0;$i<$cont-1;$i++){
			$select_nome_s 	= "SELECT SER_NOME, SER_CUSTO FROM servicos WHERE SER_ID = '$serv[$i]'";
			$query_nome_s	= mysql_query($select_nome_s);
			$a = mysql_fetch_array($query_nome_s);
			if($i==0){
				$servico_nome = $a['SER_NOME'];
				$servico_custo = $a['SER_CUSTO'];
			}
			
			else{
				$servico_nome .= "/".$a['SER_NOME'];
				$servico_custo .= "/".$a['SER_CUSTO'];
			}
			if($servico_nome == "/"){$servico_nome="";}
		}
		$valor_s2 = explode("/",$x['valor_servico']);
		$cont4 	 = count($valor_s2);
		for($i=0;$i<$cont4-1;$i++){
			if(eregi("/",$servico_custo)){
				$custo_s = explode("/",$servico_custo);
				if($i == 0){
					$lucro_s = ($valor_s2[$i]-$custo_s[$i]);
					$custo_liquido_s = $custo_s[$i]; 
				}
				else{
					$lucro_s .= "/".($valor_s2[$i]-$custo_s[$i]);
					$custo_liquido_s = $custo_liquido_s+$custo_s[$i];
				}
			}
			else{
				$lucro_s = ($valor_s2[$i]-$servico_custo);
				$custo_liquido_s = $servico_custo;
			}
		}
		$vs = explode("/",$x['valor_servico']);
		$cont5 = count($vs);
		for($i=0;$i<$cont5-1;$i++){
			if($i==0){
				$vs_v = $vs[$i];
				$bruto_s = $vs_v;
			}
			else{
				$vs_v .= "/".$vs[$i];
				$bruto_s = $bruto_s+$vs[$i]; 
			}
		}
		
		$custo_liquido_vs = number_format(($custo_liquido + $custo_liquido_s),2,',','.');
		$bruto_vs = number_format(($bruto_s + $bruto),2,',','.');
#####################################################################################################
		$liquido = number_format((($bruto_s + $bruto)-($custo_liquido + $custo_liquido_s)),2,',','.');
		$dinheiro_geral = number_format(($dinheiro_geral+$dinheiro_total),2,',','.');
		$master_geral = number_format(($master_geral+$master_total),2,',','.');
		$visa_geral = number_format(($visa_geral+$visa_total),2,',','.');
		$redeshop_geral = number_format(($redeshop_geral+$redeshop_total),2,',','.');
		$visaeletron_geral = number_format(($visaeletron_geral+$visaeletron_total),2,',','.');
		$cheque_geral = number_format(($cheque_geral+$cheque_total),2,',','.');
		$outros_geral = number_format(($outros_geral+$outros_total),2,',','.');
		
		$produto_custo_geral = $produto_custo_geral+$custo_liquido;
		$bruto_geral = ($bruto_geral+($bruto_s + $bruto));
		$liquido_geral = $liquido_geral+(($bruto_s + $bruto)-($custo_liquido + $custo_liquido_s));
		$custo_geral1 = $custo_geral1+$custo_liquido_s;
		$valor_geral1 = $valor_geral1+$bruto_s;	
		$lucro_geral1 = $valor_geral1-$custo_geral1;
		$custo_geral2 = $custo_geral2+$custo_liquido;
		$valor_geral2 = $valor_geral2+$bruto;
		$lucro_geral2 = $valor_geral2-$custo_geral2;	
  ?>
  <tr bgcolor="#FFFFFF">
    <td><?=$x['nota_vendedor']?></td>
    <td><?=$x['FUN_NOME']?></td>
    <td width="64"><?=number_format($dinheiro_total,2,',','.')?></td>
    <td width="64"><?=number_format($master_total,2,',','.')?></td>
    <td width="39"><?=number_format($visa_total,2,',','.')?></td>
    <td width="70"><?=number_format($redeshop_total,2,',','.')?></td>
    <td width="97"><?=number_format($visaeletron_total,2,',','.')?></td>
    <td width="60"><?=number_format($cheque_total,2,',','.')?></td>
    <td width="49"><?=number_format($outros_total,2,',','.')?></td>
    <td width="49"><?=$servico_nome?></td>    
    <td width="49"><?=$vs_v?></td>  
    <td width="54"><?=$servico_custo?></td>
    <td width="79"><?=$lucro_s?></td>
    <td width="49"><?=$produto_nome?></td>
    <td width="16"><?=$produto_marca?></td>
    <td width="17"><?=$qtde_p?></td>
    <td width="54"><?=$vp_v?></td>
    <td width="54"><?=$produto_custo?></td>
    <td width="79"><?=$lucro?></td>
    <td width="76"><?=$bruto_vs?></td>
    <td width="65"><?=$liquido?></td>
  </tr>
  <?
}
 ?>
<tr bgcolor="#FFFFFF">
<td colspan="21">&nbsp;</td>
</tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><div align="center"><span class="style10">TOTAL (R$)</span></div></td>
    <td><?=$dinheiro_geral?></td>
    <td><?=$master_geral?></td>
    <td><?=$visa_geral?></td>
    <td><?=$redeshop_geral?></td>
    <td><?=$visaeletron_geral?></td>
    <td><?=$cheque_geral?></td>
    <td><?=$outros_geral?></td>
    <td>&nbsp;</td>
    <td><?=number_format($valor_geral1,2,',','.')?></td>
    <td><?=number_format($custo_geral1,2,',','.')?></td>
    <td><?=number_format($lucro_geral1,2,',','.')?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><?=number_format($valor_geral2,2,',','.')?></td>
    <td><?=number_format($custo_geral2,2,',','.')?></td>
    <td><?=number_format($lucro_geral2,2,',','.')?></td>
    <td><?=number_format($bruto_geral,2,',','.')?></td>
    <td><?=number_format($liquido_geral,2,',','.')?></td>
  </tr>
</table>
</body>
</html>
