<? 
session_start();
include ("php/config.php");
include_once "php/valida_sessao.php";
//echo $_GET['id'];
################################ inscri��es #############################################
$dbinscricoes = mysql_query("SELECT * FROM trabalhos WHERE id_trabalho = '".$_GET['id']."'");
$fetchinscricoes = mysql_fetch_array($dbinscricoes);
################################ eventos   ##############################################
$dbeventos = mysql_query("SELECT * FROM eventos WHERE id = '".$fetchinscricoes['id_evento']."'");
$fetcheventos = mysql_fetch_array($dbeventos);
################################ certificados ###########################################
//echo "SELECT * FROM certificados_trabalhos WHERE id_evento = '".$fetcheventos['id']."'";
//exit();
$certificados = mysql_query("SELECT * FROM certificados_trabalhos WHERE id_evento = '".$fetcheventos['id']."'");
$result = mysql_fetch_array($certificados);
#########################################################################################
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
    <script src="js/fs.js" type="text/javascript"></script>
    <script src="js/fsprint.js" type="text/javascript"></script>
    <link href="css/imprime.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
<table cellpadding="0" cellspacing="0" border="0" style="background:url(images/certificado.jpg) no-repeat; margin-top:10px;" align="center">
	<tr>
	  <td height="605" width="900" valign="top">
        <a href="javascript:void(0)" onClick="javascript:imprime('conteudo')" style="margin-left:90%;">[ Imprimir ]</a>
          <div id="conteudo">
            <?php
               $ie6 = "MSIE 6.0";
               $ie7 = "MSIE 7.0";
               $ie8 = "MSIE 8.0";
               if( strstr($_SERVER['HTTP_USER_AGENT'], $ie8)){
                    echo '<div style="margin:auto; text-align:justify; width:900px;">';
               }elseif (( strstr($_SERVER['HTTP_USER_AGENT'], $ie7)) or ( strstr($_SERVER['HTTP_USER_AGENT'], $ie6))) {
                   echo '<div style="margin:auto; text-align:justify; width:900px;">';
               }else{
                   echo '<div style="margin:auto; text-align:justify; width:900px;">';
               } 
				$texto2 = $result['conteudo'];
				$nome_data = array('janeiro','fevereiro','mar�o','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro');
				$numero_data= array('January','February','March','April','May','June','July','August','September','October','November','December');
				$tipo_curso = "mini-curso";
				
				$titulo_trabalho = $fetchinscricoes['titulo'];
				$autor_trabalho = $fetchinscricoes['autor'];
				$coautores_trabalho = $fetchinscricoes['coautores'];
				$tema_trabalho = $fetchinscricoes['temasimposio'];
				$palestrante_1 = $fetchinscricoes['palestrante1'];
				$palestrante_2 = $fetchinscricoes['palestrante2'];
				$palestrante_3 = $fetchinscricoes['palestrante3'];
				$palestrante_4 = $fetchinscricoes['palestrante4'];
				
				$data1	= date('j', strtotime($fetcheventos['data_evento_inicio']));
				$data2	= date('j', strtotime($fetcheventos['data_evento_final']));
				$data3	= str_replace($numero_data,$nome_data,date('F', strtotime($fetcheventos['data_evento_final'])));
				$data4  = date('Y', strtotime($fetcheventos['data_evento_final']));
				$data	= $data1." a ".$data2." de ".$data3." de ".$data4;
				
				
				if($fetchinscricoes['tipo'] == 0){
				$texto2 = str_replace("titulo_trabalho", $titulo_trabalho, $texto2);
				$texto2 = str_replace("autor_trabalho", $autor_trabalho, $texto2);
				$texto2 = str_replace("coautores_trabalho", $coautores_trabalho, $texto2);
				}
				if($fetchinscricoes['tipo'] == 1){
				$texto2 = str_replace("tema_trabalho", $tema_trabalho, $texto2);
				$texto2 = str_replace("palestrante_1", $palestrante_1, $texto2);
				$texto2 = str_replace("palestrante_2", $palestrante_2, $texto2);
				$texto2 = str_replace("palestrante_3", $palestrante_3, $texto2);
				$texto2 = str_replace("palestrante_4", $palestrante_4, $texto2);
				}
				$texto2 = str_replace("data_evento", $data, $texto2);
				$evento	= $fetcheventos['nome_evento'];
				$texto2 = str_replace("nome_evento", $evento, $texto2);
				
				echo $texto2."<br><br>";
               ?>
               </div>
         </div>
      </td>
      </tr>
   </table>
</body>
</html>