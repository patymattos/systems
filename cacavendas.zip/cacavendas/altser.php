<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
-->
</style>
<form name="altera" action="altera_servicos.php" method="post" enctype="multipart/form-data">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td width="115"><span class="style4">Refer&ecirc;ncia: </span></td>
              <td width="415"><input name="S_REF" type="text" id="S_REF" <?=$ref?> size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Servi&ccedil;o:</span></td>
              <td><input name="S_NOME" type="text" id="S_NOME" <?=$nome?> size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Descri&ccedil;&atilde;o:</span></td>
              <td><input name="S_DESC" type="text" id="S_DESC" <?=$desc?> size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Pre&ccedil;o:</span></td>
              <td><input name="S_CUSTO" type="text" id="S_CUSTO"  <?=$custo?> size="40" /></td>
            </tr>
                    <tr> 
                              <td colspan="2">                                <div align="center">
                                  <br>
                                  <input type="hidden" name="id_serv" value="<?=$ser?>"><input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
                      </div></td>
                    </tr>
  </table>
</body>
</html>