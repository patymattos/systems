<?php

include_once "php/config.php";



$prod = $_GET['tr'];

$select = "SELECT * FROM produtos WHERE PRD_ID = '$prod'";

$query = mysql_query($select);

$a = mysql_fetch_array($query);



$ref = 'value="'.$a['PRD_REFERENCIA'].'"';

$nome = 'value="'.$a['PRD_NOME'].'"';

$desc = 'value="'.$a['PRD_DESCRICAO'].'"';

$marca = 'value="'.$a['PRD_MARCA'].'"';

$quant = 'value="'.$a['PRD_QUANTIDADE'].'"';

$venda = 'value="'.$a['PRD_VENDA'].'"';

$custo = 'value="'.$a['PRD_CUSTO'].'"';

$forn = '<option value="'.$a['PRD_FORN'].'">'.substr ($a['PRD_FORN'],0,50).'...</option>';

$pcom = 'value="'.$a['PRD_COM'].'"';






?>


<html>

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= PHAXECCO - SISTEMA ADMINISTRATIVO =-</title>

<script type="text/javascript" src="js/funcoes.js"></script>

<script type="application/javascript" language="javascript">

<!--

</script>

</script>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

    <style type="text/css">

<!--

.style5 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }

.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }

-->

    </style>

</head>





<body bgcolor="#FAFAD2">

<? include_once "inc_topo.php"; ?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>

    <td width="578" valign="top">

	<table width="575" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">

	  <tr>

        <td class="titulo">:: Altera��o de Produto ::</td>

      </tr>

	  <tr>

        <td><? include_once "altprod.php"; ?></td>

	  </tr>

    </table>



	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</body>

</html>