<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="css/style.css" type="text/css" title="normal" media="screen, projection" />

<title>-= Meta Marketing e Eventos =-</title>
<style type="text/css">
<!--
.TOPO{
width:1000px; /*LARGURA*/
height:134px; /*ALTURA*/
background-image:url(img/topo2.jpg); /*IMAGEM DO FUNDO*/
background-repeat:no-repeat; /*N�O REPETIR O FUNDO*/
margin:0px auto;
text-align:
}
-->
</style>
</head>
<body>
<div id="mestre">
		<div class="TOPO">
		</div>
</div>
</body>
</html>
