<html>

<style type="text/css">

<!--

.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }

.style11 {font-family: Arial, Helvetica, sans-serif}

.style12 {font-size: 14px}

-->

</style>

<form name="alteracs" action="alt_cservicos.php" method="post" enctype="multipart/form-data">

          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">

            <tr>

              <td width="115"><span class="style4">Refer&ecirc;ncia: </span></td>

              <td width="415"><input name="C_REF" type="text" id="S_REF" <?=$CS_REF?> size="26" /></td>

            </tr>

            <tr>

              <td><span class="style4">Funcion&aacute;rio:</span></td>

              <td><select name="C_FUN">
                <option selected="selected">---Escolha o Funcion�rio---</option>
                <?

				$resultado = mysql_query("SELECT DISTINCT FUN_NOME FROM funcionario ORDER BY FUN_NOME ASC");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FUN_NOME]'>".substr ($sql[FUN_NOME],0,50)."...</option>'";

				}

			?>
              </select></td>
            </tr>

            <tr>

              <td><span class="style4">% Porcentagem:</span></td>

              <td><input name="C_PORC" type="text" id="C_PORC" <?=$CS_PORC?> size="26" /></td>

            </tr>

            <tr>

              <td><span class="style4">Servi&ccedil;o:</span></td>

              <td><select name="C_SERV">
                  <option selected="selected">---Escolha um Servi�o---</option>
                  <?

				$resultado = mysql_query("SELECT DISTINCT SER_NOME FROM servicos ORDER BY SER_NOME ASC");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[SER_NOME]'>".substr ($sql[SER_NOME],0,50)."...</option>'";

				}

			?>
              </select></td>
            </tr>

                    <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br>

                                  <input type="hidden" name="id_serv" value="<?=$cser?>"><input name="enviar" type="image" img src="servi&#231;os/images/ico_cadastrar.jpg" value="enviar" border="0">

                      </div></td>

                    </tr>

  </table>

  </form>

</body>

</html>