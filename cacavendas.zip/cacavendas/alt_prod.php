<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_autocen";  // Seu Login no mySQL 
  	$pass = "k0k9p8n7u6";  // Senha do MySql
  	$db = "swcenter_kakapneus";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	$PD_DATA =$_POST['vec'];
	
	$PD_REFERENCIA =$_POST['ref'];
	
	$PD_NOME =$_POST['nome'];
  	
	$PD_DESCRICAO =$_POST['desc'];
  	
	$PD_MARCA =$_POST['marca'];
	
	$PD_QUANTIDADE =$_POST['quant'];
	
	$PD_VALOR =$_POST['venda'];
	 	
	$PD_CUSTO =$_POST['custo'];
	
	$PD_COM =$_POST['pcomissao'];

	$PD_FORN =$_POST['forn'];

 	?>
	<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
-->
</style>
<form name="cadastro" action="upod.php" method="post" onSubmit="return validaForm()">
<table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="115"><span class="style4">Refer&ecirc;ncia:</span></td>
    <td width="415"><input name="ref" value="<? echo $PD_REFERENCIA; ?>"type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style4">Produto: </span></td>
    <td><input name="nome" value="<? echo $PD_NOME; ?>" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">Descri&ccedil;&atilde;o:</span></td>
    <td><input name="desc" value="<? echo $PD_DESCRICAO; ?> "type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">Marca:</span></td>
    <td><input name="marca"  value="<? echo $PD_MARCA; ?>" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">Quantidade:</span></td>
    <td><input name="quant" value="<? echo $PD_QUANTIDADE; ?>" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">Pre&ccedil;o de Custo:</span></td>
    <td><input name="custo" value="<? echo $PD_CUSTO; ?>"type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">% Comiss&atilde;o:</span></td>
    <td><input name="pcomissao" value="<? echo $PD_COM; ?>" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">Pre&ccedil;o de Venda:</span></td>
    <td><input name="venda" value="<? echo $PD_VALOR; ?>" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5 style11 style12">Fornecedor:</span></td>
    <td><input name="venda2" value="<? echo $PD_FORN; ?>" type="text" size="40" /></td>
  </tr>
  <tr>
    <td colspan="2">
      <div align="center"> <br>
          <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
    </div></td>
  </tr>
</table>
</form>

