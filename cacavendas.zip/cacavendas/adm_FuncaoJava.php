<?php
session_start();
include ("php/valida_sessao.php");
include "php/config.php";
	$resultado = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
	$xx = mysql_fetch_array($resultado);
	$id_evento  = $xx['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<title>-= Meta Marketing e Eventos =-</title>
</head>
<body>

<?php include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><?php include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>
		 <form action="php/inc_funcao_java.php" method="post" name="form">
	 	  <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
	       <tr>
    	      <td align="center" bgcolor="#FFFFFF" colspan="2">
              <input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" />
          	  </td>
	       </tr>
	       <tr>
      	  	  <td align="center" class="titulo" colspan="3">:: Fun��es dos Formul�rios ::</td>
           </tr>
		   <tr>
 			  <td colspan="3" align="center"><a href="cad_funcao_java.php"> Cadastrar uma nova fun��o</a>
			  </td>
           </tr>
           <tr>   
             <td align="center" colspan="2"></td>
             <td align="center">Excluir</td>
		   </tr>
		    <?php
			$sqlll	= mysql_query("SELECT * FROM funcao_java WHERE id_evento='$id_evento' ORDER BY id");
			$i = 1;
			 while ($fetch = mysql_fetch_array($sqlll)){
				 $funcao_java = $fetch['funcao'];
			 	 $id = $fetch['id'];

			echo '<tr valign="top">';
				 echo '<td>';
					echo 'Fun��o '.$i.':
				 </td>
 			  	 <td>';
					echo '<textarea name="FuncaoJava" cols="40" rows="20">'.$funcao_java.'</textarea>';
              	 echo '</td>';
				 echo '<td align="center">';
   	 				 echo "<a href='php/excluir_funcao_java.php?id=$id'><img src='images/ico_excluir.jpg' border='0'/></a>";
				 echo '</td>';
           		echo '</tr>';
			$i++;	
			 } 
	
			?>
            </td>
		  </tr>
		</table>
        <input type="hidden" name="id_evento" value="<?=$id_evento;?>" />
        <input type="hidden" name="id" value="<?=$id;?>" />
       </form>
      </td>
     </tr>
  <tr>
   <td>
   		<a href="javascript:history.go(-1)">Voltar</a>
   </td>
  </tr>
    </table>
   </td>
  </tr>
 </table> 
<? 
include_once "inc_rodape.php";
echo '</body>';
echo '</html>';

?>