<?php
include "php/config.php";
echo "<select name='todos'>";
$dados = mysql_query("DESCRIBE inscricoes");

$acento = array("title", "familyname", "givenname","nametothebagde", "Affiliation", "instituicao", "especialidade", "cpf", "identidade", "mailingadress", "city", "provincestate", "country", "zipcode", "email", "phone", "fax", "accompanyingperson", "letter", "profissional", "student", "residente", "gerentologia", "congnitiva", "paleativos", "incapacidade", "accompanyingperson2", "formpagamento", "cartao", "namecredit", "datacartao", "numcredit", "expiracartao","securitycode","totalescolhido");
$semacento=array("T�tulo","Sobrenome", "Nome", "Nome Crach�", "Afilia��o", "Institui��o", "Especialidade", "CPF", "Identidade","Endere�o", "Cidade", "Estado", "Pa�s", "CEP", "Email", "Telefone", "FAX", "Acompanhante", "Letter", "Profissional", "Estudante", "Residente", "Gerentologia", "Congnitiva", "Paleativos", "Incapacidade", "Acompanhante2", "Formpagamento", "Cartao", "Nome do Cart�o", "Data Cart�o","Numero Credito", "Data Expira��o","C�digo de Seguran�a","Total Escolhido");

while($x = mysql_fetch_array($dados)){
echo"<option value='$x[0]'>".str_replace($acento, $semacento, $x[0])."</option>";
echo"<br>";
}
echo '</select>';
?>