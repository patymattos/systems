<?php

session_start();

include_once "php/valida_sessao.php";

include_once "php/config.php";

$select = "SELECT * FROM eventos";

$sql = mysql_query($select) or die ("Query : ".$select." : ".mysql_error());

$resultado = mysql_num_rows($sql);

$evento = ($resultado+2);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= KAKA PNEUS - SISTEMA ADMINISTRATIVO =-</title>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

<script language="javascript" type="text/javascript">

function validaRelat() {

	if(document.relat.dia_ini.value == "") {

		alert("Favor escolher o campo dia incial");

		document.relat.dia_ini.focus();

        return false;

	};

	if(document.relat.mes_ini.value == "") {

		alert("Favor escolher o campo mes incial");

		document.relat.mes_ini.focus();

        return false;

	};

	if(document.relat.ano_ini.value == "") {

		alert("Favor escolher o campo ano incial");

		document.relat.ano_ini.focus();

        return false;

	};

	if(document.relat.dia_fim.value == "") {

		alert("Favor escolher o campo dia final");

		document.relat.dia_fim.focus();

        return false;

	};

	if(document.relat.mes_fim.value == "") {

		alert("Favor escolher o campo mes final");

		document.relat.mes_fim.focus();

        return false;

	};

	if(document.relat.ano_fim.value == "") {

		alert("Favor escolher o campo ano final");

		document.relat.ano_fim.focus();

        return false;

	};



	if(document.relat.dia_ini.value != "" && document.relat.mes_ini.value != "" && document.relat.ano_ini.value != "" && document.relat.dia_fim.value != "" && document.relat.mes_fim.value != "" && document.relat.ano_fim.value != "") {

		document.relat.action="rvendas.php";

		document.relat.submit();

	};

};

</script>

    <style type="text/css">

<!--

.style13 {font-size: 13px}
.style22 {
	color: #000066;
	font-weight: bold;
	font-style: italic;
	font-size: 17px;
	font-family: Arial, Helvetica, sans-serif;
}
.style26 {color: #999999}
.style35 {font-size: 20px; font-weight: bold; color: #999999; }
.style41 {font-size: 18px}
.style43 {font-family: Arial, Helvetica, sans-serif}
.style45 {font-size: 17px; font-weight: bold; }

-->

    </style>

</head>





<body bgcolor="#FAFAD2">

<form enctype="multipart/form-data" name="relat" id="relat" method="post">         

<? include_once "inc_topo.php"; ?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>

    <td width="578" valign="top">

	<table width="575" border="0" align="center" cellpadding="2" cellspacing="1" bgcolor="#FFFFFF" class="texto cor_tr">

	  <tr>

        <td class="titulo">::  Relat&oacute;rio de Vendas ::</td>

      </tr>

	  <tr>

        <td>

<table width="550" border="0" bgcolor="#FFFFFF">

  <tr>
    <td>
      <table width="385" border="0">
        <tr>
          <td colspan="2"><span class="style22">Selecione o Per&iacute;odo da Venda</span></td>
		 
        </tr>
		<tr>
          <td width="105"><span class="style35 style41 style43"><span class="style45">            Data Inicial: </span></span></td>
          <td width="270"><span class="style45">            <select name="dia_ini">
                  <option value="" selected="selected">Dia</option>
                  <option value='01'>01</option>
                  <option value='02'>02</option>
                  <option value='03'>03</option>
                  <option value='04'>04</option>
                  <option value='05'>05</option>
                  <option value='06'>06</option>
                  <option value='07'>07</option>
                  <option value='08'>08</option>
                  <option value='09'>09</option>
                  <?php

                for($i=10;$i<32;$i++){

                echo "<option value='$i'>$i</option>";

                }

              ?>
            </select>
            <span class="style26">            /</span>
            <select name="mes_ini">
                  <option value="" selected="selected">Mes</option>
                  <option value='01'>01</option>
                  <option value='02'>02</option>
                  <option value='03'>03</option>
                  <option value='04'>04</option>
                  <option value='05'>05</option>
                  <option value='06'>06</option>
                  <option value='07'>07</option>
                  <option value='08'>08</option>
                  <option value='09'>09</option>
                  <option value='10'>10</option>
                  <option value='11'>11</option>
                  <option value='12'>12</option>
            </select>
            <span class="style4  style26">/</span>
            <select name="ano_ini">
                  <option value="" selected="selected">Ano</option>
                  <?php

                for($i=2010;$i<2015;$i++){

                echo "<option value='$i'>$i</option>";

                }

              ?>
            </select>
            </span></td>
        </tr>
        <tr>
          <td><span class="style35 style41 style43"><span class="style45">Data Final: </span></span></td>
          
		  <td><span class="style45">
            <select name="dia_fim">
                  <option value="" selected="selected">Dia</option>
                  <option value='01'>01</option>
                  <option value='02'>02</option>
                  <option value='03'>03</option>
                  <option value='04'>04</option>
                  <option value='05'>05</option>
                  <option value='06'>06</option>
                  <option value='07'>07</option>
                  <option value='08'>08</option>
                  <option value='09'>09</option>
                  <?php

                for($i=10;$i<32;$i++){

                echo "<option value='$i'>$i</option>";

                }

		  ?>
            </select>
            <span class="style26">/</span>
            <select name="mes_fim">
                  <option value="" selected="selected">Mes</option>
                  <option value='01'>01</option>
                  <option value='02'>02</option>
                  <option value='03'>03</option>
                  <option value='04'>04</option>
                  <option value='05'>05</option>
                  <option value='06'>06</option>
                  <option value='07'>07</option>
                  <option value='08'>08</option>
                  <option value='09'>09</option>
                  <option value='10'>10</option>
                  <option value='11'>11</option>
                  <option value='12'>12</option>
            </select>
            <span class="style26">/</span>
            <select name="ano_fim">
                  <option value="" selected="selected">Ano</option>
                  <?php

		  	for($i=2010;$i<2015;$i++){

			echo "<option value='$i'>$i</option>";

			}

		  ?>
            </select>
            </span></td>
        </tr>
      </table>      </td>
  </tr>

</table>

<table width="550" border="0" bgcolor="#FFFFFF">

  <tr>

    <td><table width="550" border="0">

      <tr>

        <td width="516" colspan="8"><div align="center"><span class="style13"></span>              <table width="510" border="0" align="left">
        
                <tr>
        
                  <td colspan="2" align="center" bgcolor="#FFFFFF">
        
                    <div align="left"><strong><span class="style4">
        
            </span>
                        <input type="Submit" value="Enviar" onClick="return validaRelat();" />
        
                    </strong></div></td>
        
                </tr>
        
          </table>
        </div></td>

        </tr>

    </table>

    </td>

  </tr>

</table>

        </td>

	  </tr>

    </table>

	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</form>

</body>

</html>