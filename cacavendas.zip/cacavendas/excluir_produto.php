<?php
include_once "php/config.php";
$id_produto = $_GET['ex'];

$sql	= "UPDATE produtos SET PRD_ATIVO = '0' WHERE PRD_ID = '$id_produto'";
$resultado = mysql_query($sql);

echo "<script>location.href='cad_produtos.php';</script>";
?>