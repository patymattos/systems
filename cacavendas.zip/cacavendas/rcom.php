<html>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
}
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
           //validar nome
           if (d.nome.value == ""){
                     alert("O campo " + d.nome.name + " deve ser preenchido!");
                     d.nome.focus();
                    return false;
           }
          //validar user
         if (d.user.value == ""){
                   alert("O campo " + d.user.name + " deve ser preenchido!");
                   d.user.focus();
                   return false;
         }
         //validar senha
         if (d.senha.value == ""){
                   alert("O campo " + d.senha.name + " deve ser preenchido!");
                   d.senha.focus();
                   return false;
         }
         //validar email
         if (d.FU_EMAIL.value == ""){
                   alert("O campo " + d.FU_EMAIL.name + " deve ser preenchido!");
                   d.FU_EMAIL.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         if (d.telefone.value == ""){
                   alert ("O campo " + d.telefone.name + " deve ser preenchido!");
                   d.telefone.focus();
                   return false;
         }
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.telefone.value)){
                   alert ("O campo " + d.telefone.name + " deve conter apenas numeros!");
                   d.telefone.focus();
                   return false;
         }
         //validar data de nascimento
         erro=0;
         hoje = new Date();
         anoAtual = hoje.getFullYear();
         barras = d.nasce.value.split("/");
         if (barras.length == 3){
                   dia = barras[0];
                   mes = barras[1];
                   ano = barras[2];
                   resultado = (!isNaN(dia) && (dia > 0) && (dia < 32)) && (!isNaN(mes) && (mes > 0) && (mes < 13)) && (!isNaN(ano) && (ano.length == 4) && (ano <= anoAtual && ano >= 1900));
                   if (!resultado) {
                             alert("Formato de data invalido!");
                             d.nasce.focus();
                             return false;
                   }
         } else {
                   alert("Formato de data invalido!");
                   d.nasce.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }



</script>

<form name="cadastro" action="teste.php" method="post" onSubmit="return validaForm()">
   <table width="787" border="0">
     <tr>
       <td width="649"><span class="style1">RELAT&Oacute;RIO  DE COMISS&Atilde;O</span></td>
       <td width="121">DATA __/__/___ </td>
     </tr>
   </table>
</form>

