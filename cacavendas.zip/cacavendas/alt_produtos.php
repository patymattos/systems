<?php
header('Content-Type: text/html; charset=utf-8');
include_once "php/config.php";

$id_produto = $_POST['id_produto'];

$ref 	= $_POST['ref'];
$ano 	= $_POST['ano'];
$nome 	= $_POST['nome'];
$desc 	= $_POST['desc'];
$marca	= $_POST['marca'];
$quant 	= $_POST['quant'];
$venda 	= $_POST['venda'];
$custo 	= $_POST['custo'];
$forn 	= $_POST['forn'];
$pcom 	= $_POST['pcomissao'];
$obs 	= $_POST['obs'];



if($venda != "" && $custo != "" && $quant != "" && $ref != "" && $nome != ""){
	$up = "UPDATE produtos SET
	PRD_REFERENCIA	='$ref',
	PRD_ANO	='$ano',
	PRD_NOME		='$nome',
	PRD_DESCRICAO	='$desc',
	PRD_MARCA		='$marca',
	PRD_QUANTIDADE	='$quant',
	PRD_VENDA		='$venda',
	PRD_CUSTO		='$custo',
	PRD_FORN		='$forn',
	PRD_COM		='$pcom',
	PRD_OBS		='$obs'



	WHERE PRD_ID = '$id_produto'";
	$cad = mysql_query($up);
	
	echo "<script>alert('Produto alterado com sucesso');location.href='cad_produtos.php'; </script>";
}
else{
	echo "<script>alert('Verifiqque se um dos campos abaixo não foi definido:\\n - Referência\\n - Produto\\n - Quantidade\\n - Preço custo\\n - Preço venda');location.href='javascript:window.history.go(-1)'; </script>";
	exit();
}
?>