<?php

header('Content-Type: text/html; charset=utf-8');

include_once "php/config.php";



$id_serv = $_POST['id_serv'];



$CS_REF 	= $_POST['C_REF'];

$CS_FUN 	= $_POST['C_FUN'];

$CS_PORC 	= $_POST['C_PORC'];

$CS_SERV 	= $_POST['C_SERV'];



if($CS_REF != "" && $CS_FUN != "" && $CS_PORC != "" && $CS_SERV != ""){

	$up = "UPDATE comissao SET

	CM_REF		='$CS_REF',

	CM_FUN	='$CS_FUN',

	CM_PORC	='$CS_PORC',

	CM_SERV	='$CS_SERV'

	WHERE CM_ID= '$id_serv'";

	$cad = mysql_query($up);

	

	echo "<script>alert('Comissão de serviço alterado com sucesso');location.href='alterar_cservicos.php?tr=$id_serv'; </script>";

}

else{

	echo "<script>alert('Verifiqque se um dos campos abaixo não foi definido:\\n - Referência\\n - Funcionário\\n - Porcentagem\\n - Serviços\\n');location.href='javascript:window.history.go(-1)'; </script>";

	exit();

}

?>