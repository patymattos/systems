<html>
<head>
<title>-= True Life Geomensura =-</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="css/estilo.css" />

<link rel="stylesheet" type="text/css" href="css/sddm.css" >
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>
<body bgcolor="#FFFAFA" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (4.1.jpg) -->
<table width="898" height="560" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
<tr>
		<td height="251" colspan="2">
			<img src="images/s_01.jpg" width="898" height="107" alt=""></td>
  </tr>
	<tr>
		<td height="147" colspan="2">
			<? include "proj.php";

?></td>
  </tr>
	
	<tr>
		<td height="143">&nbsp;
		  <script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','882','height','114','src','menu','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','menu' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="882" height="114">
        <param name="movie" value="menu.swf">
          <param name="quality" value="high">
          <embed src="menu.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="882" height="114"></embed>
	    </object></noscript></td>
<td>
			<img src="images/s_05.jpg" width="1" height="114" alt=""></td>
	</tr>
	<tr>
		<td colspan="2"><div align="left" class="texto">&nbsp;Endere&ccedil;o: Rua tallffff</div></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>