  <?php
   @include ("verifica.php");
   @include ("php/config.php");
  ?>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  </head>
  <body>
  <div id="box2" style="width: 800px; float:right;">
  <form action="procnoticias.php" method="post">
   <fieldset>
     <legend>Incluir Not�cia</legend>
     <dt><label for=nome>Not�cia:</label></dt>
     <dd><textarea name="noticias" cols="40" rows="5"></textarea></dd><br><br><br>
   <input type="submit" value="Enviar">
   </fieldset>
  </form>
  </div>
  <div id="box1" style="width: 170px;">
    <fieldset>
     <legend>Menu</legend>
       <a href="noticiasativas.php">Not�cias Ativas</a><br>
       <a href="noticiasinativas.php">Not�cias Inativas</a><br>       
       <a href="incluirnot.php">Nova Not�cias</a>  
    </fieldset>
  </div>  
   </div>
 </body>
</html>