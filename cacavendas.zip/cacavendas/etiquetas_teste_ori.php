<?php
session_start();
include ("php/config.php");
include_once "php/valida_sessao.php";

define('FPDF_FONTPATH','fpdf/font/');
require("fpdf/fpdf.php");

$evento2				= $_POST['evento2'];
$id 					= $_POST['id2'];
$title 					= $_POST['title2'];
$familyname 			= $_POST['familyname2'];
$givenname	 			= $_POST['givenname2'];
$namebagde				= $_POST['nametothebagde2'];
$affiliation 			= $_POST['affiliation2'];
$instituicao2 			= $_POST['instituicao2'];
$mailingadress 			= $_POST['mailingadress2'];
$city2 					= $_POST['city2'];
$provincestate			= $_POST['provincestate2'];
$country				= $_POST['country2'];
$zipcode				= $_POST['zipcode2'];
$email					= $_POST['email2'];
$phone 					= $_POST['phone2'];
$fax					= $_POST['fax2'];
$accompanying			= $_POST['accompanyingperson2'];
$letter 				= $_POST['letter2'];
$profissional 			= $_POST['profissional2'];
$student 				= $_POST['student2'];
$accompanying2 			= $_POST['accompanyingperson3'];
$family					= $_POST['family2'];
$especialidade	 		= $_POST['especialidade2'];
$cpf		 			= $_POST['cpf2'];
$identidade				= $_POST['identidade2'];
$resident				= $_POST['resident2'];
$gerentologia			= $_POST['gerentologia2'];
$congnitiva 			= $_POST['congnitiva2'];
$paleativos				= $_POST['paleativos2'];
$incapacidade 			= $_POST['incapacidade2'];

/*
echo "id = " .$id."<br>";
echo "title = " .$title."<br>";
echo "familyname = " . $familyname."<br>";
echo "givenname = " . $givenname."<br>";
echo "namebagde = " . $namebagde."<br>";
echo "affiliation = ". $affiliation."<br>";
echo "mailingadress = ". $mailingadress."<br>";
echo "city = ". $city2."<br>";
echo "provincestate = ". $provincestate."<br>";
echo "country = ". $country."<br>";
echo "zipcode = ". $zipcode."<br>";
echo "email = ". $email."<br>";
echo "phone = ". $phone."<br>";
echo "fax = ". $fax."<br>";
echo "accompanying = ". $accompanying."<br>";
echo "letter = ". $letter."<br>";
echo "profissional = ". $profissional."<br>";
echo "student = ". $student."<br>";
echo "accompanyng = ". $accompanying2."<br>";
echo "formpagamento = ". $formpagamento."<br>";
echo "cartao = ". $cartao."<br>";
echo "namecredit = ". $namecredit."<br>";
echo "especialidade = ". $especialidade."<br>";
echo "cpf = ". $cpf."<br>";
echo "identidade = ". $identidade."<br>";
echo "resident = ". $resident."<br>";
echo "gerentologia = ". $gerentologia."<br>";
echo "congnitiva = ". $congnitiva."<br>";
echo "paleativos = ". $paleativos."<br>";
echo "incapacidade = ". $incapacidade."<br>";
echo "family = ".$family."<br>";
*/

$busca = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'");

// Variaveis de Tamanho

$leti = "101"; // Largura da Etiqueta (mm)
$aeti = "6"; // Altura da Etiqueta (mm)

$pdf=new FPDF('P','mm','Letter'); // Cria um arquivo novo com tamanho tipo carta
$pdf->Open(); // inicia documento
$pdf->SetMargins(4,25,4); // Define as margens do documento
$pdf->AddPage(); // adiciona a primeira pagina
$pdf->SetAuthor("META EVENTOS"); // Define o autor
$pdf->SetTitle('ETIQUETAS EVENTO');
// muda fonte e coloca em negrito

// largura padrão das colunas
// altura padrão das linhas das colunas

 //$pdf->Ln(3);
// tirando o negrito
// montando a tabela com os dados (presumindo que a consulta já foi feita)
while( $row = mysql_fetch_array($busca) )
{
		$pdf->SetFont('Arial', 'B', 20);
        $pdf->Multicell($leti, $aeti, $row['nametothebagde'], 0, 'C');
		$pdf->SetFont('Arial', 'B', 18);
        $pdf->Multicell($leti, $aeti, $row['especialidade'], 0, 'C');
        $pdf->Multicell($leti, $aeti, $row['instituicao'].' - '.$row['provincestate'], 0, 'C');
        $pdf->Ln(11);
}

// exibindo o PDF
$pdf->Output();
?>