<?php
session_start();
 include ("php/config.php");
include_once "php/valida_sessao.php";
$eventos=$_POST["eventos"];
$y = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$eventos."'");
 $x = mysql_fetch_array($y);
 $id	= $x["id"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
   	<script language="javascript">
			function validar(obj) { // recebe um objeto
				var s = (obj.value).replace(/\D/g,'');
				var tam=(s).length; // removendo os caracteres não numéricos
				if (!(tam==11 || tam==14)){ // validando o tamanho
					alert("'"+s+"' N�o � um CPF ou um CNPJ v�lido!" ); // tamanho inválido
					return false;
				}
				// se for CPF
				if (tam==11 ){
					if (!validaCPF(s)){ // chama a função que valida o CPF
						alert("'"+s+"' N�o � um CPF v�lido!" ); // se quiser mostrar o erro
						obj.select();  // se quiser selecionar o campo em questão
						return false;
					}
					obj.value=maskCPF(s);    // se validou o CPF mascaramos corretamente
					return true;
				}
				// se for CNPJ
				if (tam==14){
					if(!validaCNPJ(s)){ // chama a função que valida o CNPJ
						alert("'"+s+"' N�o � um CNPJ v�lido!" ); // se quiser mostrar o erro
						obj.select();    // se quiser selecionar o campo enviado
						return false;
					}
				}
			}
		
			function validaCPF(s) {
				var c = s.substr(0,9);
				var dv = s.substr(9,2);
				var d1 = 0;
				for (var i=0; i<9; i++) {
					d1 += c.charAt(i)*(10-i);
				}
				if (d1 == 0) return false;
				d1 = 11 - (d1 % 11);
				if (d1 > 9) d1 = 0;
				if (dv.charAt(0) != d1){
					return false;
				}
				d1 *= 2;
				for (var i = 0; i < 9; i++)    {
					 d1 += c.charAt(i)*(11-i);
				}
				d1 = 11 - (d1 % 11);
				if (d1 > 9) d1 = 0;
				if (dv.charAt(1) != d1){
					return false;
				}
				return true;
			}
		
			function validaCNPJ(CNPJ) {
				var a = new Array();
				var b = new Number;
				var c = [6,5,4,3,2,9,8,7,6,5,4,3,2];
				for (i=0; i<12; i++){
					a[i] = CNPJ.charAt(i);
					b += a[i] * c[i+1];
				}
				if ((x = b % 11) < 2) { 
					a[12] = 0 
				} else { 
					a[12] = 11-x 
				}
				b = 0;
				for (y=0; y<13; y++) {
					b += (a[y] * c[y]);
				}
				if ((x = b % 11) < 2) { 
					a[13] = 0; 
				} else { 
					a[13] = 11-x; 
				}
				if ((CNPJ.charAt(12) != a[12]) || (CNPJ.charAt(13) != a[13])){
					return false;
				}
				return true;
			}
		
			function soNums(e){
				if (document.all){
					var evt=event.keyCode;
				}else{
					var evt = e.charCode;
				}
				if (evt <20 || (evt >47 && evt<58)){
					return true;
				}
				return false;
			}
		
			function maskCPF(CPF){
				return CPF.substring(0,3)+"."+CPF.substring(3,6)+"."+CPF.substring(6,9)+"-"+CPF.substring(9,11);
			}
		
			function maskCNPJ(CNPJ){
				return CNPJ.substring(0,2)+"."+CNPJ.substring(2,5)+"."+CNPJ.substring(5,8)+"/"+CNPJ.substring(8,12)+"-"+CNPJ.substring(12,14);
			} 1
		
			function nu(campo){
				var digits="0123456789"
				var campo_temp 
				for (var i=0;i<campo.value.length;i++){
					campo_temp=campo.value.substring(i,i+1) 
					if (digits.indexOf(campo_temp)==-1){
						campo.value = campo.value.substring(0,i);
						break;
					}
				}
			}
    </script>
  <style>
	fieldset dt{
	  float: left;
	  width: 220px;
	  padding: 5px;
	  margin: 0;  
	  font:  0.9em Verdana;  
	}
  input.valor{
	background: url("images/valor.gif");
	cursor:hand;
	width: 65px;
	height: 22px;
	border:0;
  }  
</style>
</head>
<body>
<?php include_once "inc_topo.php"; 

if ($id == '1'){
?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	<form action="cad_inscricoes2.php" method="post" id="teste"  name="frm_servico" enctype="multipart/form-data" onSubmit="return validaForm()">
	
    <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
	  <tr>
        <td colspan="2" class="titulo">:: Cadastrar Inscri��es ::</td>
      </tr>
      <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
    <tr>
      <td width="375" align="left" class="textotab">Title:</td>
      <td colspan="2" align="left"><input name="title" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Family Name:</td>
      <td colspan="2" align="left"><input name="familyname" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Given Name:</td>
      <td colspan="2" align="left"><input name="givenname" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Name to the Badge:</td>
      <td colspan="2" align="left"><input name="nametothebagde" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Affiliation:</td>
      <td colspan="2" align="left"><input name="Affiliation" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Mailing Adress:</td>
      <td colspan="2" align="left"><input name="mailingadress" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">City:</td>
      <td colspan="2" align="left"><input name="city" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Province/State:</td>
      <td colspan="2" align="left"><input name="provincestate" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Country:</td>
      <td colspan="2" align="left"><input name="country" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Zip Code:</td>
      <td colspan="2" align="left"><input name="zipcode" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">E-Mail:</td>
      <td colspan="2" align="left"><input name="email" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Phone (country and city code):</td>
      <td colspan="2" align="left"><input type="text" name="phoneddi" size="3"/> 
        -
          <input type="text" name="phoneddd" size="3"/>
        -
        <input type="text" name="phone" size="13"/></td>
      </tr>
    <tr>
      <td align="left" class="textotab">FAX:</td>
      <td colspan="2" align="left"><input type="text" name="faxddi" size="3"/> 
        -
          <input type="text" name="faxddd" size="3"/>
        -
          <input type="text" name="fax" size="13"/></td>
      </tr>
    <tr>
      <td align="left" class="textotab">Accompanying Person:</td>
      <td colspan="2" align="left"><input name="accompanyingperson" type="text" id="name" size="50" /></td>
    </tr>
       <input type="hidden" value="<?=$id?>" name="id" />
       <input type="hidden" value="<?=$eventos?>" name="eventos" />
    <tr>
      <td align="left" class="textotab">NEED AN INVITATION LETTER:</td>
      <td width="174" align="left"><input type="radio" name="letter" value="sim">
        <span class="textotab">Yes</span></td>
      <td width="233" align="left"><input type="radio" name="letter" value="nao">
        <span class="textotab">No</span></td>
    </tr>

         </table>


	</form>
	</td>
  </tr>
</table>
<?php
}
elseif($id == '4'){
?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	<form action="cad_inscricoes2.php" method="post" id="teste"  name="frm_servico" enctype="multipart/form-data" onSubmit="return validaForm()">
	
    <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
	  <tr>
        <td colspan="2" class="titulo">:: Cadastrar Inscri��es ::</td>
      </tr>
      <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
    <tr>
      <td width="207" align="left" class="textotab">Title:</td>
      <td width="383" colspan="2" align="left"><input name="title" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">First name:</td>
      <td colspan="2" align="left"><input name="first_name" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Middle name:</td>
      <td colspan="2" align="left"><input name="middle_name" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Family:</td>
      <td colspan="2" align="left"><input name="familyname" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Name in the badge:</td>
      <td colspan="2" align="left"><input name="nametothebagde" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Institution / Company:</td>
      <td colspan="2" align="left"><input name="institution" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Mailing address:</td>
      <td colspan="2" align="left"><input name="mailingadress" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">City:</td>
      <td colspan="2" align="left"><input name="city" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Province/State:</td>
      <td colspan="2" align="left"><input name="provincestate" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Country:</td>
      <td colspan="2" align="left"><input name="country" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Zip Code:</td>
      <td colspan="2" align="left"><input name="zipcode" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">E-mail:</td>
      <td colspan="2" align="left"><input name="email" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Phone (country and city code):</td>
      <td colspan="2" align="left"><input type="text" name="phoneddi" size="3"/> 
        -
          <input type="text" name="phoneddd" size="3"/>
        -
        <input type="text" name="phone" size="13"/></td>
      </tr>
    <tr>
      <td align="left" class="textotab">FAX:</td>
      <td colspan="2" align="left"><input type="text" name="faxddi" size="3"/> 
        -
          <input type="text" name="faxddd" size="3"/>
        -
          <input type="text" name="fax" size="13"/></td>
    </tr>
       <input type="hidden" value="<?=$id?>" name="id" />
       <input type="hidden" value="<?=$eventos?>" name="eventos" />
 </table>
	</form>
	</td>
  </tr>
</table>
<?php
}
elseif ($id == '406'){
?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	<form action="cad_inscricoes2.php" method="post" id="teste"  name="frm_servico" enctype="multipart/form-data" onSubmit="return validaForm()">
	
    <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
	  <tr>
        <td colspan="2" class="titulo">:: Cadastrar Inscri��es ::</td>
      </tr>
      <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
    <tr>
      <td width="207" align="left" class="textotab">Nome completo:</td>
      <td width="383" colspan="2" align="left"><input name="nome_completo" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Nome para crach�:</td>
      <td colspan="2" align="left"><input name="nome_para_cracha" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Institui��o:</td>
      <td colspan="2" align="left"><input name="instituicao" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Especialidade:</td>
      <td colspan="2" align="left"><input name="especialidade" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">CPF:</td>
      <td colspan="2" align="left"><input name="cpf" type="text" id="name" size="50" onblur="validar(this)"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Identidade:</td>
      <td colspan="2" align="left"><input name="identidade" type="text" id="name" size="50" onKeyUp="nu(this)"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Endere�o:</td>
      <td colspan="2" align="left"><input name="endereco" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">CEP:</td>
      <td colspan="2" align="left"><input name="cep" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Cidade:</td>
      <td colspan="2" align="left"><input name="cidade" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Estado:</td>
      <td colspan="2" align="left"><input name="estado" type="text" id="name" size="50"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">Telefone:</td>
      <td colspan="2" align="left"><input type="text" name="phoneddi" size="3"/> 
        -
          <input type="text" name="phoneddd" size="3"/>
        -
        <input type="text" name="phone" size="13"/></td>
      </tr>
    <tr>
      <td align="left" class="textotab">FAX:</td>
      <td colspan="2" align="left"><input type="text" name="faxddi" size="3"/> 
        -
          <input type="text" name="faxddd" size="3"/>
        -
          <input type="text" name="fax" size="13"/></td>
    </tr>
    <tr>
      <td align="left" class="textotab">E-mail (cadastrar um email para cada usu�rio):</td>
      <td colspan="2" align="left"><input name="email" type="text" id="name" size="50"/></td>
    </tr>
       <input type="hidden" value="<?=$id?>" name="id" />
       <input type="hidden" value="<?=$eventos?>" name="eventos" />
 </table>
	</form>
	</td>
  </tr>
</table>
<?php
}
?>
<?php include_once "inc_rodape.php"; ?>
</body>
</html>