<?php

header('Content-Type: text/html; charset=utf-8');

include_once "php/config.php";



$id_produto = $_POST['id_produto'];

	$FR_COD = $_POST['F_COD'];
	
	$FR_DATA = $_POST['F_DATA'];

	$FR_NOME = $_POST['F_NOME'];

	$FR_CC = $_POST['F_CC'];

	$FR_MARCA = $_POST['F_MARCA'];

	$FR_END = $_POST['F_END'];
  	
	$FR_CIDADE = $_POST['F_CIDADE'];
	
	$FR_ESTADO = $_POST['F_ESTADO'];
	
	$FR_CEP = $_POST['F_CEP'];
	 	
	$FR_EMAIL = $_POST['F_EMAIL'];

	$FR_TEL = $_POST['F_TEL'];

	$FR_CEL = $_POST['F_CEL'];



if($FR_COD != "" && $FR_NOME != "" && FR_CC != "" && $FR_MARCA != "" && $FR_TEL != ""){

	$up = "UPDATE fonecedor SET

	FOR_COD = '$FR_COD',
	
	FOR_DATA = '$FR_DATA',
	
	FOR_NOME = '$FR_NOME',
	
	FOR_CC = '$FR_CC',
	
	FOR_MARCA = '$FR_MARCA',
	
	FOR_END = '$FR_END',
	
	FOR_CIDADE = '$FR_CIDADE',
	
	FOR_ESTADO = '$FR_ESTADO',
	
	FOR_CEP = '$FR_CEP',
	
	FOR_EMAIL = '$FR_EMAIL', 
	
	FOR_TEL = '$FR_TEL',
	
	FOR_CEL = '$FR_CEL'
	
	WHERE FOR_ID = '$id_produto'";
	
	$cad = mysql_query($up);

	

	echo "<script>alert('Fornecedor alterado com sucesso');location.href='alterar_fornecedor.php?tr=$id_produto'; </script>";

}

else{

	echo "<script>alert('Verifique se um dos campos abaixo não foi definido:\\n - CÓDIGO\\n - NOME\\n - CPF/CNPJ\\n - MARCA\\n -  TELEFONE');location.href='javascript:window.history.go(-1)'; </script>";

	exit();

}

?>