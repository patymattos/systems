<?php
	
  $data = array();
  function add_person( $projetos,$dat, $rest, $marco_estacao, $ce, $cn, $ae, $ao, $dg, $lat, $lon, $crea, $emr, $datum, $sl, $slon, $salt, $equipamento, $fonte, $mcf, $ci )
  {
  global $data;

  $data []= array(
  'projetos' => $projetos,
  'dat' => $dat,
  'rest' => $rest,
  'marco_estacao' => $marco_estacao,
  'ce' => $ce,
  'cn' => $cn,
  'ae' => $ae,
  'ao' => $ao,
  'dg' => $dg,
  'lat' => $lat,
  'lon' => $lon,
  'crea' => $crea,
  'emr' => $emr,
  'datum' => $datum,
  'sl' => $sl,
  'slon' => $slon,
  'salt' => $salt,
  'equipamento' => $equipamento,
  'fonte' => $fonte,
  'mcf' => $mcf,
  'ci' => $ci,
  );
  
  }

  if ( $_FILES['file']['tmp_name'] )
  {
  $dom = DOMDocument::load( $_FILES['file']['tmp_name'] );
  $rows = $dom->getElementsByTagName( 'Row' );
  $projetos_row = true;
  foreach ($rows as $row)
  {
  if ( !$projetos_row )
  {
  $projetos = "";
  $dat = "";
  $rest = "";
  $marco_estacao = "";
  $ce = "";
  $cn = "";
  $ae = "";
  $ao = "";
  $dg = "";
  $lat = "";
  $lon = "";
  $crea = "";
  $emr = "";
  $datum = "";
  $sl = "";
  $slon = "";
  $salt = "";
  $equipamento = "";
  $fonte = "";
  $mcf = "";
  $ci = "";

  $cad_projetos = 1;
  $cells = $row->getElementsByTagName( 'Cell' );
  foreach( $cells as $cell )
  {
  $ind = $cell->getAttribute( 'cad_projetos.php' );
  if ( $ind != null ) $cad_projetos = $ind;

  if ( $cad_projetos == 1 ) $projetos = $cell->nodeValue;
  if ( $cad_projetos == 2 ) $dat = $cell->nodeValue;
  if ( $cad_projetos == 3 ) $rest = $cell->nodeValue;
  if ( $cad_projetos == 4 ) $marco_estacao = $cell->nodeValue;
  if ( $cad_projetos == 5 ) $ce = $cell->nodeValue;
  if ( $cad_projetos == 6 ) $cn = $cell->nodeValue;
  if ( $cad_projetos == 7 ) $ae = $cell->nodeValue;
  if ( $cad_projetos == 8 ) $ao = $cell->nodeValue;
  if ( $cad_projetos == 9 ) $dg = $cell->nodeValue;
  if ( $cad_projetos == 10 ) $lat = $cell->nodeValue;
  if ( $cad_projetos == 11) $lon = $cell->nodeValue;
  if ( $cad_projetos == 12 ) $crea = $cell->nodeValue;
  if ( $cad_projetos == 13 ) $emr = $cell->nodeValue;
  if ( $cad_projetos == 14 ) $datum = $cell->nodeValue;
  if ( $cad_projetos == 15 ) $sl = $cell->nodeValue;
  if ( $cad_projetos == 16 ) $slon = $cell->nodeValue;
  if ( $cad_projetos == 17 ) $salt = $cell->nodeValue;
  if ( $cad_projetos == 18 ) $equipamento = $cell->nodeValue;
  if ( $cad_projetos == 19 ) $fonte = $cell->nodeValue;
  if ( $cad_projetos == 20 ) $mcf = $cell->nodeValue;
  if ( $cad_projetos == 21 ) $ci = $cell->nodeValue;

  $cad_projetos += 1;
  }
  add_person( $projetos, $dat, $rest, $marco_estacao, $ce, $cn, $ae, $ao, $dg, $lat, $lon, $crea, $emr, $datum, $sl, $slon, $salt, $equipamento, $fonte, $mcf, $ci );
  }
  $projetos_row = false;
  }
  }
  
  
      
    
    
  ?>
 
  
  
  <?php foreach( $data as $row ) {
 $host = 'localhost';
 $user = 'tlgeoco_tlgeoit';
 $pass = 't1l1g5e7o8';
 $db = 'tlgeoco_tlgeo';
 
   
	
	$con = mysql_connect($host, $user, $pass);
	 mysql_select_db($db);

   	if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

   mysql_select_db($db, $con);
   
 	$projetos = ( $row['projetos'] );
 	$dat = ( $row['dat'] );
 	$rest = ( $row['rest'] );
	$marco_estacao= ( $row['marco_estacao'] );
	$ce = ( $row['ce'] );
	$cn = ( $row['cn'] );
	$ae = ( $row['ae'] );
	$ao = ( $row['ao'] );
	$dg = ( $row['dg'] );
	$lat = ( $row['lat'] );
	$lon = ( $row['lon'] );
	$crea = ( $row['crea'] );
	$emr = ( $row['emr'] );
	$datum = ( $row['datum'] );
	$sl = ( $row['sl'] );
	$slon = ( $row['slon'] );
	$salt = ( $row['salt'] );
	$equipamento = ( $row['equipamento'] );
	$fonte = ( $row['fonte'] );
	$mcf = ( $row['mcf'] );
	$ci = ( $row['ci'] );
	
	  
  mysql_query("INSERT INTO macro (id, proj, data, rtec, m_estacao, c_e, c_n, a_e, a_o, d_g, latitude, longitude, crea, e_m_r, datum, s_lat, s_lon, s_alt, equipamento, fonte, m_f, c_i)
            VALUES ('', '$projetos', '$dat','$rest', '$marco_estacao', '$ce', '$cn', '$ae', '$ao', '$dg', '$lat', '$lon', '$crea', '$emr', '$datum', '$sl', '$slon', '$salt', '$equipamento', '$fonte', '$mcf', '$ci')") or die(mysql_error());



   } ?>

  <script languagem ="JavaScript">
alert ("Cadastro realizado com sucesso!");
</script>