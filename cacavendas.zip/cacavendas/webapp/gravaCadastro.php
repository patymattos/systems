<?php
session_start();

//Caso o usuario nao esteja logado, volta para o login
if ( !isset($_SESSION['user']) )  {
	header("location: ../index.php");
}

include_once("conexao.php");

$dados = $_POST;

$km 	= $dados["km"];
$km 	= str_replace(".","",$km);
$km 	= str_replace(",",".",$km);
$km 	= doubleval($km);

$ano 	= intval($dados["ano"]);

$dados["km"] 	= $km;
$dados["ano"] 	= $ano;

if (isset($_POST['id'])) {
	$id	= $_POST["id"];
} else {
	$id = 0;
}

if ($id==0) {
	$gravou = salvar("veiculo",$dados);
} else {
	
	unset($dados["id"]);
	$gravou = atualizar("veiculo",$dados,"id=" . $id);
}


if ($id <= 0)
	header("location:../cadastro.php?st=".$gravou);
else
	header("location:../editaCadastro.php?id=".$id."&st=".$gravou);


?>