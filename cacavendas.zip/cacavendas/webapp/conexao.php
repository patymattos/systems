<?php

$path = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'PEAR';
set_include_path(get_include_path() . PATH_SEPARATOR . $path);

include_once("PEAR.php");
include_once("DB.php");

//CONFIGURACAO PEAR
//$dsn = "mysql://root@127.0.0.1/sao_sebastiao";

$dsn = "mysql://swcenter_sebasti:u7y@localhost/swcenter_sebastiao";

$options=array(
	"debug" => 2,
);

global $conexao;

$conexao =& DB::connect($dsn, $options);
if(PEAR::isError($conexao)) {
	die($conexao->getMessage());
}





function salvar($tabela, $dados) {
	
	global $conexao;
	
	$res = $conexao->autoExecute($tabela, $dados, DB_AUTOQUERY_INSERT);
	
	if (PEAR::isError($res)) {
		die($res->getMessage());
		return false;
	}
	
	return $res;
	
}

function atualizar($tabela, $dados, $condicao) {
	
	global $conexao;
	
	
	$res = $conexao->autoExecute($tabela, $dados, DB_AUTOQUERY_UPDATE, $condicao);
	
	if (PEAR::isError($res)) {
		die($res->getMessage());
		return false;
	}
	
	
	return $res;
}

function query($sql) {
	
	global $conexao;
	
	$res = $conexao->query($sql);
	
	if (PEAR::isError($res)) {
	    die($res->getMessage());
	    return false;
	}
	
	return $res;
	
}

function get($sql) {
	
	global $conexao;
	
	$res =& $conexao->getAssoc($sql);
	
	if (PEAR::isError($res)) {
	    die($res->getMessage());
	}
	
	return $res;
}

function excluir($sql) {
	global $conexao;
	
	$res =& $conexao->query($sql);
	
	if (PEAR::isError($res)) {
	    die($res->getMessage());
	    return false;
	}
	
	return true;
}

//PRODUCAO
//$conexao = mysql_connect("localhost","swcenter_sebasti","0o9i8u7y");
//mysql_select_db("swcenter_sebastiao",$conexao);

//DESENVOLVIMENTO
//$conexao = mysql_connect("127.0.0.1","root","");
//mysql_select_db("sao_sebastiao",$conexao);


?>