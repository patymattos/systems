<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	
	$COM_REF =$_POST['C_REF'];

	$COM_NOME =$_POST['C_NOME'];
	
	$COM_PORC =$_POST['C_PORC'];
  	
	$COM_PROD =$_POST['C_PROD'];
	
	$COM_SERV =$_POST['C_SERV'];
	
	

	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO comissao (CM_REF,CM_NOME,CM_PORC,CM_PROD,CM_SERV)
	VALUES ('$COM_REF','$COM_NOME','$COM_PORC','$COM_PROD','$COM_SERV')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_comissao.php");



?>	

 