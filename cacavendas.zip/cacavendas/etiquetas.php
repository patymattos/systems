<?php
session_start();
include ("php/config.php");
include_once "php/valida_sessao.php";

require('fpdf/PDF_Label.php');

$evento2				= $_POST['evento2'];
$id 					= $_POST['id2'];
$title 					= $_POST['title2'];
$familyname 			= $_POST['familyname2'];
$givenname	 			= $_POST['givenname2'];
$namebagde				= $_POST['nametothebagde2'];
$affiliation 			= $_POST['affiliation2'];
$instituicao2 			= $_POST['instituicao2'];
$mailingadress 			= $_POST['mailingadress2'];
$city2 					= $_POST['city2'];
$provincestate			= $_POST['provincestate2'];
$country				= $_POST['country2'];
$zipcode				= $_POST['zipcode2'];
$email					= $_POST['email2'];
$phone 					= $_POST['phone2'];
$fax					= $_POST['fax2'];
$accompanying			= $_POST['accompanyingperson2'];
$letter 				= $_POST['letter2'];
$profissional 			= $_POST['profissional2'];
$student 				= $_POST['student2'];
$accompanying2 			= $_POST['accompanyingperson3'];
$family					= $_POST['family2'];
$especialidade	 		= $_POST['especialidade2'];
$cpf		 			= $_POST['cpf2'];
$identidade				= $_POST['identidade2'];
$resident				= $_POST['resident2'];
$gerentologia			= $_POST['gerentologia2'];
$congnitiva 			= $_POST['congnitiva2'];
$paleativos				= $_POST['paleativos2'];
$incapacidade 			= $_POST['incapacidade2'];

/*
echo "id = " .$id."<br>";
echo "title = " .$title."<br>";
echo "familyname = " . $familyname."<br>";
echo "givenname = " . $givenname."<br>";
echo "namebagde = " . $namebagde."<br>";
echo "affiliation = ". $affiliation."<br>";
echo "mailingadress = ". $mailingadress."<br>";
echo "city = ". $city2."<br>";
echo "provincestate = ". $provincestate."<br>";
echo "country = ". $country."<br>";
echo "zipcode = ". $zipcode."<br>";
echo "email = ". $email."<br>";
echo "phone = ". $phone."<br>";
echo "fax = ". $fax."<br>";
echo "accompanying = ". $accompanying."<br>";
echo "letter = ". $letter."<br>";
echo "profissional = ". $profissional."<br>";
echo "student = ". $student."<br>";
echo "accompanyng = ". $accompanying2."<br>";
echo "formpagamento = ". $formpagamento."<br>";
echo "cartao = ". $cartao."<br>";
echo "namecredit = ". $namecredit."<br>";
echo "especialidade = ". $especialidade."<br>";
echo "cpf = ". $cpf."<br>";
echo "identidade = ". $identidade."<br>";
echo "resident = ". $resident."<br>";
echo "gerentologia = ". $gerentologia."<br>";
echo "congnitiva = ". $congnitiva."<br>";
echo "paleativos = ". $paleativos."<br>";
echo "incapacidade = ". $incapacidade."<br>";
echo "family = ".$family."<br>";
*/

$busca = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '$evento2'");


$pdf = new PDF_Label('6082');
$pdf->AddPage();

// Print labels
// tirando o negrito
// montando a tabela com os dados (presumindo que a consulta já foi feita)
if ($fetchinscricoes['nome_evento'] == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){
	while( $row = mysql_fetch_array($busca) )
	{
		$text = sprintf("%s\n%s\n%s\n%s %s %s", strtoupper($row['nametothebagde']), strtoupper($row['especialidade']), strtoupper($row['instituicao']." - ".$row['provincestate']),"","","");
		$pdf->Add_Label($text);
	}
}
else{
	while( $row = mysql_fetch_array($busca) )
	{
		$text = sprintf("%s\n%s\n%s\n%s %s %s", strtoupper($row['title'])." ".strtoupper($row['nametothebagde']), strtoupper($row['instituicao']." - ".$row['city']),strtoupper($row['country']),"","","");
		$pdf->Add_Label($text);
	}
}


// exibindo o PDF
$pdf->Output();
?>