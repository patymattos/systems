<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          
         
		   //validar C_ID
           if (d.FU_NOME.value == ""){
                     alert("Informe  o nome do funcion�rio.");
                     d.FU_NOME.focus();
                     return false;
           }
                
         
		 //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.FU_TEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_TEL.focus();
                   return false;
         }
         
		 if (isNaN(d.FU_CEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_CEL.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvarfun.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
              <td><span class="style5 style4">Tipo:</span></td>
              <td><select name="FU_TIPO">
                  <option>VENDEDOR</option>
                  <option>MEC&Acirc;NICO</option>
                  <option>BORRACHEIRO</option>
              </select></td>
            </tr>
            <tr>
              <td width="115"><span class="style4">Nome Completo: </span></td>
              <td width="415"><input name="FU_NOME" type="text" id="FU_NOME" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">CPF/CNPJ:</span></td>
              <td><input name="FU_CC" type="text" id="FU_CC" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">RG:</span></td>
              <td><input name="FU_RG" type="text" id="FU_RG" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">Endere&ccedil;o:</span></td>
              <td><input name="FU_END" type="text" id="FU_END" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Cidade:</span></td>
              <td><input name="FU_CIDADE" type="text" id="FU_CIDADE" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Estado:</span></td>
              <td><input name="FU_ESTADO" type="text" id="FU_ESTADO" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Cep:</span></td>
              <td><input name="FU_CEP" type="text" id="FU_CEP" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Email:</span></td>
              <td><input name="FU_EMAIL" type="text" id="FU_EMAIL" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Telefone:</span></td>
              <td><input name="FU_TEL" type="text" id="FU_TEL" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Celular:</span></td>
              <td><input name="FU_CEL" type="text" id="FU_CEL" size="65" /></td>
            </tr>
                    <tr> 
                              <td colspan="2">                                <div align="center">
                                  <br>
                                  <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
                      </div></td>
                    </tr>
  </table>
</form>
</body>
</html>