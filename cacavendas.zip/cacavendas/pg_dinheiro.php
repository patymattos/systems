<?php

include_once "php/config.php";

$id_forn = $_GET['ex'];



$sql	= "UPDATE despesas SET DV_DINHEIRO = '1' WHERE DV_ID = '$id_forn'";

$resultado = mysql_query($sql);



echo "<script>location.href='despesas.php';</script>";

?>