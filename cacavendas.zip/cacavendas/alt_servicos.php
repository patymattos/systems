<?php

header('Content-Type: text/html; charset=utf-8');

include_once "php/config.php";



$id_serv = $_POST['id_serv'];



$ref 	= $_POST['S_REF'];

$nome 	= $_POST['S_NOME'];

$desc 	= $_POST['S_DESC'];

$custo 	= $_POST['S_CUSTO'];
$ccom 	= $_POST['S_COM'];



if($custo != "" && $ref != "" && $nome != ""){

	$up = "UPDATE servicos SET

	SER_REF		='$ref',

	SER_NOME	='$nome',

	SER_DESC	='$desc',

	SER_CUSTO	='$custo',
	
	SER_COM	='$ccom'

	WHERE SER_ID= '$id_serv'";

	$cad = mysql_query($up);

	

	echo "<script>alert('Serviço alterado com sucesso');location.href='cad_servicos.php'; </script>";

}

else{

	echo "<script>alert('Verifiqque se um dos campos abaixo não foi definido:\\n - Referência\\n - Serviço\\n - Preço custo\\n');location.href='javascript:window.history.go(-1)'; </script>";

	exit();

}

?>