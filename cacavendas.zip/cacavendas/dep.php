<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          //validar D_VALOR
         if (d.D_DATA.value == ""){
                   alert("O campo data deve ser preenchido!");
                   d.D_DATA.focus();
                   return false;
         }
         
		   //validar D_MOTIVO
           if (d.D_MOTIVO.value == ""){
                     alert("O campo motivo deve ser preenchido!");
                     d.D_MOTIVO.focus();
                     return false;
           }
         //validar senha
         if (d.senha.value == ""){
                   alert("O campo " + d.senha.name + " deve ser preenchido!");
                   d.senha.focus();
                   return false;
         }
         //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         if (d.telefone.value == ""){
                   alert ("O campo " + d.telefone.name + " deve ser preenchido!");
                   d.telefone.focus();
                   return false;
         }
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.telefone.value)){
                   alert ("O campo " + d.telefone.name + " deve conter apenas numeros!");
                   d.telefone.focus();
                   return false;
         }
         
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvardespesas.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td><span class="style4">Tipo:</span></td>
              <td><select name="D_TIPO" id="D_TIPO">
                <option>Despesa</option>
                <option>Vale</option>
              </select></td>
            </tr>
            <tr>
              <td width="93"><span class="style4">Data:</span></td>
              <td width="437"><span class="style4">
              <input name="D_DATA" type="text" size="40">
    (yyyy-mm-dd)</span></td>
            </tr>
            <tr>
              <td><span class="style4">Motivo:</span></td>
              <td><input name="D_MOTIVO" type="text" size="40"></td>
            </tr>
            <tr>
              <td><span class="style4">Valor: </span></td>
              <td><input name="D_VALOR" type="text" id="D_VALOR" size="40" /></td>
            </tr>
                    <tr> 
                              <td colspan="2">                                <div align="center">
                                  <br>
                                  <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
                      </div></td>
                    </tr>
  </table>
</form>
</body>
</html>