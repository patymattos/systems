<?php
 include "php/config.php";
 $noticias=$_POST['noticias'];
 $id=$_POST['id'];  
 $update = mysql_query("UPDATE noticias SET noticias = '$noticias' WHERE id = '$id'") or die(mysql_error());
 header("location:incluirnot.php")
?>