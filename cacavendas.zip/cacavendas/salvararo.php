<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################
	
	$PD_DATA =$_POST['vec'];
	
	$PD_REFERENCIA =$_POST['ref'];

	$PD_COM =$_POST['ano'];

	$PD_ARO =$_POST['aro'];
	
	$PD_NOME =$_POST['nome'];
  	
	$PD_DESCRICAO =$_POST['desc'];
  	
	$PD_MARCA =$_POST['marca'];
	
	$PD_QUANTIDADE =$_POST['quant'];
	
	$PD_VALOR =$_POST['venda'];
	 	
	$PD_CUSTO =$_POST['custo'];
	
	$PD_FORN =$_POST['obs'];
	
	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO produtos (PRD_ID,PRD_DATA,PRD_REFERENCIA,PRD_ARO,PRD_ANO,PRD_NOME,PRD_DESCRICAO,PRD_MARCA,PRD_QUANTIDADE,PRD_VENDA,PRD_CUSTO,PRD_OBS)
	VALUES ( '','$PD_DATA','$PD_REFERENCIA','$PD_ARO','$PD_COM','$PD_NOME', '$PD_DESCRICAO','$PD_MARCA','$PD_QUANTIDADE','$PD_VALOR','$PD_CUSTO','$PD_FORN')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_prod.php");



?>	

 