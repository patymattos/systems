<? 

session_start();

include "php/valida_sessao.php";

$tipo_evento = $_GET['evento'];

$selecionar_todos = $_GET['todos'];



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">



<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= True Life Geomensura =-</title>

	<script type="text/javascript" src="js/funcoes.js"></script>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

	<script language="javascript" type="text/javascript">

	function Atualiza(){

	  tipo=document.form.evento.value;

	  if (tipo == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){

      	location.href='adm_etiquetas.php?evento='+tipo;

	  }else	  if (tipo == 'XIV International Conference on Strangeness in Quark Matter'){

      	location.href='adm_etiquetas.php?evento='+tipo;

	  }else	  if (tipo == '30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE'){

      	location.href='adm_etiquetas.php?evento='+tipo;

	  }

	}  

   </script>

</head>





<body onload="javascript:Atualiza();">

<? include_once "inc_topo.php"; ?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>

    <td width="578" valign="top">

	  <table width="570" border="0" align="center">

      <tr>

        <td align="left">&nbsp;</td>

      </tr>

      <tr>

        <td><? include "php/inc_adm_manografia.php"; ?></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table>

	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</body>

</html>