<?php
 include "php/config.php";
 $noticias=$_POST['noticias'];
 $insert=mysql_query("INSERT INTO noticias(noticias) VALUES('$noticias')");
 header("location:incluirnot.php");
?>