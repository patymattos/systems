<link rel="stylesheet" type="text/css" href="css/sddm.css" >

<br />

<div class="navbar">

<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem" >CADASTRO</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

         <div class="subItem"><a href="cad_clientes.php">Clientes</a></div>
             
      
	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->

<br>

<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem" >ESTOQUE</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

         <div class="subItem"><a href="cad_produtos.php">Produtos</a></div>
		 <div class="subItem"><a href="cad_servicos.php">Servi�os</a></div>
       
      
	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem" >PR�-VENDAS</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

         <div class="subItem"><a href="cad_vendas.php">Or�amento</a></div>
        
      
	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->
<br>

  <!-- *********************************Start Menu****************************** -->
</div>        

</div>

<div class="mainDiv" >

<div class="topItem"  >SISTEMA</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

		<div class="subItem"><a href="php/sair.php">Sair</a></div>

	</div>

</div>

</div>

<!-- *********************************End Menu****************************** -->

<script type="text/javascript" src="js/xpmenuv21.js"></script>

</div>

<br />