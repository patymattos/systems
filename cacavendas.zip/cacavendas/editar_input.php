<?php
session_start();
include ("php/valida_sessao.php");
include"php/config.php";
$tipo		= $_GET['tipo'];
$nome2		= $_GET['id'];
$resultado 	= mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
$xx 		= mysql_fetch_array($resultado);
$id_evento  = $xx['id'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<title>-= Meta Marketing e Eventos =-</title>
</head>
<body>

<?php include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><?php include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>
		 <form action="php/editar_input2.php" method="post" name="form">
	 	  <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
	       <tr>
    	      <td align="center" bgcolor="#FFFFFF" colspan="2">
				<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" />
          	  </td>
	       </tr>
	       <tr>
          	  <td align="center" class="titulo" colspan="2">:: Selecione o Tipo de Formul�rio ::</td>
           </tr>
		   <tr>
 			  <td width="296"> Escolha o tipo:</td>
	 		  <td width="505">
               <select name="tipo" onblur="selecao()" onchange="selecao()">
    	   	   <?php
				  echo '<option value="'.$tipo.'">'.$tipo.'<br>';
			   echo '</select>';
			  echo '</td>';
		   echo '</tr>';
			if(($tipo == "password") or ($tipo == "text")){
		  	//se a verifica��o do tipo do select j� tiver sido escolhida ele verificar� se o nome do select j� foi escolhido tamb�m
 	  		//if($nome2 != ""){
	  			$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo' AND nome='$nome2'");
				$x 	= mysql_fetch_array($sql);
				$nome_campo	= $x['nome_campo'];
				$idd		= $x['id'];
				$size		= $x['size'];
				$maxlength	= $x['maxlength'];
				$nome		= $x['nome'];
				
				//pega o id para atualizar o campo_obrigat�rio
				$sqll 	= mysql_query("SELECT * FROM campo_obrigatorio WHERE id_evento='$id_evento' AND nome='$nome'");
				$z		= mysql_fetch_array($sqll);
				$id3	= $z['id'];
				
			   echo '<tr>';
			   echo '<td>';
				   echo 'Nome do Campo';
			   echo '</td>';
		       echo '<td>';
					echo '<input type="text" name="nome_input" value="'.$nome.'">';
			   echo '</td>';
			echo '</tr>';
			  echo '<tr>';
			  	echo '<td>Campo ser� obrigat�rio:</td>';
			  	echo '<td><select name="obrigatorio">';
					echo '<option value=""></option>';
					echo '<option value="nao">N�o</option>';
					echo '<option value="sim">Sim</option>';
					echo '</select>';
				echo '</td>';
			  echo '</tr>';
			   echo '<tr>';
			   echo '<td>';
				   echo 'Atributos do Campo';
			   echo '</td>';
		       echo '<td>';
					echo '<input type="text" name="nome" value="'.$nome_campo.'">';
			   echo '</td>';
			echo '</tr>';
			  echo '<tr>';
			  	echo '<td>Estilo de fonte:</td>';
			  	echo '<td><input type="text" name="estilo_fonte" size="10"  value="verdana"/></td>';
			  echo '</tr>';
			   echo '<tr>';
				echo '<td>';
			   		echo 'Tamanho do campo:';
			   echo '</td>';
		       echo '<td>';
					echo '<input type="text" name="size" value="'.$size.'" size="6">';
			   echo '</td>';
			echo '</tr>';
			   echo '<tr>';
				echo '<td>';
			   		echo 'M�ximo de caracter permitido:';
			   echo '</td>';
		       echo '<td>';
					echo '<input type="text" name="maxlength" value="'.$maxlength.'" size="6">';
			   echo '</td>';
			echo '</tr>';
			}elseif(($tipo == "radio") or ($tipo == "checkbox")or ($tipo == "select")){
			
		  	//se a verifica��o do tipo do select j� tiver sido escolhida ele verificar� se o nome do select j� foi escolhido tamb�m
 	  		//if($nome2 != ""){
	  			$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo' AND nome='$nome2'");
				$x 	= mysql_fetch_array($sql);
				$nome_campo			= $x['nome_campo'];
				$idd				= $x['id'];
				$size				= $x['size'];
				$maxlength			= $x['maxlength'];
				$nome_campo_input	= $x['nome_campo_input'];
				
				//pega o id para atualizar o campo_obrigat�rio
				$sqll 	= mysql_query("SELECT * FROM campo_obrigatorio WHERE id_evento='$id_evento' AND nome_campo_input='$nome_campo_input'");
				$z		= mysql_fetch_array($sqll);
				$id3	= $z['id'];
				
	    	  echo '<tr>';
			   echo '<td>';
				   echo 'Nome do Input:';
			   echo '</td>';
			   echo '<td>';
			   		echo '<input type="text" name="nome_campo_input" value="'.$nome_campo_input.'">';
			   echo '</td>';
			   echo '</tr>';
			  echo '<tr>';
			  	echo '<td>Campo ser� obrigat�rio:</td>';
			  	echo '<td><select name="obrigatorio">';
					echo '<option value="nao">N�o';
					echo '<option value="sim">Sim';
					echo '</select>';
				echo '</td>';
			  echo '</tr>';
	    	  echo '<tr>';
			   echo '<td>';
				   echo 'Nome do Campo:';
			   echo '</td>';
			   echo '<td>';
			   		echo '<input type="text" name="nome3" value="'.$nome2.'">';
			   echo '</td>';
			   echo '</tr>';
			   echo '<tr>';
				echo '<td>';
			   		echo 'Atributos do campo:';
			   echo '</td>';
		       echo '<td>';
					echo '<input type="text" name="nome" value="'.$nome_campo.'">';
			   echo '</td>';
			}
			    /*$num=mysql_num_rows($sql);
		    }else{  
		  		$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo'");	
	   	  	    $num2=mysql_num_rows($sql);
		  	}
			echo "num1 = ".$num."<br>";
			echo "2 = ".$num2."<br>";
			exit();*/

		echo '</table>';
		echo '<input type="hidden" name="idd" value="'.$idd.'">';
		echo '<input type="hidden" name="id3" value="'.$id3.'">';	
		echo '<input type="hidden" name="tipo" value="'.$tipo.'">';
		echo '<input type="hidden" name="id" value="'.$id_evento.'">';
       echo '</form>';
      echo '</td>';
     echo '</tr>';
  echo '<tr>';
   echo '<td>';
   		echo '<a href="javascript:history.go(-1)">Voltar</a>';
   echo '</td>';
  echo '</tr>';
    echo '</table>';
   echo '</td>';
  echo '</tr>';
 echo '</table>'; 
 include_once "inc_rodape.php"; 
echo '</body>';
echo '</html>';