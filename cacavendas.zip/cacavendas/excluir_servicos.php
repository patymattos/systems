<?php
include_once "php/config.php";
$id_serv = $_GET['ex'];

$sql	= "UPDATE servicos SET SER_ATIVO = '0' WHERE SER_ID = '$id_serv'";
$resultado = mysql_query($sql);

echo "<script>location.href='cad_servicos.php';</script>";
?>