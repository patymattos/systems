<?

include ("config.php");


$id		= $_GET['id'];
$exclui_foto = mysql_query("SELECT * FROM eventos WHERE id ='".$id."'");
$linha = mysql_fetch_array($exclui_foto);
$foto = $linha['foto_evento'];
if(!isset($foto)){
unlink("../../..$foto");
}
$sql	= "
			DELETE FROM eventos
			WHERE id='$id'
		  ";
$resultado = mysql_query($sql);

Header("Location: ../adm_eventos.php");

?>