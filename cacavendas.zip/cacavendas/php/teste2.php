<?
//Conexão ao Banco de dados local
$conexao = mysql_connect("localhost","metaeven_galeria","metawbeventos");
$db = mysql_select_db("metaeven_meta");

$simposio 		= $_POST["simposio"];
$poster			= $_POST["poster"];
$ordem 			= $_POST["ordem"];

if (strlen($simposio) > 0){
	$condicao3 = "WHERE tipo='1' ";
}
if ((strlen($poster) > 0) and (strlen($simposio) > 0)){
	$condicao3 .= "AND tipo='0'";
}elseif (strlen($poster) > 0){
	$condicao3 = "WHERE tipo='0' ";
}

//consulta sql
$SQL 		= "SELECT * FROM trabalhos $condicao3 $ordem";  
$executa 	= mysql_query($SQL)or die(mysql_error());
$num 		= mysql_num_rows($executa);

// definimos o tipo de arquivo
header("Content-type: application/msword");

// Como será gravado o arquivo
header("Content-Disposition: attachment; filename=relatorio_inscricao.doc");

// montando a tabela
echo "<table style='border-top:1px solid #000;'>";
  echo "<tr>
			<td colspan=".($count -1)." align='left'><b>INSCRI&Ccedil;&Otilde;ES<br /></b>".date('d-m-Y')."<br /><br /></td>
			<td align='center' colspan='2'><img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' align='center' border='0' width='125' /></td>
		</tr>
</table>
<table border='1'>";
		for($i=0;$i<$num;$i++){
			$rs = mysql_fetch_array($executa);
			if (strlen($rs['check1'])>0){
				$check = "check1";
			}elseif (strlen($rs['check2'])>0){
				$check = "check2";
			}elseif (strlen($rs['check3'])>0){
				$check = "check3";
			}
			if (strlen($poster)>0){
					echo "<tr>";
					  echo "<td align='left' bgcolor='#F2F2F2' width='200'><b>Avaliador:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['email_avaliador']."</b></td>
					</tr>";
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Comentário do Avaliador:</b></td>
					  <td align='left' bgcolor='#F2F2F2'><b>".$rs['comentario']."</b></td>
					</tr>"; 
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Eixo Temático:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs[$check]."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Título:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['titulo']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Autor Principal:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['autor']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Co-Autores:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['coautores']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Autor Inscrito no Evento:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['autorevento']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Instituições:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['instrucoes']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Email**:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['email']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Palavras-Chave:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['palavrachave']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b></b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['conteudo']."</b></td>
					</tr>";
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#FFFFFF' height='40'><b></b></td>";
					  echo "<td align='left' bgcolor='#FFFFFF' height='40'><b></b></td>
					</tr>";
			}
			
			
			if (strlen($simposio)>0){
					echo "<tr>";
					  echo "<td align='left' bgcolor='#F2F2F2' width='200'><b>Avaliador:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['email_avaliador']."</b></td>
					</tr>";
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Comentário do Avaliador:</b></td>
					  <td align='left' bgcolor='#F2F2F2'><b>".$rs['comentario']."</b></td>
					</tr>"; 
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Eixo Temático:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs[$check]."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Tema Simpósio:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['temasimposio']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Coordenador:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['coordenador']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Email:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['email']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Palestra 1:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['paletra1']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b>Palestrante 1:</b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['palestrante1']."</b></td>
					</tr>";  
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#F2F2F2'><b></b></td>";
					  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['conteudo1']."</b></td>
					</tr>";
					if (strlen($rs['palestrante2'])>0){
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b>Comentário do Avaliador:</b></td>
							  <td align='left' bgcolor='#F2F2F2'><b>".$rs['comentario2']."</b></td>
							</tr>"; 
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b>Palestrante 2:</b></td>";
							  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['palestrante2']."</b></td>
							</tr>";  
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b></b></td>";
							  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['conteudo2']."</b></td>
							</tr>";
					}
					if (strlen($rs['palestrante3'])>0){
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b>Comentário do Avaliador:</b></td>
							  <td align='left' bgcolor='#F2F2F2'><b>".$rs['comentario3']."</b></td>
							</tr>"; 
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b>Palestrante 3:</b></td>";
							  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['palestrante3']."</b></td>
							</tr>";  
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b></b></td>";
							  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['conteudo3']."</b></td>
							</tr>";
					}
					if (strlen($rs['palestrante4'])>0){
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b>Comentário do Avaliador:</b></td>
							  <td align='left' bgcolor='#F2F2F2'><b>".$rs['comentario4']."</b></td>
							</tr>"; 
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b>Palestrante 4:</b></td>";
							  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['palestrante4']."</b></td>
							</tr>";  
							echo "<tr>";  
							  echo "<td align='left' bgcolor='#F2F2F2'><b></b></td>";
							  echo "<td align='left' bgcolor='#F2F2F2'><b>".$rs['conteudo4']."</b></td>
							</tr>";
					}
					echo "<tr>";  
					  echo "<td align='left' bgcolor='#FFFFFF' height='40'><b></b></td>";
					  echo "<td align='left' bgcolor='#FFFFFF' height='40'><b></b></td>
					</tr>";
			}
		}
		echo "</table>"; 
?>