<?
include"config.php";
$id_inscricoes=$_GET['id_inscricoes'];
//echo "SELECT * FROM inscricoes WHERE id = '".$id_inscricoes."'";
//exit();
$select = "SELECT * FROM inscricoes WHERE id ='".$id_inscricoes."'";
$sql = mysql_query($select) or die ("Quary: ".$select." : ".mysql_error());
$x = mysql_fetch_array($sql);
if (isset($_POST['editar_eventos']))
{
$select_eve = "SELECT * FROM eventos WHERE nome_evento = '".$x['nome_evento']."'";
$sql_eve = mysql_query($select_eve);
$result_eve = mysql_fetch_array($sql_eve);
	$id_evento = $result_eve['id'];

	$nome_evento 		= $_POST['nome_evento'];
	$title				= $_POST['title'];
	$familyname			= $_POST['familyname'];
	$givenname			= $_POST['givenname'];
	$nametothebagde		= $_POST['nametothebagde'];
	$cpf				= $_POST['cpf'];
	$identidade			= $_POST['identidade'];
	$Affiliation		= $_POST['Affiliation'];
	$instituicao		= $_POST['instituicao'];
	$especialidade		= $_POST['especialidade'];
	$email_novo			= $_POST['email_novo'];
	$mailingadress		= $_POST['mailingadress'];
	$city				= $_POST['city'];
	$provincestate		= $_POST['provincestate'];
	$country			= $_POST['country'];
	$zipcode			= $_POST['zipcode'];
	$phone				= $_POST['phoneddi'].$_POST['phoneddd'].$_POST['phone'];
	$fax				= $_POST['faxddi'].$_POST['faxddd'].$_POST['fax'];
    $formpagamento		= $_POST['formpagamento'];
	$cartao				= $_POST['cartao'];
	$namecredit			= $_POST['namecredit'];
	$datacartao			= $_POST['datacartao'];
	$numcredit			= $_POST['numcredit'];
	$expiracartao		= $_POST['expiracartao'];
	$securitycode		= $_POST['securitycode'];
	$totalescolhido 	= $_POST['totalescolhido'];


	$data = $_POST['data_pg'];; // Data no formato MySQL
	$aux = explode("-",$data); // Faz a separa��o da data em itens
	$data_pg = $aux[0]."-".$aux[1]."-".$aux[2];

	 if($formpagamento == 'deposito'){
	 $numero_pg			=$_POST['num_deposito'];
	 $valor_pg			=$_POST['valor_deposito'];
	 }
	 elseif($formpagamento == 'boleto'){
	 $numero_pg			=$_POST['num_boleto'];
	 $valor_pg			=$_POST['valor_boleto'];
	 }
	 elseif($formpagamento == 'empenho'){
	 $numero_pg			=$_POST['num_empenho'];
	 $valor_pg			=$_POST['valor_empenho'];
	 $instituicao_pg	=$_POST['instituicao_empenho'];
	 }
	 elseif($formpagamento == 'transferencia'){
	 $numero_pg			=$_POST['num_transferencia'];
	 $valor_pg			=$_POST['valor_transferencia'];
	 $E_pg				=$_POST['e_transferencia_pg'];
	 $R_pg				=$_POST['r_transferencia_pg'];
	 $U_pg				=$_POST['u_transferencia_pg'];
	 }
	 elseif($formpagamento == 'cartao_credito_debito'){
	 $numero_pg			=$_POST['num_cartao_pg'];
	 $valor_pg			=$_POST['valor_cartao'];
	 $nome_cartao_pg	=$_POST['nome_cartao_pg'];
	 $validade_cartao_pg=$_POST['validade_cartao_pg'];
	 $codigo_cartao_pg	=$_POST['codigo_cartao_pg'];
	 $E_pg				=$_POST['e_cartao_pg'];
	 $R_pg				=$_POST['r_cartao_pg'];
	 $U_pg				=$_POST['u_cartao_pg'];
	 }
	 elseif($formpagamento == 'cash'){
	 $valor_pg			=$_POST['valor_cash'];
	 $E_pg				=$_POST['e_cash_pg'];
	 $R_pg				=$_POST['r_cash_pg'];
	 $U_pg				=$_POST['u_cash_pg'];
	 $troco_pg			=$_POST['troco_cash'];
	 }
	 elseif($formpagamento == 'cheque'){
	 $numero_pg			=$_POST['num_cheque'];
	 $valor_pg			=$_POST['valor_cheque'];
	 $banco_cheque_pg	=$_POST['banco_cheque'];
	 $ag_cheque_pg		=$_POST['ag_cheque'];
	 $conta_cheque_pg	=$_POST['conta_cheque'];
	 }
	 elseif($formpagamento == 'cortesia'){
	 $cortesia_pg		=$_POST['cortesia'];
	 }
	 
	 $texto_recibo_pg	=$_POST['texto_recibo_pg'];
	 $texto_anuidade_pg	=$_POST['texto_anuidade_pg'];
	 $texto_observacoes_pg	=$_POST['texto_observacoes_pg'];

#### colocar  a condi��o para cada um dos eventos. ####
if($id_evento == 406){
	
	if((strlen($_POST['check1'])>0) or (strlen($_POST['check2'])>0) or (strlen($_POST['check3'])>0) or (strlen($_POST['check4'])>0) or (strlen($_POST['check5'])>0) or (strlen($_POST['check6'])>0) or (strlen($_POST['check7'])>0) or (strlen($_POST['check8'])>0) or (strlen($_POST['check9'])>0) or (strlen($_POST['check10'])>0) or (strlen($_POST['check11'])>0) or (strlen($_POST['check12'])>0) or (strlen($_POST['check13'])>0) or (strlen($_POST['check14'])>0) or (strlen($_POST['check15'])>0) or (strlen($_POST['check16'])>0)){
	 $check1			=$_POST['check1'];
	 $check2			=$_POST['check2'];
	 $check3			=$_POST['check3'];
	 $check4			=$_POST['check4'];
	 $check5			=$_POST['check5'];
	 $check6			=$_POST['check6'];  
	 $check7			=$_POST['check7'];
	 $check8			=$_POST['check8'];  
	 $check9			=$_POST['check9'];
	 $check10			=$_POST['check10'];
	 $check11			=$_POST['check11'];
	 $check12			=$_POST['check12'];
	 $check13			=$_POST['check13'];
	 $check14			=$_POST['check14'];
	 $check15			=$_POST['check15'];
	 $check16			=$_POST['check16'];

	 $totalescolhido	=$check1+$check2+$check3+$check4+$check5+$check6+$check7+$check8+$check9+$check10+$check11+$check12+$check13+$check14+$check15+$check16; 
	
		if ($check1!=""){ 
			$sociosquites="S�cios Quites /  At� 02/10/2009";
		}else{
			$sociosquites="";
		} 
		if ($check2!="" && $check1!=""){ 
			$sociosquites2=" / No Evento";
		}else if ($check2!=""){
			$sociosquites2="S�cios Quites / No Evento";
		}else if ($check2==""){
			$sociosquites2="";
		}
	
		if ($check3!=""){ 
			$naosocios="N�o S�cios /  At� 02/10/2009";
		}else{
			$naosocios="";
		} 
	
		if ($check3!="" && $check4!=""){ 
			$naosocios2=" / No Evento";
		}else if ($check4!=""){
			$naosocios2="N�o S�cios / No Evento";
		}else if ($check4==""){
			$naosocios2="";
		}
	
		if ($check5!=""){ 
			$residentes="Residentes /  At� 02/10/2009";
		}else{
		  $residentes="";
		} 
	
		if ($check5!="" && $check6!=""){ 
			$residentes2=" / No Evento";
		}else if ($check6!=""){
			$residentes2="Residentes / No Evento";
		}else if ($check6==""){
			$residentes2="";
		}
	
		if ($check7!=""){ 
			$estudantesdegraduacao="Estudantes de Gradua��o /  At� 02/10/2009";
		}else{
			$estudantesdegraduacao="";
		}
	
		if ($check7!="" && $check8!=""){ 
			$estudantesdegraduacao2=" / No Evento";
		}else if ($check8!=""){
			$estudantesdegraduacao2="Estudantes de Gradua��o / No Evento";
		}else if ($check8==""){
			$estudantesdegraduacao2="";
		}
	
		if ($check9!=""){ 
			$cursogerontologia="Curso Gerontologia /  At� 02/10/2009";
			$quantger=$quantger+1;
		}else{
			$cursogerontologia="";
		} 
		if ($check9!="" && $check10!=""){ 
			$cursogerontologia2=" / No Evento";
			$quantger2=$quantger2+1;
		}else if ($check10!=""){
			$cursogerontologia2="Curso Gerontologia / No Evento";
			$quantger2=$quantger2+1;
		}else if ($check10==""){
			$cursogerontologia2="";
		}
	
		if ($check11!=""){ 
			$oficina01avaliacaocognitiva="Oficina 01 Avalia��o Cognitiva /  At� 02/10/2009";
			$quantcog=$quantcog+1;
		}else{
			$oficina01avaliacaocognitiva="";
		} 
	
		if ($check11!="" && $check12!=""){ 
			$oficina01avaliacaocognitiva2=" / No Evento";
			$quantcog2=$quantcog2+1;
		}else if ($check12!=""){
			$oficina01avaliacaocognitiva2="Oficina 01 Avalia��o Cognitiva / No Evento";
			$quantcog2=$quantcog2+1;
		}else if ($check12==""){
			$oficina01avaliacaocognitiva2="";
		}	 
	
		if ($check13!=""){ 
			$oficina02cuidadospaliativos="Oficina 02 Cuidados Paliativos /  At� 02/10/2009";
			$quantpali=$quantpali+1;
		}else{
			$oficina02cuidadospaliativos="";
		} 
	
		if ($check13!="" && $check14!=""){ 
			$oficina02cuidadospaliativos2=" / No Evento";
			$quantpali2=$quantpali2+1;
		}else if ($check14!=""){
			$oficina02cuidadospaliativos2="Oficina 02 Cuidados Paliativos / No Evento";
			$quantpali2=$quantpali2+1;
		}else if ($check14==""){
			$oficina02cuidadospaliativos2="";
		}	 
	
		if ($check15!=""){ 
			$encontrocomespecialistaincapacidade="Encontro com Especialista Incapacidade /  At� 02/10/2009";
			$quantinc=$quantinc+1;
		}else{
			$encontrocomespecialistaincapacidade="";
		} 
	
		if ($check15!="" && $check16!=""){ 
			$encontrocomespecialistaincapacidade2=" / No Evento";
			$quantinc2=$quantinc2+1;
		}else if ($check16!=""){
			$encontrocomespecialistaincapacidade2="Encontro com Especialista Incapacidade / No Evento";
			$quantinc2=$quantinc2+1;
		}else if ($check16==""){
			$encontrocomespecialistaincapacidade2="";
		}
	
		$accompanyingperson2 					= $sociosquites.$sociosquites2;
		$Profissional 							= $naosocios.$naosocios2;
		$student 								= $estudantesdegraduacao.$estudantesdegraduacao2;
		$Residente 								= $residentes.$residentes2;
		$Cursogerontologia						= $cursogerontologia.$cursogerontologia2;
		$Oficina01avaliacaocognitiva			= $oficina01avaliacaocognitiva.$oficina01avaliacaocognitiva2;
		$Oficina02cuidadospaliativos			= $oficina02cuidadospaliativos.$oficina02cuidadospaliativos2;
		$Encontrocomespecialistaincapacidade	= $encontrocomespecialistaincapacidade.$encontrocomespecialistaincapacidade2;
		
		
	}
	 else{
	 $totalescolhido 						= $x['totalescolhido'];
	 $accompanyingperson2 					= $x['accompanyingperson2'];
	 $Profissional 							= $x['profissional'];
	 $student 								= $x['student'];
	 $Residente 							= $x['residente'];
	 $Cursogerontologia						= $x['gerentologia'];
	 $Oficina01avaliacaocognitiva			= $x['congnitiva'];
	 $Oficina02cuidadospaliativos			= $x['paleativos'];
	 $Encontrocomespecialistaincapacidade	= $x['incapacidade'];
	 }
	 
}
elseif($id_evento == 4){
		if((strlen($_POST['check1'])>0) or (strlen($_POST['check2'])>0) or (strlen($_POST['check3'])>0) or (strlen($_POST['check4'])>0) or (strlen($_POST['check5'])>0) or (strlen($_POST['check6'])>0) or (strlen($_POST['check7'])>0) or (strlen($_POST['check8'])>0) or (strlen($_POST['check9'])>0) or (strlen($_POST['check10'])>0) or (strlen($_POST['check11'])>0) or (strlen($_POST['check12'])>0) or (strlen($_POST['check13'])>0) or (strlen($_POST['check14'])>0) or (strlen($_POST['check15'])>0) or (strlen($_POST['check16'])>0) or (strlen($_POST['check17'])>0) or (strlen($_POST['check18'])>0) or (strlen($_POST['check19'])>0) or (strlen($_POST['check20'])>0) or (strlen($_POST['check21'])>0) or (strlen($_POST['check22'])>0)){
	 $check1			=$_POST['check1'];
	 $check2			=$_POST['check2'];
	 $check3			=$_POST['check3'];
	 $check4			=$_POST['check4'];
	 $check5			=$_POST['check5'];
	 $check6			=$_POST['check6'];  
	 $check7			=$_POST['check7'];
	 $check8			=$_POST['check8'];  
	 $check9			=$_POST['check9'];
	 $check10			=$_POST['check10'];
	 $check11			=$_POST['check11'];
	 $check12			=$_POST['check12'];
	 $check13			=$_POST['check13'];
	 $check14			=$_POST['check14'];
	 $check15			=$_POST['check15'];
	 $check16			=$_POST['check16'];
	 $check17			=$_POST['check17'];
	 $check18			=$_POST['check18'];  
	 $check19			=$_POST['check19'];
	 $check20			=$_POST['check20'];
	 $check21			=$_POST['check21'];  
	 $check22			=$_POST['check22'];

	$totalescolhido	= $check1+$check2+$check3+$check4+$check5+$check6+$check7+$check8+$check9+$check10+$check11+$check12+$check13+$check14+$check15+$check16+$check17+$check18+$check19+$check20+$check21+$check22; 
	
	if (($check1!="") or $check2!=""){ 
   		$profissional="PROFESSIONAL /  UNTIL OCT, 23th";
	}else{
    	$profissional="";
	} 

	if (($check3!="") or $check4!=""){ 
   		$profissional2="PROFESSIONAL /  UNTIL OCT, 23th + IACM";
	}else{
    	$profissional2="";
	} 

	if (($check5!="") or $check6!=""){ 
   		$profissional3="PROFESSIONAL / ON-SITE";
	}else{
    	$profissional3="";
	} 

	if (($check7!="") or $check8!=""){ 
   		$postgraduatestudent="GRADUATE STUDENT / UNTIL OCT, 23th";
	}else{
    	$postgraduatestudent="";
	} 

	if (($check9!="") or $check10!=""){ 
   		$postgraduatestudent2="GRADUATE STUDENT / UNTIL OCT, 23th + IACM";
	}else{
    	$postgraduatestudent2="";
	}

	if (($check11!="") or $check12!=""){ 
   		$postgraduatestudent3="GRADUATE STUDENT / ON-SITE";
	}else{
    	$postgraduatestudent3="";
	}

	if (($check13!="") or $check14!=""){ 
   		$graduatestudent="UNDERGRADUATE STUDENT / UNTIL OCT, 23th";
	}else{
    	$graduatestudent="";
	}

	if (($check15!="") or $check16!=""){ 
   		$graduatestudent2="UNDERGRADUATE STUDENT / UNTIL OCT, 23th + IACM";
	}else{
    	$graduatestudent2="";
	}

	if (($check17!="") or $check18!=""){ 
   		$graduatestudent3="UNDERGRADUATE STUDENT / ON-SITE";
	}else{
    	$graduatestudent3="";
	}

	if (($check19!="") or $check20!=""){ 
   		$aditionalwork ="ADITIONAL WORK / ON-SITE";
	}else{
    	$aditionalwork="";
	}

	if (($check21!="") or $check22!=""){ 
   		$cilamcedinner  ="CILAMCE 2009 DINNER  / ON-SITE";
	}else{
   	$cilamcedinner="";
	}
	$Profissional2		 	= $profissional.$profissional2.$profissional3;
	$Postgraduatestudent	= $postgraduatestudent.$postgraduatestudent2.$postgraduatestudent3;
	$Graduatestudent		= $graduatestudent.$graduatestudent2.$graduatestudent3;
	$Aditionalwork			= $aditionalwork.$aditionalwork2;
	$Cilamcedinner			= $cilamcedinner.$cilamcedinner2;
	
	$Profissional			= $Profissional2;
	$student				= $Postgraduatestudent;
	$Residente				= $Graduatestudent;
	$Cursogerontologia		= $Aditionalwork;
	$Oficina01avaliacaocognitiva = $Cilamcedinner;
		
		
	}
	 else{
	 $totalescolhido 						= $x['totalescolhido'];
	 $accompanyingperson2 					= $x['accompanyingperson2'];
	 $Profissional 							= $x['profissional'];
	 $student 								= $x['student'];
	 $Residente 							= $x['residente'];
	 $Cursogerontologia						= $x['gerentologia'];
	 $Oficina01avaliacaocognitiva			= $x['congnitiva'];
	 $Oficina02cuidadospaliativos			= $x['paleativos'];
	 $Encontrocomespecialistaincapacidade	= $x['incapacidade'];
	 }

}


	$query	= "UPDATE inscricoes SET 
	nome_evento 		= '".$nome_evento."',
	title				= '".$title."',
	familyname			= '".$familyname."',
	givenname			= '".$givenname."',
	nametothebagde		= '".$nametothebagde."',
	cpf					= '".$cpf."',
	identidade			= '".$identidade."',
	Affiliation			= '".$Affiliation."',
	instituicao			= '".$instituicao."',
	especialidade		= '".$especialidade."',
	email				= '".$email_novo."',
	mailingadress		= '".$mailingadress."',
	city				= '".$city."',
	provincestate		= '".$provincestate."',
	country				= '".$country."',
	zipcode				= '".$zipcode."',
	fax					= '".$fax."',
	accompanyingperson	= '".$accompanyingperson."',
	profissional		= '".$Profissional."',
	student				= '".$student."',
	residente			= '".$Residente."',
	gerentologia		= '".$Cursogerontologia."',
	congnitiva			= '".$Oficina01avaliacaocognitiva."',
	paleativos			= '".$Oficina02cuidadospaliativos."',
	incapacidade		= '".$Encontrocomespecialistaincapacidade."',
	accompanyingperson2 = '".$accompanyingperson2."',
	formpagamento		= '".$formpagamento."',
	data_pg				= '".$data_pg."',

	numero_pg			='".$numero_pg."', 
	valor_pg			='".$valor_pg."', 
	instituicao_pg		='".$instituicao_pg."', 
	R_pg				='".$R_pg."', 
	E_pg				='".$E_pg."', 
	U_pg				='".$U_pg."', 
	nome_cartao_pg		='".$nome_cartao_pg."', 
	validade_pg			='".$validade_cartao_pg."', 
	codigo_seguranca_pg	='".$codigo_cartao_pg."', 
	troco_pg			='".$troco_pg."', 
	banco_pg			='".$banco_cheque_pg."', 
	ag_pg				='".$ag_cheque_pg."', 
	conta_cheque_pg		='".$conta_cheque_pg."', 
	cortesia_pg			='".$cortesia_pg."', 
	data_pg				='".$data_pg."', 
	texto_recibo_pg		='".$texto_recibo_pg."', 
	texto_anuidade_pg	='".$texto_anuidade_pg."', 
	texto_observacoes_pg='".$texto_observacoes_pg."',	
	
	cartao				= '".$cartao."',
	namecredit			= '".$namecredit."',
	datacartao			= '".$datacartao."',
	numcredit			= '".$numcredit."',
	expiracartao		= '".$expiracartao."',
	securitycode		= '".$securitycode."',
	totalescolhido		= '".$totalescolhido."',
	phone				= '".$phone."'

	WHERE id='".$id_inscricoes."'";
	 //echo $query;
	 //exit();

	$result	= mysql_query($query);
	
	$data_hora_atual = date("y.m.d H:i:s");
	$update = "UPDATE usuarios SET data_hora = '".$data_hora_atual."' WHERE email ='".$x['email']."'";
	$agora = mysql_query($update);

	Header("Location: ../adm_inscricoes.php");
}
?>