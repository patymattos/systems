<?
include"config.php";

$y = mysql_query("SELECT * FROM eventos WHERE id = '".$_GET['id']."'");
if ($x = mysql_fetch_array($y))

{
$h = "SELECT * FROM cedente WHERE id_evento = '".$_GET['id']."'";
$consulta_cedente = mysql_query($h) or die ("Query error: ".$h." : ".mysql_error());
$b = mysql_fetch_array($consulta_cedente);

echo '
<form name="form1" method="post" action="php/alterar_db_eventos.php?id='.$x[id].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="id_evento" value="'.$x[id].'" />
<table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
          <tr>
		    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
          </tr>
		  <tr>
            <td align="center" class="titulo" colspan="2">Visualizar Evento</td>
          </tr>
		  <tr>
			<td>Id do Evento:</td>
			<td>'.$x[id].'</td>
		  </tr>
		  <tr>
			<td width="296">Nome do Evento:</td>
			<td width="505"><input name="evento" value="'.$x[nome_evento].'" type="text" id="evento" size="50" /></td>
		  </tr>
		  <tr>
			<td>Tipo do Evento:</td>
			<td><select name="tipo_evento">
			  <option>-= Escolha o Tipo do Evento =-</option>
			  <option value="1">EVENTOS T&Eacute;CNICOS-CIENT&Iacute;FICOS</option>
			  <option value="2">ORGANIZA&Ccedil;&Otilde;ES NO EXTERIOR</option>
			  <option value="3">FEIRAS E EXPOSI&Ccedil;&Otilde;ES</option>
			  <option value="4">MONTAGEM DE ESTANDES</option>
			  <option value="5">EVENTOS ESPORTIVOS</option>
			  <option value="6">EVENTOS CULTURAIS</option>
			  <option value="7">OUTRAS PRODU&Ccedil;&Otilde;ES</option>
			  <option value="8">FORMATURAS</option>
			  <option value="9">MARKETING POL&Iacute;TICO</option>
			</select></td>
		  </tr>
		  <tr>
			<td>Data inicial do evento:</td>
			<td><input name="data_evento_inicio" value="'.date('d/m/Y', strtotime($x[data_evento_inicio])).'" type="text" id="data_evento_inicio" size="10" maxlength="10"  onkeypress="barra(this)" /></td>
		  </tr>
		  <tr>
			<td>Data final do evento:</td>
			<td><input name="data_evento_final" value="'.date('d/m/Y', strtotime($x[data_evento_final])).'" type="text" id="data_evento_final" size="10" maxlength="10" onkeypress="barra(this)" /></td>
		  </tr>
		  <tr>
			<td>Local a ser realizado o evento:</td>
			<td><input name="local_evento" value="'.$x[local_evento].'" type="text" id="local_evento" size="50" /></td>
		  </tr>
		  <tr>
			<td>Promo��o:</td>
			<td><input name="promocao" type="text" id="promocao" size="50" value="'.$x[promocao].'" /></td>
		  </tr>
		  <tr>
			<td>Patroc�nio:</td>
			<td><input name="patrocinio" type="text" id="patrocinio" size="50" value="'.$x[patrocinio].'" /></td>
		  </tr>
		  <tr>
			<td>Apoio:</td>
			<td><input name="apoio" type="text" id="apoio" size="50" value="'.$x[apoio].'" /></td>
		  </tr>
		  <tr>
			<td>Montagens:</td>
			<td><input name="montagens" type="text" id="montagens" size="50" value="'.$x[montagens].'" /></td>
		  </tr>
		  <tr>
			<td>Tem�tica:</td>
			<td><input name="tematica" type="text" id="tematica" size="50" value="'.$x[tematica].'" /></td>
		  </tr>
		  <tr>
			<td>Candidato:</td>
			<td><input name="candidato" type="text" id="candidato" size="50" value="'.$x[candidato].'" /></td>
		  </tr>
		  <tr>
			<td>Email do evento:</td>
			<td><input name="email_evento" type="text" id="email_evento" size="50" value="'.$x['email_evento'].'" /></td>
		  </tr>
		  <tr>
			<td>Link:</td>
			<td><input name="link" type="text" id="link" size="50" value="'.$x['link'].'" /></td>
		  </tr>
		  <tr>
			<td>Imagem do Evento(*):</td>
			<td><img src="https://www.metaeventos.net'.$x[foto_evento].'" /><br><input name="foto_evento" type="file" id="foto_evento" />(*) 152 X 170 px</td>
		  </tr>
		  <tr>
			<td>Imagem do Topo do Evento(*):</td>
			<td><img src="https://www.metaeventos.net/inscricoes/'.$x[topo].'" width="200" height="59" /><br><input name="foto_topo" type="file" id="foto_topo" />(*) 744 X 218 px</td>
		  </tr>
	  <tr>
        <td colspan="2">&nbsp;</td>
	  </tr>
      <tr>
      	<td colspan="2" align="center"><b>Preencher caso Forma de Pagamento for por meio de Boleto Banc�rio</b></td>
      </tr>
	  <tr>
        <td colspan="2">&nbsp;</td>
	  </tr>
	  <tr>
        <td>Tipo de Boleto:</td>
        <td>';
		if ($x['boleto'] == 1){
		echo '<input type="radio" name="unibanco" id="unibanco" checked="checked" />Unibanco</td>';
		}
		else{
		echo '<input type="radio" name="unibanco" id="unibanco" />Unibanco</td>';
		}
		echo'
	  </tr>
	  <tr>
        <td>Nome Cedente:</td>
        <td><input type="text" name="cedente" id="cedente" size="50" value="'.$b[cedente].'" /></td>
	  </tr>
	  <tr>
        <td>Ag�ncia:&nbsp;</td>';
		if($b['agencia'] == 0){
		echo'<td><input type="text" name="agencia" id="agencia" size="6" /></td>';}
		else{ echo'<td><input type="text" name="agencia" id="agencia" size="6" value="'.$b[agencia].'" /></td>';}
		echo'
	  </tr>
	  <tr>
        <td>Conta:</td>';
		if(($b['conta'] == 0) and ($b['conta_div'] == 0)){
		echo'<td><input type="text" name="conta" id="conta" size="6" />-<input type="text" name="conta_div" id="conta_div" size="2" /></td>';}
		else{echo'<td><input type="text" name="conta" id="conta" size="6" value="'.$b[conta].'" />-<input type="text" name="conta_div" id="conta_div" size="2" value="'.$b[conta_div].'" /></td>';}
		echo'
	  </tr>
	  <tr>
        <td>C�digo do Cliente:</td>';
		if($b['codigo_cliente'] == 0){
		echo'<td><input type="text" name="codigo_cliente" id="codigo_cliente" /></td>';}
		else{echo'<td><input type="text" name="codigo_cliente" id="codigo_cliente" value="'.$b[codigo_cliente].'" /></td>';}
		echo'
	  </tr>
	  <tr>
        <td>Carteira:</td>';
		if($b['carteira'] == 0){		
        echo'<td><input type="text" name="carteira" id="carteira" /></td>';}
		else{echo'<td><input type="text" name="carteira" id="carteira" value="'.$b[carteira].'" /></td>';}
		echo'
	  </tr>
	  <tr>
        <td>Dias para pagamento:</td>
        <td><input type="text" name="diap" id="diap" value="'.$b[diap].'" size="5" /></td>
	  </tr>
	  <tr>
        <td>Taxa bancaria:</td>
        <td><input type="text" name="txb" id="txb" value="'.$b[txb].'" size="5" />(adicione o valor do boleto, exemplo: "R$ 2,95")</td>
	  </tr>
	  <tr>
        <td>CPF/CNPJ:</td>
        <td><input name="cpf_cnpj" type="text" id="cpf_cnpj" onblur="validar(this)" maxlength="18" value="'.$b[cpf_cnpj].'" /></td>
	  </tr>
	  <tr>
        <td>Endere�o:</td>
        <td><input type="text" name="endereco" id="endereco" value="'.$b[endereco].'" /></td>
	  </tr>
	  <tr>
        <td>Cidade:</td>
        <td><input type="text" name="cidade" id="cidade" value="'.$b[cidade].'" />&nbsp;
        	Estado: <select name="uf">
                          <option value="" selected="selected"></option>
                          <option value="AC">AC</option>
                          <option value="AL">AL</option>
                          <option value="AM">AM</option>
                          <option value="AP">AP</option>
                          <option value="BA">BA</option>
                          <option value="CE">CE</option>
                          <option value="DF">DF</option>
                          <option value="ES">ES</option>
                          <option value="GO">GO</option>
                          <option value="MA">MA</option>
                          <option value="MG">MG</option>
                          <option value="MS">MS</option>
                          <option value="MT">MT</option>
                          <option value="PA">PA</option>
                          <option value="PB">PB</option>
                          <option value="PE">PE</option>
                          <option value="PI">PI</option>
                          <option value="PR">PR</option>
                          <option value="RJ">RJ</option>
                          <option value="RN">RN</option>
                          <option value="RO">RO</option>
                          <option value="RR">RR</option>
                          <option value="RS">RS</option>
                          <option value="SC">SC</option>
                          <option value="SE">SE</option>
                          <option value="SP">SP</option>
                          <option value="TO">TO</option>
                     </select></td>
	  </tr>
      <tr>
		<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
	  </tr>
      </table>
	</form>';		

}
?>