<?
include"config.php";

$select = "SELECT * FROM eventos WHERE id ='".$_POST['id_evento']."'";
$sql = mysql_query($select) or die ("Quary: ".$select." : ".mysql_error());
$x = mysql_fetch_array($sql);
$id = $_POST['id_evento'];
if (isset($_POST['editar_eventos']))

{
$evento 			= $_POST['evento']; 
$tipo_evento		= $_POST['tipo_evento'];
$data_evento_inicio = $_POST['data_evento_inicio'];
$data_evento_final 	= $_POST['data_evento_final'];
$local_evento 		= $_POST['local_evento'];
$promocao 			= $_POST['promocao'];
$patrocinio			= $_POST['patrocinio'];
$apoio				= $_POST['apoio'];
$montagens			= $_POST['montagens'];
$tematica			= $_POST['tematica'];
$candidato			= $_POST['candidato'];
$email_evento		= $_POST['email_evento'];
$link				= $_POST['link'];
$foto_evento 		= $_FILES['foto_evento']['name'];
$foto_topo			= $_FILES['foto_topo']['name'];
$cedente			= $_POST['cedente'];
$agencia			= $_POST['agencia'];
$conta				= $_POST['conta'];
$conta_div			= $_POST['conta_div'];
$codigo_cliente		= $_POST['codigo_cliente'];
$carteira			= $_POST['carteira'];
$diap				= $_POST['diap'];
$txb				= str_replace(",",".",$_POST['txb']);
$cpf_cnpj			= $_POST['cpf_cnpj'];
$endereco			= $_POST['endereco'];
$cidade				= $_POST['cidade'];
$uf					= $_POST['uf'];

if (isset($_POST['unibanco'])){
$boleto				= 1;
}
else{
	$boleto = 0;
}

$data_evento_inicio2 = explode("/",$data_evento_inicio);
$dataeventoinicio = $data_evento_inicio2[2].$data_evento_inicio2[1].$data_evento_inicio2[0];

$data_evento_final2 = explode("/",$data_evento_final);
$dataeventofinal = $data_evento_final2[2].$data_evento_final2[1].$data_evento_final2[0];

// imagem do evento que ficar� na p�gina principal
if (strlen($foto_evento) > 1){
$caminho_dir = "/imagem/eventos/".$foto_evento;
$status = move_uploaded_file($_FILES['foto_evento']['tmp_name'],"../../../imagem/eventos/"."$foto_evento");
}
else {
	$caminho_dir = $x['foto_evento'];
}
//imagem do topo que ficar� na p�gina de inscri��o
if (strlen($foto_topo) > 1){
$caminho_topo = "imagem/".$foto_topo;
$status2 = move_uploaded_file($_FILES['foto_topo']['tmp_name'],"../../../inscricoes/imagem/"."$foto_topo");

}
else {
	$caminho_topo = $x['topo'];
}


$query	= "
	UPDATE eventos SET 
	nome_evento 		= '".$evento."',
	tipo_evento			= '".$tipo_evento."',
	data_evento_inicio	= '".$dataeventoinicio."',
	data_evento_final	= '".$dataeventofinal."',
	local_evento		= '".$local_evento."',
	promocao			= '".$promocao."',
	patrocinio			= '".$patrocinio."',
	apoio				= '".$apoio."',
	montagens			= '".$montagens."',
	tematica			= '".$tematica."',
	candidato			= '".$candidato."',
	email_evento		= '".$email_evento."',
	link				= '".$link."',
	foto_evento			= '".$caminho_dir."',
	topo				= '".$caminho_topo."',
	boleto				= '".$boleto."'
	
	WHERE id='".$id."'";
//echo $query;
$result	= mysql_query($query);

######### ALTERANDO CEDENTE PARA O REFERIDO EVENTO #########################################################
$a = "
	UPDATE cedente SET
cedente 				= '".$cedente."',
agencia          		= '".$agencia."',
conta          			= '".$conta."',
conta_div          		= '".$conta_div."',
codigo_cliente          = '".$codigo_cliente."',
carteira          		= '".$carteira."',
diap					= '".$diap."',
txb						= '".$txb."',
cpf_cnpj          		= '".$cpf_cnpj."',
endereco          		= '".$endereco."',
cidade          		= '".$cidade."',
uf          			= '".$uf."'

WHERE id_evento = '".$id."'";
//echo "<br>";
//echo $a;
//exit();
$arquivo = mysql_query($a) or die ("Query error: ".$a." : ".mysql_error());

##############################################################################################################

Header("Location: ../adm_eventos.php");

}

?>