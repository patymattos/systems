<?
include"config.php";

$y = mysql_query("SELECT * FROM noticias WHERE id = '".$_GET['id']."'");
if ($x = mysql_fetch_array($y))

{

echo '
<form name="form1" method="post" action="php/alterar_db_noticias.php?id='.$x[id].'">
 <input type="hidden" name="editar_noticias" value="1" />
	<input type="hidden" name="id_noticias" value="'.$x[id].'" />
<table width="550" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
          <tr>
		    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="images/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
          </tr>
		  <tr>
            <td align="center" class="titulo" colspan="2">Visualizar Not�cia</td>
          </tr>
		  <tr>
			<td>Noticia:</td>
			<td><textarea name="noticias" id="noticias" cols="50" rows="15">'.$x[noticias].'</textarea></td>
		  </tr>
		 <tr>
		<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
		</tr>
        </table>
		</form>';		

}
?>