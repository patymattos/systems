<?php
include ("config.php");
?>

<table width="550" border="0" cellpadding="1" cellspacing="1" class="cor_tr">
  <form action="proc_adm_rela_trab.php" method="post" name="form">
    <tr>
        <td class='titulo' colspan="4">:: Gerar Relat�rios de Trabalhos ::</td>
    </tr>
    <tr><td class="texto" colspan="2" style="text-align:center;"><strong>Selecione o tipo de trabalho:</strong></td></tr>
    <tr>
      <td width='175' class='texto'><strong>Tipo de Trabalho:</strong></td>
   	  <td width="368" class='texto'>
	      <select name="tipo" onblur="selecao()" onchange="selecao()">
			<option value="">-= Selecione o tipo do campo =-</option>
		  	<option value="simposio">Simp�sio</option>
    		<option value="poster">P�ster</option>
	    	<option value="simposio_poster">Simp�sio / P�ster</option>
		   </select>
      </td>
    </tr>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
  </form>  
</table>
