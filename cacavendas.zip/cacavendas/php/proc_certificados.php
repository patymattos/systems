<?php
$lista 		= $_POST['lista'];
$count 		= count($lista);
$eventos 	= $_POST['eventos'];
$curso		= $_POST['curso'];
echo $eventos."<br>";
echo $curso."<br>";
for ($i=0;$i<$count;$i++){
	$lista2 = $lista[$i];
	echo $lista2."<br>";
	//dbcertificados = mysql_query("INSERT INTO certificados(nome, evento) VALUE ('$lista2', '$evento')");
}
?>
