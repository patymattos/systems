<?php
include ("config.php");
$sql = mysql_query("SELECT * FROM usuarios WHERE tipo_usuario != 'usuario'");

echo "<table width=550 border=0 cellpadding=1 cellspacing=1>";
echo "<tr>";
echo "<td class='titulo' colspan='4'>Administrar Usu�rio</td>";
echo "</tr>";
echo "<tr>";
echo "<td class='texto' width='160'><b>Email:</b></td>";
echo "<td class='texto' width='150'><b>Login:</b></td>";
echo "<td class='texto' width='150'><b>Senha:</b></td>";
echo "<td class='texto' width='45'><b>Excluir</b></td>";
echo "</tr>";

while ($linha = mysql_fetch_array($sql))
{
	$id		= $linha["id"];
	$email = $linha["email"];
	$login	= $linha["login"];
	$senha	= $linha["senha"];

	echo "<tr>";
	echo "<td class='texto'><a href='vis_usuario.php?id=$id'>$email</a></td>";
	echo "<td class='texto'><a href='vis_usuario.php?id=$id'>$login</td>";
	echo "<td class='texto'><a href='vis_usuario.php?id=$id'>xxxxxxxx</td>";
	echo "<td align='center'><a href='php/excluir_usuario.php?id=$id'><img src='images/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
	echo "</tr>";		
}

echo "</table>";

?>