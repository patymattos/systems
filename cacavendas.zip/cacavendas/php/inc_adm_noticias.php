<?php
include ("config.php");
$sql = mysql_query("SELECT * FROM noticias ORDER BY id ASC");

echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
echo "<tr>";
echo "<td class='titulo' colspan='4'>Administrar Not�cias</td>";
echo "</tr>";
echo "<tr>";
echo "<td class='texto' width='505'><b>Not�cias:</b></td>";
echo "<td class='texto' width='45'><b>Excluir</b></td>";
echo "</tr>";

while ($linha = mysql_fetch_array($sql))
{
	$id		= $linha["id"];
	$noticia = $linha["noticias"];

	echo "<tr>";
	echo "<td class='texto'><a href='vis_noticias.php?id=$id'>$noticia</a></td>";
	echo "<td align='center'><a href='php/excluir_noticias.php?id=$id'><img src='images/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
	echo "</tr>";
	echo "<tr><td colspan='2'>&nbsp;</td></tr>";
}

echo "</table>";

?>