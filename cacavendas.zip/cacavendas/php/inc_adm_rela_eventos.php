<?php
include ("config.php");
$ano =date("Y");
############# EVENTOS ############################
$select_ev = "SELECT * FROM eventos WHERE ativo=1 ORDER BY data_evento_inicio DESC";
$sql_ev = mysql_query($select_ev);
$rows_ev = mysql_num_rows($sql_ev);

##################################################
############# INSCRICOES #########################
$select_insc = "SELECT * FROM inscricoes ORDER BY familyname ASC";
$sql_insc = mysql_query($select_insc);
$rows_insc = mysql_num_rows($sql_insc);
##################################################
############# ISCRICOES DISTINTAS ################
$select_insc2 = "SELECT DISTINCT (city) FROM inscricoes ORDER BY city ASC";
$sql_insc2 = mysql_query($select_insc2);
$rows_insc2 = mysql_num_rows($sql_insc2);
##################################################
############# USUARIOS ###########################

?>

<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>
  <form action="proc_adm_rela_eventos.php" method="post" name="form">
    <tr>
        <td class='titulo' colspan=4>:: Gerar Relat�rios de Eventos ::</td>
    </tr>
    <tr><td class="texto" align="center" colspan="2"><p><strong>Escolha os Filtros:</strong></p></td></tr>
    <tr>
        <td class='texto' width='347'><b>Ano</b></td>
  		<td width="196" class='texto'>
  			<select name="ano" size="1" class="texto">
            	<option value="">---Escolha um Ano---</option>
				<?php
					for ($i=1985;$i<=$ano;$i++){
						echo '<option value="'.$i.'">'.$i.'</option>';
					}
				?>
            </select>
	  	</td>
  	</tr>
    <tr>
        <td class='texto' width='347'><b>M�s</b></td>
  		<td width="196" class='texto'>
  			<select name="mes" size="1" class="texto">
            	<option value="">---Escolha um M�s---</option>
				<?php
					for ($i=1;$i<13;$i++){
						echo '<option value="'.$i.'">'.$i.'</option>';
					}
				?>
            </select>
	  	</td>
  	</tr>
    <tr>
        <td class='texto' width='347'><b>Ou se preferir, pelo tipo de evento:</b></td>
  		<td width="196" class='texto'>
  			<select name="tipo_evento" size="1" class="texto">
            	<option value="">---Tipo de Evento---</option>
                <option value="1">EVENTOS T�CNICO-CIENT�FICOS</option>
                <option value="2">ORGANIZA��ES NO EXTERIOR</option>
                <option value="3">FEIRAS E EXPOSI��ES</option>
                <option value="4">MONTAGEM DE ESTANDES</option>
                <option value="5">EVENTOS ESPORTIVOS</option>
                <option value="6">EVENTOS CULTURAIS</option>
                <option value="7">OUTRAS PRODU��ES</option>
                <option value="8">FORMATURAS</option>
                <option value="9">MARKETING POL�TICO</option>
            </select>
            
	  	</td>
  	</tr>
    <tr><td class="texto" align="center" colspan="2"><p><strong>Selecione o(s) campo(s) para relat�rio:</strong></p></td></tr>
    <tr>
        <td width='347' class='texto'>Tipo do Evento</td>
   	  <td class='texto'><input type="checkbox" name="tipo_evento2" value="tipo_evento2" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Nome Evento</td>
   	  <td class='texto'><input type="checkbox" name="nome_evento" value="nome_evento" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Data In�cio</td>
   	  <td class='texto'><input type="checkbox" name="data_evento_inicio" value="data_evento_inicio" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Data Evento Final</td>
   	  <td class='texto'><input type="checkbox" name="data_evento_final" value="data_evento_final" /></td>
    </tr>      
    <tr>
        <td width='347' class='texto'>Local do Evento</td>
   	  <td class='texto'><input type="checkbox" name="local_evento" value="local_evento" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Promo��o</td>
   	  <td class='texto'><input type="checkbox" name="promocao" value="promocao" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Patroc�nio</td>
   	  <td class='texto'><input type="checkbox" name="patrocinio" value="patrocinio" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Apoio</td>
   	  <td class='texto'><input type="checkbox" name="apoio" value="apoio" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Montagens</td>
   	  <td class='texto'><input type="checkbox" name="montagens" value="montagens" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Tem�tica</td>
   	  <td class='texto'><input type="checkbox" name="tematica" value="tematica" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Candidato</td>
   	  <td class='texto'><input type="checkbox" name="candidato" value="candidato" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Email do Evento</td>
   	  <td class='texto'><input type="checkbox" name="email_evento" value="email_evento " /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Link do Evento</td>
   	  <td class='texto'><input type="checkbox" name="link" value="link" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>T�tulo</td>
   	  <td class='texto'><input type="checkbox" name="titulo" value="titulo" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'>Ativo</td>
   	  <td class='texto'><input type="checkbox" name="ativo" value="ativo" /></td>
    </tr>
	<tr>
	  <td width='347' class='texto'><strong>Selecionar todos:</strong></td>
	  <td class='texto'><input name='todas' type='checkbox' id='todas' value='checkbox' onClick='selecionar_todas(this.checked)'></td>
    </tr>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
    <tr>
        <td width='347' class='texto'><strong>Ordenado por:</strong></td>
  		<td class='texto'>
      		<select name="ordem" size="1" class="texto">
            	<option value="">---Escolha---</option>
                <option value="nome_evento">Nome do Evento</option>
                <option value="data_evento_inicio">Data de In�cio</option>
                <option value="data_evento_final">Data Final</option>
                <option value="tipo_evento">Tipo de Evento</option>
                <option value="local_evento">Local do Evento</option>
                <option value="promocao">Promo��o</option>
                <option value="patrocinio">Patroc�nio</option>
                <option value="apoio">Apoio</option>
                <option value="montagens">Montagens</option>
                <option value="tematica">Tem�tica</option>
                <option value="candidato">Candidato</option>
                <option value="email_evento">Email do Evento</option>
                <option value="link">Link</option>
                <option value="titulo">T�tulo</option>
                <option value="termo">Termo</option>
            </select>
        </td>
    </tr>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
    <tr>
    	<td align="center" colspan="2"><input type="submit" value="Gerar Relat�rio" /></td>
    </tr>
  </form>  
  <script type="text/javascript">
	formulario=document.form;
	function selecionar_todas(retorno){
	  if(retorno==true){
		  for(i=0;i<formulario.length;i++){
			if(formulario.elements[i].type=="checkbox" && formulario.elements[i].name!="todas"){
			  if(formulario.elements[i].checked==false){
				   formulario.elements[i].checked=true;
			  }
			}
		  }
	  } else {
		for(i=0;i<formulario.length;i++){
			if(formulario.elements[i].type=="checkbox" && formulario.elements[i].name!="todas"){
			  if(formulario.elements[i].checked==true){
				   formulario.elements[i].checked=false;
			  }
			}
		}
	  }
	}
  </script>
</table>
