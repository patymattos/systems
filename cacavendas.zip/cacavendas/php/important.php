<?php
	
  $data = array();
  function add_person( $projetos, $marco_estacao, $ce, $cn, $ae, $ao, $dg, $lat, $lon, $crea, $emr, $datum, $sl, $slon, $salt, $equipamento, $fonte, $mcf, $ci )
  {
  global $data;

  $data []= array(
  'projetos' => $projetos,
  'marco_estacao' => $marco_estacao,
  'ce' => $ce,
  'cn' => $cn,
  'ae' => $ae,
  'ao' => $ao,
  'dg' => $dg,
  'lat' => $lat,
  'lon' => $lon,
  'crea' => $crea,
  'emr' => $emr,
  'datum' => $datum,
  'sl' => $sl,
  'slon' => $slon,
  'salt' => $salt,
  'equipamento' => $equipamento,
  'fonte' => $fonte,
  'mcf' => $mcf,
  'ci' => $ci,
  );
  
  }

  if ( $_FILES['file']['tmp_name'] )
  {
  $dom = DOMDocument::load( $_FILES['file']['tmp_name'] );
  $rows = $dom->getElementsByTagName( 'Row' );
  $projetos_row = true;
  foreach ($rows as $row)
  {
  if ( !$projetos_row )
  {
  $projetos = "";
  $marco_estacao = "";
  $ce = "";
  $cn = "";
  $ae = "";
  $ao = "";
  $dg = "";
  $lat = "";
  $lon = "";
  $crea = "";
  $emr = "";
  $datum = "";
  $sl = "";
  $slon = "";
  $salt = "";
  $equipamento = "";
  $fonte = "";
  $mcf = "";
  $ci = "";

  $cad_projetos = 1;
  $cells = $row->getElementsByTagName( 'Cell' );
  foreach( $cells as $cell )
  {
  $ind = $cell->getAttribute( 'cad_projetos.php' );
  if ( $ind != null ) $cad_projetos = $ind;

  if ( $cad_projetos == 1 ) $projetos = $cell->nodeValue;
  if ( $cad_projetos == 2 ) $marco_estacao = $cell->nodeValue;
  if ( $cad_projetos == 3 ) $ce = $cell->nodeValue;
  if ( $cad_projetos == 4 ) $cn = $cell->nodeValue;
  if ( $cad_projetos == 5 ) $ae = $cell->nodeValue;
  if ( $cad_projetos == 6 ) $ao = $cell->nodeValue;
  if ( $cad_projetos == 7 ) $dg = $cell->nodeValue;
  if ( $cad_projetos == 8 ) $lat = $cell->nodeValue;
  if ( $cad_projetos == 9 ) $lon = $cell->nodeValue;
  if ( $cad_projetos == 10 ) $crea = $cell->nodeValue;
  if ( $cad_projetos == 11 ) $emr = $cell->nodeValue;
  if ( $cad_projetos == 12 ) $datum = $cell->nodeValue;
  if ( $cad_projetos == 13 ) $sl = $cell->nodeValue;
  if ( $cad_projetos == 14 ) $slon = $cell->nodeValue;
  if ( $cad_projetos == 15 ) $salt = $cell->nodeValue;
  if ( $cad_projetos == 16 ) $equipamento = $cell->nodeValue;
  if ( $cad_projetos == 17 ) $fonte = $cell->nodeValue;
  if ( $cad_projetos == 18 ) $mcf = $cell->nodeValue;
  if ( $cad_projetos == 19 ) $ci = $cell->nodeValue;

  $cad_projetos += 1;
  }
  add_person( $projetos, $marco_estacao, $ce, $cn, $ae, $ao, $dg, $lat, $lon, $crea, $emr, $datum, $sl, $slon, $salt, $equipamento, $fonte, $mcf, $ci );
  }
  $projetos_row = false;
  }
  }
  
  
      
    
    
  ?>
 
  
  <html>
  <body>
  <table>
  <tr>
  <th>Projetos</th>
  <th>Marco_Esta��o</th>
  <th>Coordenada_E</th>
  <th>Coordenada_N</th>
  <th>Altitude_Elipsoidal</th>
  <th>Altitude_Ortom�trica</th>
  <th>Desnivel_Geoidal</th>
  <th>Latitude</th>
  <th>Longitude</th>
  <th>Crea</th>
  <th>Esta��es_Marcos_de_Refer�ncia:</th>
  <th>Datum</th>
  <th>Sigma_Latitude</th>
  <th>Sigma_Longitude</th>
  <th>Sigma_Altitude</th>
  <th>Equipamento</th>
  <th>Fonte</th>
  <th>Mc_Fuso</th>
  <th>Categora_Incra</th>
  </tr>
  <?php foreach( $data as $row ) { ?>
  <tr>
  <td><?php echo( $row['projetos'] ); ?></td>
  <td><?php echo( $row['marco_estacao'] ); ?></td>
  <td><?php echo( $row['ce'] ); ?></td>
  <td><?php echo( $row['cn'] ); ?></td>
  <td><?php echo( $row['ae'] ); ?></td>
  <td><?php echo( $row['ao'] ); ?></td>
  <td><?php echo( $row['dg'] ); ?></td>
  <td><?php echo( $row['lat'] ); ?></td>
  <td><?php echo( $row['lon'] ); ?></td>
  <td><?php echo( $row['crea'] ); ?></td>
  <td><?php echo( $row['emr'] ); ?></td>
  <td><?php echo( $row['datum'] ); ?></td>
  <td><?php echo( $row['sl'] ); ?></td>
  <td><?php echo( $row['slon'] ); ?></td>
  <td><?php echo( $row['salt'] ); ?></td>
  <td><?php echo( $row['equipamento'] ); ?></td>
  <td><?php echo( $row['fonte'] ); ?></td>
  <td><?php echo( $row['mcf'] ); ?></td>
  <td><?php echo( $row['ci'] ); ?></td>
  <?php  } ?>
  
  <?php foreach( $data as $row ) {
  $host = "localhost";  // Endere�o do servidor MySQL

    $user = "tlgeoco_tlgeoit";  // Seu Login no mySQL

    $pass = "t1l1g5e7o8";  // Senha do MySql

    $db = "tlgeoco_tlgeo";  // Nome do Banco de Dados
    
	
	$con = mysql_connect($host, $user, $pass);
   	if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

   mysql_select_db($db, $con);
   
 	$projetos = ( $row['projetos'] );
	$marco_estacao= ( $row['marco_estacao'] );
	$ce = ( $row['ce'] );
	$cn = ( $row['cn'] );
	$ae = ( $row['ae'] );
	$ao = ( $row['ao'] );
	$dg = ( $row['dg'] );
	$lat = ( $row['lat'] );
	$lon = ( $row['lon'] );
	$crea = ( $row['crea'] );
	$emr = ( $row['emr'] );
	$datum = ( $row['datum'] );
	$sl = ( $row['sl'] );
	$slon = ( $row['slon'] );
	$salt = ( $row['salt'] );
	$equipamento = ( $row['equipamento'] );
	$fonte = ( $row['fonte'] );
	$mcf = ( $row['mcf'] );
	$ci = ( $row['ci'] );
	
	  
  mysql_query("INSERT INTO macro (id, proj, m_estacao, c_e, c_n, a_e, a_o, d_g, latitude, longitude, crea, e_m_r, datum, s_lat, s_lon, s_alt, equipamento, fonte, m_f, c_i)
            VALUES ('', '$projetos', '$marco_estacao', '$ce', '$cn', '$ae', '$ao', '$dg', '$lat', '$lon', '$crea', '$emr', '$datum', '$sl', '$slon', '$salt', '$equipamento', '$fonte', '$mcf', '$ci')") or die(mysql_error());



   } ?>

  </table>
  </body>
  </html>
