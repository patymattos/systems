<?php
include ("config.php");

$principais_clientes 	= $_POST['principais_clientes']; 
$id	=	$_POST['id'];

$query = mysql_query("UPDATE site SET principais_clientes='$principais_clientes' WHERE id = '$id' ");


Header("Location: ../adm_pri_clientes.php");
?>
