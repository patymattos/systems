<?
$host = 'localhost';
$user = '';
$pass = '';
$db = '';

    $a = mysql_connect($host, $user, $pass);
    mysql_select_db($db);


?>