<?php
include ("config.php");
		
		if($tipo_trabalho == 0){
			$ordem_t = "ORDER BY titulo ASC";
		}
		else{
			$ordem_t = "ORDER BY temasimposio ASC";
		}

		$sql = mysql_query("SELECT * FROM trabalhos WHERE tipo = '$tipo_trabalho' $ordem_t"); // Executa a query no MySQL com o limite de linhas.
		echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
		echo "<tr>";
			echo "<td class=titulo colspan=4>:: Administrar Emiss�es de Certificados dos Trabalhos ::</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td class='texto' width='5'><b>Qnt:</b></td>";
			if ($tipo_trabalho == 0){
			echo "<td class='texto' width='400'><b>Titulo P�ster</b></td>";
			}
			elseif ($tipo_trabalho == 1){
			echo "<td class='texto' width='400'><b>Tema Simp�sio</b></td>";
			}
			echo "<td class='texto' width='100'><center><b>E-Mail</b></center></td>";
			echo "<td class='texto' width='45'><b>Certificado</b></td>";
		echo "</tr>";
			$i = 0;
		while ($linha = mysql_fetch_array($sql)){
			$i++;
			//$id_evento = $linha["id"];
			$id_trabalho = $linha["id_trabalho"];
			$titulo = $linha["titulo"];
			$tema = $linha["temasimposio"];
			$email = $linha["email"];
			$tipo_trabalho2 = $linha["tipo"];
			echo "<tr>";
			echo "<td class='texto'><center>".$i."</center></td>";
			if ($tipo_trabalho2 == 0){
			echo "<td class='texto'>".$titulo."</td>";
			}
			elseif($tipo_trabalho2 == 1){
			echo "<td class='texto'>".$tema."</td>";
			}
			echo "<td class='texto'>".$email."</td>";
			echo "<td class='texto'><a href='certificados_trabalhos.php?id=$id_trabalho'>CERTIFICADO</a></td>";
			echo "</tr>";		
		}
		echo "</table>";
		echo "<span class='texto'><br /><br /><a href='javascript:history.go(-1)'>Voltar</a></span>";
		echo "<br />";
?>