<?
$host = 'localhost';
$user = 'tlgeoco_tlgeoit';
$pass = 't1l1g5e7o8';
$db = 'tlgeoco_tlgeo';

    $a = mysql_connect($host, $user, $pass);
    mysql_select_db($db);


?>