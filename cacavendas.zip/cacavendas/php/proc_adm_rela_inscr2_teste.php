<?php
include ("config.php");

$dia =date("d");
$mes =date("m");
$ano =date("Y");
$data =$dia."-".$mes."-".$ano;

//condi��es
$city 				= $_POST["city"];
$evento				= $_POST['evento2'];
$formpagamento 		= $_POST["formpagamento"];
$ordem				= $_POST['ordem'];

//id = 1
$id 				= $_POST["id2"];
$title 				= $_POST["title2"];
$familyname 		= $_POST["familyname2"];
$givenname	 		= $_POST["givenname2"];
$namebagde			= $_POST["nametothebagde2"];
$affiliation 		= $_POST["affiliation2"];
$mailingadress 		= $_POST["mailingadress2"];
$city2 				= $_POST["city2"];
$provincestate		= $_POST['provincestate2'];
$country			= $_POST['country2'];
$zipcode			= $_POST['zipcode2'];
$email				= $_POST['email2'];
$phone 				= $_POST["phone2"];
$fax				= $_POST["fax2"];
$accompanying		= $_POST["accompanyingperson2"];
$letter 			= $_POST["letter2"];
$profissional 		= $_POST["profissional2"];
$student 			= $_POST["student2"];
$accompanying2 		= $_POST["accompanyingperson3"];
$formpagamento2		= $_POST["formpagamento2"];
$cartao 			= $_POST["cartao2"];
$namecredit			= $_POST['namecredit2'];
$datacartao			= $_POST['datacartao2'];
$numcredit			= $_POST['numcredit2'];
$expiracartao		= $_POST['expiracartao2'];
$securitycode		= $_POST['securitycode2'];
$totalescolhido		= $_POST['totalescolhido2'];
$family				= $_POST['family2'];

//id = 406
$especialidade 		= $_POST["especialidade2"];
$cpf		 		= $_POST["cpf2"];
$identidade			= $_POST["identidade2"];
$resident			= $_POST["resident2"];
$gerentologia		= $_POST["gerentologia2"];
$congnitiva 		= $_POST["congnitiva2"];
$paleativos			= $_POST["paleativos2"];
$incapacidade 		= $_POST["incapacidade2"];



/*echo "id = " .$id."<br>";
echo "title = " .$title."<br>";
echo "familyname = " . $familyname."<br>";
echo "givenname = " . $givenname."<br>";
echo "namebagde = " . $namebagde."<br>";
echo "affiliation = ". $affiliation."<br>";
echo "mailingadress = ". $mailingadress."<br>";
echo "city = ". $city."<br>";
echo "provincestate = ". $provincestate."<br>";
echo "country = ". $country."<br>";
echo "zipcode = ". $zipcode."<br>";
echo "email = ". $email."<br>";
echo "phone = ". $phone."<br>";
echo "fax = ". $fax."<br>";
echo "accompanying = ". $accompanying."<br>";
echo "letter = ". $letter."<br>";
echo "profissional = ". $profissional."<br>";
echo "student = ". $student."<br>";
echo "accompanyng = ". $accompanying2."<br>";
echo "formpagamento = ". $formpagamento."<br>";
echo "cartao = ". $cartao."<br>";
echo "namecredit = ". $namecredit."<br>";
echo "datacartao = ". $datacartao."<br>";
echo "numcredit = ". $numcredit."<br>";
echo "expiracartao = ". $expiracartao."<br>";
echo "securitycode = ". $securitycode."<br>";
echo "totalescolhido = ". $totalescolhido."<br>";

echo "especialidade = ". $especialidade."<br>";
echo "cpf = ". $cpf."<br>";
echo "identidade = ". $identidade."<br>";
echo "resident = ". $resident."<br>";
echo "gerentologia = ". $gerentologia."<br>";
echo "congnitiva = ". $congnitiva."<br>";
echo "paleativos = ". $paleativos."<br>";
echo "incapacidade = ". $incapacidade."<br>";
echo "family = ".$family."<br>";*/


if ((strlen($id)>0) || (strlen($title)>0) || (strlen($familyname)>0) || (strlen($givenname)>0) || (strlen($nametothebagde)>0) || (strlen($affiliation)>0) || (strlen($affiliation)>0) || (strlen($mailingadress)>0) || (strlen($city)>0) || (strlen($provincestate)>0) || (strlen($country)>0) || (strlen($zipcode)>0) || (strlen($email)>0) ||  (strlen($phone)>0) || (strlen($fax)>0) || (strlen($accompanying)>0) || (strlen($letter)>0) || (strlen($profissional)>0) || (strlen($student)>0) || (strlen($accompanying2)>0) || (strlen($formpagamento)>0) || (strlen($cartao)>0) || (strlen($namecredit)>0) || (strlen($datacartao)>0) || (strlen($numcredit)>0) || (strlen($expiracartao)>0) || (strlen($securitycode)>0) || (strlen($totalescolhido)>0) || (strlen($especialidade)>0) || (strlen($cpf)>0) || (strlen($identidade)>0) || (strlen($resident)>0) || (strlen($gerentologia)>0) || (strlen($congnitiva)>0) || (strlen($paleativos)>0) || (strlen($incapacidade)>0) || (strlen($family)>0) || (strlen($data_hora)>0) || (strlen($ordem)>0)){

		if(strlen($ordem)>0){
			$ordem = "ORDER BY $ordem ASC";
		}
		
		if(strlen($evento) > 0){
			$condicao3 = "WHERE nome_evento='$evento' ";
		}
		if(strlen($formpagamento) > 0){
		   if(strlen($evento) < 1){
			$condicao3 = "WHERE formpagamento='$formpagamento'";
		   }else{
			$condicao3 .= "AND formpagamento='$formpagamento'";
		   }	
		}
		if(strlen($city) > 0){
		  if((strlen($formpagamento) < 1) and (strlen($evento) < 1)){
			$condicao3 = "WHERE city='$city'";
		  }else{
			$condicao3 .= "AND city='$city'";
		  }	
		}
		
		$condicao="";
		$condicao2="";
		if(strlen($id)> 0){
		  $condicao .= "id";
		  $condicao2 .= "id";
		}
		if(strlen($title)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "title";
		  $condicao2 .= "Title";
		}
		if(strlen($familyname)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "familyname";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "Nome Completo";
		  }else{
			  $condicao2 .= "Family Name";
		  }
		}
		if(strlen($givenname)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "givenname";
		  $condicao2 .= "Given Name";
		}
		if(strlen($family)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "Affiliation";
		  $condicao2 .= "Family";
		}
		if(strlen($namebagde)> 0){
		  if(strlen($condicao) > 0){
		    $condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "nametothebagde";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Nome do Crach�";
		  }else{
		  	$condicao2 .= "Name in the badge";
		  }
		}
		if(strlen($affiliation)> 0){
		  if(strlen($condicao) > 0){
		    $condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Institui��o";
			$condicao .= "instituicao";
			$instituicao = "instituicao";
		  }else{
		  	$condicao2 .= "Affiliation";
		  	$condicao .= "Affiliation";
		  }
		}
		if(strlen($especialidade)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "especialidade";
		  $condicao2 .= "Especialidade";
		}
		if(strlen($cpf)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "cpf";
		  $condicao2 .= "CPF";
		}
		if(strlen($identidade)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "identidade";
		  $condicao2 .= "Identidade";
		}
		if(strlen($mailingadress)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "mailingadress";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Endere�o";
		  }else{
		  	$condicao2 .= "Mailing Address";
		  }
		}
		if(strlen($city2)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "city";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Cidade";
		  }else{
		  	$condicao2 .= "City";
		  }
		}
		if(strlen($provincestate)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "provincestate";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Estado";
		  }else{
		  	$condicao2 .= "Province / state";
		  }
		}
		if(strlen($country)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "country";
		  $condicao2 .= "Country";
		}
		if(strlen($zipcode)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "zipcode";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "CEP";
		  }else{
		  	$condicao2 .= "Zip Code";
		  }
		}
		if(strlen($email)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "email";
		  $condicao2 .= "Email";
		}
		if(strlen($phone)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "phone";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Telefone";
		  }else{
		  	$condicao2 .= "Phone";
		  }
		}
		if(strlen($fax)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "fax";
		  $condicao2 .= "Fax";
		}
		if(strlen($accompanying)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "accompanyingperson";
		  $condicao2 .= "Accompanying Person";
		}
		if(strlen($letter)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "letter";
		  $condicao2 .= "Letter";
		}
		if(strlen($profissional)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "profissional";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "N�o S�cios";
		  }else{
			  $condicao2 .= "Profissional";
		  }	  
		}
		if(strlen($student)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "student";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "Estudantes de Gradua��o";
		  }elseif ($evento == "Iberian-Latin-American Congress on Computational Methods in Engineering, organized by the Brazilian Association for Computational Methods in Engineering"){
			  $condicao2 .= "Graduate Student";
		  }else{
			  $condicao2 .= "Student";
		  }
		}
		if(strlen($accompanying2)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "accompanyingperson2";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "S�cios Quites";
		  }else{
  			$condicao2 .= "Accompanying Person";
		  }
		}
		if(strlen($resident)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "residente";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Residente";
		  }elseif ($evento == "Iberian-Latin-American Congress on Computational Methods in Engineering, organized by the Brazilian Association for Computational Methods in Engineering"){
		  	$condicao2 .= "Undergraduate Student";
		  }else{
		  	$condicao2 .= "Resident";
		  }
		}
		if(strlen($gerentologia)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "gerentologia";
		  if ($evento == "Iberian-Latin-American Congress on Computational Methods in Engineering, organized by the Brazilian Association for Computational Methods in Engineering"){
		  $condicao2 .= "Aditional Work";
		  }else{
		  $condicao2 .= "Gerentologia";
		  }
		}
		if(strlen($congnitiva)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "congnitiva";
		  if ($evento == "Iberian-Latin-American Congress on Computational Methods in Engineering, organized by the Brazilian Association for Computational Methods in Engineering"){
		  $condicao2 .= "Cilamce 2009 / Dinner";
		  }else{
		  $condicao2 .= "Congnitiva";
		  }
		}
		if(strlen($paleativos)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "paleativos";
		  $condicao2 .= "Paleativos";
		}
		if(strlen($incapacidade)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "incapacidade";
		  $condicao2 .= "Incapacidade";
		}
		if(strlen($formpagamento2)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "formpagamento";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "Forma de Pagamento";
		  }else{
			  $condicao2 .= "Methods of Payment";
		  }
		}
		if(strlen($cartao)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "cartao";
		  $condicao2 .= "Card";
		}
		if(strlen($namecredit)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "namecredit";
		  $condicao2 .= "Name Card";
		}
		if(strlen($datacartao)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "datacartao";
		  $condicao2 .= "Date of the Registration";
		}
		if(strlen($numcredit)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "numcredit";
		  $condicao2 .= "Number Card";
		}
		if(strlen($expiracartao)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "expiracartao";
		  $condicao2 .= "Expiration Date";
		}
		if(strlen($securitycode)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "securitycode";
		  $condicao2 .= "Security Code";
		}
		if(strlen($totalescolhido)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "totalescolhido";
		  $condicao2 .= "Total";
		}

		$condicao2= explode(",",$condicao2);
		//consulta sql
		$SQL = "SELECT $condicao FROM inscricoes $condicao3 $ordem";  
		$executa = mysql_query($SQL)or die(mysql_error());
		echo $SQL;
		exit();
		// montando a tabela
		$count = count($condicao2);
		echo "<table border='0' width='100%'>
				  <tr>
				   <td colspan=".($count+1)." align='center'>
						<a href=javascript:history.go(-1) style='color:#000'>Voltar</a>
				   </td>
				  </tr>";
		echo "</table>";
		echo "<table border='0' width='900' cellspacing='1' bgcolor='#000000'>
				<tr>
				  <td bgcolor='#F2F2F2' colspan=".($count+1)." align='left'><b>INSCRI��ES</b>";
				  echo "<img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' border='0' width='125' align='right'>";
				  ?>
				   <form action="php/teste.php" method="post" style="text-align:center;">
					  <input type="submit" value="Download" />
					  <input type="hidden" name="city" 					value="<?=$city?>"/>
					  <input type="hidden" name="evento"				value="<?=$evento?>" />
					  <input type="hidden" name="formpagamento"			value="<?=$formpagamento?>" />
					  <input type="hidden" name="ordem"		 			value="<?=$ordem?>" />
					  <input type="hidden" name="id2"			 		value="<?=$id?>" />
					  <input type="hidden" name="title2"				value="<?=$title?>" />
					  <input type="hidden" name="familyname2" 			value="<?=$familyname?>" />
					  <input type="hidden" name="givenname2"			value="<?=$givenname?>" />
					  <input type="hidden" name="nametothebagde2" 		value="<?=$namebagde?>" />
					  <input type="hidden" name="affiliation2"			value="<?=$affiliation?>" />
					  <input type="hidden" name="mailingadress2" 		value="<?=$mailingadress?>" />
					  <input type="hidden" name="city2" 				value="<?=$city2?>" />
                      <input type="hidden" name="provincestate2" 		value="<?=$provincestate?>" />
					  <input type="hidden" name="country2" 				value="<?=$country?>"/>
					  <input type="hidden" name="zipcode2" 				value="<?=$zipcode?>" />
					  <input type="hidden" name="email2" 				value="<?=$email?>" />
					  <input type="hidden" name="phone2" 				value="<?=$phone?>" />
					  <input type="hidden" name="fax2" 					value="<?=$fax?>" />
					  <input type="hidden" name="accompanyingperson2"	value="<?=$accompanying?>" />
					  <input type="hidden" name="letter2" 				value="<?=$letter?>" />
					  <input type="hidden" name="profissional2"			value="<?=$profissional?>" />
					  <input type="hidden" name="student2" 				value="<?=$student?>" />
					  <input type="hidden" name="accompanyingperson3" 	value="<?=$accompanying2?>" />
					  <input type="hidden" name="formpagamento2" 		value="<?=$formpagamento2?>" />
					  <input type="hidden" name="cartao2" 				value="<?=$cartao?>" />
                      <input type="hidden" name="namecredit2" 			value="<?=$namecredit?>" />
					  <input type="hidden" name="datacartao2" 			value="<?=$datacartao?>"/>
					  <input type="hidden" name="numcredit2" 			value="<?=$numcredit?>" />
					  <input type="hidden" name="expiracartao2" 		value="<?=$expiracartao?>" />
					  <input type="hidden" name="securitycode2" 		value="<?=$securitycode?>" />
					  <input type="hidden" name="totalescolhido2" 		value="<?=$totalescolhido?>" />
					  <input type="hidden" name="family2"				value="<?=$family?>" />
					  <input type="hidden" name="especialidade2" 		value="<?=$especialidade?>" />
					  <input type="hidden" name="cpf2"					value="<?=$cpf?>" />
					  <input type="hidden" name="identidade2" 			value="<?=$identidade?>" />
					  <input type="hidden" name="resident2" 			value="<?=$resident?>" />
					  <input type="hidden" name="gerentologia2" 		value="<?=$gerentologia?>" />
					  <input type="hidden" name="congnitiva2" 			value="<?=$congnitiva?>" />
                      <input type="hidden" name="paleativos2" 			value="<?=$paleativos?>" />
                      <input type="hidden" name="incapacidade2" 		value="<?=$incapacidade?>" />
				  </form>
				  <?php
				  echo "".$data."</td>
				</tr>
				<tr>
				  <td bgcolor='#F2F2F2'><b>Quant</b></td>";
					 for ($i = 0; $i < $count; $i++) {
						echo "<td align='center' bgcolor='#F2F2F2'><b>".$condicao2[$i]."</b></td>";
					 }	
			   echo "</tr>";
		$i=1;
		while ($rs = mysql_fetch_array($executa)){
		//consulta tabela usuarios
		$usu = "SELECT data_hora FROM usuarios where email='".$rs["email"]."'";  
		$executausu = mysql_query($usu)or die(mysql_error());
		$numexe	= mysql_num_rows($executausu);
		if ($numexe > 0){
			$fetch = mysql_fetch_array($executausu);
		}else{
			$usueve = "SELECT data_hora FROM usuarios_eventos where email='".$rs["email"]."'";  
			$exeusu = mysql_query($usueve)or die(mysql_error());
			$fetch = mysql_fetch_array($exeusu);
		}
		
		  echo "<tr>";
			echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $i . "</td>";
			if(strlen($id) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["id"] . "</td>";
			}
			if(strlen($title) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $rs["title"] ." </td>";
			}
			if(strlen($familyname) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $rs["familyname"] . "</td>";
			}
			if(strlen($givenname) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $rs["givenname"] . "</td>";
			}
			if(strlen($family) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' bgcolor='#F2F2F2'>" . $rs["Affiliation"] . "</td>";
			}
			if(strlen($namebagde) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='100' bgcolor='#F2F2F2'>" . $rs["nametothebagde"] . "</td>";
			}
			if(strlen($affiliation) >0 ){
			 if(strlen($instituicao) > 0){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs["instituicao"] . "</td>";
			 }else{
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs["Affiliation"] . "</td>";
			 }	
			}
			if(strlen($especialidade) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs["especialidade"] . "</td>";
			}
			if(strlen($cpf) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["cpf"] . "</td>";
			}
			if(strlen($identidade) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["identidade"] . "</td>";
			}
			if(strlen($mailingadress) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["mailingadress"] . "</td>";
			}
			if(strlen($city2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["city"] . "</td>";
			}
			if(strlen($provincestate) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["provincestate"] . "</td>";
			}
			if(strlen($country) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["country"] . "</td>";
			}
			if(strlen($zipcode) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["zipcode"] . "</td>";
			}
			if(strlen($email) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["email"] . "</td>";
			}
			if(strlen($phone) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["phone"] . "</td>";
			}
			if(strlen($fax) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["fax"] . "</td>";
			}
			if(strlen($accompanying) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["accompanyingperson"] . "</td>";
			}
			if(strlen($letter) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["letter"] . "</td>";
			}
			if(strlen($profissional) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["profissional"] . "</td>";
			}
			if(strlen($student) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["student"] . "</td>";
			}
			if(strlen($accompanying2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["accompanyingperson2"] . "</td>";
			}
			if(strlen($resident) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["residente"] . "</td>";
			}
			if(strlen($gerentologia) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["gerentologia"] . "</td>";
			}
			if(strlen($congnitiva) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["congnitiva"] . "</td>";
			}
			if(strlen($paleativos) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["paleativos"] . "</td>";
			}
			if(strlen($incapacidade) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["incapacidade"] . "</td>";
			}
			if(strlen($formpagamento2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["formpagamento"] . "</td>";
			}
			if(strlen($cartao) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["cartao"] . "</td>";
			}
			if(strlen($namecredit) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["namecredit"] . "</td>";
			}
			if(strlen($datacartao) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["datacartao"] . "</td>";
			}
			if(strlen($numcredit) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["numcredit"] . "</td>";
			}
			if(strlen($expiracartao) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["expiracartao"] . "</td>";
			}
			if(strlen($securitycode) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["securitycode"] . "</td>";
			}
			if(strlen($totalescolhido) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["totalescolhido"] . "</td>";
			}
		  echo "</tr>";
		  $i++;
		}
		  echo "<tr>
				  <td colspan=".($count+1)." bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PE�ANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
														TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
				  </td>
				</tr>  
		</table> 
		<table border='0' width='100%'>
				  <tr>
				   <td colspan=".($count+1)." align='center'>
						<a href=javascript:history.go(-1) style='color:#000'>Voltar</a>
				   </td>
				  </tr>";
		echo "</table>";
}else{
  echo "<script> alert('Por Favor! escolha pelo menos 1 campo para relat�rio');location.href='javascript:window.history.go(-1)'; </script>";
}
?>