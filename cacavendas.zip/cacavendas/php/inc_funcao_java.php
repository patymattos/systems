<?
include ("config.php");
$id		 			= $_POST['id']; 
$id_evento 			= $_POST['id_evento'];
$FuncaoJava			= $_POST['FuncaoJava'];

/*echo $id."<br>";
echo $id_evento."<br>";
echo $FuncaoJava."<br>";
exit();*/
if ($id == ""){
	$query  = mysql_query("INSERT INTO funcao_java VALUES ('', '$id_evento','$FuncaoJava')") or die (mysql_error());
}else{
	$query = mysql_query("UPDATE funcao_java SET funcao = '$FuncaoJava' WHERE id = '$id'");
}
Header("Location: ../adm_FuncaoJava.php");
?>