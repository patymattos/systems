<?
include"config.php";
$id = $_GET['id'];
$y = mysql_query("SELECT * FROM usuarios WHERE id = '$id'");

if ($x = mysql_fetch_array($y))
{

echo '
<form name="form1" method="post" action="php/alterar_db_usuario.php?id='.$x[id].'">
 <input type="hidden" name="editar_usuario" value="1" />
	<input type="hidden" name="id" value="'.$x[id].'" />
	<input type="hidden" name="ip" value="'.$x[ip].'" />
	<input type="hidden" name="data" value="'.$x[data].'" />
	<input type="hidden" name="hora" value="'.$x[hora].'" />
<table width="550" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
          <tr>
		    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="images/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
          </tr>
		  <tr>
            <td align="center" class="titulo" colspan="2">Visualizar Usu�rio</td>
          </tr>
		  <tr>
			<td>E-mail:</td>
			<td><input name="email" value="'.$x[email].'" type="text" id="email" size="20" /></td>
		  </tr>
		  <tr>
			<td>Login:</td>
			<td><input name="login" value="'.$x[login].'" type="text" id="login" size="20" /></td>
		  </tr>
		  <tr>
			<td>Senha:</td>
			<td><input name="senha" value="'.$x[senha].'" type="password" id="senha" size="20" /></td>
		  </tr>
		 <tr>
		<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
		</tr>
        </table>
		</form>';		

}
?>