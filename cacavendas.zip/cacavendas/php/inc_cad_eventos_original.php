<?
include ("config.php");

$evento 			= $_POST['evento']; 
$tipo_evento		= $_POST['tipo_evento'];
$data_evento_inicio = $_POST['data_evento_inicio'];
$data_evento_final 	= $_POST['data_evento_final'];
$local_evento 		= $_POST['local_evento'];
$promocao 			= $_POST['promocao'];
$patrocinio			= $_POST['patrocinio'];
$apoio				= $_POST['apoio'];
$montagens			= $_POST['montagens'];
$tematica			= $_POST['tematica'];
$candidato			= $_POST['candidato'];
$email_evento		= $_POST['email_evento'];
$link				= $_POST['link'];
$foto_evento 		= $_FILES['foto_evento']['name'];
$foto_topo			= $_FILES['foto_topo']['name'];
$cedente			= $_POST['cedente'];
$agencia			= $_POST['agencia'];
$conta				= $_POST['conta'];
$conta_div			= $_POST['conta_div'];
$codigo_cliente		= $_POST['codigo_cliente'];
$carteira			= $_POST['carteira'];
$diap				= $_POST['diap'];
$txb				= str_replace(",",".",$_POST['txb']);
$cpf_cnpj			= $_POST['cpf_cnpj'];
$endereco			= $_POST['endereco'];
$cidade				= $_POST['cidade'];
$uf					= $_POST['uf'];

if (isset($_POST[unibanco])){
$boleto				= 1;
}
else{
$boleto 			= 0;
}

$data_evento_inicio2 = explode("/",$data_evento_inicio);
$dataeventoinicio = $data_evento_inicio2[2].$data_evento_inicio2[1].$data_evento_inicio2[0];

$data_evento_final2 = explode("/",$data_evento_final);
$dataeventofinal = $data_evento_final2[2].$data_evento_final2[1].$data_evento_final2[0];


$caminho_dir = "/imagem/eventos/".$foto_evento;
$caminho_topo = "imagem/".foto_topo;

$status = move_uploaded_file($_FILES['foto_evento']['tmp_name'],"../../../imagem/eventos/"."$foto_evento");
$status2 = move_uploaded_file($_FILES['foto_topo']['tmp_name'],"../../../inscricoes/imagem/"."$foto_topo");

$diretorio = "../../userfiles/files/".$evento;
 mkdir($diretorio);
$diretorio2 = "../../userfiles/flash/".$evento;
 mkdir($diretorio);
$diretorio3 = "../../userfiles/image/".$evento;
 mkdir($diretorio);
$diretorio4 = "../../userfiles/media/".$evento;
 mkdir($diretorio);


########## CADASTRANDO NOVO EVENTO NO BANCO DE DADOS #######################################################
$select_evento = "INSERT INTO eventos (nome_evento, tipo_evento, data_evento_inicio, data_evento_final, local_evento, promocao, patrocinio, apoio, montagens, tematica, candidato, email_evento, link, foto_evento, topo, ativo, boleto) 
VALUES ('$evento','$tipo_evento','$dataeventoinicio','$dataeventofinal','$local_evento','$promocao','$patrocinio','$apoio','$montagens','$tematica','$candidato','$email_evento','$link','$caminho_dir','$caminho_topo',0,'$boleto')";

$query_eventos = mysql_query($select_evento) or die ("Query error: ".$select_evento." : ".mysql_error());

############################################################################################################
if($boleto == 1){
########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########

$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
$resultado_consulta = mysql_fetch_array($query_consulta);

$id_evento = $resultado_consulta['id'];

########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUANTOS CEDENTE J� EXISTE #########

$select_consulta_cedente = "SELECT * FROM cedente";
$query_consulta_cedente = mysql_query($select_consulta_cedente);
$resultado = mysql_num_rows($query_consulta_cedente);

##############################################################################################################

$id_cedente = $resultado + 1;

######### CADASTRANDO CEDENTE PARA O REFERIDO EVENTO #########################################################

$select_cedente = "INSERT INTO cedente (id_cedente, cedente, agencia, conta, conta_div, codigo_cliente, carteira, diap, txb, cpf_cnpj, endereco, cidade, uf, id_evento)
VALUES ('$id_cedente','$cedente','$agencia','$conta','$conta_div','$codigo_cliente','$carteira','$diap','$txb','$cpf_cnpj','$endereco','$cidade','$uf','$id_evento')";

$query_cedente = mysql_query($select_cedente) or die ("Query error: ".$select_cedente." : ".mysql_error());

##############################################################################################################
}
Header("Location: ../adm_eventos.php");
?>
