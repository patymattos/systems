<?php

include ("config.php");



############# EVENTOS ############################

$select_ev = "SELECT * FROM eventos WHERE ativo=1 ORDER BY data_evento_inicio DESC";

$sql_ev = mysql_query($select_ev);

$rows_ev = mysql_num_rows($sql_ev);



##################################################

?>



<table width="550" border="0" cellpadding="1" cellspacing="1" class="cor_tr">

  <form action="etiquetas.php" method="post" name="form">

      <input type="hidden" name="evento2" value="<?=$tipo_evento;?>" />

    <tr>

        <td class='titulo' colspan="4">:: Gerar Manografia em PDF ::</td>
    </tr>

    <tr><td class="texto" align="center" colspan="2"><p><strong>Escolha os Filtros:</strong></p></td></tr>

    <tr>

        <td class='texto' width='347'><b>Projeto</b></td>

  		<td width="196" class='texto'>

	    <select name="evento" size="1" class="texto" onChange="javascript:Atualiza();">

        	 <?php

			   if (strlen($tipo_evento) < 1){

            	echo '<option value="">---Escolha um Projeto---</option>';

			   }else{

				echo '<option value="">'.substr($tipo_evento,0,50).'</option>';

			   }

			

				for ($i=0;$i<$rows_ev;$i++){

        			$event = mysql_fetch_array($sql_ev);



					echo '<option value="'.$event['nome_evento'].'">'.substr ($event['nome_evento'],0,50).'</option>';



				}

			?>
        </select>	  	</td>
  	</tr>

    <tr>
      <td class='texto'><b>Manografia</b></td>
      <td class='texto'><select name="evento" size="1" class="texto" onchange="javascript:Atualiza();">
          <?php

			   if (strlen($tipo_evento) < 1){

            	echo '<option value="">---Escolha a Manografia---</option>';

			   }else{

				echo '<option value="">'.substr($tipo_evento,0,50).'</option>';

			   }

			

				for ($i=0;$i<$rows_ev;$i++){

        			$event = mysql_fetch_array($sql_ev);



					echo '<option value="'.$event['nome_evento'].'">'.substr ($event['nome_evento'],0,50).'</option>';



				}

			?>
        </select>      </td>
   	</tr>

    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>

    <tr>

    	<td align="center" colspan="2"><input type="submit" value="Gerar PDF" /></td>
    </tr>
  </form>  
</table>

