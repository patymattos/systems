<?
   include("config.php"); //conexao com o banco
   Header("Content-type: application/xml; charset=iso-8859-1");
?>
      <tr>
        <td>Termo de Compromisso</td>
      </tr>
	  <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF">
		<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
      <tr>
        <td>
		<?		
		include ("js/fckeditor.php");
		$oFCKeditor = new fckeditor('termo', 530, 350);
		$oFCKeditor->Width  = '100%' ;
		$oFCKeditor->Height = '400' ;
		$oFCKeditor->BasePath = 'js/';
		$oFCKeditor->ToolbarSet = 'metalfortec' ;

		$y = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_GET['eventos']."'");
		while($x = mysql_fetch_array($y))
		{
		$id	= $x["id"];
		$termo	= $x["termo"];
		
		$oFCKeditor->Value = "$termo";
		}
		$oFCKeditor->Create();
		?>
        <input type="hidden" value="<?=$id?>" name="id" />
		</td>
      </tr>



