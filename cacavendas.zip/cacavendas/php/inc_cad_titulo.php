<?php
include ("config.php");

$titulo 	= $_POST['titulo']; 
$id	=	$_POST['id'];

$query = mysql_query("UPDATE eventos SET titulo ='$titulo' WHERE id = '$id' ");


Header("Location: ../adm_titulo2.php");
?>
