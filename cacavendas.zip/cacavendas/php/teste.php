<?
//Conexão ao Banco de dados local
include "config.php";

$dia =date("d");
$mes =date("m");
$ano =date("Y");
$data =$dia."-".$mes."-".$ano;
$city 				= $_POST["city"];
$evento				= $_POST['evento'];
$formpagamento 		= $_POST["formpagamento"];
$ordem				= $_POST['ordem'];
$result_data		= $_POST['result_data'];
//id = 1
$id 				= $_POST["id2"];
$data_inicio		= $_POST["data_inicio"];
$title 				= $_POST["title2"];
$familyname 		= $_POST["familyname2"];
$givenname	 		= $_POST["givenname2"];
$namebagde			= $_POST["nametothebagde2"];
$affiliation 		= $_POST["affiliation2"];
$mailingadress 		= $_POST["mailingadress2"];
$city2 				= $_POST["city2"];
$provincestate		= $_POST['provincestate2'];
$country			= $_POST['country2'];
$zipcode			= $_POST['zipcode2'];
$email				= $_POST['email2'];
$phone 				= $_POST["phone2"];
$fax				= $_POST["fax2"];
$accompanying		= $_POST["accompanyingperson2"];
$letter 			= $_POST["letter2"];
$profissional 		= $_POST["profissional2"];
$student 			= $_POST["student2"];
$accompanying2 		= $_POST["accompanyingperson3"];
$formpagamento2		= $_POST["formpagamento2"];
$cartao 			= $_POST["cartao2"];
$namecredit			= $_POST['namecredit2'];
$datacartao			= $_POST['datacartao2'];
$numcredit			= $_POST['numcredit2'];
$expiracartao		= $_POST['expiracartao2'];
$securitycode		= $_POST['securitycode2'];
$totalescolhido		= $_POST['totalescolhido2'];
$family				= $_POST['family2'];
$inscricoes_pagas	= $_POST['inscricoes_pagas2'];

####### FORMAS DE PAGAMENTOS ###################

$numero_pg				= $_POST['numero_pg'];
$valor_pg				= $_POST['valor_pg'];
$instituicao_pg			= $_POST['instituicao_pg'];
$R_pg					= $_POST['r_pg'];
$E_pg					= $_POST['e_pg'];
$U_pg					= $_POST['u_pg'];
$nome_cartao_pg			= $_POST['nome_cartao_pg'];
$validade_pg			= $_POST['validade_pg'];
$codigo_seguranca_pg	= $_POST['codigo_seguranca_pg'];
$troco_pg				= $_POST['troco_pg'];
$banco_pg				= $_POST['banco_pg'];
$ag_pg					= $_POST['ag_pg'];
$conta_cheque_pg		= $_POST['conta_cheque_pg'];
$cortesia_pg			= $_POST['cortesia_pg'];
$data_pg				= $_POST['data_pg'];
$texto_recibo_pg		= $_POST['texto_recibo_pg'];
$texto_anuidade_pg		= $_POST['texto_anuidade_pg'];
$texto_observacoes_pg	= $_POST['texto_observacoes_pg'];

################################################

//id = 406
$especialidade 		= $_POST["especialidade2"];
$cpf		 		= $_POST["cpf2"];
$identidade			= $_POST["identidade2"];
$resident			= $_POST["resident2"];
$gerentologia		= $_POST["gerentologia2"];
$congnitiva 		= $_POST["congnitiva2"];
$paleativos			= $_POST["paleativos2"];
$incapacidade 		= $_POST["incapacidade2"];

		if(strlen($evento) > 0){
			$condicao3 = "WHERE inscricoes.nome_evento='$evento' ";
		}
		if(strlen($formpagamento) > 0){
		   if(strlen($evento) < 1){
			$condicao3 = "WHERE inscricoes.formpagamento='$formpagamento'";
		   }else{
			$condicao3 .= "AND inscricoes.formpagamento='$formpagamento'";
		   }	
		}
		if(strlen($city) > 0){
		  if((strlen($formpagamento) < 1) and (strlen($evento) < 1)){
			$condicao3 = "WHERE inscricoes.city='$city'";
		  }else{
			$condicao3 .= "AND inscricoes.city='$city'";
		  }	
		}
		
		if((strlen($result_data)> 2)){
		  if((strlen($formpagamento) < 1) and (strlen($evento) < 1) and (strlen($city)< 1)){
			$condicao3 = "WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email";
		  }
		  elseif((strlen($formpagamento)<1) and (strlen($evento)<1) and (strlen($city)>0)){
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email AND inscricoes.city='$city'";
		  }
		  elseif((strlen($formpagamento)>0) and (strlen($evento)<1) and (strlen($city)<1)){
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email AND inscricoes.formpagamento='$formpagamento'";
		  }
		  elseif((strlen($formpagamento)>0) and (strlen($evento)>0) and (strlen($city)<1)){
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email AND inscricoes.nome_evento ='$evento' AND inscricoes.formpagamento='$formpagamento'";
		  }
		  elseif((strlen($formpagamento)>0) and (strlen($evento)<1) and (strlen($city)>0)){
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email AND inscricoes.city='$city' AND inscricoes.formpagamento='$formpagamento'";
		  }
		  elseif((strlen($formpagamento)<1) and (strlen($evento)>0) and (strlen($city)<1)){
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email AND inscricoes.nome_evento ='$evento'";
		  }
		  elseif((strlen($formpagamento)<1) and (strlen($evento)>0) and (strlen($city)>0)){
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data' AND usuarios.email = inscricoes.email AND inscricoes.city='$city' AND inscricoes.nome_evento ='$evento'";
		  }
		  else{
			$condicao3 = ",usuarios WHERE usuarios.inicio REGEXP'^$result_data$' AND usuarios.email = inscricoes.email AND inscricoes.formpagamento='$formpagamento' AND inscricoes.city='$city' AND inscricoes.nome_evento ='$evento'";
		  }
		}
		
		$condicao="";
		$condicao2="";
		if(strlen($id)> 0){
		  $condicao .= "inscricoes.id";
		  $condicao2 .= "id";
		}
		if(strlen($data_inicio)>0){
			if(strlen($condicao) > 0){
				$condicao2 .= ", ";
		  }
		  $condicao2 .= "Data Inscri&ccedil;&atilde;o";
		}
		if((strlen($data_inscr)> 0)){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }
		  if((strlen($result_data)> 2)){
		  	$condicao3 = $condicao3;
		  }
		  else{
		  	$condicao3 = str_replace("WHERE",",usuarios WHERE",$condicao3);
		  }
		  $condicao .= "usuarios.inicio";
		  $condicao2 .= "Data Inscri&ccedil;&atilde;o";
		}
		if(strlen($title)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.title";
		  $condicao2 .= "Title";
		}
		if(strlen($familyname)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.familyname";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "Nome Completo";
		  }else{
			  $condicao2 .= "Family Name";
		  }
		}
		if(strlen($givenname)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.givenname";
		  $condicao2 .= "Given Name";
		}
		if(strlen($family)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.Affiliation";
		  $condicao2 .= "Family";
		}
		if(strlen($namebagde)> 0){
		  if(strlen($condicao) > 0){
		    $condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.nametothebagde";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Nome do Crach&aacute;";
		  }else{
		  	$condicao2 .= "Name in the badge";
		  }
		}
		if(strlen($affiliation)> 0){
		  if(strlen($condicao) > 0){
		    $condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Institui&ccedil;&atilde;o";
			$condicao .= "inscricoes.instituicao";
			$instituicao = "instituicao";
		  }else{
		  	$condicao2 .= "Affiliation";
		  	$condicao .= "inscricoes.Affiliation";
		  }
		}
		if(strlen($especialidade)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.especialidade";
		  $condicao2 .= "Especialidade";
		}
		if(strlen($cpf)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.cpf";
		  $condicao2 .= "CPF";
		}
		if(strlen($identidade)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.identidade";
		  $condicao2 .= "Identidade";
		}
		if(strlen($mailingadress)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.mailingadress";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Endere&ccedil;o";
		  }else{
		  	$condicao2 .= "Mailing Address";
		  }
		}
		if(strlen($city2)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.city";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Cidade";
		  }else{
		  	$condicao2 .= "City";
		  }
		}
		if(strlen($provincestate)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.provincestate";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Estado";
		  }else{
		  	$condicao2 .= "Province / state";
		  }
		}
		if(strlen($country)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.country";
		  $condicao2 .= "Country";
		}
		if(strlen($zipcode)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.zipcode";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "CEP";
		  }else{
		  	$condicao2 .= "Zip Code";
		  }
		}
		if(strlen($email)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.email";
		  $condicao2 .= "Email";
		}
		if(strlen($phone)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.phone";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Telefone";
		  }else{
		  	$condicao2 .= "Phone";
		  }
		}
		if(strlen($fax)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.fax";
		  $condicao2 .= "Fax";
		}
		if(strlen($accompanying)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.accompanyingperson";
		  $condicao2 .= "Accompanying Person";
		}
		if(strlen($letter)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.letter";
		  $condicao2 .= "Letter";
		}
		if(strlen($profissional)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.profissional";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "N&atilde;o S&oacute;cios";
		  }else{
			  $condicao2 .= "Profissional";
		  }	  
		}
		if(strlen($student)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.student";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "Estudantes de Gradua&ccedil;&atilde;o";
		  }elseif ($evento == "30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE"){
			  $condicao2 .= "Graduate Student";
		  }else{
			  $condicao2 .= "Student";
		  }
		}
		if(strlen($accompanying2)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.accompanyingperson2";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "S&oacute;cios Quites";
		  }else{
  			$condicao2 .= "Accompanying Person";
		  }
		}
		if(strlen($resident)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.residente";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
		  	$condicao2 .= "Residente";
		  }elseif ($evento == "30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE"){
		  	$condicao2 .= "Undergraduate Student";
		  }else{
		  	$condicao2 .= "Resident";
		  }
		}
		if(strlen($gerentologia)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.gerentologia";
		  if ($evento == "30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE"){
		  $condicao2 .= "Aditional Work";
		  }else{
		  $condicao2 .= "Gerentologia";
		  }
		}
		if(strlen($congnitiva)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.congnitiva";
		  if ($evento == "30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE"){
		  $condicao2 .= "Cilamce 2009 / Dinner";
		  }else{
		  $condicao2 .= "Congnitiva";
		  }
		}
		if(strlen($paleativos)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.paleativos";
		  $condicao2 .= "Paleativos";
		}
		if(strlen($incapacidade)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.incapacidade";
		  $condicao2 .= "Incapacidade";
		}
		if(strlen($formpagamento2)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.formpagamento";
		  if ($evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
			  $condicao2 .= "Forma de Pagamento";
		  }else{
			  $condicao2 .= "Methods of Payment";
		  }
		}
		if(strlen($cartao)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.cartao";
		  $condicao2 .= "Card";
		}
		if(strlen($namecredit)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.namecredit";
		  $condicao2 .= "Name Card";
		}
		if(strlen($datacartao)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.datacartao";
		  $condicao2 .= "Date of the Registration";
		}
		if(strlen($numcredit)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.numcredit";
		  $condicao2 .= "Number Card";
		}
		if(strlen($expiracartao)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.expiracartao";
		  $condicao2 .= "Expiration Date";
		}
		if(strlen($securitycode)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.securitycode";
		  $condicao2 .= "Security Code";
		}
		if(strlen($numero_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.numero_pg";
		  $condicao2 .= "Numero do Pagamento";
		}
		if(strlen($valor_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.valor_pg";
		  $condicao2 .= "Valor Pago";
		}
		if(strlen($R_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.R_pg";
		  $condicao2 .= "Real";
		}
		if(strlen($E_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.E_pg";
		  $condicao2 .= "Euro";
		}
		if(strlen($U_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.U_pg";
		  $condicao2 .= "Dollar";
		}
		if(strlen($troco_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.troco_pg";
		  $condicao2 .= "Troco de Pagamento";
		}
		if(strlen($instituicao_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.instituicao_pg";
		  $condicao2 .= "Institui&ccedil;&atilde;o de Pagamento";
		}
		if(strlen($nome_cartao_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.nome_cartao_pg";
		  $condicao2 .= "Nome no Cart&atilde;o";
		}
		if(strlen($validade_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.validade_pg";
		  $condicao2 .= "Validade do Cart&atilde;o";
		}
		if(strlen($codigo_seguranca_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.codigo_seguranca_pg";
		  $condicao2 .= "C&oacute;d. Seguran&ccedil;a do Cart&atilde;o";
		}
		if(strlen($banco_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.banco_pg";
		  $condicao2 .= "Banco/Cheque";
		}
		if(strlen($ag_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.ag_pg";
		  $condicao2 .= "Ag&ecirc;ncia/Cheque";
		}
		if(strlen($conta_cheque_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.conta_cheque_pg";
		  $condicao2 .= "Conta Corrente/Cheque";
		}
		if(strlen($cortesia_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.cortesia_pg";
		  $condicao2 .= "Cortesia";
		}
		if(strlen($data_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.data_pg";
		  $condicao2 .= "Data Pagamento";
		}
		if(strlen($texto_recibo_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.texto_recibo_pg";
		  $condicao2 .= "Recibo";
		}
		if(strlen($texto_anuidade_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.texto_anuidade_pg";
		  $condicao2 .= "Anuidade";
		}
		if(strlen($texto_observacoes_pg)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.texto_observacoes_pg";
		  $condicao2 .= "Observa&ccedil;&otilde;es";
		}
		if(strlen($totalescolhido)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.totalescolhido";
		  $condicao2 .= "Total";
		}
		if(strlen($inscricoes_pagas)> 0){
		  if(strlen($condicao) > 0){
			$condicao .= ", ";
			$condicao2 .= ", ";
		  }	
		  $condicao .= "inscricoes.paid";
		  $condicao2 .= "Pagamentos";
		}

$condicao2= explode(",",$condicao2);
//consulta sql
		
$SQL2 = mysql_query("SELECT paid FROM invoices");
$SQL = "SELECT $condicao FROM inscricoes $condicao3 $ordem"; 
//echo $SQL;
//exit();
$executa = mysql_query($SQL)or die(mysql_error());

// definimos o tipo de arquivo
header("Content-type: application/msexcel");

// Como será gravado o arquivo
header("Content-Disposition: attachment; filename=relatorio_inscricao.xls");

		// montando a tabela
		$count = count($condicao2);
		echo "<table border='0' width='900' cellspacing='1'>
				<tr>
				  <td bgcolor='#F2F2F2' colspan=".($count - 1)." align='left' height='80'><b>INSCRI&Ccedil;&Otilde;ES</b><br />";
				  echo "".$data."</td>
				  <td bgcolor='#F2F2F2' colspan='2' align='left' height='80'>
				  	<img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' border='0' width='125' align='right'>
				  </td>";
				  
				echo "</tr>
			</table>	
			<table border='1' width='900' cellspacing='1'>	
				<tr>
				  <td bgcolor='#F2F2F2'><b>Quant</b></td>";
					 for ($i = 0; $i < $count; $i++) {
						echo "<td align='center' bgcolor='#F2F2F2'><b>".$condicao2[$i]."</b></td>";
					 }	
			   echo "</tr>";
		$i=1;
		while ($rs = mysql_fetch_array($executa)){
		$rs2 = mysql_fetch_array($SQL2);
		//consulta tabela usuarios
		$usu = "SELECT inicio FROM usuarios where email='".$rs["email"]."'";  
		$executausu = mysql_query($usu)or die(mysql_error());
		$numexe	= mysql_num_rows($executausu);
		if ($numexe > 0){
			$fetch = mysql_fetch_array($executausu);
		}else{
			$usueve = "SELECT inicio FROM usuarios_eventos where email='".$rs["email"]."'";  
			$exeusu = mysql_query($usueve)or die(mysql_error());
			$fetch = mysql_fetch_array($exeusu);
		}
		
		  echo "<tr>";
			echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $i . "</td>";
			if(strlen($id) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["id"] . "</td>";
			}
			if((strlen($dia_inscr)> 0) and (strlen(mes_inscr)>0) and (strlen(ano_inscr)>0)){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $dia_inscr."-".$mes_inscr."-".$ano_inscr. "</td>";
			}
			elseif(strlen($data_inicio)>0){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $fetch['inicio']. "</td>";
			}
			if(strlen($data_modf) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $fetch["data_hora"] ." </td>";
			}
			if(strlen($title) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $rs["title"] ." </td>";
			}
			if(strlen($familyname) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $rs["familyname"] . "</td>";
			}
			if(strlen($givenname) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>" . $rs["givenname"] . "</td>";
			}
			if(strlen($family) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' bgcolor='#F2F2F2'>" . $rs["Affiliation"] . "</td>";
			}
			if(strlen($namebagde) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='100' bgcolor='#F2F2F2'>" . $rs["nametothebagde"] . "</td>";
			}
			if(strlen($affiliation) >0 ){
			 if(strlen($instituicao) > 0){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs["instituicao"] . "</td>";
			 }else{
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs["Affiliation"] . "</td>";
			 }	
			}
			if(strlen($instituicao2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='100' bgcolor='#F2F2F2'>" . $rs["instituicao"] . "</td>";
			}
			if(strlen($especialidade) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs["especialidade"] . "</td>";
			}
			if(strlen($cpf) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["cpf"] . "</td>";
			}
			if(strlen($identidade) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["identidade"] . "</td>";
			}
			if(strlen($mailingadress) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["mailingadress"] . "</td>";
			}
			if(strlen($city2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["city"] . "</td>";
			}
			if(strlen($provincestate) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["provincestate"] . "</td>";
			}
			if(strlen($country) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["country"] . "</td>";
			}
			if(strlen($zipcode) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["zipcode"] . "</td>";
			}
			if(strlen($email) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["email"] . "</td>";
			}
			if(strlen($phone) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["phone"] . "</td>";
			}
			if(strlen($fax) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["fax"] . "</td>";
			}
			if(strlen($accompanying) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["accompanyingperson"] . "</td>";
			}
			if(strlen($letter) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["letter"] . "</td>";
			}
			if(strlen($profissional) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["profissional"] . "</td>";
			}
			if(strlen($student) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["student"] . "</td>";
			}
			if(strlen($accompanying2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["accompanyingperson2"] . "</td>";
			}
			if(strlen($resident) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["residente"] . "</td>";
			}
			if(strlen($gerentologia) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["gerentologia"] . "</td>";
			}
			if(strlen($congnitiva) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["congnitiva"] . "</td>";
			}
			if(strlen($paleativos) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["paleativos"] . "</td>";
			}
			if(strlen($incapacidade) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["incapacidade"] . "</td>";
			}
			if(strlen($formpagamento2) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["formpagamento"] . "</td>";
			}
			if(strlen($numero_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["numero_pg"] . "</td>";
			}
			if(strlen($valor_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["valor_pg"] . "</td>";
			}
			if(strlen($R_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>"; if($rs["R_pg"] != '0')echo $rs["R_pg"]; echo "</td>";
			}
			if(strlen($E_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>"; if($rs["E_pg"] != '0')echo $rs["E_pg"]; echo "</td>";
			}
			if(strlen($U_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>"; if($rs["U_pg"] != '0')echo $rs["U_pg"]; echo"</td>";
			}
			if(strlen($troco_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>"; if($rs["troco_pg"] != '0')echo $rs["troco_pg"]; echo"</td>";
			}
			if(strlen($instituicao_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["instituicao_pg"] . "</td>";
			}
			if(strlen($nome_cartao_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["nome_cartao_pg"] . "</td>";
			}
			if(strlen($validade_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["validade_pg"] . "</td>";
			}
			if(strlen($codigo_seguranca_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["codigo_seguranca_pg"] . "</td>";
			}
			if(strlen($banco_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["banco_pg"] . "</td>";
			}
			if(strlen($ag_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["ag_pg"] . "</td>";
			}
			if(strlen($conta_cheque_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["conta_cheque_pg"] . "</td>";
			}
			if(strlen($cortesia_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["cortesia_pg"] . "</td>";
			}
			
			 $data 				=$rs['data_pg']; 
			 $aux 				=explode("-",$data); 
			 $data_pagamento_pg =$aux[2]."-".$aux[1]."-".$aux[0];
			
			if(strlen($data_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $data_pagamento_pg . "</td>";
			}
			if(strlen($texto_recibo_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["texto_recibo_pg"] . "</td>";
			}
			if(strlen($texto_anuidade_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["texto_anuidade_pg"] . "</td>";
			}
			if(strlen($texto_observacoes_pg) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["texto_observacoes_pg"] . "</td>";
			}
			if(strlen($cartao) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["cartao"] . "</td>";
			}
			if(strlen($namecredit) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["namecredit"] . "</td>";
			}
			if(strlen($datacartao) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["datacartao"] . "</td>";
			}
			if(strlen($numcredit) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["numcredit"] . "</td>";
			}
			if(strlen($expiracartao) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["expiracartao"] . "</td>";
			}
			if(strlen($securitycode) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["securitycode"] . "</td>";
			}			
			if(strlen($totalescolhido) >0 ){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs["totalescolhido"] . "</td>";
			}
						
			if(strlen($inscricoes_pagas) >0 ){
			 if($rs['paid'] == 0){
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>N&atilde;o Pago</td>";
			 }else{
				echo "<td align='center' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>Pago</td>";
			 }
			}
		  echo "</tr>";
		  echo "</tr>";
		  $i++;
		}
		  echo "<tr>
				  <td colspan=".($count+1)." bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PE&Ccedil;ANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
														TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
				  </td>
				</tr>  
		</table> ";
?>