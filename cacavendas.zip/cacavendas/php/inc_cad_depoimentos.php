<?php
include ("config.php");

$depoimentos = $_POST['depoimentos']; 
$id = $_POST['id'];

$query = mysql_query("UPDATE site SET depoimentos='$depoimentos' WHERE id = '$id' ");


Header("Location: ../adm_depoimentos.php");
?>
