<?
include ("config.php"); //aqui inserimos as v�riaveis da p�gina de configura��o

$ip = $_SERVER["REMOTE_ADDR"];
$ip_inicio= $ip;
$data_hora = date("y.m.d H:i:s");
$inicio=$data_hora;
#$hora = date("H:i:s");
$login = $_POST["login"];
$senha = $_POST["senha"];
$email = $_POST["email"];
$id_eventos = $_POST["projetos"];
$tipo = $_POST["arquivo"];


$query="SELECT * FROM usuarios_eventos WHERE login = '$login'";
#print "1. query: $query"; exit();
$pesquisar = mysql_query($query); 
//conferimos se o login escolhido j� n�o foi cadastrado
if(mysql_error() )
{
  print("*** 1. $query ***<br>");
  print "\nMysql error:" . mysql_errno()
    . " : "  . mysql_error() . "<br>";
  exit();
}
#print "2. query: $query"; exit();

$contagem = mysql_num_rows($pesquisar); //traz o resultado da consulta acima

if ( $contagem == 1 ) {
  echo("<script>
      alert(\"Usu�rio j� cadastrado\");
      window.location = '../cad_usuario_projetos.php';
      </script>");
} else {
	if($id_eventos != 'evento'){
  $cadastrar = mysql_query("INSERT INTO usuarios_eventos (id_evento, inicio, ip,
	ip_inicio, data_hora, login, senha, tipo_usuario, email)
    VALUES ('$id_eventos', '$inicio', '$ip', '$ip_inicio','$data_hora', '$login',
	'$senha', '$tipo', '$email')"); //insere os campos na tabela
	}
if(mysql_error() )
{
  print("*** 2. $query ***<br>");
  print "\nMysql error:" . mysql_errno()
    . " : "  . mysql_error() . "<br>";
  exit();
}

    if ( $cadastrar == 1 ) {
      echo("<script>
      alert(\"Cadastrado efetuado com sucesso\");
      window.location = '../adm_usuarios_projetos.php';
      </script>"); //se cadastrou com sucesso o usu�rio aparece essa mensagem
      } else {
  print("*** 2. $query ***<br>");
  print "\nMysql error:" . mysql_errno()
    . " : "  . mysql_error() . "<br>";

	echo("<script>
      alert(\"Ocorreu um erro no servidor\");
      window.location = '../cad_usuario_projetos.php';
      </script>");  }
  } 
?>
