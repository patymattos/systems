<?php
include ("config.php");

$noticias 	= $_POST['noticias']; 

$query = mysql_query("INSERT INTO noticias SET noticias ='$noticias'");


Header("Location: ../adm_noticias.php");
?>
