<?php
include ("config.php");

$aempresa 	= $_POST['aempresa']; 
$id	=	$_POST['id'];

$query = mysql_query("UPDATE site SET aempresa ='$aempresa' WHERE id = '$id' ");


Header("Location: ../adm_aempresa.php");
?>
