<?
include"config.php";
$email=$_GET['email'];
$y = mysql_query("SELECT * FROM inscricoes WHERE email = '".$email."'");
if ($x = mysql_fetch_array($y))
{
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<script language="javascript">
		function checar(){
		  campo1=document.frm_servico.check1;
		  campo2=document.frm_servico.check2;
		  campo3=document.frm_servico.check3;
		  campo4=document.frm_servico.check4;  
		  campo5=document.frm_servico.check5;  
		  campo6=document.frm_servico.check6; 
		  campo7=document.frm_servico.check7;  
		  campo8=document.frm_servico.check8;  
		  campo9=document.frm_servico.check9;         
		  if(campo1.checked==true){
			  valor1=campo1.value;
		  }else{
			  valor1="";
		  }
		  if(campo2.checked==true){
			  valor2=campo2.value;
		  }else{
			  valor2="";
		  }
		  if(campo3.checked==true){
			  valor3=campo3.value;
		  }else{
			  valor3="";
		  }
		  if(campo4.checked==true){
			  valor4=campo4.value;
		  }else{
			  valor4="";
		  }
		  if(campo5.checked==true){
			  valor5=campo5.value;
		  }else{
			  valor5="";
		  }
		  if(campo6.checked==true){
			  valor6=campo6.value;
		  }else{
			  valor6="";
		  }
		  if(campo7.checked==true){
			  valor7=campo7.value;
		  }else{
			  valor7="";
		  }
		  if(campo8.checked==true){
			  valor8=campo8.value;
		  }else{
			  valor8="";
		  }
		  if(campo9.checked==true){
			  valor9=campo9.value;
		  }else{
			  valor9="";
		  }      
		  um=valor1*2/2;
		  dois=valor2*2/2;
		  tres=valor3*2/2;  
		  quatro=valor4*2/2;
		  cinco=valor5*2/2;
		  seis=valor6*2/2;
		  sete=valor7*2/2;
		  oito=valor8*2/2;
		  nove=valor9*2/2;  
		 if(um=="" && dois=="" && tres==""&& quatro==""&& cinco==""&& seis==""&& sete==""&& oito==""&& nove==""){
			 document.frm_servico.total.value="";
		 }else{
			 document.frm_servico.total.value=um+dois+tres+quatro+cinco+seis+sete+oito+nove;
		 }
		 if(um=="" && dois=="" && tres==""){
			 document.frm_servico.total2.value="";
		 }else{
			 document.frm_servico.total2.value=um+dois+tres;
		 }
		 if(quatro=="" && cinco=="" && seis==""){
			 document.frm_servico.total3.value="";
		 }else{
			 document.frm_servico.total3.value=quatro+cinco+seis;
		 }
		 if(sete=="" && oito=="" && nove==""){
			 document.frm_servico.total4.value="";
		 }else{
			 document.frm_servico.total4.value=sete+oito+nove;
		 }   
	 }
	</script>
  
  <style>
	fieldset dt{
	  float: left;
	  width: 220px;
	  padding: 5px;
	  margin: 0;  
	  font:  0.9em Verdana;  
	}
  input.valor{
	background: url("images/valor.gif");
	cursor:hand;
	width: 65px;
	height: 22px;
	border:0;
  }  
</style>
</head>
<body>
<form name="form1" method="post" action="php/alterar_db_inscricoes2.php?email=<?=$email;?>" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">


      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
	  <tr>
        <td colspan="2" class="titulo">:: Alterar Participante ::</td>
      </tr>



      <table width="98%" border="0" bordercolor="#333333" class="texto cor_tr">
       <tr>
        <td width="27%" align="center"><span class="texto">Registration Fees*</span></td>
        <td width="19%" align="center"><span class="texto">Until Aug, 21th</span></td>
        <td width="19%" align="center"><span class="texto">Until Sep, 21th</span></td>
        <td width="19%" align="center">On-site</td>
        <td width="16%" align="center"><span class="texto">TOTAL (US$)</span></td>        
       </tr>
       <tr>
        <td align="center"><span class="texto">Professional</span></td>
        <td align="center"><input type="checkbox" name="check1" value="400" onclick="checar()" 
/><span class="texto"> US$ 400</span></td>
        <td align="center"><input type="checkbox" name="check2" value="440" onclick="checar()" 
/>
          <span class="texto"> US$ 440</span></td>
        <td align="center"><input type="checkbox" name="check3" value="480" onclick="checar()" 
/> 
          <span class="texto">US$ 480</span></td>
        <td align="center"><input type="button" name="total2" class="valor" value="" size="5" /></td>
       </tr>
       <tr>
        <td align="center"><span class="texto">Student</span></td>
        <td align="center"><input type="checkbox" name="check4" value="200" onclick="checar()" 
/> <span class="texto">US$ 200</span></td>
        <td align="center"><input type="checkbox" name="check5" value="250" onclick="checar()" 
>
          <span class="texto"> US$ 250</span></td>
        <td align="center"><input type="checkbox" name="check6" value="280" onclick="checar()" 
/> 
          <span class="texto">US$ 280</span></td>
        <td align="center"><input type="button" name="total3" class="valor" value="" size="5" /></td>
       </tr>
       <tr>
        <td align="center"><span class="texto">Accompanying person</span></td>
        <td align="center"><input type="checkbox" name="check7" value="110" onclick="checar()" 
><span class="texto"> US$ 110</span></td>
        <td align="center"><input type="checkbox" name="check8" value="110" onclick="checar()" 
><span class="texto"> US$ 110</span></td>
        <td align="center"><input type="checkbox" name="check9" value="110" onclick="checar()" 
/>
        <span class="texto"> US$ 110</span></td>
        <td align="center"><input type="button" name="total4" class="valor" value="" size="5" /></td>
       </tr>
       <tr>
         <td colspan="4" align="left">Total</td>
         <td align="center"><input type="button" name="total" class="valor" value="" size="5" /></td>
       </tr>
       <tr>
         <td colspan="5" align="left">
         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="payment_cash" />
                 <span class="textotab">On-site payment in cash</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="onsite_payment_credit" />
                 <span class="textotab">On-site payment with Credit card</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="creditcard" />
                 <span class="textotab">Credit Card</span></td>
           </tr>
           <tr>
             <td align="left"><input type="radio" name="cartao" value="american" />
                 <span class="textotab">American Express</span></td>
             <td align="left"><input type="radio" name="cartao" value="visa" />
                 <span class="textotab">VISA</span></td>
           </tr>
           <tr>
             <td align="left" class="textotab"><br />Name on Credit Card- holder:</td>
             <td align="left"><br /><input name="namecredit" type="text" size="30"/></td>
           </tr>
           <tr>
             <td align="left" class="textotab">Date:</td>
             <td align="left"><input type="text" name="datedia" size="4" maxlength="2"/>
               -
               <input type="text" name="datemes" size="4" maxlength="2"/>
               -
               <input type="text" name="dateano" size="4" maxlength="4"/></td>
           </tr>
           <tr>
             <td align="left" class="textotab">Credit  Card N&ordm;:</td>
             <td align="left">
           <input name="numcredit1" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit2" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit3" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit4" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit5" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit6" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit7" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit8" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit9" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit10" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit11" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit12" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit13" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit14" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit15" type="text" style="width: 10px; margin:0;" maxlength="1"/><input name="numcredit16" type="text" style="width: 10px; margin:0;" maxlength="1"/>
             
             </td>
           </tr>
           <tr>
             <td align="left" class="textotab">Credit Card Expiration Date:</td>
             <td align="left"><input type="text" name="expmes" size="2" maxlength="2"/>
               -
               <input type="text" name="expano" size="4" maxlength="4"/></td>
           </tr>
         <input type="hidden" value="<?=$eventos?>" name="eventos" />
         <input type="hidden" value="<?=$id?>" name="id" />    
         <input type="hidden" value="<?=$title?>" name="title" /> 
         <input type="hidden" value="<?=$familyname?>" name="familyname" /> 
         <input type="hidden" value="<?=$givenname?>" name="givenname" /> 
         <input type="hidden" value="<?=$nametothebagde?>" name="nametothebagde" /> 
         <input type="hidden" value="<?=$Affiliation?>" name="Affiliation" /> 
         <input type="hidden" value="<?=$mailingadress?>" name="mailingadress" /> 
         <input type="hidden" value="<?=$city?>" name="city" /> 
         <input type="hidden" value="<?=$provincestate?>" name="provincestate" /> 
         <input type="hidden" value="<?=$country?>" name="country" /> 
         <input type="hidden" value="<?=$zipcode?>" name="zipcode" /> 
         <input type="hidden" value="<?=$email?>" name="email" /> 
         <input type="hidden" value="<?=$phoneddi?>" name="phoneddi" /> 
         <input type="hidden" value="<?=$phoneddd?>" name="phoneddd" />
         <input type="hidden" value="<?=$phone?>" name="phone" /> 
         <input type="hidden" value="<?=$faxddi?>" name="faxddi" /> 
         <input type="hidden" value="<?=$faxddd?>" name="faxddd" /> 
         <input type="hidden" value="<?=$fax?>" name="fax" /> 
         <input type="hidden" value="<?=$accompanyingperson?>" name="accompanyingperson" /> 
         <input type="hidden" value="<?=$letter?>" name="letter" />
           <tr>
             <td align="left" class="textotab">Security Code N&ordm;:<br />
                <br /></td>
             <td align="left"><input name="securitycode" type="text" size="30"/></td>
           </tr>
         </table></td>
        </tr>
      </table> 




        </table>
		</form>
<?php	
}
?>