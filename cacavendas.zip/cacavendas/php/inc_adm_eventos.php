<?php
if (strlen($_GET["buscar"])>0){
		include ("config.php");
	    $buscar = $_POST["buscar"];
		if (strlen($buscar)==0){
			$buscar = $_GET["buscar"];
		}

		if ((strlen($buscar) == 4) and (is_numeric($buscar))){
			$buscar2 = $buscar."-01-01";
			$buscar3 = $buscar."-12-31";
		}
		if (strlen($buscar) == 7){
			$buscar1  = explode("/", $buscar);
			$buscar2 = $buscar1[1]."-".$buscar1[0]."-01";
			$buscar3 = $buscar1[1]."-".$buscar1[0]."-31";
	    }
		if (strlen($buscar) == 10){
			$buscar1  = explode("/", $buscar);
			$buscar2 = $buscar1[2]."-".$buscar1[1]."-".($buscar1[0]-1);
			$buscar3 = $buscar1[2]."-".$buscar1[1]."-".($buscar1[0]+1);
		}
		$sql = mysql_query("SELECT * FROM projetos WHERE nome_projeto LIKE '%".$buscar."%' ORDER BY nome_projeto DESC");
		$geti = $_GET['pagina'];
		if ($geti>0){
			$inicio = 10*$geti; // Especifique quantos resultados voc� quer por p�gina
			$lpp= 10; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
		}else{
			$inicio = 0;
			$lpp	= 10;
		}
		$total = mysql_num_rows($sql); // Esta fun��o ir� retornar o total de linhas na tabela
		$paginas = ceil($total / 10); // Retorna o total de p�ginas
		if(!isset($pagina)) { 
			$pagina = 0; 
		} // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
		
		$sql = mysql_query("SELECT * FROM projetos WHERE nome_projeto LIKE '%".$buscar."%' ORDER BY nome_projeto DESC LIMIT $inicio, $lpp");
		$num = mysql_num_rows($sql);
		if ($num > 0){
			echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
			echo "<tr>";
			echo "<td class=titulo colspan=4>:: Administrar Eventos ::</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td class='texto' width='305'><b>Projetos</b></td>";
			echo "<td class='texto' width='45'><b>Excluir</b></td>";
			echo "</tr>";
			
			while ($linha = mysql_fetch_array($sql)){
				$id_projeto = $linha["id"];
				$evento = $linha["nome_projeto"];
				$ativo = $linha["ativo"];
			
				echo "<tr>";
				echo "<td class='texto'><a href='vis_eventos.php?id=$id_projeto'>".substr ($evento,0,60)."...</a></td>";
				echo "<td class='texto'>";
				echo "<td align='center'><a href='php/excluir_eventos.php?id=$id_evento'><img src='img/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
				echo "</tr>";		
			}

			echo "</table>";
			if ($total > 10){
				echo "<span class='texto'>Mais registros</span>";
				echo "<br />";
				if($pagina > 0) {
					$menos = $pagina - 1;
					$url = "$PHP_SELF?buscar=".$buscar."&pagina=$menos";
					echo "<a class=\"destaque\" href=\"$url\">&laquo;</a>"; // Vai para a p�gina anterior
				}
				for($i=0;$i<$paginas;$i++) { // Gera um loop com o destaque para as p�ginas
					$url = "$PHP_SELF?buscar=".$buscar."&pagina=$i";
					echo " | <a class=\"destaque\" href=\"$url\">$i</a>";
				}
				if($pagina < ($paginas - 1)) {
					$mais = $pagina + 1;
					$url = "$PHP_SELF?buscar=".$buscar."&pagina=$mais";
					echo " | <a href=\"$url\">&raquo;</a>";
				}
			}
		}
			$sqls   = mysql_query("SELECT * FROM projetos WHERE nome_projeto > '".$buscar2."' AND nome_projeto < '".$buscar3."' ORDER BY nome_projeto DESC");
			//echo $sqls;
			//exit();
			$numm   = mysql_num_rows($sqls);
			if (($numm == 0) and ($num == 0)){
			  echo "Nenhum registro foi encontrado.";
			}elseif ($numm > 0){
				if ($num == 0){
					echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
					echo "<tr>";
					echo "<td class=titulo colspan=4>:: Administrar Eventos ::</td>";
					echo "</tr>";
					echo "<tr>";
					echo "<td class='texto' width='305'><b>Eventos</b></td>";
					echo "<td class='texto' width='45'><b>Excluir</b></td>";
					echo "</tr>";
				}else{
					echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
				}
				while ($linha = mysql_fetch_array($sqls)){
					$id_evento = $linha["id"];
					$projeto = $linha["nome_projeto"];
							
					echo "<tr>";
					echo "<td class='texto' width='273'><a href='vis_eventos.php?id=$id_evento'>".substr ($evento,0,60)."...</a></td>";
					echo "<td align='center' width='58'><a href='php/excluir_eventos.php?id=$id_evento'><img src='img/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
					echo "</tr>";		
				}
				echo "</table>";
			}
}else{
		include ("config.php");
		$id = $_GET['id'];
		$mode = $_GET['mode'];
		$query = mysql_query("UPDATE projetos SET ativo = '$mode' WHERE id = '$id'") or die(mysql_error());
		$sql = mysql_query("SELECT * FROM eventos");
		
		$geti = $_GET['pagina'];
		if ($geti>0){
			$inicio = 10*$geti; // Especifique quantos resultados voc� quer por p�gina
			$lpp= 10; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
		}else{
			$inicio = 0;
			$lpp	= 10;
		}
		$total = mysql_num_rows($sql); // Esta fun��o ir� retornar o total de linhas na tabela
		$paginas = ceil($total / 10); // Retorna o total de p�ginas
		if(!isset($pagina)) { 
			$pagina = 0; 
		} // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
		
		$sql = mysql_query("SELECT * FROM projetos ORDER BY nome_projeto DESC LIMIT $inicio, $lpp"); // Executa a query no MySQL com o limite de linhas.
		
		echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
		echo "<tr>";
		echo "<td class=titulo colspan=4>:: Administrar Eventos ::</td>";
		echo "</tr>";
		echo "<tr>";
		echo "<td class='texto' width='305'><b>Eventos</b></td>";
		echo "<td class='texto' width='45'><b>Excluir</b></td>";
		echo "</tr>";
		
		while ($linha = mysql_fetch_array($sql))
		{
			$id_evento = $linha["id"];
			$projeto = $linha["nome_projeto"];
		
			echo "<tr>";
			echo "<td class='texto'><a href='vis_eventos.php?id=$id_evento'>".substr ($evento,0,60)."...</a></td>";
			echo "<td align='center'><a href='php/excluir_eventos.php?id=$id_evento'><img src='img/ico_excluir.jpg' alt='' border='0' /></a><br></td>";
			echo "</tr>";		
		}
		
		echo "</table>";
		
		echo "<span class='texto'>Mais registros</span>";
		echo "<br />";
		if($pagina > 0) {
		$menos = $pagina - 1;
		$url = "$PHP_SELF?pagina=$menos";
		echo "<a class=\"destaque\" href=\"$url\">&laquo;</a>"; // Vai para a p�gina anterior
		
		}
		for($i=0;$i<$paginas;$i++) { // Gera um loop com o destaque para as p�ginas
		$url = "$PHP_SELF?pagina=$i";
		echo " | <a class=\"destaque\" href=\"$url\">$i</a>";
		}
		
		if($pagina < ($paginas - 1)) {
		$mais = $pagina + 1;
		$url = "$PHP_SELF?pagina=$mais";
		echo " | <a href=\"$url\">&raquo;</a>";
		}
}
?>