<?php
session_start();
include "config.php";
$id_evento  		= $_POST['id'];
$nome_input_mais 	= $_POST['nome_input_mais'];
$nome_input	 		= $_POST['nome_input'];
$nome_campo_input 	= $_POST['nome_campo_input'];
$tipo 				= $_POST['tipo'];
$nome_tipo 			= $_POST['tipo2'];
$campo_tipo 		= $_POST['campo_tipo'];
$tamanho_input 		= $_POST['tamanho_input_mais'];
$maxlength			= $_POST['maxlength'];
$todos				= $_POST['todos'];
$obrigatorio		= $_POST['obrigatorio'];
//$estilo_fonte		= $_POST['estilo_fonte'];

$semespaco			= array(" ");
$troca				= array("_");
$nome_input_mais2	= str_replace($semespaco, $troca, $nome_input_mais);
$nome_input2		= str_replace($semespaco, $troca, $nome_input);

$ordem_form 		= mysql_query("SELECT * FROM ordem_formulario WHERE id_evento='$id_evento'")or die(mysql_query()); 
$num_ordem			= mysql_num_rows($ordem_form);
$fetch_ordem		= mysql_fetch_array($ordem_form);
$nome_ordem			= $fetch_ordem['ordem'];

if($num_ordem == 0){//ir� inserir os dados na tabela ordem_formulario se n�o tiver esse evento cadastrado
	$todos = ",".$todos;
	$insert_ordem 	= mysql_query("INSERT INTO ordem_formulario(id_evento, ordem) values('$id_evento', '$todos')")or die(mysql_query()); 

}else{//Se tiver, ele ir� atualizar
	$todos  = $nome_ordem.",".$todos;
	$update	= mysql_query("UPDATE ordem_formulario SET ordem='$todos' WHERE id_evento='$id_evento'")or die(mysql_query());
}

if($nome_tipo != ""){
	$sql   	= mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo' AND nome='$nome_tipo'")or die(mysql_query());
	$x 		= mysql_fetch_array($sql);
	$campo	= $x['nome_campo']."/".$nome_input_mais;

	$insert	= mysql_query("UPDATE formulario SET  nome_campo='$campo', fonte='$estilo_fonte' WHERE id_evento='$id_evento' and tipo='$tipo' and nome='$nome_tipo'")or die(mysql_query());

}elseif (($tipo != "text") and ($tipo != "password")){//se o campo n�o for um input, ele ir� inserir
	$insert	= mysql_query("INSERT INTO formulario(id_evento, tipo, nome, nome_campo, nome_campo_input, fonte) VALUES('$id_evento', '$tipo', '$nome_input', '$nome_campo_input', '$nome_input2', '$estilo_fonte')")or die(mysql_query());
	
}else{//ir� inserir se o campo for um input
	$insert	= mysql_query("INSERT INTO formulario(id_evento, tipo, nome, nome_campo, size, maxlength, fonte) VALUES('$id_evento', '$tipo', '$nome_input_mais2', '$nome_input_mais', '$tamanho_input', '$maxlength', '$estilo_fonte')")or die(mysql_query());

}

if ($obrigatorio == "sim"){
	$insertt	= mysql_query("INSERT INTO campo_obrigatorio(id_evento, tipo, nome, nome_campo_input) VALUES('$id_evento', '$tipo', '$nome_input_mais2', '$nome_input')")or die(mysql_query());
}

header("location:../adm_formulario2.php");

?>