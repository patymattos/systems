<?php
include ("config.php");

$dia =date("d");
$mes =date("m");
$ano =date("Y");
$data =$dia."-".$mes."-".$ano;

$simposio 		= $_POST["simposio"];
$poster			= $_POST["poster"];
$ordem2			= $_POST["ordem"];

if(strlen($ordem)>0){
	$ordem = "ORDER BY $ordem2 ASC";
}else{
	$ordem = "ORDER BY id_trabalho ASC";
}

if (strlen($simposio) > 0){
	$condicao3 = "WHERE tipo='1' ";
}
if ((strlen($poster) > 0) and (strlen($simposio) > 0)){
	$condicao3 = "";
}elseif (strlen($poster) > 0){
	$condicao3 = "WHERE tipo='0' ";
}

//consulta sql
$SQL 		= "SELECT * FROM trabalhos $condicao3 $ordem";  
$executa 	= mysql_query($SQL)or die(mysql_error());
$num 		= mysql_num_rows($executa);

// montando a tabela
echo "<table border='0' width='900'>
		  <tr>";
		  if ($ordem2 == 'check4'){
		   "<td colspan='7'>";
		  }else{
		   "<td colspan='6'>";
		  } 
				echo "<a href=javascript:history.go(-1) style='color:#000'>Voltar</a>
		   </td>
		  </tr>
      </table>
  	  <table border='0' width='900' cellspacing='1' bgcolor='#000000'>
		<tr>";
		if ($ordem2 == 'check4'){
		  echo "<td bgcolor='#F2F2F2' colspan='7' align='left'><b>TRABALHOS</b>";
		}else{
		  echo "<td bgcolor='#F2F2F2' colspan='6' align='left'><b>TRABALHOS</b>";
		}
		  echo "<img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' border='0' width='125' align='right'>";
		  ?>
           <form action="php/downloadword.php" method="post" style="margin-left:400px;">
	          <input type="submit" value="Download (Word)" />
              <input type="hidden" name="simposio" 			value="<?=$simposio?>"/>
              <input type="hidden" name="poster" 			value="<?=$poster?>" />
              <input type="hidden" name="ordem" 			value="<?=$ordem?>"/>
          </form>
           <form action="php/downloadexcel.php" method="post" style="margin:10px 0 0 400px;">
	          <input type="submit" value="Download (Excel)" />
              <input type="hidden" name="simposio" 			value="<?=$simposio?>"/>
              <input type="hidden" name="poster" 			value="<?=$poster?>" />
              <input type="hidden" name="ordem" 			value="<?=$ordem?>"/>
          </form>
          <?php
		  echo "".$data."</td>
		</tr>";

		echo "<tr>";
			  echo "<td align='center' bgcolor='#F2F2F2' width='200'><b>Modalidade:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Eixo Tem�tico:</b></td>";
			  if ($ordem2 == 'check4'){
			  	echo "<td align='center' bgcolor='#F2F2F2'><b>T�tulo:</b></td>";
			  }
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Avaliador 1:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Avaliador 2:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Avaliador 3:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Status</b></td>
		</tr>";  
		for($i=0;$i<$num;$i++){
			$rs = mysql_fetch_array($executa);
			if (strlen($rs['check1'])>0){
				$check = "check1";
			}elseif (strlen($rs['check2'])>0){
				$check = "check2";
			}elseif (strlen($rs['check3'])>0){
				$check = "check3";
			}
			if (strlen($rs['autor'])>0){
					  echo "<td align='center' bgcolor='#F2F2F2'><b>P�ster</b></td>";
			}else{
					echo "<td align='center' bgcolor='#F2F2F2'><b>Simp�sio Proposto</b></td>";
			}		  
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['check4']."</b></td>";
					  if ($ordem2 == 'check4'){
					  	echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['titulo']."</b></td>";
					  }
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['email_avaliador']."</b></td>";
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['email_avaliador2']."</b></td>";
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['email_avaliador3']."</b></td>";
  					  if($rs['processo']==0)echo "<td align='center' bgcolor='#F2F2F2'><b>Aguardando</b></td>";
					  elseif($rs['processo']==1)echo "<td align='center' bgcolor='#F2F2F2'><b><img src='https://www.metaeventos.net/inscricoes/imagem/ampulheta.gif' border='0' /></b></td>";
					  elseif($rs['processo']==2)echo "<td align='center' bgcolor='#F2F2F2'><b><img src='https://www.metaeventos.net/inscricoes/imagem/tick.png' border='0' /></b></td>";
					  elseif($rs['processo']==3)echo "<td align='center' bgcolor='#F2F2F2'><b><img src='https://www.metaeventos.net/inscricoes/imagem/revisar.gif' border='0' /></b></td>";
					  elseif($rs['processo']==4)echo "<td align='center' bgcolor='#F2F2F2'><b><img src='https://www.metaeventos.net/inscricoes/imagem/ico_excluir.jpg' border='0' /></b></td>";
					echo "</tr>";
			
		}
  echo "<tr>";
	  if ($ordem2 == 'check4'){
   		 echo "<td colspan='7' bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PE�ANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
												TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
		  </td>";
	  }else{
   		 echo "<td colspan='6' bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PE�ANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
												TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
		  </td>";
	  }  
		echo "</tr>
		</table> 
		<table border='0' width='900'>
		  <tr>";
		  if ($ordem2 == 'check4'){
		   echo "<td colspan='7' align='center'>";
		  }else{
		   echo "<td colspan='6' align='center'>";
		  } 
				echo "<a href=javascript:history.go(-1) style='color:#000'>Voltar</a>
		   </td>
		  </tr>";
		echo "</table>";
?>
</body>
</html>