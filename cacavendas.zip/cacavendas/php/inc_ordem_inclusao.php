<?php
session_start();
include "config.php";
$id_evento	= $_POST['id'];
$ordem	 	= $_POST['ordem'];
/*echo $ordem."<br>";
echo $id_evento."<br>";
exit();*/
if ($ordem != ""){
$update		= mysql_query("UPDATE ordem_formulario SET ordem='$ordem' WHERE id_evento='$id_evento'")or die(mysql_query());
}

header("location:../ordem_inclusao.php");
?>