0<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Gr�fica Brasil It�lia</title>
<script type="text/javascript" src="js/funcoes.js"></script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

    <style type="text/css">
<!--
.style1 {
	font-size: 16px;
	font-weight: bold;
	color: #666666;
}
.style3 {
	color: #666666;
	font-size: 14px;
}
-->
    </style>
</head>


<body background="images/fundo.jpg">
<div align="center">
  <? include_once "inc_topo.php"; ?>
    
</div>
<table width="713" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    
    <td width="705" valign="top">
	<form method="post" action="upload.php" name="form1" enctype="multipart/form-data">
	<input type="hidden" name="id_passagens" id="id_passagens" value="<?=$_GET['id']; ?>" />
	<table width="713" border="0" align="center" cellpadding="2" cellspacing="1" bgcolor="#F2F2F2" class="texto cor_tr">
	  <tr>
        <td width="704" class="titulo">:: Cadastrar Arquivos::</td>
      </tr>
	  <tr>
        <td><div align="center" class="style1">
          <p><br />
            <? echo "A extens�o do arquivo <b>" . $nome_final . "</b> n�o � v�lida";?></p>
          <div align="center"><a href="index.php" >Voltar  </a>          </div>
        </div>
          <div align="center"></div></td>
	  </tr>
    </table>
	</form>
	</td>
  </tr>
</table>
</body>
</html>