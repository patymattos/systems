<?

if (isset($_POST['editar_noticias'])){
	include"config.php";
	$id = $_GET['id'];
	$noticias = $_POST["noticias"];
	$query	= "
		UPDATE noticias SET 
		noticias = '".$noticias."' 
		
		WHERE id='".$id."'";
	
	$result	= mysql_query($query);
	#print "query: $query <br>"; exit();
	
	Header("Location: ../adm_noticias.php");

}

?>
