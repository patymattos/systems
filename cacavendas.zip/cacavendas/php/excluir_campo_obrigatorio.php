<?
session_start();
include"config.php";

$id	= $_GET['id'];

/*echo "id = ".$id."<br>";
echo "idd = ".$idd."<br>";
echo "nome_campo = ".$nome_campo."<br>";
echo "nome3 = ".$nome3."<br>";
echo "tipo = ".$tipo."<br>";
echo "size = ".$size."<br>";
echo "maxlength = ".$maxlength."<br>";
exit();*/

$sqll	= "	DELETE FROM campo_obrigatorio
			WHERE id='$id'
		  ";
$resultado2 = mysql_query($sqll);

Header("Location: ../campo_obrigatorio.php");	
?>