<?

include ("config.php");
$id		= $_GET['id'];
$sql	= "
			DELETE FROM usuarios_eventos
			WHERE id='$id'
		  ";
$resultado = mysql_query($sql);

Header("Location: ../adm_usuarios_eventos.php");

?>