<?
include ("config.php");
$id_inscricoes=$_GET['id_inscricoes'];
$exclui_foto = mysql_query("SELECT * FROM inscricoes WHERE id ='".$id_inscricoes."'");
$linha = mysql_fetch_array($exclui_foto);
$sqll	= "
			DELETE FROM usuarios
			WHERE id='$id_inscricoes' and tipo_usuario = 'usuario'
		  ";
$resultados = mysql_query($sqll);
$sql	= "
			DELETE FROM inscricoes
			WHERE id='$id_inscricoes'
		  ";
$resultado = mysql_query($sql);
echo"<script>location.href='javascript:window.history.go(-1)'; </script>";
?>