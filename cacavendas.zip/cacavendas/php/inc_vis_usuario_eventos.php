<?
include"config.php";
$id = $_GET[id];
$y = mysql_query("SELECT * FROM usuarios_eventos WHERE id = '$id'");
if ($x = mysql_fetch_array($y))

{

echo '
<form name="form1" method="post" action="php/alterar_db_usuario_eventos.php">
 <input type="hidden" name="editar_usuario_eventos" value="1" />
	<input type="hidden" name="id" value="'.$x[id].'" />
<table width="550" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
          <tr>
		    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="images/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
          </tr>
		  <tr>
            <td align="center" class="titulo" colspan="2">Visualizar Usu�rio do Evento</td>
          </tr>
	  <tr>
	    <td align="left">Evento:</td>
        <td align="left">
			<select name="eventos">
          		<option value="evento" selected="selected">---Escolha um Evento---</option>';
				
          			$resultado = mysql_query("SELECT * FROM eventos WHERE ativo = '1' ORDER BY nome_evento ASC");
					while($sql = mysql_fetch_array($resultado))
					{
						echo "<option value='$sql[id]'>".substr ($sql[nome_evento],0,30)."...</option>'";
					}
				echo'
        	</select>
        </td>
      </tr>
	  <tr>
	    <td align="left">Tipo Usu�rio:</td>
	    <td align="left">
        	<select name="tipo">
            	<option selected="selected" value="escolha">-=Escolha=-</option>
            	<option value="Administrador">Administrador</option>
                <option value="Avaliador">Avaliador</option>
                <option value="Participante">Participante</option>
            </select>
        </td>
	  </tr>
		  <tr>
			<td>E-mail:</td>
			<td><input name="email" value="'.$x[email].'" type="text" id="email" size="20" /></td>
		  </tr>
		  <tr>
			<td>Login:</td>
			<td><input name="login" value="'.$x[login].'" type="text" id="login" size="20" /></td>
		  </tr>
		  <tr>
			<td>Senha:</td>
			<td><input name="senha" value="'.$x[senha].'" type="password" id="senha" size="20" /></td>
		  </tr>
		 <tr>
		<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
		</tr>
		 <tr>
		<td align="center" colspan="2">&nbsp;</td>
		</tr>
		 <tr>
		<td colspan="2">*cadastrar o mesmo nome do email para o login, se tipo de usu�rio for <b>Participante</b>.</td>
		</tr>
        </table>
		</form>';		

}
?>