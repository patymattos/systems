<?
session_start();
include"config.php";

$id					= $_POST['id'];
$id3				= $_POST['id3'];
$idd				= $_POST['idd'];
$nome_campo			= $_POST['nome'];
$nome3				= $_POST['nome3'];
$tipo				= $_POST['tipo'];
$size				= $_POST['size'];
$maxlength			= $_POST['maxlength'];
$nome_campo_input	= $_POST['nome_campo_input'];
$obrigatorio		= $_POST['obrigatorio'];
$fonte				= $_POST['estilo_fonte'];
$nome_input			= $_POST['nome_input'];

/*echo "id = ".$id."<br>";
echo "idd = ".$idd."<br>";
echo "nome_campo = ".$nome_campo."<br>";
echo "nome_campo_input = ".$nome_campo_input."<br>";
echo "nome_input = ".$nome_input."<br>";
echo "nome3 = ".$nome3."<br>";
echo "tipo = ".$tipo."<br>";
echo "size = ".$size."<br>";
echo "maxlength = ".$maxlength."<br>";
exit();*/



if(($tipo != "text") and ($tipo != "password")){
	$query	= "UPDATE formulario SET
	nome_campo_input	= '$nome_campo_input', 
	nome_campo			= '$nome_campo',
	fonte				= '$fonte',
	nome				= '$nome3'
	WHERE id	= '$idd'";
	$result	= mysql_query($query);
	
	$campo_obrigatorio		= mysql_query("SELECT * FROM campo_obrigatorio WHERE id_evento='$id' AND id='$id3'");
	$num_obrigatorio		= mysql_num_rows($campo_obrigatorio);
	if(($obrigatorio == "sim") and ($num_obrigatorio == 0)){
		$insert = mysql_query("INSERT INTO campo_obrigatorio(id_evento, tipo, nome_campo_input) VALUES ('$id', '$tipo', '$nome_campo_input')");

	}elseif(($obrigatorio == "sim") and ($num_obrigatorio != 0)){
		$update = mysql_query("UPDATE campo_obrigatorio SET nome_campo_input = '$nome_campo_input' WHERE id = '$id3'");

	}elseif(($obrigatorio == "nao") and ($num_obrigatorio == 1)){
		$deletar = mysql_query("DELETE FROM campo_obrigatorio WHERE nome_campo_input='$nome_campo_input'");
	}

}else{
	$query	= "UPDATE formulario SET 
	nome_campo		= '$nome_campo',
	nome			= '$nome_input',
	size			= '$size',
	fonte			= '$fonte',
	maxlength		= '$maxlength'
	WHERE id	= '$idd'";
	$result	= mysql_query($query);
	
	$campo_obrigatorio		= mysql_query("SELECT * FROM campo_obrigatorio WHERE id_evento='$id' AND id='$id3'");
	$num_obrigatorio		= mysql_num_rows($campo_obrigatorio);

	if(($obrigatorio == "sim") and ($num_obrigatorio == 0)){
		$insert = mysql_query("INSERT INTO campo_obrigatorio(id_evento, tipo, nome) VALUES ('$id', '$tipo', '$nome_input')");
	
	}elseif(($obrigatorio == "sim") and ($num_obrigatorio != 0)){
		$update = mysql_query("UPDATE campo_obrigatorio SET nome = '$nome_input' WHERE id = '$id3'");
	
	}elseif(($obrigatorio == "nao") and ($num_obrigatorio == 1)){
		$deletar = mysql_query("DELETE FROM campo_obrigatorio WHERE nome='$nome_input'");
	}
}
Header("Location: ../adm_formulario2.php");
	
?>