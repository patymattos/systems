<?php
include ("config.php");

$conteudo 	= $_POST['conteudo']; 
$id	=	$_POST['id'];
$id_evento	=	$_POST['id_evento'];

$texto = "UPDATE certificados SET conteudo ='".$conteudo."' WHERE id_evento = '".$id_evento."' ";
$query = mysql_query($texto) or die ("Nao deu certo");


Header("Location: ../adm_certificados.php");
?>
