<?
include"config.php";
$email=$_GET['email'];
$select = "SELECT * FROM inscricoes WHERE email ='".$email."'";
$sql = mysql_query($select) or die ("Quary: ".$select." : ".mysql_error());
$x = mysql_fetch_array($sql);
if (isset($_POST['editar_eventos']))
{
	$formpagamento		= $_POST['formpagamento'];
	$cartao				= $_POST['cartao'];
	$namecredit			= $_POST['namecredit'];
	$datedia			= $_POST['datedia'];
	$datemes			= $_POST['datemes'];
	$dateano			= $_POST['dateano'];
	$datacartao 		= $dateano."-".$datemes."-".$datedia;
	$numcredit			= $_POST['numcredit1']."".$_POST['numcredit2']."".$_POST['numcredit3']."".$_POST['numcredit4']."".$_POST['numcredit5']."".$_POST['numcredit6']."".$_POST['numcredit7']."".$_POST['numcredit8']."".$_POST['numcredit9']."".$_POST['numcredit10']."".$_POST['numcredit11']."".$_POST['numcredit12']."".$_POST['numcredit13']."".$_POST['numcredit14']."".$_POST['numcredit15']."".$_POST['numcredit16'];
	$expmes				= $_POST['expmes'];
	$expano				= $_POST['expano'];
	$expiracartao 		= $expmes."/".$expano;
	$securitycode		= $_POST['securitycode'];
	$check1				= $_POST['check1'];
	$check2				= $_POST['check2'];
	$check3				= $_POST['check3'];
	$check4				= $_POST['check4'];
	$check5				= $_POST['check5'];
	$check6				= $_POST['check6'];  
	$check7				= $_POST['check7'];
	$check8				= $_POST['check8'];  
	$check9				= $_POST['check9'];
	$totalescolhido		= $check1+$check2+$check3+$check4+$check5+$check6+$check7+$check8+$check9; 
	 if ($check1!=""){ 
		$profissional="Until Aug, 21th";
	}else{
		$profissional="";
	} 
	if ($check2!="" && $check1!=""){ 
	    $profissional2=" / Until Sep, 21th";
	}else if ($check2!=""){
	    $profissional2="Until Sep, 21th";
	}else if ($check2==""){
	    $profissional2="";
	}
	if ($check2!="" && $check3!=""){ 
	    $profissional3=" / On-site";
	}else if ($check3!=""){
	    $profissional3="On-site";
	}
	if ($check4!=""){ 
	    $Student="Until Aug, 21th";
	}else{
	    $Student="";
	}
	if ($check4!="" && $check5!=""){ 
	    $Student2=" / Until Sep, 21th";
	}else if ($check5!=""){
	    $Student2="Until Sep, 21th";
	}else{
	    $Student2="";
	}
	if ($check5!="" && $check6!=""){ 
	    $Student3=" / On-site";
	}else if ($check6!=""){
	    $Student3="On-site";
	}else{
	    $Student3="";
	}
	if ($check7!=""){ 
	    $Accompanyingperson2="Until Aug, 21th";
	}else{
	    $Accompanyingperson2="";
	}
	if ($check7!="" && $check8!=""){ 
	    $Accompanyingperson3=" / Until Sep, 21th";
	}else if ($check8!=""){
	    $Accompanyingperson3="Until Sep, 21th";
	}else{
	    $Accompanyingperson3="";
	}
	if ($check8!="" && $check9!=""){ 
	    $Accompanyingperson4=" / On-site";
	}else if ($check9!=""){
	    $Accompanyingperson4="On-site";
	}else{
	    $Accompanyingperson4="";
	}
	 $accompanyingperson2 = $Accompanyingperson2.$Accompanyingperson3.$Accompanyingperson4;
	 $Profissional = $profissional.$profissional2.$profissional3;
	 $student = $Student.$Student2.$Student3;
	
	$query	= "UPDATE inscricoes SET 
	formpagamento 		= '".$formpagamento."',
	cartao				= '".$cartao."',
	namecredit			= '".$namecredit."',
	datacartao			= '".$datacartao."',
	numcredit			= '".$numcredit."',
	expiracartao 		= '".$expiracartao ."',
	securitycode		= '".$securitycode."',
	totalescolhido		= '".$totalescolhido."',
	accompanyingperson2		= '".$accompanyingperson2."',
	country				= '".$country."',
	zipcode				= '".$zipcode."',
	fax					= '".$fax."',
	accompanyingperson	= '".$accompanyingperson."',
	Profissional		= '".$Profissional."',
	student				= '".$student."'
	WHERE email='".$email."'";
	$result	= mysql_query($query) or die("Erro");
	Header("Location: ../adm_inscricoes.php");
}
?>