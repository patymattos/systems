<?
include"config.php";
$id_inscricoes=$_GET['id_inscricoes'];
//echo "SELECT * FROM inscricoes WHERE id = '".$id_inscricoes."'";
//exit();
$y = mysql_query("SELECT * FROM inscricoes WHERE id = '".$id_inscricoes."'");
if ($x = mysql_fetch_array($y))
{
$formpagamento = $x['formpagamento'];
$data_pg = $x['data_pg']; // Data no formato MySQL
//$aux = explode("-",$data); // Faz a separa��o da data em itens
//$data_pg = $aux[2]."-".$aux[1]."-".$aux[0];

	if($formpagamento == 'deposito'){
		$num_deposito_pg 	= $x['numero_pg'];
		$valor_deposito_pg 	= $x['valor_pg'];
	}
	elseif($formpagamento == 'boleto'){
		$num_boleto_pg 		= $x['numero_pg'];
		$valor_boleto_pg 	= $x['valor_pg'];
	}
	elseif($formpagamento == 'empenho'){
		$num_empenho_pg 	= $x['numero_pg'];
		$valor_empenho_pg 	= $x['valor_pg'];
		$instituicao_pg		= $x['instituicao_pg'];
	}
	elseif($formpagamento == 'transferencia'){
		$num_transferencia_pg 	= $x['numero_pg'];
		$valor_transferencia_pg = $x['valor_pg'];
		$e_transferencia_pg		= $x['E_pg'];
		$r_transferencia_pg		= $x['R_pg'];
		$u_transferencia_pg		= $x['U_pg'];
	}
	elseif($formpagamento == 'cartao_credito_debito'){
		$num_cartao_pg 		= $x['numero_pg'];
		$valor_cartao_pg 	= $x['valor_pg'];
		$nome_cartao_pg		= $x['nome_cartao_pg'];
		$validade_cartao_pg = $x['validade_pg'];
		$codigo_cartao_pg	= $x['codigo_seguranca_pg'];
		$e_cartao_pg		= $x['E_pg'];
		$r_cartao_pg		= $x['R_pg'];
		$u_cartao_pg		= $x['U_pg'];
	}
	elseif($formpagamento == 'cash'){
		$num_cash_pg 		= $x['numero_pg'];
		$valor_cash_pg 		= $x['valor_pg'];
		$e_cash_pg			= $x['E_pg'];
		$r_cash_pg			= $x['R_pg'];
		$u_cash_pg			= $x['U_pg'];
		$troco_cash_pg		= $x['troco_pg'];
	}
	elseif($formpagamento == 'cheque'){
		$num_cheque_pg 		= $x['numero_pg'];
		$valor_cheque_pg 	= $x['valor_pg'];
		$conta_cheque_pg	= $x['conta_cheque_pg'];
		$banco_cheque_pg	= $x['banco_pg'];
		$ag_cheque_pg		= $x['ag_pg'];
	}
	elseif($formpagamento == 'cortesia'){
		$cortesia_pg 		= $x['cortesia_pg'];
	}
	
	$texto_recibo_pg 		= $x['texto_recibo_pg'];
	$texto_anuidade_pg 		= $x['texto_anuidade_pg'];
	$texto_observacoes_pg 	= $x['texto_observacoes_pg'];
	
$data = $x['data_cadastro']; // Data no formato MySQL
$aux = explode("-",$data); // Faz a separa��o da data em itens
// de uma array
// Agora faz a jun��o invertendo a ordem do itens da data
// para a forma normal.
$data_cadastro = $aux[2]."/".$aux[1]."/".$aux[0];

if($x['nome_evento'] == 'XIV International Conference on Strangeness in Quark Matter'){
echo '
<form name="form" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes='.$x['id'].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="'.$x['email'].'" />
	<input type="hidden" name="nome_evento" value="'.$x['nome_evento'].'" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>'.$x['id'].'</td>
	   </tr>
	   <tr>
 		  <td>Data de Cadastro:</td>
 		  <td>'.$x['data_cadastro'].'</td>
	   </tr>';
	   if(strlen($x['title']) > 0 ){
	  	echo '<tr>
 		  <td width="296">Title:</td>
 		  <td width="505"><input name="title" value="'.$x['title'].'" type="text" id="title" size="50" /></td>
	   	</tr>';
	   }
	   echo '<tr>
		  <td>Family Name:</td>
		  <td><input name="familyname" value="'.$x['familyname'].'" type="text" id="familyname" size="50" /></td>
	   </tr>';
	   if(strlen($x['givenname']) > 0 ){
	   	echo '<tr>
		  <td>Given Name:</td>
		  <td><input name="givenname" value="'.$x['givenname'].'" type="text" id="givenname" size="50"/></td>
		</tr>';
	   }
	   echo '<tr>
			<td>Name to the Badge:</td>
			<td><input name="nametothebagde" value="'.$x['nametothebagde'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	   if(strlen($x['cpf']) > 0 ){
		echo '<tr>
		  <td>CPF:</td>
		  <td><input name="cpf" value="'.$x['cpf'].'" type="text" id="cpf" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['identidade']) > 0 ){
		echo '<tr>
		  <td>Identidade:</td>
		  <td><input name="identidade" value="'.$x['identidade'].'" type="text" id="identidade" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['Affiliation']) > 0 ){
	  	echo '<tr>
			<td>Affiliation:</td>
			<td><input name="Affiliation" value="'.$x['Affiliation'].'" type="text" id="Affiliation" size="50" /></td>
	    </tr>';
	  }else {
	    echo '<tr>
			<td>Institui��o:</td>
			<td><input name="instituicao" value="'.$x['instituicao'].'" type="text" id="instituicao" size="50" /></td>
	    </tr>
		<tr>
			<td>Especialidade:</td>
			<td><input name="especialidade" value="'.$x['especialidade'].'" type="text" id="especialidade" size="50" /></td>
	    </tr>';
	  }
	  echo '<tr>
			<td>Email:</td>
			<td><input name="email_novo" value="'.$x['email'].'" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Mailing Adress:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x[mailingadress].'" /></td>
	  </tr>
	  <tr>
			<td>City:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x[city].'" /></td>
	  </tr>
	  <tr>
			<td>Province/State:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x[provincestate].'" /></td>
	  </tr>';
	  if(strlen($x['country']) > 0 ){
			echo '<tr>
				<td>Country:</td>
				<td><input name="country" type="text" id="country" size="50" value="'.$x[country].'" /></td>
	  		</tr>';
	   }
	   echo '<tr>
			<td>Zip Code:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x[zipcode].'" /></td>
	   </tr>
	   <tr>
			<td>Phone(country and city code):</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x[phone].'" /></td>
	   </tr>
	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x[fax].'" /></td>
	   </tr>';
	   if(strlen($x['accompanyingperson']) > 0 ){
		 echo' <tr>
			<td>Accompanying Person:</td>
			<td><input name="accompanyingperson" type="text" id="accompanyingperson" size="50" value="'.$x[accompanyingperson].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['letter']) > 0 ){
		  echo '<tr>
			<td>NEED AN INVITATION LETTER:</td>
			<td><input name="letter" type="text" id="letter" size="50" value="'.$x[letter].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['profissional']) > 0 ){
		  echo'<tr>
			<td>Profissional Packages:</td>
			<td><input name="profissional" type="text" id="profissional" size="50" value="'.$x[profissional].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['student']) > 0 ){
		  echo '<tr>
			<td>Student Packages:</td>
			<td><input name="student" type="text" id="student" size="50" value="'.$x[student].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['residente']) > 0 ){
		  echo '<tr>
			<td>Residente:</td>
			<td><input name="residente" type="text" id="residente" size="50" value="'.$x[residente].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['gerentologia']) > 0 ){
		  echo '<tr>
			<td>Gerentologia:</td>
			<td><input name="gerentologia" type="text" id="gerentologia" size="50" value="'.$x[gerentologia].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['congnitiva']) > 0 ){
		  echo '<tr>
			<td>Congnitiva:</td>
			<td><input name="congnitiva" type="text" id="congnitiva" size="50" value="'.$x[congnitiva].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['paleativos']) > 0 ){
		  echo '<tr>
			<td>Paleativos:</td>
			<td><input name="paleativos" type="text" id="paleativos" size="50" value="'.$x[paleativos].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['incapacidade']) > 0 ){
		  echo '<tr>
			<td>Incapacidade:</td>
			<td><input name="incapacidade" type="text" id="incapacidade" size="50" value="'.$x[incapacidade].'" /></td>
		  </tr>';
 	   }
	   if(strlen($x['accompanyingperson2']) > 0 ){
		  echo '<tr>
			<td>Accompanying person Packages:</td>
			<td><input name="accompanyingperson2" type="text" id="accompanyingperson2" size="50" value="'.$x[accompanyingperson2].'" /></td>
		  </tr>';
	   }
	   echo '<tr>
			<td>Form Pagamento:</td>
			<td><input name="formpagamento" type="text" id="formpagamento" size="50" value="'.$x[formpagamento].'" /></td>
	   </tr>';
	   if (($x['formpagamento'] != 'boleto') and ($x['formpagamento'] != 'payment_cash') and ($x['formpagamento'] != 'onsite_payment_credit') and ($x['formpagamento'] != 'Deposit') and ($x['formpagamento'] != 'deposito')){
		   echo '<tr>
			<td>Credit Card:</td>
			<td><input name="cartao" type="text" id="cartao" size="50" value="'.$x[cartao].'" /></td>
		  </tr>
		  <tr>
			<td>Name on Credit Card- holder:</td>
			<td><input name="namecredit" type="text" id="namecredit" size="50" value="'.$x[namecredit].'" /></td>
		  </tr>
		  <tr>
			<td>Date:</td>
			<td><input name="datacartao" type="text" id="datacartao" size="50" value="'.$x[datacartao].'" /></td>
		  </tr>
		  <tr>
			<td>Credit Card N�:</td>
			<td><input name="numcredit" type="text" id="numcredit" size="50" value="'.$x[numcredit].'" /></td>
		  </tr>
		  <tr>
			<td>Credit Card Expiration Date:</td>
			<td><input name="expiracartao" type="text" id="expiracartao" size="50" value="'.$x[expiracartao].'" /></td>
		  </tr>
		  <tr>
			<td>Security Code N�:</td>
			<td><input name="securitycode" type="text" id="securitycode" size="50" value="'.$x[securitycode].'" /></td>
		  </tr>';
	   }
	   echo '<tr>
			<td>Total (R$):</td>
			<td><input name="totalescolhido" type="text" id="totalescolhido" size="50" value="'.$x[totalescolhido].'" /></td>
	   </tr>
	   <tr>
			<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
	   </tr>
	 </table>
	</form>';		
}
elseif($x['nome_evento'] == '30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE'){
echo '
<form name="form" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes='.$x['id'].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="'.$x['email'].'" />
	<input type="hidden" name="nome_evento" value="'.$x['nome_evento'].'" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>'.$x['id'].'</td>
	   </tr>
	   <tr>
 		  <td>Data de Cadastro:</td>
 		  <td>'.$data_cadastro.'</td>
	   </tr>';
	   if(strlen($x['title']) > 0 ){
	  	echo '<tr>
 		  <td width="296">Title:</td>
 		  <td width="505"><input name="title" value="'.$x['title'].'" type="text" id="title" size="50" /></td>
	   	</tr>';
	   }
	   if(strlen($x['givenname']) > 0 ){
	   	echo '<tr>
		  <td>First Name:</td>
		  <td><input name="givenname" value="'.$x['givenname'].'" type="text" id="givenname" size="50"/></td>
		</tr>';
	   }
	   echo '<tr>
		  <td>Middle Name:</td>
		  <td><input name="familyname" value="'.$x['familyname'].'" type="text" id="familyname" size="50" /></td>
	   </tr>';
	   echo '<tr>
			<td>Family Name:</td>
			<td><input name="Affiliation" value="'.$x['Affiliation'].'" type="text" id="Affiliation" size="50"/></td>
	   </tr>';
	   echo '<tr>
			<td>Name to the Badge:</td>
			<td><input name="nametothebagde" value="'.$x['nametothebagde'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	  echo '<tr>
			<td>Email:</td>
			<td><input name="email_novo" value="'.$x['email'].'" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Mailing Adress:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x['mailingadress'].'" /></td>
	  </tr>
	  <tr>
			<td>City:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x['city'].'" /></td>
	  </tr>
	  <tr>
			<td>Province/State:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x['provincestate'].'" /></td>
	  </tr>';
	  if(strlen($x['country']) > 0 ){
			echo '<tr>
				<td>Country:</td>
				<td><input name="country" type="text" id="country" size="50" value="'.$x['country'].'" /></td>
	  		</tr>';
	   }
	   echo '<tr>
			<td>Zip Code:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x['zipcode'].'" /></td>
	   </tr>
	   <tr>
			<td>Phone(country and city code):</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x['phone'].'" /></td>
	   </tr>
	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x['fax'].'" /></td>
	   </tr>';
	   if(strlen($x['accompanyingperson']) > 0 ){
		 echo' <tr>
			<td>Accompanying Person:</td>
			<td><input name="accompanyingperson" type="text" id="accompanyingperson" size="50" value="'.$x['accompanyingperson'].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['letter']) > 0 ){
		  echo '<tr>
			<td>NEED AN INVITATION LETTER:</td>
			<td><input name="letter" type="text" id="letter" size="50" value="'.$x['letter'].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['profissional']) > 0 ){
		  echo'<tr>
			<td>Profissional Packages:</td>
			<td><input name="profissional" type="text" id="profissional" size="50" value="'.$x['profissional'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['student']) > 0 ){
		  echo '<tr>
			<td>Student Packages:</td>
			<td><input name="student" type="text" id="student" size="50" value="'.$x['student'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['residente']) > 0 ){
		  echo '<tr>
			<td>Residente:</td>
			<td><input name="residente" type="text" id="residente" size="50" value="'.$x['residente'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['gerentologia']) > 0 ){
		  echo '<tr>
			<td>Aditional Work:</td>
			<td><input name="gerentologia" type="text" id="gerentologia" size="50" value="'.$x['gerentologia'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['congnitiva']) > 0 ){
		  echo '<tr>
			<td>Cilance Dinner:</td>
			<td><input name="congnitiva" type="text" id="congnitiva" size="50" value="'.$x['congnitiva'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['paleativos']) > 0 ){
		  echo '<tr>
			<td>Paleativos:</td>
			<td><input name="paleativos" type="text" id="paleativos" size="50" value="'.$x['paleativos'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['incapacidade']) > 0 ){
		  echo '<tr>
			<td>Incapacidade:</td>
			<td><input name="incapacidade" type="text" id="incapacidade" size="50" value="'.$x['incapacidade'].'" /></td>
		  </tr>';
 	   }
	   if(strlen($x['accompanyingperson2']) > 0 ){
		  echo '<tr>
			<td>Accompanying person Packages:</td>
			<td><input name="accompanyingperson2" type="text" id="accompanyingperson2" size="50" value="'.$x['accompanyingperson2'].'" /></td>
		  </tr>';
	   }
	   echo "<tr>
	   			<td colspan='2'>";
	   ?>
 
        <table border="1" bordercolor="#333333" >
             <tr>
               <td width="21%" rowspan="2" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">REGISTRATION  FEES</span>       </td>
               <td colspan="2" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">UNTIL OCT, 23th</span>       </td>
               <td colspan="2" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">UNTIL OCT, 23th + IACM</span>       </td>
            <td colspan="2" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">ON-SITE</span>       </td>
               <td width="10%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">TOTAL</span>       </td>
             </tr>
             <tr>
               <td width="6%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">R$</span>       </td>
               <td width="7%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">US$</span>       </td>
               <td width="6%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">R$</span>       </td>
               <td width="7%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">US$</span>       </td>
            <td width="7%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">R$</span>       </td>
               <td width="7%" align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">US$</span>       </td>
               <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">(R$  or US$)</span>       </td>
             </tr>
             <tr>
               <td align="left">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">PROFESSIONAL  (*)</span>       </td>
               <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                        <input type="checkbox" name="check1" value="500" onClick="checar()"/><br />500            </span>       </td>
               <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check2" value="245" onClick="checar()"/><br />245            </span>       </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check3" value="540" onClick="checar()"/><br />540</span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check4" value="265" onClick="checar()"/><br />265</span>        </td>
        <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check5" value="700" onClick="checar()"/><br />700            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check6" value="340" onClick="checar()"/><br />340            </span>        </td>
                <td align="center">
                    <span class="style21"><input type="button" name="total1" class="valor" size="5" /></span>        </td>
             </tr>
             <tr>
                <td align="left">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">GRADUATE  STUDENT (*)</span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check7" value="300" onClick="checar()"/><br />300            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check8" value="145" onClick="checar()"/><br />145            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check9" value="340" onClick="checar()"/><br />340</span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check10" value="165" onClick="checar()"/><br />165            </span>        </td>
        <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check11" value="500" onClick="checar()"/><br />500            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check12" value="245" onClick="checar()"/><br />245            </span>        </td>
                <td align="center">
                    <span class="style21">
                    <input type="button" name="total2" class="valor" size="5" />
                    </span>        </td>
             </tr>
             <tr>
                <td align="left">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">UNDERGRADUATE STUDENT  (**)</span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check13" value="100" onClick="checar()"/><br />100            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check14" value="50" onClick="checar()"/><br />50            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check15" value="140" onClick="checar()"/><br />140            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check16" value="70" onClick="checar()"/><br />70            </span>        </td>
        <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check17" value="250" onClick="checar()"/><br />250            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check18" value="125" onClick="checar()"/><br />125            </span>        </td>
                <td align="center">
                    <span class="style21">
                    <input type="button" name="total3" class="valor" size="5" />
                    </span>        </td>
             </tr>
             <tr>
                <td align="left">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">ADITIONAL  WORK  (***)</span>        </td>
                <td colspan="4" align="center"><span class="style21"></span></td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check19" value="150" onClick="checar()"/><br />150            </span>        </td>
                <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check20" value="75" onClick="checar()"/><br />75            </span>        </td>
                <td align="center">
                    <span class="style21">
                    <input type="button" name="total4" class="valor" size="5" />
                    </span>        </td>
             </tr>
             <tr>
               <td align="left">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">CILAMCE  2009 / DINNER  (****)</span>       </td>
               <td colspan="4" align="center"><span class="style21"></span></td>
               <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check21" value="100" onClick="checar()"/><br />100            </span>       </td>
               <td align="center">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif;  font-size: 10px;">
                    <input type="checkbox" name="check22" value="50" onClick="checar()"/><br />50            </span>        </td>
                <td align="center">
                    <span class="style21">
                    <input type="button" name="total5" class="valor" size="5" />
                    </span>        </td>
             </tr>
             <tr>
               <td align="left">
                    <span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;">Total</span>       </td>
               <td colspan="6" align="left">&nbsp;</td>
               <td align="center">
                    <span class="style21">
                    <input type="button" name="totall" class="valor" size="5" id="totall" value="<?=$x['totalescolhido']?>" />
                    </span>       </td>
             </tr>
</table> 
      
       <?php

	 if ($formpagamento == "deposito"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" checked="checked" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "boleto"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto"  checked="checked" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "empenho"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" checked="checked" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "transferencia"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" checked="checked" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cartao_credito_debito"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" checked="checked" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cash"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash"  checked="checked" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cheque"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque"  checked="checked" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cortesia"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0001049 - Conta Corrente: 100136-7
Favorecido: META MARKETING E EVENTOS LTDA - CNPJ:29.595.295/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia"  checked="checked" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>';
                    	if($cortesia_pg == 'Palestrante'){
							$check1 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Comiss�o Organizadora'){
							$check2 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Comiss�o Cient�fica'){
							$check3 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Convidado'){
							$check4 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Staff'){
							$check5 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Free'){
							$check6 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Patroc�nio'){
							$check7 = 'checked="checked"';
						}
						
					echo'	<td><input type="radio" name="cortesia" value="Palestrante" '.$check1.' /></td>
							<td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" '.$check2.' /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" '.$check3.' /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" '.$check4.' /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" '.$check5.' /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free" '.$check6.' /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" '.$check7.' /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }else{
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }
	  ?>      
	 </td>
   </tr>

	   
	</td>
		</tr>
		</table>
	</form>		
<?php 
}

elseif($x['nome_evento'] == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){
echo '
<form name="form" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes='.$x['id'].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="'.$x['email'].'" />
	<input type="hidden" name="nome_evento" value="'.$x['nome_evento'].'" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>'.$x['id'].'</td>
	   </tr>
	   <tr>
 		  <td>Data de Cadastro:</td>
 		  <td>'.$data_cadastro.'</td>
	   </tr>';
	   if(strlen($x['title']) > 0 ){
	  	echo '<tr>
 		  <td width="296">Title:</td>
 		  <td width="505"><input name="title" value="'.$x['title'].'" type="text" id="title" size="50" /></td>
	   	</tr>';
	   }
	   echo '<tr>
		  <td>Nome Completo:</td>
		  <td><input name="familyname" value="'.$x['familyname'].'" type="text" id="familyname" size="50" /></td>
	   </tr>';
	   if(strlen($x['givenname']) > 0 ){
	   	echo '<tr>
		  <td>Given Name:</td>
		  <td><input name="givenname" value="'.$x['givenname'].'" type="text" id="givenname" size="50"/></td>
		</tr>';
	   }
	   echo '<tr>
			<td>Nome para Crach�:</td>
			<td><input name="nametothebagde" value="'.$x['nametothebagde'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	   if(strlen($x['cpf']) > 0 ){
		echo '<tr>
		  <td>CPF:</td>
		  <td><input name="cpf" value="'.$x['cpf'].'" type="text" id="cpf" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['identidade']) > 0 ){
		echo '<tr>
		  <td>Identidade:</td>
		  <td><input name="identidade" value="'.$x['identidade'].'" type="text" id="identidade" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['Affiliation']) > 0 ){
	  	echo '<tr>
			<td>Affiliation:</td>
			<td><input name="Affiliation" value="'.$x['Affiliation'].'" type="text" id="Affiliation" size="50" /></td>
	    </tr>';
	  }else {
	    echo '<tr>
			<td>Institui��o:</td>
			<td><input name="instituicao" value="'.$x['instituicao'].'" type="text" id="instituicao" size="50" /></td>
	    </tr>
		<tr>
			<td>Especialidade:</td>
			<td><input name="especialidade" value="'.$x['especialidade'].'" type="text" id="especialidade" size="50" /></td>
	    </tr>';
	  }
	  echo '<tr>
			<td>Email:</td>
			<td><input name="email_novo" value="'.$x['email'].'" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Endere�o:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x[mailingadress].'" /></td>
	  </tr>
	  <tr>
			<td>Cidade:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x[city].'" /></td>
	  </tr>
	  <tr>
			<td>Estado:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x[provincestate].'" /></td>
	  </tr>';
	  if(strlen($x['country']) > 0 ){
			echo '<tr>
				<td>Country:</td>
				<td><input name="country" type="text" id="country" size="50" value="'.$x[country].'" /></td>
	  		</tr>';
	   }
	   echo '<tr>
			<td>CEP:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x[zipcode].'" /></td>
	   </tr>
	   <tr>
			<td>Telefone:</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x[phone].'" /></td>
	   </tr>
	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x[fax].'" /></td>
	   </tr>
	   ';
	   //$pacote = "";
	   if(isset($x['accompanyingperson'])){
	   $pacote = $x['accompanyingperson']."  ";
	   }
	   if(isset($x['profissional'])){
	   $pacote .= $x['profissional']."  ";
	   }
	   if(isset($x['residente'])){
	   $pacote .= $x['residente']."  ";
	   }
	   if(isset($x['student'])){
	   $pacote .= $x['student']."  ";
	   }
	   if(ereg('At� 02',$x['gerentologia'])){
	   $pacote .= $x['gerentologia']."  ";
	   }
	   if(ereg('At� 02',$x['congnitiva'])){
	   $pacote .= $x['congnitiva']."  ";
	   }
	   if(ereg('At� 02',$x['paleativos'])){
	   $pacote .= $x['paleativos']."  ";
	   }
	   if(ereg('At� 02',$x['incapacidade'])){
	   $pacote .= $x['incapacidade']."  ";
	   }
	   if(isset($x['accompanyingperson2'])){
	   $pacote .= $x['accompanyingperson2']."  ";
	   }
	   if(isset($x['profissional'])){
	   $pacote .= $x['profissional']."  ";
	   }
	   if(ereg('No Evento',$x['gerentologia'])){
	   $pacote .= $x['gerentologia']."  ";
	   }
	   if(ereg('No Evento',$x['congnitiva'])){
	   $pacote .= $x['congnitiva']."  ";
	   }
	   if(ereg('No Evento',$x['paleativos'])){
	   $pacote .= $x['paleativos']."  ";
	   }
	   if(ereg('No Evento',$x['incapacidade'])){
	   $pacote .= $x['incapacidade']."  ";
	   }
	   echo	'<td>PACOTE ESCOLHIDO:</td>
			<td>'.$pacote.'</td>
	   </tr>
	   ';
	   ?>
       
<table width="100%" border="1" bordercolor="" bgcolor="" cellpadding="0" style="margin-top:0px;" cellspacing="0">
 <tr>
	<td colspan="4" align="center" style="font-family:verdana; font-size:12px"; bgcolor=""><strong>Investimentos</strong>
    </td>
 </tr>
 <tr>
 	<td width="50%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> Categoria</strong>
    </td>
	<td width="21%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> At&eacute; 02/10/2009</strong>
    </td>
	<td width="21%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> Recebido pela secretaria at� 19/10/2009</strong>
    </td>
	<td width="8%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> Total</strong>
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	S&oacute;cios Quites da SBGG
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check1' value='270.00' onClick="checar()" />R$ 270.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
   		<input type='checkbox' name="check2" value='380.00' onClick="checar()" />R$ 380.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
   		<input type="button" name="total1" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	N&acirc;o S&oacute;cios
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check3' value='380.00' onClick="checar()" />R$ 380.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name="check4" value='480.00' onClick="checar()" />R$ 480.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total2" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
		Residentes
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check5' value='340.00' onClick="checar()" />R$ 340.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name="check6" value='400.00' onClick="checar()" />R$ 400.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total3" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
		Estudantes de Gradua&ccedil;&acirc;o
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check7' value='200.00' onClick="checar()" />R$ 200.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name="check8" value='200.00' onClick="checar()" />R$ 200.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total4" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	Curso "Gerontologia"(*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND gerentologia > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
        if($z <= 800){
          	echo '<input type="checkbox" name="check9" value="50.00" onclick="checar()" />';
		}
	?>
    R$ 50.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
	if($z <= 800){
       	echo '<input type="checkbox" name="check10" value="50.00" onclick="checar()" />';
	}
	?>
    R$ 50.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total5" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
	    Oficina 01 "Avalia&ccedil;&acirc;o Cognitiva" (*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
     <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND congnitiva > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
		if($z <= 800){
            echo '<input type="checkbox" name="check11" value="50.00" onclick="checar()" />';
		}
	 ?>	
    	R$ 50.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		if($z <= 800){
          	echo '<input type="checkbox" name="check12" value="50" onclick="checar()" />';
		}
	?>
    R$ 50.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total6" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	Tribuna Livre "&Uacute;ltimo Ato - Li&ccedil;&otilde;es Perto do Fim" (antiga Oficina 2) (*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND paleativos > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
		if($z <= 800){
           	echo '<input type="checkbox" name="check13" value="gratuito" />';
		}
	?>
    gratuito
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
	<?php
	if($z <= 800){
       	echo '<input type="checkbox" name="check14" value="gratuito" />';
	}
	?> 
    gratuito
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total7" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	Encontro com Especialista "Incapacidade" (*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND incapacidade > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
		if($z <= 800){
           	echo '<input type="checkbox" name="check15" value="gratuito" />';
		}
	?>	 
    gratuito
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
	if($z <= 800){
       	echo '<input type="checkbox" name="check16" value="gratuito" />';
	}
	?> 
    gratuito
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total8" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="3" style="font-family:verdana; font-size:12px";>
	    <strong> Total</strong>
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="totall" class="valor" size="5" />
    </td>
 </tr>
</table>
<table border="0" width="100%">
  <tr>
	<td align="left" colspan="3">
	 <?php
	 $sql=mysql_query("SELECT * FROM cedente WHERE id_evento='$id_ev'");
	 $x=mysql_fetch_array($sql);
	 $conta=$x['conta']."-".$x['conta_div'];
	 $agencia=$x['agencia'];
	 $cnpj=$x['cpf_cnpj'];
	 $favorecido=$x['cedente'];
	 if ($formpagamento == "deposito"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" checked="checked" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "boleto"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto"  checked="checked" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "empenho"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" checked="checked" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "transferencia"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" checked="checked" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cartao_credito_debito"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" checked="checked" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cash"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash"  checked="checked" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cheque"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque"  checked="checked" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }elseif($formpagamento == "cortesia"){
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia"  checked="checked" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>';
                    	if($cortesia_pg == 'Palestrante'){
							$check1 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Comiss�o Organizadora'){
							$check2 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Comiss�o Cient�fica'){
							$check3 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Convidado'){
							$check4 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Staff'){
							$check5 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Free'){
							$check6 = 'checked="checked"';
						}
						elseif($cortesia_pg == 'Patroc�nio'){
							$check7 = 'checked="checked"';
						}
						
					echo'	<td><input type="radio" name="cortesia" value="Palestrante" '.$check1.' /></td>
							<td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" '.$check2.' /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" '.$check3.' /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" '.$check4.' /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" '.$check5.' /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free" '.$check6.' /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" '.$check7.' /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }else{
	 	echo '         <table width="100%" border="0" bordercolor="#333333" class="texto cor_tr">
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
           		<td colspan="2" align="center"><b>FORMAS DE PAGAMENTO</b></td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Data de Pagamento</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="data_pg" size="10" maxlength="10" onKeyUp="barra(this)" value="'.$data_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
           		<td colspan="2">&nbsp;</td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="deposito" />
                 <span class="textotab"><b>Dep�sito / Trasfer�ncia</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Banco: UNIBANCO (409) - Ag�ncia: 0000586 - Conta Corrente: 127595-5
Favorecido: Sociedade Brasileira de Geriatria e Gerontologia Se��o Rio de Janeiro - CNPJ:29.548.054/0001-78</td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_deposito" size="30" value="'.$num_deposito_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_deposito" size="30" value="'.$valor_deposito_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="boleto" />
                 <span class="textotab"><b>Boleto Banc�rio</b></span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="50%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_boleto" size="30" value="'.$num_boleto_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_boleto" size="30" value="'.$valor_boleto_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="empenho" />
                 <span class="textotab"><b>Empenho</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Empenho: </span></td>
                        <td><input type="text" name="num_empenho" size="30" value="'.$num_empenho_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Institui��o: </span></td>
                        <td><input type="text" name="instituicao_empenho" size="30" value="'.$instituicao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_empenho" size="30" value="'.$valor_empenho_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="transferencia" />
                 <span class="textotab"><b>Transfer�ncia Internacional</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                	<tr>
                    	<td><span class="textotab">N�: </span></td>
                        <td><input type="text" name="num_transferencia" size="30" value="'.$num_transferencia_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
<td>E$: <input type="text" name="e_transferencia_pg" size="5" value="'.$e_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_transferencia_pg" size="5" value="'.$r_transferencia_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_transferencia_pg" size="5" value="'.$u_transferencia_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cartao_credito_debito" />
                 <span class="textotab"><b>Cart�o de Cr�dito/D�bito</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="100%">
                	<tr>
                    	<td><span class="textotab">Nome: </span></td>
                        <td><input type="text" name="nome_cartao_pg" size="30" value="'.$nome_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">N� Cart�o: </span></td>
                        <td><input type="text" name="num_cartao_pg" size="30" value="'.$num_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">Validade: </span></td>
                        <td><input type="text" name="validade_cartao_pg" size="30" value="'.$validade_cartao_pg.'" /></td>
                    </tr>
                	<tr>
                    	<td><span class="textotab">C�digo Seguran�a: </span></td>
                        <td><input type="text" name="codigo_cartao_pg" size="30" value="'.$codigo_cartao_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cartao_pg" size="5" value="'.$e_cartao_pg.'" />&nbsp;&nbsp;&nbsp;R$: <input type="text" name="r_cartao_pg" size="5" value="'.$r_cartao_pg.'" />&nbsp;&nbsp;&nbsp;U$: <input type="text" name="u_cartao_pg" size="5" value="'.$u_cartao_pg.'" /></td>
</tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cash" />
                 <span class="textotab"><b>Cash</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="80%">
                    <tr>
                        <td><span class="textotab">Valor: </span></td>                        
						<td>E$: <input type="text" name="e_cash_pg" size="5" value="'.$e_cash_pg.'" /><br />R$: <input type="text" name="r_cash_pg" size="5" value="'.$r_cash_pg.'" /><br />U$: <input type="text" name="u_cash_pg" size="5" value="'.$u_cash_pg.'" /></td>
</tr>
                	<tr>
                    	<td><span class="textotab">Troco: </span></td>
                        <td><input type="text" name="troco_cash" size="10" value="'.$troco_cash_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cheque" />
                 <span class="textotab"><b>Cheque</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><span class="textotab">N� Cheque: </span></td>
                        <td><input type="text" name="num_cheque" size="30" value="'.$num_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Banco: </span></td>
                        <td><input type="text" name="banco_cheque" size="30" value="'.$banco_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Ag: </span></td>
                        <td><input type="text" name="ag_cheque" size="30" value="'.$ag_cheque_pg.'" /></td>
                    </tr>
					<tr>
                        <td><span class="textotab">C/C: </span></td>
                        <td><input type="text" name="conta_cheque" size="30" value="'.$conta_cheque_pg.'" /></td>
                    </tr>
                    <tr>
                        <td><span class="textotab">Valor: </span></td>
                        <td><input type="text" name="valor_cheque" size="30" value="'.$valor_cheque_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><input type="radio" name="formpagamento" value="cortesia" />
                 <span class="textotab"><b>Cortesia</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                    	<td><input type="radio" name="cortesia" value="Palestrante" /></td>
                        <td>Palestrante</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Organizadora" /></td>
                        <td>Comiss�o Organizadora</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Comiss�o Cient�fica" /></td>
                        <td>Comiss�o Cient�fica</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Convidado" /></td>
                        <td>Convidado</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Staff" /></td>
                        <td>Staff</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Free"  /></td>
                        <td>FREE</td>
                    </tr>
                    <tr>
                    	<td><input type="radio" name="cortesia" value="Patroc�nio" /></td>
                        <td>Patroc�nio</td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Recibo</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_recibo_pg" size="30" value="'.$texto_recibo_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Anuidade</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><input type="text" name="texto_anuidade_pg" size="30" value="'.$texto_anuidade_pg.'" /></td>
                    </tr>
                </table>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="left"><span class="textotab"><b>Observa��es</b>:</span></td>
           </tr>
           <tr>
             <td colspan="2" align="left">
             	<table width="60%">
                	<tr>
                        <td><textarea name="texto_observacoes_pg" cols="50" rows="5">'.$texto_observacoes_pg.'</textarea></td>
                    </tr>
                </table>
             </td>
           </tr>
       </table>
		';
	 }
	  ?>      
	 </td>
   </tr>
   <?php
	   echo '<tr>
			<td align="center" colspan="5"><a href="javascript:history.go(-1)">Voltar</a></td>
	   </tr>
	 </table>
	</form>';		
}
}
?>