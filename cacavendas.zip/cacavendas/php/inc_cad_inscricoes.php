<?
include ("config.php");
 $id				= $_POST['id'];
 
 if($id == '1'){
 $data_cadastro 	=date('Y-m-d');
 $nome_evento 		= $_POST['eventos'];
 $title				= $_POST['title'];
 $familyname		= $_POST['familyname'];
 $givenname			= $_POST['givenname'];
 $nametothebagde	= $_POST['nametothebagde'];
 $Affiliation		= $_POST['Affiliation'];
 $mailingadress		= $_POST['mailingadress'];
 $city				= $_POST['city'];
 $provincestate		= $_POST['provincestate'];
 $country			= $_POST['country'];
 $zipcode			= $_POST['zipcode'];
 $email				= $_POST['email'];
 $phone				= $_POST['phone'];
 $phoneddi			= $_POST['phoneddi'];
 $phoneddd			= $_POST['phoneddd'];
 $fax				= $_POST['fax'];
 $faxddi			= $_POST['faxddi'];
 $faxddd			= $_POST['faxddd'];
 $accompanyingperson= $_POST['accompanyingperson']; 
 $letter			= $_POST['letter'];
 $formpagamento		= $_POST['formpagamento'];
 $cartao			= $_POST['cartao'];
 $namecredit		= $_POST['namecredit'];
 $datedia			= $_POST['datedia'];
 $datemes			= $_POST['datemes'];
 $dateano			= $_POST['dateano'];
 $datacartao 		= $dateano."-".$datemes."-".$datedia;
 $numcredit				= $_POST['numcredit1']."".$_POST['numcredit2']."".$_POST['numcredit3']."".$_POST['numcredit4']."".$_POST['numcredit5']."".$_POST['numcredit6']."".$_POST['numcredit7']."".$_POST['numcredit8']."".$_POST['numcredit9']."".$_POST['numcredit10']."".$_POST['numcredit11']."".$_POST['numcredit12']."".$_POST['numcredit13']."".$_POST['numcredit14']."".$_POST['numcredit15']."".$_POST['numcredit16'];
 $expmes			= $_POST['expmes'];
 $expano			= $_POST['expano'];
 $expiracartao 		= $expmes."/".$expano;
 $securitycode		= $_POST['securitycode'];
 $check1			= $_POST['check1'];
 $check2			= $_POST['check2'];
 $check3			= $_POST['check3'];
 $check4			= $_POST['check4'];
 $check5			= $_POST['check5'];
 $check6			= $_POST['check6'];  
 $check7			= $_POST['check7'];
 $check8			= $_POST['check8'];  
 $check9			= $_POST['check9'];
 $totalescolhido	= $check1+$check2+$check3+$check4+$check5+$check6+$check7+$check8+$check9; 

 if ($check1!=""){ 
    $profissional="Until Aug, 21th";
 }else{
    $profissional="";
 } 
 if ($check2!="" && $check1!=""){ 
    $profissional2=" / Until Sep, 21th";
 }else if ($check2!=""){
    $profissional2="Until Sep, 21th";
 }else if ($check2==""){
    $profissional2="";
 }
 if ($check2!="" && $check3!=""){ 
    $profissional3=" / On-site";
 }else if ($check3!=""){
    $profissional3="On-site";
 }
 if ($check4!=""){ 
    $Student="Until Aug, 21th";
 }else{
    $Student="";
 }
 if ($check4!="" && $check5!=""){ 
    $Student2=" / Until Sep, 21th";
 }else if ($check5!=""){
    $Student2="Until Sep, 21th";
 }else{
    $Student2="";
 }
 if ($check5!="" && $check6!=""){ 
    $Student3=" / On-site";
 }else if ($check6!=""){
    $Student3="On-site";
 }else{
    $Student3="";
 }
 if ($check7!=""){ 
    $Accompanyingperson2="Until Aug, 21th";
 }else{
    $Accompanyingperson2="";
 }
 if ($check7!="" && $check8!=""){ 
    $Accompanyingperson3=" / Until Sep, 21th";
 }else if ($check8!=""){
    $Accompanyingperson3="Until Sep, 21th";
 }else{
    $Accompanyingperson3="";
 }
 if ($check8!="" && $check9!=""){ 
    $Accompanyingperson4=" / On-site";
 }else if ($check9!=""){
    $Accompanyingperson4="On-site";
 }else{
    $Accompanyingperson4="";
 }
 $accompanyingperson2 = $Accompanyingperson2.$Accompanyingperson3.$Accompanyingperson4;
 $Profissional = $profissional.$profissional2.$profissional3;
 $student = $Student.$Student2.$Student3;
 $select = "SELECT * FROM eventos WHERE nome_evento = '".$nome_evento."'";
 $sql = mysql_query($select) or die ("Query  ".$select." : ".mysql_error());
 $y = mysql_fetch_array($sql);
 
   //gerar senha para a altera��o do cadastro
		$senha = "abcdefghijlkmnopqrstuvxzwyABCDEFGHIJLKMNOPQRSTUVXZYW0123456789";
		srand ((double)microtime()*1000000);
		for ($i=0; $i<6; $i++) {
		$password .= $senha[rand()%strlen($senha)];
		}
		$login = $email;
		$senha = $password;
		$ipuser= $_SERVER['REMOTE_ADDR'];
		$dateuser= date("y.m.d H:i:s");
    //email que ser� enviado para o candidato
   $headers = "MIME-Version: 1.0\n";
   $headers.= "Content-type: text/html; charset=UTF-8\n";	
   $headers.= "From: Online Registration <meta@wb.com.br>\n";
    $subjectt= "Meta - Event Confirmation";
    $messagee= "Your registration request has been succesfully received.<br><br>Please, save your login and password:<br />login = ".$login."<br />password = ".$senha."<br /><br>To change your payment choice, access the link below and type login and password:
<a href='https://www.metaeventos.net/inscricoes/index2.php?id_evento=".$y['id']."'>Payment choice</a><br /><br>Att.<br><b>Meta Marketing e Eventos</b><br>Secretariat.";
   //mail($email, $subjectt, $messagee, $headers);
 
 
  $sql = mysql_query("INSERT INTO usuarios (login, senha, email, data_hora, tipo_usuario, ip, inicio, ip_inicio)
    VALUES ('$login','$senha', '$email', '$dateuser', 'usuario', '$ipuser', '$dateuser', '$ipuser')");
   //Insere no banco de dados
      $cadastrar = mysql_query("INSERT INTO inscricoes (nome_evento, data_cadastro, title, familyname, givenname, nametothebagde, Affiliation, mailingadress, city, provincestate, country, zipcode, email, phone, fax, accompanyingperson,  letter, profissional, student, accompanyingperson2, formpagamento, cartao, namecredit, datacartao, numcredit, expiracartao, securitycode, totalescolhido )    VALUES ( '$nome_evento', '$data_cadastro', '$title', '$familyname', '$givenname', '$nametothebagde', '$Affiliation', '$mailingadress', '$city', '$provincestate', '$country', '$zipcode', '$email', '$phone', '$fax', '$accompanyingperson',  '$letter', '$Profissional', '$student', '$accompanyingperson2', '$formpagamento', '$cartao', '$namecredit', '$datacartao', '$numcredit', '$expiracartao', '$securitycode', '$totalescolhido')"); 
	  //insere os campos na tabela
	Header("Location: ../adm_inscricoes.php");

}
elseif($id == '4'){
 $data_cadastro 	=date('Y-m-d');
 $nome_evento 		= $_POST['eventos'];
 $title				= $_POST['title'];
 $first_name		= $_POST['first_name'];
 $middle_name		= $_POST['middle_name'];
 $familyname		= $_POST['familyname'];
 $nametothebagde	= $_POST['nametothebagde'];
 $institution		= $_POST['institution'];
 $mailingadress		= $_POST['mailingadress'];
 $city				= $_POST['city'];
 $provincestate		= $_POST['provincestate'];
 $country			= $_POST['country'];
 $zipcode			= $_POST['zipcode'];
 $email				= $_POST['email'];
 $phone				= $_POST['phone'];
 $phoneddi			= $_POST['phoneddi'];
 $phoneddd			= $_POST['phoneddd'];
 $phone			    = "(".$phoneddi.")(".$phoneddd.") ".$phone;
 $fax				= $_POST['fax'];
 $faxddi			= $_POST['faxddi'];
 $faxddd			= $_POST['faxddd'];
 $fax			    = "(".$faxddi.")(".$faxddd.") ".$fax;
 $formpagamento		= $_POST['formpagamento'];
 $cartao			= $_POST['cartao'];
 $namecredit		= $_POST['namecredit'];
 $numcredit				= $_POST['numcredit1']."".$_POST['numcredit2']."".$_POST['numcredit3']."".$_POST['numcredit4']."".$_POST['numcredit5']."".$_POST['numcredit6']."".$_POST['numcredit7']."".$_POST['numcredit8']."".$_POST['numcredit9']."".$_POST['numcredit10']."".$_POST['numcredit11']."".$_POST['numcredit12']."".$_POST['numcredit13']."".$_POST['numcredit14']."".$_POST['numcredit15']."".$_POST['numcredit16'];
 $expmes			= $_POST['expmes'];
 $expano			= $_POST['expano'];
 $expiracartao 		= $expmes."/".$expano;
 $securitycode		= $_POST['securitycode'];
 $data_pagamento_pg =$aux[0]."-".$aux[1]."-".$aux[2];


 
  if($formpagamento == 'deposito'){
 $numero_pg			=$_POST['num_deposito'];
 $valor_pg			=$_POST['valor_deposito'];
 }
 elseif($formpagamento == 'boleto'){
 $numero_pg			=$_POST['num_boleto'];
 $valor_pg			=$_POST['valor_boleto'];
 }
 elseif($formpagamento == 'empenho'){
 $numero_pg			=$_POST['num_empenho'];
 $valor_pg			=$_POST['valor_empenho'];
 $instituicao_pg	=$_POST['instituicao_empenho'];
 }
 elseif($formpagamento == 'transferencia'){
 $numero_pg			=$_POST['num_transferencia'];
 $valor_pg			=$_POST['valor_transferencia'];
 $E_pg				=$_POST['e_pg'];
 $R_pg				=$_POST['r_pg'];
 $U_pg				=$_POST['u_pg'];
 }
 elseif($formpagamento == 'cartao_credito_debito'){
 $numero_pg			=$_POST['num_cartao_pg'];
 $valor_pg			=$_POST['valor_cartao'];
 $nome_cartao_pg	=$_POST['nome_cartao_pg'];
 $validade_cartao_pg=$_POST['validade_cartao_pg'];
 $codigo_cartao_pg	=$_POST['codigo_cartao_pg'];
 $E_pg				=$_POST['e_pg'];
 $R_pg				=$_POST['r_pg'];
 $U_pg				=$_POST['u_pg'];
 }
 elseif($formpagamento == 'cash'){
 $valor_pg			=$_POST['valor_cash'];
 $E_pg				=$_POST['e_pg'];
 $R_pg				=$_POST['r_pg'];
 $U_pg				=$_POST['u_pg'];
 $troco_pg			=$_POST['troco'];
 }
 elseif($formpagamento == 'cheque'){
 $numero_pg			=$_POST['num_cheque'];
 $valor_pg			=$_POST['valor_cheque'];
 $banco_cheque_pg	=$_POST['banco_cheque'];
 $ag_cheque_pg		=$_POST['ag_cheque'];
 $conta_cheque_pg	=$_POST['conta_cheque'];
 }
 elseif($formpagamento == 'cortesia'){
 $cortesia_pg		=$_POST['cortesia'];
 }
 
 $texto_recibo_pg	=$_POST['texto_recibo_pg'];
 $texto_anuidade_pg	=$_POST['texto_anuidade_pg'];
 $texto_observacoes_pg	=$_POST['texto_observacoes_pg'];

 
 $check1			= $_POST['check1'];
 $check2			= $_POST['check2'];
 $check3			= $_POST['check3'];
 $check4			= $_POST['check4'];
 $check5			= $_POST['check5'];
 $check6			= $_POST['check6'];  
 $check7			= $_POST['check7'];
 $check8			= $_POST['check8'];  
 $check9			= $_POST['check9'];
 $check10			= $_POST['check10'];
 $check11			= $_POST['check11'];
 $check12			= $_POST['check12'];
 $check13			= $_POST['check13'];
 $check14			= $_POST['check14'];
 $check15			= $_POST['check15'];
 $check16			= $_POST['check16'];  
 $check17			= $_POST['check17'];
 $check18			= $_POST['check18'];  
 $check19			= $_POST['check19'];
 $check20			= $_POST['check20'];
 $check21			= $_POST['check21'];  
 $check22			= $_POST['check22'];
 $totalescolhido	= $check1+$check2+$check3+$check4+$check5+$check6+$check7+$check8+$check9+$check10+$check11+$check12+$check13+$check14+$check15+$check16+$check17+$check18+$check19+$check20+$check21+$check22; 

	if (($check1!="") or $check2!=""){ 
   		$profissional="PROFESSIONAL /  UNTIL OCT, 23th";
	}else{
    	$profissional="";
	} 

	if (($check3!="") or $check4!=""){ 
   		$profissional2="PROFESSIONAL /  UNTIL OCT, 23th + IACM";
	}else{
    	$profissional2="";
	} 

	if (($check5!="") or $check6!=""){ 
   		$profissional3="PROFESSIONAL / ON-SITE";
	}else{
    	$profissional3="";
	} 

	if (($check7!="") or $check8!=""){ 
   		$postgraduatestudent="GRADUATE STUDENT / UNTIL OCT, 23th";
	}else{
    	$postgraduatestudent="";
	} 

	if (($check9!="") or $check10!=""){ 
   		$postgraduatestudent2="GRADUATE STUDENT / UNTIL OCT, 23th + IACM";
	}else{
    	$postgraduatestudent2="";
	}

	if (($check11!="") or $check12!=""){ 
   		$postgraduatestudent3="GRADUATE STUDENT / ON-SITE";
	}else{
    	$postgraduatestudent3="";
	}

	if (($check13!="") or $check14!=""){ 
   		$graduatestudent="UNDERGRADUATE STUDENT / UNTIL OCT, 23th";
	}else{
    	$graduatestudent="";
	}

	if (($check15!="") or $check16!=""){ 
   		$graduatestudent2="UNDERGRADUATE STUDENT / UNTIL OCT, 23th + IACM";
	}else{
    	$graduatestudent2="";
	}

	if (($check17!="") or $check18!=""){ 
   		$graduatestudent3="UNDERGRADUATE STUDENT / ON-SITE";
	}else{
    	$graduatestudent3="";
	}

	if (($check19!="") or $check20!=""){ 
   		$aditionalwork ="ADITIONAL WORK / ON-SITE";
	}else{
    	$aditionalwork="";
	}

	if (($check21!="") or $check22!=""){ 
   		$cilamcedinner  ="CILAMCE 2009 DINNER  / ON-SITE";
	}else{
   	$cilamcedinner="";
	}
	$Profissional		 	= $profissional.$profissional2.$profissional3;
	$Postgraduatestudent	= $postgraduatestudent.$postgraduatestudent2.$postgraduatestudent3;
	$Graduatestudent		= $graduatestudent.$graduatestudent2.$graduatestudent3;
	$Aditionalwork			= $aditionalwork.$aditionalwork2;
	$Cilamcedinner			= $cilamcedinner.$cilamcedinner2;
	
 $select = "SELECT * FROM eventos WHERE nome_evento = '".$nome_evento."'";
 $sql = mysql_query($select) or die ("Query  ".$select." : ".mysql_error());
 $y = mysql_fetch_array($sql);
 
   //gerar senha para a altera��o do cadastro
		$senha = "abcdefghijlkmnopqrstuvxzwyABCDEFGHIJLKMNOPQRSTUVXZYW0123456789";
		srand ((double)microtime()*1000000);
		for ($i=0; $i<6; $i++) {
		$password .= $senha[rand()%strlen($senha)];
		}
		$login = $email;
		$senha = $password;
		$ipuser= $_SERVER['REMOTE_ADDR'];
		$dateuser= date("y.m.d H:i:s");
    //email que ser� enviado para o candidato
   $headers = "MIME-Version: 1.0\n";
   $headers.= "Content-type: text/html; charset=UTF-8\n";	
   $headers.= "From: Online Registration <meta@wb.com.br>\n";
    $subjectt= "Meta - Event Confirmation";
    $messagee= "Your registration request has been succesfully received.<br><br>Please, save your login and password:<br />login = ".$login."<br />password = ".$senha."<br /><br>To change your payment choice, access the link below and type login and password:
<a href='https://www.metaeventos.net/inscricoes/index2.php?id_evento=".$y['id']."'>Payment choice</a><br /><br>Att.<br><b>Meta Marketing e Eventos</b><br>Secretariat.";
   //mail($email, $subjectt, $messagee, $headers);
 
 
  $sql = mysql_query("INSERT INTO usuarios (login, senha, email, data_hora, tipo_usuario, ip, inicio, ip_inicio)
    VALUES ('$login','$senha', '$email', '$dateuser', 'usuario', '$ipuser', '$dateuser', '$ipuser')");
   //Insere no banco de dados
      $cadastrar = mysql_query("INSERT INTO inscricoes (nome_evento, data_cadastro, title, givenname, familyname, Affiliation, nametothebagde, instituicao, mailingadress, city, provincestate, country, zipcode, email, phone, fax, profissional, student, residente, gerentologia, congnitiva, formpagamento, numero_pg, valor_pg, instituicao_pg, R_pg, E_pg, U_pg, nome_cartao_pg, validade_pg, codigo_seguranca_pg, troco_pg, banco_pg, ag_pg, conta_cheque_pg, cortesia_pg, data_pg, texto_recibo_pg, texto_anuidade_pg, texto_observacoes_pg, cartao, namecredit, numcredit, expiracartao, securitycode, totalescolhido )    VALUES ( '$nome_evento', '$data_cadastro', '$title', '$first_name', '$middle_name', '$familyname', '$nametothebagde', '$institution', '$mailingadress', '$city', '$provincestate', '$country', '$zipcode', '$email', '$phone', '$fax', '$Profissional','$Postgraduatestudent','$Graduatestudent', '$Aditionalwork','$Cilamcedinner', '$formpagamento', '$numero_pg', '$valor_pg', '$instituicao_pg', '$R_pg', '$E_pg', '$U_pg', '$nome_cartao_pg', '$validade_cartao_pg', '$codigo_cartao_pg', '$troco_pg', '$banco_cheque_pg', '$ag_cheque_pg', '$conta_cheque_pg', '$cortesia_pg', '$data_pagamento_pg', '$texto_recibo_pg', '$texto_anuidade_pg', '$texto_observacoes_pg', '$cartao', '$namecredit', '$numcredit', '$expiracartao', '$securitycode', '$totalescolhido')"); 
	  //insere os campos na tabela
	Header("Location: ../adm_inscricoes.php");

}
elseif ($id == '406'){

 $nome_evento		=$_POST['eventos'];
 $nome_completo		=$_POST['nome_completo'];
 $nome_para_cracha	=$_POST['nome_para_cracha'];
 $instituicao		=$_POST['instituicao'];
 $especialidade		=$_POST['especialidade'];
 $cpf				=$_POST['cpf'];
 $identidade		=$_POST['identidade'];
 $endereco			=$_POST['endereco'];
 $cep				=$_POST['cep'];
 $cidade			=$_POST['cidade'];
 $estado			=$_POST['estado'];
 $email				=$_POST['email'];
 $phoneddi			=$_POST['phoneddi'];
 $phoneddd			=$_POST['phoneddd'];
 $phone			   .="(".$phoneddi.")(".$phoneddd.") ".$_POST['phone'];
 $faxddi			=$_POST['faxddi'];
 $faxddd			=$_POST['faxddd'];
 $fax			   .="(".$faxddi.")(".$faxddd.") ".$_POST['fax'];
 $formpagamento		=$_POST['formpagamento'];
 $data_cadastro 	=date('Y-m-d');
 $data 				=$_POST['data_pagamento']; 
 $aux 				=explode("-",$data); 
 $data_pagamento_pg =$aux[0]."-".$aux[1]."-".$aux[2];
 
 if($formpagamento == 'deposito'){
 $numero_pg			=$_POST['num_deposito'];
 $valor_pg			=$_POST['valor_deposito'];
 }
 elseif($formpagamento == 'boleto'){
 $numero_pg			=$_POST['num_boleto'];
 $valor_pg			=$_POST['valor_boleto'];
 }
 elseif($formpagamento == 'empenho'){
 $numero_pg			=$_POST['num_empenho'];
 $valor_pg			=$_POST['valor_empenho'];
 $instituicao_pg	=$_POST['instituicao_empenho'];
 }
 elseif($formpagamento == 'transferencia'){
 $numero_pg			=$_POST['num_transferencia'];
 $valor_pg			=$_POST['valor_transferencia'];
 $E_pg				=$_POST['e_pg'];
 $R_pg				=$_POST['r_pg'];
 $U_pg				=$_POST['u_pg'];
 }
 elseif($formpagamento == 'cartao_credito_debito'){
 $numero_pg			=$_POST['num_cartao_pg'];
 $valor_pg			=$_POST['valor_cartao'];
 $nome_cartao_pg	=$_POST['nome_cartao_pg'];
 $validade_cartao_pg=$_POST['validade_cartao_pg'];
 $codigo_cartao_pg	=$_POST['codigo_cartao_pg'];
 $E_pg				=$_POST['e_pg'];
 $R_pg				=$_POST['r_pg'];
 $U_pg				=$_POST['u_pg'];
 }
 elseif($formpagamento == 'cash'){
 $valor_pg			=$_POST['valor_cash'];
 $E_pg				=$_POST['e_pg'];
 $R_pg				=$_POST['r_pg'];
 $U_pg				=$_POST['u_pg'];
 $troco_pg			=$_POST['troco'];
 }
 elseif($formpagamento == 'cheque'){
 $numero_pg			=$_POST['num_cheque'];
 $valor_pg			=$_POST['valor_cheque'];
 $banco_cheque_pg	=$_POST['banco_cheque'];
 $ag_cheque_pg		=$_POST['ag_cheque'];
 $conta_cheque_pg	=$_POST['conta_cheque'];
 }
 elseif($formpagamento == 'cortesia'){
 $cortesia_pg		=$_POST['cortesia'];
 }
 
 $texto_recibo_pg	=$_POST['texto_recibo_pg'];
 $texto_anuidade_pg	=$_POST['texto_anuidade_pg'];
 $texto_observacoes_pg	=$_POST['texto_observacoes_pg'];

 $check1			=$_POST['check1'];
 $check2			=$_POST['check2'];
 $check3			=$_POST['check3'];
 $check4			=$_POST['check4'];
 $check5			=$_POST['check5'];
 $check6			=$_POST['check6'];  
 $check7			=$_POST['check7'];
 $check8			=$_POST['check8'];  
 $check9			=$_POST['check9'];
 $check10			=$_POST['check10'];
 $check11			=$_POST['check11'];
 $check12			=$_POST['check12'];
 $check13			=$_POST['check13'];
 $check14			=$_POST['check14'];
 $check15			=$_POST['check15'];
 $check16			=$_POST['check16'];  
 $totalescolhido	=$check1+$check2+$check3+$check4+$check5+$check6+$check7+$check8+$check9+$check10+$check11+$check12+$check13+$check14+$check15+$check16; 

	if ($check1!=""){ 
   		$sociosquites="S�cios Quites /  At� 02/10/2009";
	}else{
    	$sociosquites="";
	} 
	if ($check2!="" && $check1!=""){ 
   		$sociosquites2=" / No Evento";
	}else if ($check2!=""){
    	$sociosquites2="S�cios Quites / No Evento";
	}else if ($check2==""){
    	$sociosquites2="";
	}

	if ($check3!=""){ 
   		$naosocios="N�o S�cios /  At� 02/10/2009";
	}else{
    	$naosocios="";
	} 

	if ($check3!="" && $check4!=""){ 
  		$naosocios2=" / No Evento";
	}else if ($check4!=""){
    	$naosocios2="N�o S�cios / No Evento";
	}else if ($check4==""){
    	$naosocios2="";
	}

	if ($check5!=""){ 
   		$residentes="Residentes /  At� 02/10/2009";
	}else{
  	  $residentes="";
	} 

	if ($check5!="" && $check6!=""){ 
   		$residentes2=" / No Evento";
	}else if ($check6!=""){
    	$residentes2="Residentes / No Evento";
	}else if ($check6==""){
    	$residentes2="";
	}

	if ($check7!=""){ 
   		$estudantesdegraduacao="Estudantes de Gradua��o /  At� 02/10/2009";
	}else{
    	$estudantesdegraduacao="";
	}

	if ($check7!="" && $check8!=""){ 
  		$estudantesdegraduacao2=" / No Evento";
	}else if ($check8!=""){
    	$estudantesdegraduacao2="Estudantes de Gradua��o / No Evento";
	}else if ($check8==""){
    	$estudantesdegraduacao2="";
	}

	if ($check9!=""){ 
   		$cursogerontologia="Curso Gerontologia /  At� 02/10/2009";
		$quantger=$quantger+1;
	}else{
    	$cursogerontologia="";
	} 
	if ($check9!="" && $check10!=""){ 
   		$cursogerontologia2=" / No Evento";
		$quantger2=$quantger2+1;
	}else if ($check10!=""){
    	$cursogerontologia2="Curso Gerontologia / No Evento";
		$quantger2=$quantger2+1;
	}else if ($check10==""){
    	$cursogerontologia2="";
	}

	if ($check11!=""){ 
   		$oficina01avaliacaocognitiva="Oficina 01 Avalia��o Cognitiva /  At� 02/10/2009";
		$quantcog=$quantcog+1;
	}else{
    	$oficina01avaliacaocognitiva="";
	} 

	if ($check11!="" && $check12!=""){ 
   		$oficina01avaliacaocognitiva2=" / No Evento";
		$quantcog2=$quantcog2+1;
	}else if ($check12!=""){
    	$oficina01avaliacaocognitiva2="Oficina 01 Avalia��o Cognitiva / No Evento";
		$quantcog2=$quantcog2+1;
	}else if ($check12==""){
    	$oficina01avaliacaocognitiva2="";
	}	 

	if ($check13!=""){ 
	   	$oficina02cuidadospaliativos="Oficina 02 Cuidados Paliativos /  At� 02/10/2009";
		$quantpali=$quantpali+1;
	}else{
    	$oficina02cuidadospaliativos="";
	} 

	if ($check13!="" && $check14!=""){ 
   		$oficina02cuidadospaliativos2=" / No Evento";
		$quantpali2=$quantpali2+1;
	}else if ($check14!=""){
    	$oficina02cuidadospaliativos2="Tribuna Livre '&Uacute;ltimo Ato - Li&ccedil;&otilde;es Perto do Fim' (antiga Oficina 2) / No Evento";
		$quantpali2=$quantpali2+1;
	}else if ($check14==""){
    	$oficina02cuidadospaliativos2="";
	}	 

	if ($check15!=""){ 
   		$encontrocomespecialistaincapacidade="Encontro com Especialista Incapacidade /  At� 02/10/2009";
		$quantinc=$quantinc+1;
	}else{
    	$encontrocomespecialistaincapacidade="";
	} 

	if ($check15!="" && $check16!=""){ 
   		$encontrocomespecialistaincapacidade2=" / No Evento";
		$quantinc2=$quantinc2+1;
	}else if ($check16!=""){
    	$encontrocomespecialistaincapacidade2="Encontro com Especialista Incapacidade / No Evento";
		$quantinc2=$quantinc2+1;
	}else if ($check16==""){
    	$encontrocomespecialistaincapacidade2="";
	}

	$accompanyingperson2 					= $sociosquites.$sociosquites2;
	$Profissional 							= $naosocios.$naosocios2;
	$student 								= $estudantesdegraduacao.$estudantesdegraduacao2;
	$Residente 								= $residentes.$residentes2;
	$Cursogerontologia						= $cursogerontologia.$cursogerontologia2;
	$Oficina01avaliacaocognitiva			= $oficina01avaliacaocognitiva.$oficina01avaliacaocognitiva2;
	$Oficina02cuidadospaliativos			= $oficina02cuidadospaliativos.$oficina02cuidadospaliativos2;
	$Encontrocomespecialistaincapacidade	= $encontrocomespecialistaincapacidade.$encontrocomespecialistaincapacidade2;
	
 $select = "SELECT * FROM eventos WHERE nome_evento = '".$nome_evento."'";
 $sql = mysql_query($select) or die ("Query  ".$select." : ".mysql_error());
 $y = mysql_fetch_array($sql);
 
   //gerar senha para a altera��o do cadastro
		$senha = "abcdefghijlkmnopqrstuvxzwyABCDEFGHIJLKMNOPQRSTUVXZYW0123456789";
		srand ((double)microtime()*1000000);
		for ($i=0; $i<6; $i++) {
		$password .= $senha[rand()%strlen($senha)];
		}
		$login = $email;
		$senha = $password;
		$ipuser= $_SERVER['REMOTE_ADDR'];
		$dateuser= date("y.m.d H:i:s");
    //email que ser� enviado para o candidato
   $headers = "MIME-Version: 1.0\n";
   $headers.= "Content-type: text/html; charset=ISO-8859-1\n";	
   $headers.= "From: Registro Online <meta@wb.com.br>\n";
    $subjectt= "Meta - Registro Online";
	

  $sql = mysql_query("INSERT INTO usuarios (login, senha, email, data_hora, tipo_usuario, ip, inicio, ip_inicio)
    VALUES ('$login','$senha', '$email', '$dateuser', 'usuario', '$ipuser', '$dateuser', '$ipuser')");
   //Insere no banco de dados
      $cadastrar = mysql_query("INSERT INTO inscricoes (nome_evento, data_cadastro, familyname, nametothebagde, instituicao, especialidade, cpf, identidade, mailingadress, zipcode, city, provincestate, phone, fax, email, profissional, student, residente, gerentologia, congnitiva, paleativos, incapacidade, accompanyingperson2, totalescolhido, formpagamento, numero_pg, valor_pg, instituicao_pg, R_pg, E_pg, U_pg, nome_cartao_pg, validade_pg, codigo_seguranca_pg, troco_pg, banco_pg, ag_pg, conta_cheque_pg, cortesia_pg, data_pg, texto_recibo_pg, texto_anuidade_pg, texto_observacoes_pg)    VALUES ( '$nome_evento', '$data_cadastro', '$nome_completo', '$nome_para_cracha', '$instituicao', '$especialidade', '$cpf', '$identidade', '$endereco', '$cep', '$cidade', '$estado', '$phone', '$fax', '$email', '$Profissional','$student','$Residente', '$Cursogerentologia','$Oficina01avaliacaocognitiva', '$Oficina02cuidadospaliativos', '$Encontrocomespecialistaincapacidade', '$accompanyingperson', '$totalescolhido', '$formpagamento', '$numero_pg', '$valor_pg', '$instituicao_pg', '$R_pg', '$E_pg', '$U_pg', '$nome_cartao_pg', '$validade_cartao_pg', '$codigo_cartao_pg', '$troco_pg', '$banco_cheque_pg', '$ag_cheque_pg', '$conta_cheque_pg', '$cortesia_pg', '$data_pagamento_pg', '$texto_recibo_pg', '$texto_anuidade_pg', '$texto_observacoes_pg')"); 
	
    if ($formpagamento == "boleto"){

   		  $messagee = "Sua requisi��o de registro foi realizado com sucesso.<br /><br />Por favor, salve o seu login e senha:<br /><br />login = ".$login."<br />Senha = ".$senha."<br /><br />Para trocar a forma de pagamento acesse:<br /><br /><a href='https://www.metaeventos.net/inscricoes/index2.php?id_evento=".$y['id']."'>Alterar Pagamento</a><br /><br />Se Precisar emitir a segunda via do boleto clique abaixo <br /><a href='https://www.metaeventos.net/gera_boleto.php?via=2&ne=".base64_encode($nome_evento)."&fam=".base64_encode($familyname)."'>2� Via Boleto</a><br />Se o link acima n�o funcionar acesse:<br />https://www.metaeventos.net/gera_boleto.php?via=2&ne=".base64_encode($nome_evento)."&fam=".base64_encode($familyname)."<br /><br>Att.<br /><b>Meta Marketing e Eventos</b><br />Secretariat.";

	   	  //mail($email, $subjectt, $messagee, $headers);

		  echo "<script>window.location = '../../../gera_boleto.php?ne=$nome_evento&fam=$nome_completo';</script>";

    }elseif ($formpagamento == "deposito"){

	      $messagee= "Sua requisi��o de registro foi realizado com sucesso.<br><br>Por favor, salve o seu login e senha para poss�veis altera��es na forma de pagamento:<br />login = ".$login."<br />Senha = ".$senha."<br /><br />Para trocar a forma de pagamento acesse:<br /><br /><a href='https://www.metaeventos.net/inscricoes/index2.php?id_evento=".$y['id']."'>Alterar Pagamento</a><br /><br />Att.<br><b>Meta Marketing e Eventos</b><br>Secretariat.";

   		  //mail($email, $subjectt, $messagee, $headers);

	      echo "<script> alert(unescape('Seu pedido de registro foi realizado com sucesso!'));location.href='../adm_inscricoes.php'; </script>";

    }
	else{
	      echo "<script> alert(unescape('Seu pedido de registro foi realizado com sucesso!'));location.href='../adm_inscricoes.php'; </script>";
	}
 
}
?>

