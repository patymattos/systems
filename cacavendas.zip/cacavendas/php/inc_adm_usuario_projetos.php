<?php

include ("config.php");

if (strlen($_GET['buscar']) > 0) {



	$sql = mysql_query("SELECT * FROM usuarios_eventos  WHERE tipo_usuario LIKE '%".$_POST['buscar']."%' OR login LIKE '%".$_POST['buscar']."%'");



	echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";

		echo "<tr>";

			echo "<td class='titulo' colspan='4'>Administrar Usu�rio do Projeto</td>";

		echo "</tr>";

		echo "<tr>";

			echo "<td class='texto' width='160'><b>Permiss�o:</b></td>";

			echo "<td class='texto' width='150'><b>Login:</b></td>";

			echo "<td class='texto' width='150'><b>Senha:</b></td>";

			echo "<td class='texto' width='45'><b>Excluir</b></td>";

		echo "</tr>";

	

		while ($linha = mysql_fetch_array($sql)){

			$id		= $linha["id"];

			if($linha['tipo_usuario'] == 'Administrador'){

				$tipo	= '<strong>'.$linha["tipo_usuario"].'</strong>';

			}else {

				$tipo	= $linha["tipo_usuario"];

			}

			$login	= $linha["login"];

			$senha	= $linha["senha"];

		

			echo "<tr>";

				echo "<td class='texto'><a href='vis_usuario_eventos.php?id=$id'>$tipo</a></td>";

				echo "<td class='texto'><a href='vis_usuario_eventos.php?id=$id'>$login</td>";

				echo "<td class='texto'><a href='vis_usuario_eventos.php?id=$id'>xxxxxxxx</td>";

				echo "<td align='center'><a href='php/excluir_usuario_eventos.php?id=$id'><img src='images/ico_excluir.jpg' alt='' border='0' /></a><br></td>";

			echo "</tr>";		

		}

	

	echo "</table>";

############################################### se o campo de busca n�o tiver sido executado ########################################################################

}else{

	$sql = mysql_query("SELECT * FROM usuarios_eventos");

	

	echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";

		echo "<tr>";

			echo "<td class='titulo' colspan='4'>Administrar Usu�rio do Projeto</td>";

		echo "</tr>";

		echo "<tr>";

			echo "<td class='texto' width='160'><b>Permiss�o:</b></td>";

			echo "<td class='texto' width='150'><b>Login:</b></td>";

			echo "<td class='texto' width='150'><b>Senha:</b></td>";

			echo "<td class='texto' width='45'><b>Excluir</b></td>";

		echo "</tr>";

	

		while ($linha = mysql_fetch_array($sql)){

			$id		= $linha["id"];

			if($linha['tipo_usuario'] == 'Administrador'){

				$tipo	= '<strong>'.$linha["tipo_usuario"].'</strong>';

			}else {

				$tipo	= $linha["tipo_usuario"];

			}

			$login	= $linha["login"];

			$senha	= $linha["senha"];

		

			echo "<tr>";

				echo "<td class='texto'><a href='vis_usuario_eventos.php?id=$id'>$tipo</a></td>";

				echo "<td class='texto'><a href='vis_usuario_eventos.php?id=$id'>$login</td>";

				echo "<td class='texto'><a href='vis_usuario_eventos.php?id=$id'>xxxxxxxx</td>";

				echo "<td align='center'><a href='php/excluir_usuario_eventos.php?id=$id'><img src='images/ico_excluir.jpg' alt='' border='0' /></a><br></td>";

			echo "</tr>";		

		}

	

	echo "</table>";

}

?>