<?php
include ("config.php");
$buscar = $_POST["buscar"];
if (strlen($buscar) > 0){
	$sql = mysql_query ("SELECT email, titulo FROM trabalhos WHERE email LIKE '%".$buscar."%' OR titulo LIKE '%".$buscar."%'");
	$fetch = mysql_fetch_array($sql);
}
$select_insc2 = "SELECT * FROM usuarios_eventos WHERE tipo_usuario='Avaliador' ORDER BY email ASC";
$sql_insc2    = mysql_query($select_insc2);
$sql_insc3    = mysql_query($select_insc2);
$sql_insc4    = mysql_query($select_insc2);
$rows_insc2   = mysql_num_rows($sql_insc2);

##################################################
############# USUARIOS ###########################


/*<table width="550" border="0" cellpadding="0" cellspacing="0" style="text-align:left; margin-bottom:10px;">
  <tr>
    <td bgcolor="#FFFFFF">
 	  	<form action="adm_rela_trab3.php?buscar=buscar" method="post">
          	<input type="text" name="buscar"/> 
            <input type="submit" value="Buscar"/>            
        </form> 
    </td>
  </tr> 
</table>*/
?>
<table width="550" border="0" cellpadding="1" cellspacing="1" class="cor_tr">
  <form action="proc_adm_rela_trab.php" method="post" name="form">
    <tr>
        <td class='titulo' colspan="4">:: Gerar Relat�rios de Trabalhos ::</td>
    </tr>
    <?php
    if (strlen($buscar) > 0){
	  echo '<tr>
	     <td class="texto" colspan="2" style="text-align:center;">Email</td>
	     <td class="texto" colspan="2" style="text-align:center;">T�tulo</td>
	  </tr>
	  <tr>
    	 <td class="texto" colspan="2" style="text-align:center;"><a href="php/proc_adm_rela_trab3.php?email='.$fetch['email'].'">'.$fetch['email'].'</a></td>
    	 <td class="texto" colspan="2" style="text-align:left;"><a href="php/proc_adm_rela_trab3.php?email='.$fetch['email'].'">'.$fetch['titulo'].'</a></td>
	  </tr>
	 </table>';
	echo "<table border='0' width='100%'>
			<tr>
			   <td colspan='2' align='center'>
					<a href=javascript:history.go(-1) style='color:#000'>Voltar</a>
			   </td>
			</tr>";
	echo "</table>";
	 exit(); 			
    }
	?>
    <tr>
    	<td class="texto" colspan="2" style="text-align:center;">
        	<p><strong>
				<?php 
					if (strlen($_GET['tipo']) < 1 )
					 echo "Selecione o tipo de trabalho:";
					else
					 echo "Escolha os Filtros:";
				?>	  
			</strong></p>
        </td>
    </tr>
    <tr>
      <td width='175' class='texto'><strong>Tipo de Trabalho:</strong></td>
   	  <td width="368" class='texto'>
	      <select name="tipo" onblur="selecao()" onchange="selecao()">
           <?php 
		   if (strlen($_GET['tipo']) < 1 ){
			  echo "<option value=''>-= Selecione o tipo do campo =-</option>";
		   }else{
		    if ($_GET['tipo'] == 'simposio'){
		      echo '<option value="simposio">Simp�sio</option>';
			}elseif ($_GET['tipo'] == 'poster'){
		      echo '<option value="poster">P�ster</option>';
			}elseif ($_GET['tipo'] == 'simposio_poster'){
		      echo '<option value="simposio_poster">Simp�sio / P�ster</option>';
			}
		   }	  
		   ?>   
		  	<option value="simposio">Simp�sio</option>
    		<option value="poster">P�ster</option>
	    	<option value="simposio_poster">Simp�sio / P�ster</option>
		   </select>
      </td>
    </tr>
    <tr>
      <td width='347' class='texto'><strong>Eixo Tem�tico</strong></td>
   	  <td class='texto'>
  	      <select name="eixotematico" style="text-align:center;">
			<option value="">--=  Selecione o Eixo  =--</option>
		  		<option value="1">1</option>
		  		<option value="2">2</option>
		  		<option value="3">3</option>
		   </select>
      </td>
    </tr>
    <tr>
      <td width='347' class='texto'><strong>Email Avaliador 1</strong></td>
   	  <td class='texto'>
  	      <select name="emailavaliador1">
			<option value="">-= Selecione o email =-</option>
			<?php
			 while($fetch  = mysql_fetch_array($sql_insc2)){
		  		echo '<option value='.$fetch['email'].'>'.$fetch['email'].'</option>';
			 }	
			?>
		   </select>
      </td>
    </tr>
    <tr>
      <td width='347' class='texto'><strong>Email Avaliador 2</strong></td>
   	  <td class='texto'>
  	      <select name="emailavaliador2">
			<option value="">-= Selecione o email =-</option>
			<?php
			 while($fetch  = mysql_fetch_array($sql_insc3)){
		  		echo '<option value='.$fetch['email'].'>'.$fetch['email'].'</option>';
			 }	
			?>
		   </select>
      </td>
    </tr>
    <tr>
      <td width='347' class='texto'><strong>Email Avaliador 3</strong></td>
   	  <td class='texto'>
  	      <select name="emailavaliador3">
			<option value="">-= Selecione o email =-</option>
			<?php
			 while($fetch  = mysql_fetch_array($sql_insc4)){
		  		echo '<option value='.$fetch['email'].'>'.$fetch['email'].'</option>';
			 }	
			?>
		   </select>
      </td>
    </tr>
    <tr>
      <td width='347' class='texto'><strong>Status</strong></td>
   	  <td class='texto'>
  	      <select name="status">
			<option value="">-= Selecione o Status =-</option>
		  		<option value="0">Aguardando</option>
		  		<option value="1">Em Processo</option>
		  		<option value="2">Aceito</option>
				<option value="3">Revisar</option>
				<option value="4">Reprovado</option>
		   </select>
      </td>
    </tr>
    <tr><td class="texto" style="text-align:center;" colspan="2"><p><strong>Selecione o(s) campo(s) para relat�rio:</strong></p></td></tr>
    <?php if ($_GET['tipo'] == 'simposio_poster'){?>
        <tr><td class="texto" style="text-align:left;" colspan="2"><p><strong>Simp�sio e P�ster:</strong></p></td></tr>
    <tr>
      <td class='texto' width='347'>Autor</td>
   	  <td class='texto'><input type="checkbox" name="autor" value="autor" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Autor Evento</td>
   	  <td class='texto'><input type="checkbox" name="autorevento" value="autorevento" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Co-autores</td>
   	  <td class='texto'><input type="checkbox" name="coautores" value="coautores" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 1</td>
   	  <td class='texto'><input type="checkbox" name="comentario" value="comentario" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 2</td>
   	  <td class='texto'><input type="checkbox" name="comentario2" value="comentario2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 3</td>
   	  <td class='texto'><input type="checkbox" name="comentario3" value="comentario3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 4</td>
   	  <td class='texto'><input type="checkbox" name="comentario4" value="comentario4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo</td>
   	  <td class='texto'><input type="checkbox" name="conteudo" value="conteudo" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 1</td>
   	  <td class='texto'><input type="checkbox" name="conteudo1" value="conteudo1" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 2</td>
   	  <td class='texto'><input type="checkbox" name="conteudo2" value="conteudo2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 3</td>
   	  <td class='texto'><input type="checkbox" name="conteudo3" value="conteudo3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 4</td>
   	  <td class='texto'><input type="checkbox" name="conteudo4" value="conteudo4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Eixo Tem�tico</td>
   	  <td class='texto'><input type="checkbox" name="eixotematico2" value="eixotematico2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Email</td>
   	  <td class='texto'><input type="checkbox" name="email" value="email" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 1</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf1" value="emailavaliadorf1" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 1</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf1" value="notaavaliadorf1" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 2</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf2" value="emailavaliadorf2" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 2</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf2" value="notaavaliadorf2" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 3</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf3" value="emailavaliadorf3" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 3</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf3" value="notaavaliadorf3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Instru��es</td>
   	  <td class='texto'><input type="checkbox" name="instrucoes" value="instrucoes" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Nome do Evento</td>
   	  <td class='texto'><input type="checkbox" name="nome_evento" value="id_evento" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 1</td>
   	  <td class='texto'><input type="checkbox" name="palestra1" value="palestra1" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 2</td>
   	  <td class='texto'><input type="checkbox" name="palestra2" value="palestra2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 3</td>
   	  <td class='texto'><input type="checkbox" name="palestra3" value="palestra3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 4</td>
   	  <td class='texto'><input type="checkbox" name="palestra4" value="palestra4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 1</td>
   	  <td class='texto'><input type="checkbox" name="palestrante1" value="palestrando1" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 2</td>
   	  <td class='texto'><input type="checkbox" name="palestrante2" value="palestrando2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 3</td>
   	  <td class='texto'><input type="checkbox" name="palestrante3" value="palestrando3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 4</td>
   	  <td class='texto'><input type="checkbox" name="palestrante4" value="palestrando4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palavra Chave</td>
   	  <td class='texto'><input type="checkbox" name="palavrachave" value="palavrachave" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Processo</td>
   	  <td class='texto'><input type="checkbox" name="processo" value="processo" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Tema Simp�sio</td>
   	  <td class='texto'><input type="checkbox" name="tema" value="tema" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Titulo</td>
   	  <td class='texto'><input type="checkbox" name="titulo" value="titulo" /></td>
    </tr>

    <?php }elseif ($_GET['tipo'] == 'simposio'){?>
    <tr><td class="texto" style="text-align:left;" colspan="2"><strong>Simp�sio:</strong></td></tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 1</td>
   	  <td class='texto'><input type="checkbox" name="comentario2" value="comentario2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 2</td>
   	  <td class='texto'><input type="checkbox" name="comentario3" value="comentario3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio 3</td>
   	  <td class='texto'><input type="checkbox" name="comentario4" value="comentario4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 1</td>
   	  <td class='texto'><input type="checkbox" name="conteudo1" value="conteudo1" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 2</td>
   	  <td class='texto'><input type="checkbox" name="conteudo2" value="conteudo2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 3</td>
   	  <td class='texto'><input type="checkbox" name="conteudo3" value="conteudo3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conteudo 4</td>
   	  <td class='texto'><input type="checkbox" name="conteudo4" value="conteudo4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Eixo Tem�tico</td>
   	  <td class='texto'><input type="checkbox" name="eixotematico2" value="eixotematico2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Email</td>
   	  <td class='texto'><input type="checkbox" name="email" value="email" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 1</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf1" value="emailavaliadorf1" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 1</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf1" value="notaavaliadorf1" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 2</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf2" value="emailavaliadorf2" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 2</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf2" value="notaavaliadorf2" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 3</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf3" value="emailavaliadorf3" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 3</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf3" value="notaavaliadorf3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Nome do Evento</td>
   	  <td class='texto'><input type="checkbox" name="nome_evento" value="id_evento" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 1</td>
   	  <td class='texto'><input type="checkbox" name="palestra1" value="palestra1" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 2</td>
   	  <td class='texto'><input type="checkbox" name="palestra2" value="palestra2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 3</td>
   	  <td class='texto'><input type="checkbox" name="palestra3" value="palestra3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestra 4</td>
   	  <td class='texto'><input type="checkbox" name="palestra4" value="palestra4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 1</td>
   	  <td class='texto'><input type="checkbox" name="palestrante1" value="palestrante1" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 2</td>
   	  <td class='texto'><input type="checkbox" name="palestrante2" value="palestrante2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 3</td>
   	  <td class='texto'><input type="checkbox" name="palestrante3" value="palestrante3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palestrante 4</td>
   	  <td class='texto'><input type="checkbox" name="palestrante4" value="palestrante4" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Processo</td>
   	  <td class='texto'><input type="checkbox" name="processo" value="processo" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Tema Simp�sio</td>
   	  <td class='texto'><input type="checkbox" name="tema" value="tema" /></td>
    </tr>
    <?php }elseif ($_GET['tipo'] == 'poster'){?>
    <tr><td class="texto" style="text-align:left;" colspan="2"><strong>P�ster:</strong></td></tr>
    <tr>
      <td class='texto' width='347'>Autor</td>
   	  <td class='texto'><input type="checkbox" name="autor" value="autor" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Autor Evento</td>
   	  <td class='texto'><input type="checkbox" name="autorevento" value="autorevento" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Co-autores</td>
   	  <td class='texto'><input type="checkbox" name="coautores" value="coautores" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Coment�rio</td>
   	  <td class='texto'><input type="checkbox" name="comentario" value="comentario" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Conte�do</td>
   	  <td class='texto'><input type="checkbox" name="conteudo" value="conteudo" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Eixo Tem�tico</td>
   	  <td class='texto'><input type="checkbox" name="eixotematico2" value="eixotematico2" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Email</td>
   	  <td class='texto'><input type="checkbox" name="email" value="email" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 1</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf1" value="emailavaliadorf1" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 1</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf1" value="notaavaliadorf1" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 2</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf2" value="emailavaliadorf2" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 2</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf2" value="notaavaliadorf2" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Email Avaliador 3</td>
   	  <td class='texto'><input type="checkbox" name="emailavaliadorf3" value="emailavaliadorf3" /></td>
    </tr>
    <tr>
      <td class='texto' width='347'>Nota Avaliador 3</td>
   	  <td class='texto'><input type="checkbox" name="notaavaliadorf3" value="notaavaliadorf3" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Instru��es</td>
   	  <td class='texto'><input type="checkbox" name="instrucoes" value="instrucoes" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Nome do Evento</td>
   	  <td class='texto'><input type="checkbox" name="nome_evento" value="406" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Palavra Chave</td>
   	  <td class='texto'><input type="checkbox" name="palavrachave" value="palavrachave" /></td>
    </tr>
    <tr>
      <td width='347' class='texto'>Processo</td>
   	  <td class='texto'><input type="checkbox" name="processo" value="processo" /></td>
    </tr>

    <tr>
      <td class='texto' width='347'>Titulo</td>
   	  <td class='texto'><input type="checkbox" name="titulo" value="titulo" /></td>
    </tr>
    <?php }?>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
    <tr>
        <td width='347' class='texto'>Ordenado por:</td>
  		<td class='texto'>
      		<select name="ordem" size="1" class="texto">
            	<option value="">---Escolha---</option>
                <option value="autor">Autor</option>
                <option value="autorevento">Autor Evento</option>
                <option value="coautores">Co-Autores</option>
                <option value="comentario">Coment�rio</option>
            	<option value="comentario2">Coment�rio 2</option>
                <option value="comentario3">Coment�rio 3</option>
                <option value="comentario4">Coment�rio 4</option>
                <option value="conteudo">Conte�do</option>
                <option value="conteudo2">Conte�do 2</option>
            	<option value="conteudo3">Conte�do 3</option>
                <option value="conteudo4">Conte�do 4</option>
                <option value="email">Email</option>
                <option value="email_avaliador">Email do Avaliador 1</option>
                <option value="email_avaliador2">Email do Avaliador 2</option>
            	<option value="email_avaliador3">Email do Avaliador 3</option>
                <option value="nota_avaliador">Nota do Avaliador 1</option>
                <option value="nota_avaliador2">Nota do Avaliador 2</option>
                <option value="nota_avaliador3">Nota do Avaliador 3</option>
                <option value="instrucoes">Instru��es</option>
                <option value="palestra1">Palestra 1</option>
                <option value="palestra2">Palestra 2</option>
                <option value="palestra3">Palestra 3</option>
                <option value="palestra4">Palestra 4</option>
                <option value="palestrante1">Palestrante 1</option>
                <option value="palestrante2">Palestrante 2</option>
                <option value="palestrante3">Palestrante 3</option>
                <option value="palestrante4">Palestrante 4</option>
            	<option value="palavrachave">Palavra Chave</option>
                <option value="processo">Processo</option>
                <option value="temasimposio">Tema</option>
                <option value="titulo">T�tulo</option>
            </select>
        </td>
    </tr>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
    <tr>
    	<td align="center" colspan="2"><input type="submit" value="Gerar Relat�rio" /></td>
    </tr>
  </form>  
</table>
