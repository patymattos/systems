<?php
// Inicia sesses
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
// Conexo com o banco de dados
require "config.php";
// Recupera o login
//$email = addslashes(strip_tags(trim($_POST['email'])));
$login = isset($_POST["login"]) ? addslashes(trim($_POST["login"])) : FALSE;
// Recupera a senha, a criptografando em MD5
$senha = $_POST["senha"];

// Usurio no forneceu a senha ou o login
if(!$login || !$senha)
{
  echo "<script>alert('Você deve digitar sua senha e login!');</script>";
  echo "<script>history.go(-1);</script>";  
}

/**
* Executa a consulta no banco de dados.
* Caso o nmero de linhas retornadas seja 1 o login  vlido,
* caso 0, invlido.
*/
$SQL = "SELECT * FROM usuarios WHERE login = '" . $login . "'";
$result_id = @mysql_query($SQL) or die("Erro no banco de dados!");
$total = @mysql_num_rows($result_id);

// Caso o usurio tenha digitado um login vlido o nmero de linhas ser 1..
if($total)
{
    // Obtm os dados do usurio, para poder verificar a senha e passar os demais dados para a sesso
    $dados = @mysql_fetch_array($result_id);

    // Agora verifica a senha
    if(!strcmp($senha, $dados["senha"]))
    {
        // TUDO OK! Agora, passa os dados para a sesso e redireciona o usurio
		$_SESSION["login"]   = $dados["login"];
        echo "<script>location.href='../incluirnot.php'</script>";
        exit;
    // Senha invlida
    }else{
     echo "<script>alert('Senha inválida!');</script>";
     echo "<script>history.go(-1);</script>";
    }
 // Login invlido
 }else{
  echo "<script>alert('O login fornecido por voc  inexistente!');</script>";
  echo "<script>history.go(-1);</script>";
}
?>