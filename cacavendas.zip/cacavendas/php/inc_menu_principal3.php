<?php
session_start();
include "config.php";
$id_evento  	= $_POST['id'];
$fonte			= $_POST['fonte'];
$tamanho_fonte	= $_POST['tamanho_fonte'].$_POST['tipo_fonte'];
$negrito		= $_POST['negrito'];

if	($negrito == "strong"){
	$negrito = "<strong>";
}elseif($negrito == "i"){
	$negrito = "<i>";
}elseif($negrito == "n/i"){
	$negrito = "<strong><i>";
}else{
	$negrito = "";
}
//faz um loop para pegar todos os menus digitados nos inputs
for ($i=1;$i<=12;$i++){
	$menu  	= "menu".$i;
	$menu1 	= $_POST[$menu];
	//echo "menu$i = ".$menu1."<br>";


		//verifica se tem algum menu do evento cadastrado
		$sql	= mysql_query("SELECT * FROM menu_evento WHERE id_evento = '$id_evento'");
		$num	= mysql_num_rows($sql);
		//se n�o tiver ele cadastra um novo menu
		if ($num == 0){
			$insert_ordem 	= mysql_query("INSERT INTO menu_evento(id_evento, $menu, fonte, tamanho_fonte, negrito) values('$id_evento', '$menu1','$fonte','$tamanho_fonte', '$negrito')")or die(mysql_error());
			
		}else{
			$update	= mysql_query("UPDATE menu_evento SET $menu = '$menu1', fonte = '$fonte', negrito = '$negrito', tamanho_fonte = '$tamanho_fonte' WHERE id_evento='$id_evento'")or die(mysql_error());
		}

}
header("location:../menu_principal.php");

?>