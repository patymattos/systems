<?
include ("config.php");

$cd_projeto 			= $_POST['c_projeto']; 
$cd_m_estacao	    	= $_POST['m_estacao'];
$cd_c_m_estacao         = $_POST['c_m_estacao'];
$cd_c_c_e			 	= $_POST['c_c_e'];
$cd_c_c_n 				= $_POST['c_c_n'];
$cd_c_a_elipsoidal 		= $_POST['c_a_elipsoidal'];
$cd_c_a_ortometrica		= $_POST['c_a_ortometrica'];
$cd_c_d_geoidal			= $_POST['c_d_geoidal'];
$cd_c_latitude			= $_POST['c_latitude'];
$cd_c_longitude			= $_POST['c_longitude'];
$cd_c_crea			    = $_POST['c_crea'];
$cd_c_estacoes		    = $_POST['c_estacoes'];
$cd_c_datum				= $_POST['c_datum'];
$cd_c_s_latitude		= $_POST['c_s_latitude'];
$cd_c_s_longitude		= $_POST['c_s_longitude'];
$cd_c_s_altitude		= $_POST['c_s_altitude'];
$cd_c_equipamento		= $_POST['c_equipamento'];
$cd_c_fonte		        = $_POST['c_fonte'];
$cd_c_mc_fuso		    = $_POST['c_mc_fuso'];
$cd_c_c_incra			= $_POST['c_c_incra'];
$cd_link	    		= $_POST['link'];
$cd_arquivo 	    	= $_FILES['arquivo']['name'];

if (isset($_POST[unibanco])){
$boleto				= 1;
}
else{
$boleto 			= 0;
}

$caminho_dir = "/arquivos/".$cd_arquivo;

$status = move_uploaded_file($_FILES['arquivo']['tmp_name'],"../../../arquivos/"."$foto_evento");



$link_inscricao = "$link";
$link_file = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio);
$link_imagem = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio2);
$link_flash = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio3);
$link_media = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio4);
$link_trabalhos = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio5);
$link_form_off = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio6);





########## CADASTRANDO NOVO EVENTO NO BANCO DE DADOS #######################################################
$select_projeto = "INSERT INTO projetos (nome_projeto, tipo_evento, data_evento_inicio, data_evento_final, local_evento, promocao, patrocinio, apoio, montagens, tematica, candidato, email_evento, link, foto_evento, topo, ativo, boleto) 
VALUES ('$evento','$tipo_evento','$dataeventoinicio','$dataeventofinal','$local_evento','$promocao','$patrocinio','$apoio','$montagens','$tematica','$candidato','$email_evento','$link','$caminho_dir','$caminho_topo',0,'$boleto')";

$query_eventos = mysql_query($select_evento) or die ("Query error: ".$select_evento." : ".mysql_error());

############################################################################################################
if($boleto == 1){
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########
	
	$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
	$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
	$resultado_consulta = mysql_fetch_array($query_consulta);
	
	$id_evento = $resultado_consulta['id'];
	
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUANTOS CEDENTE J� EXISTE #########
	
	$select_consulta_cedente = "SELECT * FROM cedente";
	$query_consulta_cedente = mysql_query($select_consulta_cedente);
	$resultado = mysql_num_rows($query_consulta_cedente);
	
	##############################################################################################################
	
	$id_cedente = $resultado + 1;
	
	######### CADASTRANDO CEDENTE PARA O REFERIDO EVENTO #########################################################
	
	$select_cedente = "INSERT INTO cedente (id_cedente, cedente, agencia, conta, conta_div, codigo_cliente, carteira, diap, txb, cpf_cnpj, endereco, cidade, uf, id_evento)
	VALUES ('$id_cedente','$cedente','$agencia','$conta','$conta_div','$codigo_cliente','$carteira','$diap','$txb','$cpf_cnpj','$endereco','$cidade','$uf','$id_evento')";
	
	$query_cedente = mysql_query($select_cedente) or die ("Query error: ".$select_cedente." : ".mysql_error());
	
	##############################################################################################################
	############ INSERINDO OS LINKS DO EVENTOS EM UMA BASE DE DADOS ##############################################
	
	$insert_link = "INSERT INTO links (id_evento, link_inscricao, link_file, link_imagem, link_flash, link_media, link_trabalhos, link_inscricao_off ) VALUES ('$id_evento','$link_inscricao','$link_file','$link_imagem','$link_flash','$link_media','$link_trabalhos','$link_form_off');";
	$query_link = mysql_query($insert_link) or die ("Query error".$insert_link." : ".mysql_error());

}
else{
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########
	
	$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
	$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
	$resultado_consulta = mysql_fetch_array($query_consulta);
	
	$id_evento = $resultado_consulta['id'];
	
	
	##############################################################################################################
	############ INSERINDO OS LINKS DO EVENTOS EM UMA BASE DE DADOS ##############################################
	
	$insert_link = "INSERT INTO links (id_evento, link_inscricao, link_file, link_imagem, link_flash, link_media, link_trabalhos, link_inscricao_off ) VALUES ('$id_evento','$link_inscricao','$link_file','$link_imagem','$link_flash','$link_media','$link_trabalhos','$link_form_off');";
	$query_link = mysql_query($insert_link) or die ("Query error".$insert_link." : ".mysql_error());
}
Header("Location: ../adm_projetos.php");
?>
