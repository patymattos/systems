<?
//Conexão ao Banco de dados local
$conexao = mysql_connect("localhost","metaeven_galeria","metawbeventos");
$db = mysql_select_db("metaeven_meta");

$email		= $_POST['email'];
$linktitulo	= $_POST['linktitulo'];

$dia =date("d");
$mes =date("m");
$ano =date("Y");
$data =$dia."-".$mes."-".$ano;
//consulta sql
$SQL 		= "SELECT * FROM trabalhos WHERE email='$email' AND titulo='$linktitulo'";  
$executa 	= mysql_query($SQL)or die(mysql_error());
$num 		= mysql_num_rows($executa);
$rs			= mysql_fetch_array($executa);

$ordemnome  = array('', 'Nome Evento', 'Autor', 'Autor Evento', 'Co-Autores', 'T&iacute;tulo', 'palavra Chave', 'Conte&uacute;do', 'Palestra 1', 'Conteudo 1', 'Coment&aacute;rio', 'Palestra 2', 'Conte&uacute;do 2','Coment&aacute;rio 2', 'Palestra 3','Conte&uacute;do 3','Coment&aacute;rio 3','Palestra 4','Conte&uacute;do 4', 'Coment&aacute;rio 4', 'Email', 'Email avaliador 1', 'Email Avaliador 2', 'Email Avaliador 3', 'Eixo Tem&aacute;tico', 'Instru&ccedil;&otilde;es', 'Palestrante 1', 'Palestrante 2', 'Palestrante 3', 'Palestrante 4', 'Processo', 'Tema Simp&oacute;sio');
$nome[2] 	= $rs['autor'];
$nome[3] 	= $rs['autorevento'];
$nome[4] 	= $rs['coautores'];
$nome[5] 	= $rs['titulo'];
$nome[6] 	= $rs['palavrachave'];
$nome[7]	= $rs['conteudo'];
$nome[8]	= $rs['palestra1'];
$nome[9]	= $rs['conteudo1'];
$nome[10] 	= $rs['comentario'];
$nome[11]	= $rs['palestra2'];
$nome[12]	= $rs['conteudo2'];
$nome[13]	= $rs['comentario2'];
$nome[14]	= $rs['palestra3'];
$nome[15]	= $rs['conteudo3'];
$nome[16]	= $rs['comentario3'];
$nome[17]	= $rs['palestra4'];
$nome[18]	= $rs['conteudo4'];
$nome[19]	= $rs['comentario4'];
$nome[20]	= $rs['email'];
$nome[21] 	= $rs['email_avaliador'];
$nome[22] 	= $rs['email_avaliador2'];
$nome[23] 	= $rs['email_avaliador3'];
$nome[24]	= $rs['check4'];
$nome[25]	= $rs['instrucoes'];
$nome[26] 	= $rs['palestrante1'];
$nome[27] 	= $rs['palestrante2'];
$nome[28] 	= $rs['palestrante3'];
$nome[29] 	= $rs['palestrante4'];
$nome[30]	= $rs['processo'];
$nome[31]	= $rs['temasimposio'];

$nomee[1]	= $rs['id_evento'];

//consulta tabela usuarios
$usu = "SELECT * FROM eventos where id='".$nomee[1]."'";  
$executausu = mysql_query($usu)or die(mysql_error());
$fetch		= mysql_fetch_array($executausu);
$nome[1]	= $fetch['nome_evento'];
//echo $SQL;
//exit();

$count = 0;
for ($i=1;$i<33;$i++){
	if (strlen($nome[$i]) > 0){
		$condicao2[$i] = $ordemnome[$i];
		$count += 1;
	}
}

// definimos o tipo de arquivo
header("Content-type: application/msexcel");

// Como será gravado o arquivo
header("Content-Disposition: attachment; filename=relatorio_trabalhos.xls");
echo "<table border='0' width=".$width." cellspacing='1' bgcolor='#000000' height='100'>
		<tr>
		  <td bgcolor='#F2F2F2' colspan=".$count." align='left'><b>TRABALHOS</b><br />";
		  echo "".$data."</td>";
		  echo "<td bgcolor='#F2F2F2'  align='right'><img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' border='0' width='125'></td>
		</tr>
</table>";
echo "<table border='1' width=".$width." cellspacing='1' bgcolor='#000000'>
	    <tr>";
			echo "<td bgcolor='#F2F2F2' align='left' valign='top'><b>Modalidade</b></td>";
			for ($i = 1; $i < 33; $i++) {
				if (strlen($condicao2[$i]) > 0){
					echo "<td align='center' bgcolor='#F2F2F2'><b>".$condicao2[$i]."</b></td>";
				}	
			}	
		echo "</tr>";
	
			//echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $i . "</td>";
			echo "<tr>";
			if ($rs['tipo'] == 0){
				echo "<td bgcolor='#F2F2F2' align='left' valign='top' width='100'>P&ocirc;ster</td>";
			}else{
				echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='100'>Simp&oacute;sio Proposto</td>";
			}
			if(strlen($fetch['nome_evento']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $fetch['nome_evento']. "</td>";
			}
			if (strlen($rs['autor']) > 0){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top'  width='150'>".$rs['autor']."</td>";
			}
			if(strlen($rs['autorevento']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;'  width='150' bgcolor='#F2F2F2' valign='top'>" . $rs['autorevento'] . "</td>";
			}
			if(strlen($rs['coautores']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' align='left' bgcolor='#F2F2F2' valign='top'  width='150'>" . $rs['coautores'] . "</td>";
			}
			if(strlen($rs['titulo']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' width='150' align='left' bgcolor='#F2F2F2' valign='top'>" . $rs['titulo'] . "</td>";
			}
			if(strlen($rs['palavrachave']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palavrachave'] . "</td>";
			}
			if(strlen($rs['conteudo']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo'] . "</td>";
			}
			if(strlen($rs['palestra1']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra1'] . "</td>";
			}
			if(strlen($rs['conteudo1']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo1'] . "</td>";
			}
			if(strlen($rs['comentario']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario'] . "</td>";
			}
			if(strlen($rs['palestra2']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra2'] . "</td>";
			}
			if(strlen($rs['conteudo2']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo2'] . "</td>";
			}
			if(strlen($rs['comentario2']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario2'] . "</td>";
			}
			if(strlen($rs['palestra3']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra3'] . "</td>";
			}
			if(strlen($rs['conteudo3']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo3'] . "</td>";
			}
			if(strlen($rs['comentario3']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario3'] . "</td>";
			}
			if(strlen($rs['palestra4']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra4'] . "</td>";
			}
			if(strlen($rs['conteudo4']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo4'] . "</td>";
			}
			if(strlen($rs['comentario4']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario4'] . "</td>";
			}
			if(strlen($rs['email']) >0 ){
			   echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email'] . "</td>";
			}
			if(strlen($rs['email_avaliador']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email_avaliador'] . "</td>";
			}
			if(strlen($rs['email_avaliador2']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email_avaliador2'] . "</td>";
			}
			if(strlen($rs['email_avaliador3']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email_avaliador3'] . "</td>";
			}
			if(strlen($rs['check4']) >0 ){
			echo "<td align='center' style='font-size:10px; font-family:Verdana;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['check4'] . "</td>";
			}
			if(strlen($rs['instrucoes']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' align='left' width='150' bgcolor='#F2F2F2' valign='top'>" . $rs['instrucoes'] . "</td>";
			}
			if(strlen($rs['palestrante1']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante1'] . "</td>";
			}
			if(strlen($rs['palestrante2']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante2'] . "</td>";
			}
			if(strlen($rs['palestrante3']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante3'] . "</td>";
			}
			if(strlen($rs['palestrante4']) >0 ){
				echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante4'] . "</td>";
			}

			if (strlen($rs['processo']) > 0){
			  if($rs['processo']==0){
				echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><b>Aguardando</b></td>";
			  }elseif($rs['processo']==1){
				echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><img src='https://www.metaeventos.net/inscricoes/imagem/ampulheta.gif' border='0' /></td>";
			  }elseif($rs['processo']==2){
				echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><img src='https://www.metaeventos.net/inscricoes/imagem/tick.png' border='0' /></td>";
			  }elseif($rs['processo']==3){
			    echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><img src='https://www.metaeventos.net/inscricoes/imagem/revisar.gif' border='0' /></td>";
			  }elseif($rs['processo']==4){
			    echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><img src='https://www.metaeventos.net/inscricoes/imagem/ico_excluir.jpg' border='0'/></td>";
			  }
			}
			if(strlen($rs['temasimposio']) >0 ){
			   echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['temasimposio'] . "</td>";
			}
		echo "</tr>";
	    echo "<tr>
		  <td colspan=".($count + 1)." bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PE&Ccedil;ANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
												TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
		  </td>
	</tr>  
</table>";
?>