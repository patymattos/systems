<?php
include ("config.php");

$menuss 	= $_POST['menuss']; 
$menus = $_POST['menus'];
$id	=	$_POST['id'];


$select = "UPDATE eventos SET $menus ='$menuss' WHERE id = '$id' ";

$query = mysql_query($select) or die ("Query : ".$select." : ".mysql_error());


Header("Location: ../adm_menu.php");
?>
