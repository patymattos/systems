<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style13 {font-size: 13px}
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="250" border="0" align="right">
      <tr>
        <td width="155"><img src="img/06.jpg" width="30" height="30"> <span class="style10">Todas as Despesas</span></td>
        <td width="85"><img src="img/imprimir.jpg" width="30" height="30" /><span class="style10"> Imprimir </span></td>
        </tr>
    </table></td>
  </tr>
</table>
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="550" border="0">
      <tr>
        <td width="516" colspan="8"><span class="style13"></span>          <div align="left">
              <br>
              <table width="497" border="0" align="left">
                <tr>
                  <td width="477" colspan="2" align="center" bgcolor="#FFFFFF">
                    <div align="left"><strong><span class="style3">Periodo </span><span class="style4">
                      <input name="textfield4" type="text" size="2" />
        / </span><span class="style4">
        <input name="textfield5" type="text" size="2" />
        </span><span class="style4"> /
        <input name="textfield6" type="text" size="4" />
        </span> -- <span class="style4">
        <input name="textfield42" type="text" size="2" />
        / </span><span class="style4">
        <input name="textfield52" type="text" size="2" />
        </span><span class="style4"> /
        <input name="textfield62" type="text" size="4" />
        </span>
        <input name="OK" type="submit" id="OK" value="Enviar" />
        <br />
                    </strong></div></td>
                </tr>
              </table>
              <p>&nbsp;</p>
              <table width="577" border="0" align="center" bordercolor="#000000" bgcolor="#000000">
                <tr bgcolor="#333333">
                  <td width="67"><span class="style13"><span class="style29">DATA</span></span></td>
                  <td width="97"><span class="style13"><span class="style29">MOTIVO</span></span></td>
                  <td width="66"><span class="style13"><span class="style29">VALOR</span></span></td>
                  <td width="53"><span class="style13"><span class="style29">TOTAL</span></span></td>
                  <td width="73"><span class="style13"><span class="style29">DINHEIRO</span></span></td>
                  <td width="65"><span class="style13"><span class="style29"> CHEQUE</span></span></td>
                  <td width="61"><span class="style13"><span class="style29">SALDO</span></span></td><br>
                  <td width="61"><span class="style13"><span class="style29">EXCLUIR</span></span></td>
                </tr>
				<?

		$sql = "SELECT * FROM despesas";   
		$qr = mysql_query($sql);   
		while($row = mysql_fetch_array($qr)) {  
		
 		
		?>
                
				
				<tr bgcolor="#FFFFFF">
      <td><? echo $row['DV_DATA']; ?></td>
      <td><? echo $row['DV_MOTIVO']; ?></td>
      <td><? echo $row['DV_VALOR']; ?></td>
      <td><? echo $row['DV_TOTAL']; ?></td>
      <td><? echo $row['DV_DINHEIRO']; ?></td>
      <td><? echo $row['DV_CHEQUE']; ?></td>
      <td><? echo $row['DV_SALDO']; ?></td>
      <td><a href='excluir_usuario.php?id=$id'><img src='images/ico_excluir.jpg' alt='' border='0' /></a></td>

   </tr>
   <?
}
 ?>
              </table>
              </div>
          <div align="center"></div>
          <div align="center"></div></td>
        </tr>
    </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>
