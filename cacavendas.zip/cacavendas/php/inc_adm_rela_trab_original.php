<?php
include ("config.php");
/*
############# EVENTOS ############################
$select_ev = "SELECT * FROM eventos WHERE ativo=1 ORDER BY data_evento_inicio DESC";
$sql_ev = mysql_query($select_ev);
$rows_ev = mysql_num_rows($sql_ev);

##################################################
############# INSCRICOES #########################
$select_insc = "SELECT * FROM inscricoes ORDER BY familyname ASC";
$sql_insc = mysql_query($select_insc);
$rows_insc = mysql_num_rows($sql_insc);
##################################################
############# ISCRICOES DISTINTAS ################
$select_insc2 = "SELECT DISTINCT (city) FROM inscricoes ORDER BY city ASC";
$sql_insc2 = mysql_query($select_insc2);
$rows_insc2 = mysql_num_rows($sql_insc2);
##################################################
############# USUARIOS ###########################
*/
?>

<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>
  <form action="proc_adm_rela_trab.php" method="post">
    <tr>
        <td class='titulo' colspan=4>:: Gerar Relat�rios de Trabalhos ::</td>
    </tr>
    <tr><td class="texto" colspan="2" style="text-align:center;"><strong>Selecione o tipo de trabalho:</strong></td></tr>
    <tr><td class="texto" colspan="2" style="text-align:center;"></td></tr>
    <tr>
        <td width='175' class='texto'><strong>Simp&oacute;sio Proposto</strong></td>
   	  <td width="368" class='texto'><input type="checkbox" name="simposio" value="simposio" /></td>
    </tr>
    <tr>
        <td class='texto' width='175'><strong>P&ocirc;ster</strong></td>
   	  <td class='texto'><input type="checkbox" name="poster" value="poster" /></td>
    </tr>
    <tr>
        <td width='347' class='texto'><strong>Ordenado por:</strong></td>
  		<td class='texto'>
      		<select name="ordem" size="1" class="texto">
            	<option value="">---Escolha---</option>
                <option value="autor">Modalidade</option>
                <option value="check4">Eixo Tem�tico</option>
                <option value="email_avaliador">Avaliador 1</option>
                <option value="email_avaliador">Avaliador 2</option>
                <option value="email_avaliador">Avaliador 3</option>
                <option value="processo">Status</option>
            </select>
        </td>
    </tr>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
    <tr>
    	<td align="center" colspan="2"><input type="submit" value="Gerar Relat�rio" /></td>
    </tr>
  </form>  
</table>
