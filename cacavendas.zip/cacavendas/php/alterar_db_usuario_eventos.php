<?


if (isset($_POST['editar_usuario_eventos']))

{
include"config.php";
$id = $_POST['id'];
$ip = $_SERVER["REMOTE_ADDR"];
$data_hora = date("y.m.d H:i:s");
$email = $_POST["email"];
$login = $_POST["login"];
$senha = $_POST["senha"];
$id_eventos = $_POST["eventos"];
$tipo = $_POST["tipo"];

if($id_eventos != 'evento' and $tipo != 'escolha'){
$query	= "
	UPDATE usuarios_eventos SET 
	ip = '".$ip."',
	id_evento = '".$id_eventos."',
	data_hora = '" .$data_hora."',
	tipo_usuario = '".$tipo."',
	email = '".$email."',
	login = '".$login."', 
	senha = '".$senha."' 
	
	WHERE id='".$id."'";

$result	= mysql_query($query) or die ("Query: ".$query." : ".mysql_error());

Header("Location: ../adm_usuarios_eventos.php");
}
else{
	echo "<script> alert('Por favor preencha o campo EVENTO e/ou TIPO DE USU�RIO!');location.href='javascript:window.history.go(-1)';</script>";
	exit();
	}
}

?>
