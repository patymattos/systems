<?
include"config.php";
$id_inscricoes=$_GET['id_inscricoes'];
//echo "SELECT * FROM inscricoes WHERE id = '".$id_inscricoes."'";
//exit();
$y = mysql_query("SELECT * FROM inscricoes WHERE id = '".$id_inscricoes."'");
if ($x = mysql_fetch_array($y))
{
if($x['nome_evento'] == 'XIV International Conference on Strangeness in Quark Matter'){
echo '
<form name="form1" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes='.$x['id'].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="'.$x['email'].'" />
	<input type="hidden" name="nome_evento" value="'.$x['nome_evento'].'" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>'.$x['id'].'</td>
	   </tr>';
	   if(strlen($x['title']) > 0 ){
	  	echo '<tr>
 		  <td width="296">Title:</td>
 		  <td width="505"><input name="title" value="'.$x['title'].'" type="text" id="title" size="50" /></td>
	   	</tr>';
	   }
	   echo '<tr>
		  <td>Family Name:</td>
		  <td><input name="familyname" value="'.$x['familyname'].'" type="text" id="familyname" size="50" /></td>
	   </tr>';
	   if(strlen($x['givenname']) > 0 ){
	   	echo '<tr>
		  <td>Given Name:</td>
		  <td><input name="givenname" value="'.$x['givenname'].'" type="text" id="givenname" size="50"/></td>
		</tr>';
	   }
	   echo '<tr>
			<td>Name to the Badge:</td>
			<td><input name="nametothebagde" value="'.$x['nametothebagde'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	   if(strlen($x['cpf']) > 0 ){
		echo '<tr>
		  <td>CPF:</td>
		  <td><input name="cpf" value="'.$x['cpf'].'" type="text" id="cpf" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['identidade']) > 0 ){
		echo '<tr>
		  <td>Identidade:</td>
		  <td><input name="identidade" value="'.$x['identidade'].'" type="text" id="identidade" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['Affiliation']) > 0 ){
	  	echo '<tr>
			<td>Affiliation:</td>
			<td><input name="Affiliation" value="'.$x['Affiliation'].'" type="text" id="Affiliation" size="50" /></td>
	    </tr>';
	  }else {
	    echo '<tr>
			<td>Institui��o:</td>
			<td><input name="instituicao" value="'.$x['instituicao'].'" type="text" id="instituicao" size="50" /></td>
	    </tr>
		<tr>
			<td>Especialidade:</td>
			<td><input name="especialidade" value="'.$x['especialidade'].'" type="text" id="especialidade" size="50" /></td>
	    </tr>';
	  }
	  echo '<tr>
			<td>Email:</td>
			<td><input name="email_novo" value="'.$x['email'].'" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Mailing Adress:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x[mailingadress].'" /></td>
	  </tr>
	  <tr>
			<td>City:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x[city].'" /></td>
	  </tr>
	  <tr>
			<td>Province/State:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x[provincestate].'" /></td>
	  </tr>';
	  if(strlen($x['country']) > 0 ){
			echo '<tr>
				<td>Country:</td>
				<td><input name="country" type="text" id="country" size="50" value="'.$x[country].'" /></td>
	  		</tr>';
	   }
	   echo '<tr>
			<td>Zip Code:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x[zipcode].'" /></td>
	   </tr>
	   <tr>
			<td>Phone(country and city code):</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x[phone].'" /></td>
	   </tr>
	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x[fax].'" /></td>
	   </tr>';
	   if(strlen($x['accompanyingperson']) > 0 ){
		 echo' <tr>
			<td>Accompanying Person:</td>
			<td><input name="accompanyingperson" type="text" id="accompanyingperson" size="50" value="'.$x[accompanyingperson].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['letter']) > 0 ){
		  echo '<tr>
			<td>NEED AN INVITATION LETTER:</td>
			<td><input name="letter" type="text" id="letter" size="50" value="'.$x[letter].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['profissional']) > 0 ){
		  echo'<tr>
			<td>Profissional Packages:</td>
			<td><input name="profissional" type="text" id="profissional" size="50" value="'.$x[profissional].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['student']) > 0 ){
		  echo '<tr>
			<td>Student Packages:</td>
			<td><input name="student" type="text" id="student" size="50" value="'.$x[student].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['residente']) > 0 ){
		  echo '<tr>
			<td>Residente:</td>
			<td><input name="residente" type="text" id="residente" size="50" value="'.$x[residente].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['gerentologia']) > 0 ){
		  echo '<tr>
			<td>Gerentologia:</td>
			<td><input name="gerentologia" type="text" id="gerentologia" size="50" value="'.$x[gerentologia].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['congnitiva']) > 0 ){
		  echo '<tr>
			<td>Congnitiva:</td>
			<td><input name="congnitiva" type="text" id="congnitiva" size="50" value="'.$x[congnitiva].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['paleativos']) > 0 ){
		  echo '<tr>
			<td>Paleativos:</td>
			<td><input name="paleativos" type="text" id="paleativos" size="50" value="'.$x[paleativos].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['incapacidade']) > 0 ){
		  echo '<tr>
			<td>Incapacidade:</td>
			<td><input name="incapacidade" type="text" id="incapacidade" size="50" value="'.$x[incapacidade].'" /></td>
		  </tr>';
 	   }
	   if(strlen($x['accompanyingperson2']) > 0 ){
		  echo '<tr>
			<td>Accompanying person Packages:</td>
			<td><input name="accompanyingperson2" type="text" id="accompanyingperson2" size="50" value="'.$x[accompanyingperson2].'" /></td>
		  </tr>';
	   }
	   echo '<tr>
			<td>Form Pagamento:</td>
			<td><input name="formpagamento" type="text" id="formpagamento" size="50" value="'.$x[formpagamento].'" /></td>
	   </tr>';
	   if (($x['formpagamento'] != 'boleto') and ($x['formpagamento'] != 'payment_cash') and ($x['formpagamento'] != 'onsite_payment_credit') and ($x['formpagamento'] != 'Deposit') and ($x['formpagamento'] != 'deposito')){
		   echo '<tr>
			<td>Credit Card:</td>
			<td><input name="cartao" type="text" id="cartao" size="50" value="'.$x[cartao].'" /></td>
		  </tr>
		  <tr>
			<td>Name on Credit Card- holder:</td>
			<td><input name="namecredit" type="text" id="namecredit" size="50" value="'.$x[namecredit].'" /></td>
		  </tr>
		  <tr>
			<td>Date:</td>
			<td><input name="datacartao" type="text" id="datacartao" size="50" value="'.$x[datacartao].'" /></td>
		  </tr>
		  <tr>
			<td>Credit Card N�:</td>
			<td><input name="numcredit" type="text" id="numcredit" size="50" value="'.$x[numcredit].'" /></td>
		  </tr>
		  <tr>
			<td>Credit Card Expiration Date:</td>
			<td><input name="expiracartao" type="text" id="expiracartao" size="50" value="'.$x[expiracartao].'" /></td>
		  </tr>
		  <tr>
			<td>Security Code N�:</td>
			<td><input name="securitycode" type="text" id="securitycode" size="50" value="'.$x[securitycode].'" /></td>
		  </tr>';
	   }
	   echo '<tr>
			<td>Total (R$):</td>
			<td><input name="totalescolhido" type="text" id="totalescolhido" size="50" value="'.$x[totalescolhido].'" /></td>
	   </tr>
	   <tr>
			<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
	   </tr>
	 </table>
	</form>';		
}
elseif($x['nome_evento'] == 'Iberian-Latin-American Congress on Computational Methods in Engineering, organized by the Brazilian Association for Computational Methods in Engineering'){
echo '
<form name="form1" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes='.$x['id'].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="'.$x['email'].'" />
	<input type="hidden" name="nome_evento" value="'.$x['nome_evento'].'" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>'.$x['id'].'</td>
	   </tr>';
	   if(strlen($x['title']) > 0 ){
	  	echo '<tr>
 		  <td width="296">Title:</td>
 		  <td width="505"><input name="title" value="'.$x['title'].'" type="text" id="title" size="50" /></td>
	   	</tr>';
	   }
	   echo '<tr>
		  <td>First Name:</td>
		  <td><input name="familyname" value="'.$x['givenname'].'" type="text" id="familyname" size="50" /></td>
	   </tr>';
	   if(strlen($x['givenname']) > 0 ){
	   	echo '<tr>
		  <td>Middle Name:</td>
		  <td><input name="givenname" value="'.$x['familyname'].'" type="text" id="givenname" size="50"/></td>
		</tr>';
	   }
	   echo '<tr>
			<td>Family Name:</td>
			<td><input name="nametothebagde" value="'.$x['Affiliation'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	   echo '<tr>
			<td>Name to the Badge:</td>
			<td><input name="nametothebagde" value="'.$x['nametothebagde'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	  echo '<tr>
			<td>Email:</td>
			<td><input name="email_novo" value="'.$x['email'].'" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Mailing Adress:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x['mailingadress'].'" /></td>
	  </tr>
	  <tr>
			<td>City:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x['city'].'" /></td>
	  </tr>
	  <tr>
			<td>Province/State:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x['provincestate'].'" /></td>
	  </tr>';
	  if(strlen($x['country']) > 0 ){
			echo '<tr>
				<td>Country:</td>
				<td><input name="country" type="text" id="country" size="50" value="'.$x['country'].'" /></td>
	  		</tr>';
	   }
	   echo '<tr>
			<td>Zip Code:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x['zipcode'].'" /></td>
	   </tr>
	   <tr>
			<td>Phone(country and city code):</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x['phone'].'" /></td>
	   </tr>
	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x['fax'].'" /></td>
	   </tr>';
	   if(strlen($x['accompanyingperson']) > 0 ){
		 echo' <tr>
			<td>Accompanying Person:</td>
			<td><input name="accompanyingperson" type="text" id="accompanyingperson" size="50" value="'.$x['accompanyingperson'].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['letter']) > 0 ){
		  echo '<tr>
			<td>NEED AN INVITATION LETTER:</td>
			<td><input name="letter" type="text" id="letter" size="50" value="'.$x['letter'].'" /></td>
		  </tr>';
	   }
  	   if(strlen($x['profissional']) > 0 ){
		  echo'<tr>
			<td>Profissional Packages:</td>
			<td><input name="profissional" type="text" id="profissional" size="50" value="'.$x['profissional'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['student']) > 0 ){
		  echo '<tr>
			<td>Student Packages:</td>
			<td><input name="student" type="text" id="student" size="50" value="'.$x['student'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['residente']) > 0 ){
		  echo '<tr>
			<td>Residente:</td>
			<td><input name="residente" type="text" id="residente" size="50" value="'.$x['residente'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['gerentologia']) > 0 ){
		  echo '<tr>
			<td>Aditional Work:</td>
			<td><input name="gerentologia" type="text" id="gerentologia" size="50" value="'.$x['gerentologia'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['congnitiva']) > 0 ){
		  echo '<tr>
			<td>Cilance Dinner:</td>
			<td><input name="congnitiva" type="text" id="congnitiva" size="50" value="'.$x['congnitiva'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['paleativos']) > 0 ){
		  echo '<tr>
			<td>Paleativos:</td>
			<td><input name="paleativos" type="text" id="paleativos" size="50" value="'.$x['paleativos'].'" /></td>
		  </tr>';
	   }
	   if(strlen($x['incapacidade']) > 0 ){
		  echo '<tr>
			<td>Incapacidade:</td>
			<td><input name="incapacidade" type="text" id="incapacidade" size="50" value="'.$x['incapacidade'].'" /></td>
		  </tr>';
 	   }
	   if(strlen($x['accompanyingperson2']) > 0 ){
		  echo '<tr>
			<td>Accompanying person Packages:</td>
			<td><input name="accompanyingperson2" type="text" id="accompanyingperson2" size="50" value="'.$x['accompanyingperson2'].'" /></td>
		  </tr>';
	   }
	   echo '<tr>
			<td>Form Pagamento:</td>
			<td><input name="formpagamento" type="text" id="formpagamento" size="50" value="'.$x['formpagamento'].'" /></td>
	   </tr>';
	   if (($x['formpagamento'] != 'boleto') and ($x['formpagamento'] != 'payment_cash') and ($x['formpagamento'] != 'onsite_payment_credit') and ($x['formpagamento'] != 'Deposit') and ($x['formpagamento'] != 'deposito')){
		   echo '<tr>
			<td>Credit Card:</td>
			<td><input name="cartao" type="text" id="cartao" size="50" value="'.$x[cartao].'" /></td>
		  </tr>
		  <tr>
			<td>Name on Credit Card- holder:</td>
			<td><input name="namecredit" type="text" id="namecredit" size="50" value="'.$x[namecredit].'" /></td>
		  </tr>
		  <tr>
			<td>Credit Card N�:</td>
			<td><input name="numcredit" type="text" id="numcredit" size="50" value="'.$x[numcredit].'" /></td>
		  </tr>
		  <tr>
			<td>Credit Card Expiration Date:</td>
			<td><input name="expiracartao" type="text" id="expiracartao" size="50" value="'.$x[expiracartao].'" /></td>
		  </tr>
		  <tr>
			<td>Security Code N�:</td>
			<td><input name="securitycode" type="text" id="securitycode" size="50" value="'.$x[securitycode].'" /></td>
		  </tr>';
	   }
	   echo '<tr>
			<td>Total (R$):</td>
			<td><input name="totalescolhido" type="text" id="totalescolhido" size="50" value="'.$x[totalescolhido].'" /></td>
	   </tr>
	   <tr>
			<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
	   </tr>
	 </table>
	</form>';		
}

elseif($x['nome_evento'] == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){
echo '
<form name="form" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes='.$x['id'].'" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="'.$x['email'].'" />
	<input type="hidden" name="nome_evento" value="'.$x['nome_evento'].'" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>'.$x['id'].'</td>
	   </tr>';
	   if(strlen($x['title']) > 0 ){
	  	echo '<tr>
 		  <td width="296">Title:</td>
 		  <td width="505"><input name="title" value="'.$x['title'].'" type="text" id="title" size="50" /></td>
	   	</tr>';
	   }
	   echo '<tr>
		  <td>Nome Completo:</td>
		  <td><input name="familyname" value="'.$x['familyname'].'" type="text" id="familyname" size="50" /></td>
	   </tr>';
	   if(strlen($x['givenname']) > 0 ){
	   	echo '<tr>
		  <td>Given Name:</td>
		  <td><input name="givenname" value="'.$x['givenname'].'" type="text" id="givenname" size="50"/></td>
		</tr>';
	   }
	   echo '<tr>
			<td>Nome para Crach�:</td>
			<td><input name="nametothebagde" value="'.$x['nametothebagde'].'" type="text" id="nametothebadge" size="50"/></td>
	   </tr>';
	   if(strlen($x['cpf']) > 0 ){
		echo '<tr>
		  <td>CPF:</td>
		  <td><input name="cpf" value="'.$x['cpf'].'" type="text" id="cpf" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['identidade']) > 0 ){
		echo '<tr>
		  <td>Identidade:</td>
		  <td><input name="identidade" value="'.$x['identidade'].'" type="text" id="identidade" size="50"/></td>
		</tr>';
	   }
	   if(strlen($x['Affiliation']) > 0 ){
	  	echo '<tr>
			<td>Affiliation:</td>
			<td><input name="Affiliation" value="'.$x['Affiliation'].'" type="text" id="Affiliation" size="50" /></td>
	    </tr>';
	  }else {
	    echo '<tr>
			<td>Institui��o:</td>
			<td><input name="instituicao" value="'.$x['instituicao'].'" type="text" id="instituicao" size="50" /></td>
	    </tr>
		<tr>
			<td>Especialidade:</td>
			<td><input name="especialidade" value="'.$x['especialidade'].'" type="text" id="especialidade" size="50" /></td>
	    </tr>';
	  }
	  echo '<tr>
			<td>Email:</td>
			<td><input name="email_novo" value="'.$x['email'].'" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Endere�o:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x[mailingadress].'" /></td>
	  </tr>
	  <tr>
			<td>Cidade:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x[city].'" /></td>
	  </tr>
	  <tr>
			<td>Estado:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x[provincestate].'" /></td>
	  </tr>';
	  if(strlen($x['country']) > 0 ){
			echo '<tr>
				<td>Country:</td>
				<td><input name="country" type="text" id="country" size="50" value="'.$x[country].'" /></td>
	  		</tr>';
	   }
	   echo '<tr>
			<td>CEP:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x[zipcode].'" /></td>
	   </tr>
	   <tr>
			<td>Telefone:</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x[phone].'" /></td>
	   </tr>
	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x[fax].'" /></td>
	   </tr>';
	   ?>
<table width="100%" border="1" bordercolor="" bgcolor="" cellpadding="0" style="margin-top:0px;" cellspacing="0">
 <tr>
	<td colspan="4" align="center" style="font-family:verdana; font-size:12px"; bgcolor=""><strong>Investimentos</strong>
    </td>
 </tr>
 <tr>
 	<td width="50%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> Categoria</strong>
    </td>
	<td width="21%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> At&eacute; 02/10/2009</strong>
    </td>
	<td width="21%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> Recebido pela secretaria at� 19/10/2009</strong>
    </td>
	<td width="8%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
    	<strong> Total</strong>
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	S&oacute;cios Quites da SBGG
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check1' value='270.00' onClick="checar()" disabled="disabled" />R$ 270.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
   		<input type='checkbox' name="check2" value='380.00' onClick="checar()"/>R$ 380.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
   		<input type="button" name="total1" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	N&acirc;o S&oacute;cios
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check3' value='380.00' onClick="checar()" disabled="disabled" />R$ 380.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name="check4" value='480.00' onClick="checar()"/>R$ 480.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total2" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
		Residentes
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check5' value='340.00' onClick="checar()" disabled="disabled" />R$ 340.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name="check6" value='400.00' onClick="checar()"/>R$ 400.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total3" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
		Estudantes de Gradua&ccedil;&acirc;o
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name='check7' value='200.00' onClick="checar()" disabled="disabled" />R$ 200.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    	<input type='checkbox' name="check8" value='200.00' onClick="checar()"/>R$ 200.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total4" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	Curso "Gerontologia"(*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND gerentologia > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
        if($z <= 80){
          	echo '<input type="checkbox" name="check9" value="50.00" onclick="checar()" disabled="disabled" />';
		}
	?>
    R$ 50.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
	if($z <= 80){
       	echo '<input type="checkbox" name="check10" value="50.00" onclick="checar()" />';
	}
	?>
    R$ 50.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total5" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
	    Oficina 01 "Avalia&ccedil;&acirc;o Cognitiva" (*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
     <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND congnitiva > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
		if($z <= 80){
            echo '<input type="checkbox" name="check11" value="50.00" onclick="checar()" disabled="disabled" />';
		}
	 ?>	
    	R$ 50.00
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		if($z <= 80){
          	echo '<input type="checkbox" name="check12" value="50" onclick="checar()" />';
		}
	?>
    R$ 50.00
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total6" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	Tribuna Livre "&Uacute;ltimo Ato - Li&ccedil;&otilde;es Perto do Fim" (antiga Oficina 2) (*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND paleativos > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
		if($z <= 80){
           	echo '<input type="checkbox" name="check13" value="gratuito" disabled="disabled" />';
		}
	?>
    gratuito
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
	<?php
	if($z <= 80){
       	echo '<input type="checkbox" name="check14" value="gratuito"  />';
	}
	?> 
    gratuito
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total7" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="0" style="font-family:verdana; font-size:12px";> 
    	Encontro com Especialista "Incapacidade" (*)(**)
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
		$select = "SELECT * FROM inscricoes WHERE nome_evento='$nome_evento' AND incapacidade > '1'";
		$sql=mysql_query($select) or die (mysql_error($select));
		$z=mysql_num_rows($sql);
		if($z <= 80){
           	echo '<input type="checkbox" name="check15" value="gratuito" disabled="disabled" />';
		}
	?>	 
    gratuito
    </td>
    <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
    <?php
	if($z <= 80){
       	echo '<input type="checkbox" name="check16" value="gratuito"  />';
	}
	?> 
    gratuito
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="total8" class="valor" size="5" />
    </td>
 </tr>
 <tr>
 	<td align="left" colspan="3" style="font-family:verdana; font-size:12px";>
	    <strong> Total</strong>
    </td>
    <td align="left" style="font-family:verdana; font-size:12px";>
    	<input type="button" name="totall" class="valor" size="5" />
    </td>
 </tr>
</table>
<table border="0" width="100%">
  <tr>
	<td align="left" colspan="3">
	 <?php
	 $sql=mysql_query("SELECT * FROM cedente WHERE id_evento='$id_ev'");
	 $x=mysql_fetch_array($sql);
	 $conta=$x['conta']."-".$x['conta_div'];
	 $agencia=$x['agencia'];
	 $cnpj=$x['cpf_cnpj'];
	 $favorecido=$x['cedente'];
	 if ($formpagamento == "deposito"){
	 	echo '<input type="radio" name="formpagamento" value="deposito" checked="checked"/>';
	    echo '<samp class="texto">Op&ccedil;&atilde;o 1 &ndash; Dep&oacute;sito<br />
		Banco: UNIBANCO (409) - Ag&ecirc;ncia: 0000'.$agencia.' - Conta Corrente: '.$conta.' <br />
		Favorecido: '.$favorecido.' - CNPJ:'.$cnpj.'<br /><br /></samp>
		<input type="radio" name="formpagamento" value="boleto"/>
		<samp class="texto">Op&ccedil;&atilde;o 2 &ndash; Boleto Banc&aacute;rio<br /></samp>';
	 }else{
		echo '<input type="radio" name="formpagamento" value="deposito"/>';    
		echo '<samp class="texto">Op&ccedil;&atilde;o 1 &ndash; Dep&oacute;sito<br />
		Banco: UNIBANCO (409) - Ag&ecirc;ncia: 0000'.$agencia.' - Conta Corrente: '.$conta.' <br />
		Favorecido: '.$favorecido.' - CNPJ:'.$cnpj.'<br /><br /></samp>
		<input type="radio" name="formpagamento" value="boleto" checked="checked"/>
		<samp class="texto">Op&ccedil;&atilde;o 2 &ndash; Boleto Banc&aacute;rio<br /></samp>';
	 }
	  ?>      
	 </td>
   </tr>
   <?php
	   echo '<tr>
			<td align="center" colspan="5"><a href="javascript:history.go(-1)">Voltar</a></td>
	   </tr>
	 </table>
	</form>';		
}
}
?>