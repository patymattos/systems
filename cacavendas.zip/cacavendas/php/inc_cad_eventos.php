<?
include ("config.php");

$evento 			= $_POST['evento']; 
$tipo_evento		= $_POST['tipo_evento'];
$data_evento_inicio = $_POST['data_evento_inicio'];
$data_evento_final 	= $_POST['data_evento_final'];
$local_evento 		= $_POST['local_evento'];
$promocao 			= $_POST['promocao'];
$patrocinio			= $_POST['patrocinio'];
$apoio				= $_POST['apoio'];
$montagens			= $_POST['montagens'];
$tematica			= $_POST['tematica'];
$candidato			= $_POST['candidato'];
$email_evento		= $_POST['email_evento'];
$link				= $_POST['link'];
$foto_evento 		= $_FILES['foto_evento']['name'];
$foto_topo			= $_FILES['foto_topo']['name'];
$cedente			= $_POST['cedente'];
$agencia			= $_POST['agencia'];
$conta				= $_POST['conta'];
$conta_div			= $_POST['conta_div'];
$codigo_cliente		= $_POST['codigo_cliente'];
$carteira			= $_POST['carteira'];
$diap				= $_POST['diap'];
$txb				= str_replace(",",".",$_POST['txb']);
$cpf_cnpj			= $_POST['cpf_cnpj'];
$endereco			= $_POST['endereco'];
$cidade				= $_POST['cidade'];
$uf					= $_POST['uf'];

if (isset($_POST[unibanco])){
$boleto				= 1;
}
else{
$boleto 			= 0;
}

$data_evento_inicio2 = explode("/",$data_evento_inicio);
$dataeventoinicio = $data_evento_inicio2[2].$data_evento_inicio2[1].$data_evento_inicio2[0];

$data_evento_final2 = explode("/",$data_evento_final);
$dataeventofinal = $data_evento_final2[2].$data_evento_final2[1].$data_evento_final2[0];


$caminho_dir = "/imagem/eventos/".$foto_evento;
$caminho_topo = "imagem/".foto_topo;

$status = move_uploaded_file($_FILES['foto_evento']['tmp_name'],"../../../imagem/eventos/"."$foto_evento");
$status2 = move_uploaded_file($_FILES['foto_topo']['tmp_name'],"../../../inscricoes/imagem/"."$foto_topo");

$acento = array("�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "A", "E", "I", "O", "U", "/", " ");
$semacento=array("a", "a", "a", "a", "e", "e", "i", "o", "o", "o", "u", "u", "c", "a", "a", "a", "a", "e", "e", "i", "o", "o", "o", "u", "u", "c", "a", "e", "i", "o", "u", "", "");

$evento_sem_acento = str_replace($acento,$semacento,$evento);

$diretorio = "../../../userfiles/file/".$evento_sem_acento;
 mkdir($diretorio);
 chmod ($diretorio,0777);
$diretorio2 = "../../../userfiles/flash/".$evento_sem_acento;
 mkdir($diretorio2);
 chmod ($diretorio2,0777);
$diretorio3 = "../../../userfiles/image/".$evento_sem_acento;
 mkdir($diretorio3);
 chmod ($diretorio3,0777);
$diretorio4 = "../../../userfiles/media/".$evento_sem_acento;
 mkdir($diretorio4);
 chmod ($diretorio4,0777);
$diretorio5 = "../../../inscricoes/trabalhos/".$evento_sem_acento;
 mkdir($diretorio5);
 chmod ($diretorio5,0777);
$diretorio6 = "../../../inscricoes/formularios_off/".$evento_sem_acento;
 mkdir($diretorio6);
 chmod ($diretorio6,0777);

$link_inscricao = "$link";
$link_file = str_replace("../../../","https://www.metaeventos.net/",$diretorio);
$link_imagem = str_replace("../../../","https://www.metaeventos.net/",$diretorio2);
$link_flash = str_replace("../../../","https://www.metaeventos.net/",$diretorio3);
$link_media = str_replace("../../../","https://www.metaeventos.net/",$diretorio4);
$link_trabalhos = str_replace("../../../","https://www.metaeventos.net/",$diretorio5);
$link_form_off = str_replace("../../../","https://www.metaeventos.net/",$diretorio6);





########## CADASTRANDO NOVO EVENTO NO BANCO DE DADOS #######################################################
$select_evento = "INSERT INTO eventos (nome_evento, tipo_evento, data_evento_inicio, data_evento_final, local_evento, promocao, patrocinio, apoio, montagens, tematica, candidato, email_evento, link, foto_evento, topo, ativo, boleto) 
VALUES ('$evento','$tipo_evento','$dataeventoinicio','$dataeventofinal','$local_evento','$promocao','$patrocinio','$apoio','$montagens','$tematica','$candidato','$email_evento','$link','$caminho_dir','$caminho_topo',0,'$boleto')";

$query_eventos = mysql_query($select_evento) or die ("Query error: ".$select_evento." : ".mysql_error());

############################################################################################################
if($boleto == 1){
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########
	
	$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
	$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
	$resultado_consulta = mysql_fetch_array($query_consulta);
	
	$id_evento = $resultado_consulta['id'];
	
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUANTOS CEDENTE J� EXISTE #########
	
	$select_consulta_cedente = "SELECT * FROM cedente";
	$query_consulta_cedente = mysql_query($select_consulta_cedente);
	$resultado = mysql_num_rows($query_consulta_cedente);
	
	##############################################################################################################
	
	$id_cedente = $resultado + 1;
	
	######### CADASTRANDO CEDENTE PARA O REFERIDO EVENTO #########################################################
	
	$select_cedente = "INSERT INTO cedente (id_cedente, cedente, agencia, conta, conta_div, codigo_cliente, carteira, diap, txb, cpf_cnpj, endereco, cidade, uf, id_evento)
	VALUES ('$id_cedente','$cedente','$agencia','$conta','$conta_div','$codigo_cliente','$carteira','$diap','$txb','$cpf_cnpj','$endereco','$cidade','$uf','$id_evento')";
	
	$query_cedente = mysql_query($select_cedente) or die ("Query error: ".$select_cedente." : ".mysql_error());
	
	##############################################################################################################
	############ INSERINDO OS LINKS DO EVENTOS EM UMA BASE DE DADOS ##############################################
	
	$insert_link = "INSERT INTO links (id_evento, link_inscricao, link_file, link_imagem, link_flash, link_media, link_trabalhos, link_inscricao_off ) VALUES ('$id_evento','$link_inscricao','$link_file','$link_imagem','$link_flash','$link_media','$link_trabalhos','$link_form_off');";
	$query_link = mysql_query($insert_link) or die ("Query error".$insert_link." : ".mysql_error());

}
else{
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########
	
	$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
	$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
	$resultado_consulta = mysql_fetch_array($query_consulta);
	
	$id_evento = $resultado_consulta['id'];
	
	
	##############################################################################################################
	############ INSERINDO OS LINKS DO EVENTOS EM UMA BASE DE DADOS ##############################################
	
	$insert_link = "INSERT INTO links (id_evento, link_inscricao, link_file, link_imagem, link_flash, link_media, link_trabalhos, link_inscricao_off ) VALUES ('$id_evento','$link_inscricao','$link_file','$link_imagem','$link_flash','$link_media','$link_trabalhos','$link_form_off');";
	$query_link = mysql_query($insert_link) or die ("Query error".$insert_link." : ".mysql_error());
}
Header("Location: ../adm_eventos.php");
?>
