<?php
include ("config.php");

$servicos = $_POST['servicos']; 
$id = $_POST['id'];

$query = mysql_query("UPDATE site SET servicos='$servicos' WHERE id = '$id' ");


Header("Location: ../adm_servicos.php");
?>
