<?
include ("config.php");

$cd_arquivo 	    	= $_FILES['arquivo']['name'];

if (isset($_POST[unibanco])){
$boleto				= 1;
}
else{
$boleto 			= 0;
}

$caminho_dir = "/arquivos/".$cd_arquivo;

$status = move_uploaded_file($_FILES['arquivo']['tmp_name'],"../../../arquivos/"."$cd_arquivo");


$link_inscricao = "$link";
$link_file = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio);
$link_imagem = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio2);
$link_flash = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio3);
$link_media = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio4);
$link_trabalhos = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio5);
$link_form_off = str_replace("../../../","http://www.softwaresworld.com.br/",$diretorio6);


########## CADASTRANDO NOVO EVENTO NO BANCO DE DADOS #######################################################
$select_projeto = "INSERT INTO projetos (arquivo) 
VALUES ('$arquivo')";

$query_eventos = mysql_query($select_evento) or die ("Query error: ".$select_evento." : ".mysql_error());

############################################################################################################
if($boleto == 1){
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########
	
	$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
	$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
	$resultado_consulta = mysql_fetch_array($query_consulta);
	
	$id_evento = $resultado_consulta['id'];
	
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUANTOS CEDENTE J� EXISTE #########
	
	$select_consulta_cedente = "SELECT * FROM cedente";
	$query_consulta_cedente = mysql_query($select_consulta_cedente);
	$resultado = mysql_num_rows($query_consulta_cedente);
	
	##############################################################################################################
	
	$id_cedente = $resultado + 1;
	
	######### CADASTRANDO CEDENTE PARA O REFERIDO EVENTO #########################################################
	
	$select_cedente = "INSERT INTO cedente (id_cedente, cedente, agencia, conta, conta_div, codigo_cliente, carteira, diap, txb, cpf_cnpj, endereco, cidade, uf, id_evento)
	VALUES ('$id_cedente','$cedente','$agencia','$conta','$conta_div','$codigo_cliente','$carteira','$diap','$txb','$cpf_cnpj','$endereco','$cidade','$uf','$id_evento')";
	
	$query_cedente = mysql_query($select_cedente) or die ("Query error: ".$select_cedente." : ".mysql_error());
	
	##############################################################################################################
	############ INSERINDO OS LINKS DO EVENTOS EM UMA BASE DE DADOS ##############################################
	
	$insert_link = "INSERT INTO links (id_evento, link_inscricao, link_file, link_imagem, link_flash, link_media, link_trabalhos, link_inscricao_off ) VALUES ('$id_evento','$link_inscricao','$link_file','$link_imagem','$link_flash','$link_media','$link_trabalhos','$link_form_off');";
	$query_link = mysql_query($insert_link) or die ("Query error".$insert_link." : ".mysql_error());

}
else{
	########## FAZENDO CONSULTA AO BANCO DE EVENTOS PARA SABER QUAL O NUMERO DO ID DO EVENTO CADASTRADO #########
	
	$select_consulta = "SELECT * FROM eventos WHERE nome_evento = '$evento' ";
	$query_consulta = mysql_query($select_consulta) or die ("Query error: ".$select_consulta." : ".mysql_error());
	$resultado_consulta = mysql_fetch_array($query_consulta);
	
	$id_evento = $resultado_consulta['id'];
	
	
	##############################################################################################################
	############ INSERINDO OS LINKS DO EVENTOS EM UMA BASE DE DADOS ##############################################
	
	$insert_link = "INSERT INTO links (id_evento, link_inscricao, link_file, link_imagem, link_flash, link_media, link_trabalhos, link_inscricao_off ) VALUES ('$id_evento','$link_inscricao','$link_file','$link_imagem','$link_flash','$link_media','$link_trabalhos','$link_form_off');";
	$query_link = mysql_query($insert_link) or die ("Query error".$insert_link." : ".mysql_error());
}
Header("Location: ../adm_projetos.php");
?>
