<?
include"config.php";
$email=$_GET['email'];
$y = mysql_query("SELECT * FROM inscricoes WHERE email = '".$email."'");
if ($x = mysql_fetch_array($y))
{
echo '
	<form action="teste2.php" method="post" name="form">
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2">
			<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" />
		</td>
       </tr>
       <tr>
          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td width="296"> Escolha o tipo:</td>
 		  <td width="505"><select name="tipo" onblur="selecao()" onchange="selecao()"></td>
	   </tr>
	   <tr>
		if($tipo!= ""){
		  <td><option value="'.$tipo.'">'.$tipo.'</td>
		}else{  
		  <td><option value=" ">-= Selecione o tipo do campo =-</option></td>
		}
		  <td>    	
		  	<option value="text">text</option>
	    	<option value="password">password</option>
	    	<option value="radio">Radio</option>
	    	<option value="checkbox">Checkbox</option>
    		<option value="select">Select</option>
		   </select>
		  </td>
	   </tr>
	   <tr>
		  <td>Given Name:</td>
		  <td><input name="givenname" value="'.$x[givenname].'" type="text" id="givenname" size="50"/></td>
		  </tr>
		  <tr>
			<td>Name to the Badge:</td>
			<td><input name="nametothebagde" value="'.$x[nametothebagde].'" type="text" id="nametothebadge" size="50"/></td>
		  </tr>
		  <tr>
			<td>Affiliation:</td>
			<td><input name="Affiliation" value="'.$x[Affiliation].'" type="text" id="Affiliation" size="50" /></td>
		  </tr>
		  <tr>
			<td>Mailing Adress:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="'.$x[mailingadress].'" /></td>
		  </tr>
		  <tr>
			<td>City:</td>
			<td><input name="city" type="text" id="city" size="50" value="'.$x[city].'" /></td>
		  </tr>
		  <tr>
			<td>Province/State:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="'.$x[provincestate].'" /></td>
		  </tr>
		  <tr>
			<td>Country:</td>
			<td><input name="country" type="text" id="country" size="50" value="'.$x[country].'" /></td>
		  </tr>
		  <tr>
			<td>Zip Code:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="'.$x[zipcode].'" /></td>
		  </tr>
		  <tr>
			<td>Phone(country and city code):</td>
			<td><input name="phone" type="text" id="phone" size="50" value="'.$x[phone].'" /></td>
		  </tr>
		  <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="'.$x[fax].'" /></td>
		  </tr>
		  <tr>
			<td>Accompanying Person:</td>
			<td><input name="accompanyingperson" type="text" id="accompanyingperson" size="50" value="'.$x[accompanyingperson].'" /></td>
		  </tr>
		  <tr>
			<td>NEED AN INVITATION LETTER:</td>
			<td><input name="letter" type="text" id="letter" size="50" value="'.$x[letter].'" /></td>
		  </tr>
		 <tr>
		<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
		</tr>
        </table>
		</form>';		
}
?>