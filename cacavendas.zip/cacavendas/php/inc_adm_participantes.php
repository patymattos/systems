<?php
include ("config.php");


	if ($nome_evento == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){
		$sql = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '$nome_evento' ORDER BY familyname ASC"); // Executa a query no MySQL com o limite de linhas.
	}
	elseif ($nome_evento == '30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE'){
		$sql = mysql_query("SELECT * FROM inscricoes WHERE nome_evento = '$nome_evento' ORDER BY givenname ASC"); // Executa a query no MySQL com o limite de linhas.
	}
			echo "<table width=550 border=0 cellpadding=1 cellspacing=1 class='cor_tr'>";
			echo "<tr>";
			echo "<td class=titulo colspan=4>:: Administrar Emiss�es de Certificados ::</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td class='texto' width='5'><b>Qnt:</b></td>";
			echo "<td class='texto' width='400'><b>Participantes</b></td>";
			echo "<td class='texto' width='100'><center><b>E-Mail</b></center></td>";
			echo "<td class='texto' width='45'><b>Certificado</b></td>";
		echo "</tr>";
			$i = 0;
		while ($linha = mysql_fetch_array($sql)){
			$i++;
			//$id_evento = $linha["id"];
			$id_inscricoes = $linha["id"];
			$familyname = $linha["familyname"];
			$givenname = $linha["givenname"];
			$Affiliation = $linha["Affiliation"];
			$email = $linha["email"];
			$nome_evento = $linha["nome_evento"];
			echo "<tr>";
			echo "<td class='texto'><center>".$i."</center></td>";
			if ($nome_evento == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){
			echo "<td class='texto'>".$familyname."</td>";
			}
			elseif($nome_evento == '30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE'){
			echo "<td class='texto'>".$givenname." ".$familyname." ".$Affiliation."</td>";
			}
			elseif($nome_evento == 'XIV International Conference on Strangeness in Quark Matter'){
			echo "<td class='texto'>".$givenname."</td>";
			}
			echo "<td class='texto'>".$email."</td>";
			echo "<td class='texto'><a href='certificados.php?id=$id_inscricoes'>CERTIFICADO</a></td>";
			echo "</tr>";		
		}
		echo "</table>";
		echo "<span class='texto'><br /><br /><a href='javascript:history.go(-1)'>Voltar</a></span>";
		echo "<br />";
?>