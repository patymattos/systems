<?
//Conexão ao Banco de dados local
$conexao = mysql_connect("localhost","metaeven_galeria","metawbeventos");
$db = mysql_select_db("metaeven_meta");

$dia =date('d');
$mes =date('m');
$ano =date('Y');
$data =$dia."-".$mes."-".$ano;

$ano 				= $_POST['ano'];
$mes				= $_POST['mes'];
if ($mes < 10){
	$mesano			= $_POST['ano']."-0".$_POST['mes'];
}else{
	$mesano			= $_POST['ano']."-".$_POST['mes'];
}
$tipo_evento 		= $_POST['tipo_evento'];
$tipo_evento2 		= $_POST['tipo_evento2'];
//$id			 		= $_POST['id'];
$nome_evento 		= $_POST['nome_evento'];
$data_evento_inicio = $_POST['data_evento_inicio'];
$data_evento_final  = $_POST['data_evento_final'];
$local_evento 		= $_POST['local_evento'];
$promocao 			= $_POST['promocao'];
$patrocinio 		= $_POST['patrocinio'];
$apoio				= $_POST['apoio'];
$montagens			= $_POST['montagens'];
$tematica			= $_POST['tematica'];
$candidato 			= $_POST["candidato"];
$email_evento		= $_POST['email_evento'];
$link				= $_POST['link'];
$titulo				= $_POST['titulo'];
$termo				= $_POST['termo'];
$ativo				= $_POST['ativo'];
$ordem				= $_POST['ordem'];


if(strlen($ano) > 0){
	$condicao3 = "WHERE data_evento_inicio > '".$ano."-01-01' AND data_evento_inicio < '".$ano."-12-31'";
}
if(strlen($mes) > 0){
  if(strlen($ano) < 1){
      echo "<script> alert('Por Favor escolha um ano');location.href='javascript:window.history.go(-1)'; </script>";
  }else{
	$condicao3 = "WHERE data_evento_inicio > '".$mesano."-01' AND data_evento_inicio < '".$mesano."-31'";
  }	
}
if(strlen($tipo_evento) > 0){
    if(strlen($ano) < 1){
		$condicao3 = "WHERE tipo_evento='$tipo_evento'";
	}else{
		$condicao3 .= "AND tipo_evento='$tipo_evento'";
	}
}

$condicao="";
$condicao2="";
if(strlen($tipo_evento2)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "tipo_evento";
  $condicao2 .= "Tipo do Evento";
}
if(strlen($data_evento_inicio)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "data_evento_inicio";
  $condicao2 .= "Data de Inicio";
}
if(strlen($data_evento_final)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "data_evento_final";
  $condicao2 .= "Data Final";
}
if(strlen($nome_evento)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "nome_evento";
  $condicao2 .= "Nome do Evento";
}


if(strlen($local_evento)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "local_evento";
  $condicao2 .= "Local do Evento";
}
if(strlen($promocao)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "promocao";
  $condicao2 .= "Promoção";
}
if(strlen($patrocinio)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "patrocinio";
  $condicao2 .= "Patrocínio";
}
if(strlen($apoio)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "apoio";
  $condicao2 .= "Apoio";
}
if(strlen($montagens)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "montagens";
  $condicao2 .= "Montagens";
}
if(strlen($tematica)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "tematica";
  $condicao2 .= "Temática";
}
if(strlen($candidato)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "candidato";
  $condicao2 .= "Candidato";
}
if(strlen($email_evento)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "email_evento";
  $condicao2 .= "Email do Evento";
}
if(strlen($link)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "link";
  $condicao2 .= "Link";
}
if(strlen($titulo)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "titulo";
  $condicao2 .= "Titulo";
}

if(strlen($ativo)> 0){
  if(strlen($condicao) > 0){
  	$condicao .= ", ";
	$condicao2 .= ", ";
  }	
  $condicao .= "ativo";
  $condicao2 .= "Ativo";
}

$condicao2= explode(",",$condicao2);
//consulta sql
$SQL = "SELECT $condicao FROM eventos $condicao3 $ordem";  
$executa = mysql_query($SQL)or die(mysql_error());

// montando a tabela
$count = count($condicao2);
// definimos o tipo de arquivo
header("Content-type: application/msexcel");

// Como será gravado o arquivo
header("Content-Disposition: attachment; filename=relatorio_eventos.xls");
echo "<table border='0' width='900' cellspacing='1' style='border-top:1px solid #000;'>
		<tr>
		  <td bgcolor='#F2F2F2' align='left'><b>Eventos</b><br /><br />".$data."
		  </td>
		  <td bgcolor='#F2F2F2' align='right'>
		  	<img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' border='0' width='125' align='right'>
		  </td>
		</tr>  	
     </table>";
echo "<table border='1' width='900' cellspacing='1'>";
		 while($rs = mysql_fetch_array($executa)){
		    if (strlen($rs['nome_evento']) > 0){ 
					  echo "<tr>";
						echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Nome do Evento</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' bgcolor='#F2F2F2'>" . $rs['nome_evento'] . "</td>";
					  echo "</tr>";
					}
					if ($rs['tipo_evento'] == 1){
					    echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>EVENTOS T&Eacute;CNICO-CIENT&Iacute;FICOS</td>";
						echo "</tr>";  
					}elseif ($rs['tipo_evento'] == 2){
					   echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>ORGANIZA&Ccedil;&Otilde;ES NO EXTERIOR</td>";
						echo "</tr>";  
					}elseif ($rs['tipo_evento'] == 3){
					    echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>FEIRAS E EXPOSI&Ccedil;&Otilde;ES</td>";
						echo "</tr>";
					}elseif ($rs['tipo_evento'] == 4){
					   echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
					  	  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>MONTAGEM DE ESTANDES</td>";
					   echo "</tr>";
					}elseif ($rs['tipo_evento'] == 5){
					   echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>EVENTOS ESPORTIVOS</td>";
						echo "</tr>";  
					}elseif ($rs['tipo_evento'] == 6){
					   echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>EVENTOS CULTURAIS</td>";
						echo "</tr>";  
					}elseif ($rs['tipo_evento'] == 7){
						echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>OUTRAS PRODU&Ccedil;&Otilde;ES </td>";
					   echo "</tr>";
					}elseif ($rs['tipo_evento'] == 8){
						echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>FORMATURAS</td>";
						echo "</tr>";
					}elseif ($rs['tipo_evento'] == 9){
						echo "<tr>";  
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tipo do Evento</b></td>";
						  echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='200' align='left' bgcolor='#F2F2F2'>MARKETING POL&Iacute;TICO</td>";
						  echo "</tr>";  
					}
					
					if (strlen($rs['data_evento_inicio']) > 0){ 
					  if (substr($rs['data_evento_inicio'],0,4) != '0000'){
						  echo "<tr>";
							  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Data de In&iacute;cio</b></td>";
							  echo "<td bgcolor='#F2F2F2' width='200' align='left'>" . date('d-m-Y',strtotime(substr($rs['data_evento_inicio'],0,10))) . "</td>";
						  echo "</tr>";
					  }	  
					}
					if (strlen($rs['data_evento_final']) > 0){ 
					 if (substr($rs['data_evento_final'],0,4) != '0000'){
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Data Final</b></td>";
						  echo "<td bgcolor='#F2F2F2' width='200' align='left'>" . date('d-m-Y',strtotime(substr($rs['data_evento_final'],0,10))) . "</td>";
					  echo "</tr>";
					 }	 
				   }
					if (strlen($rs['local_evento']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Local do Evento</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' width='100' bgcolor='#F2F2F2'>" . $rs['local_evento'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['promocao']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Promo&ccedil;&atilde;o</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' width='230' bgcolor='#F2F2F2'>" . $rs['promocao'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['patrocinio']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Patroc&iacute;nio</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['patrocinio'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['apoio']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Apoio</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['apoio'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['montagens']) > 0){ 
					  echo "<tr>";
					  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Montagens</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['montagens'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['tematica']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Tem&aacute;tica</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['tematica'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['candidato']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Candidato</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['candidato'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['email_evento']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Email do Evento</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['email_evento'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['link']) > 7){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Link do Evento</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['link'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['titulo']) > 0){ 
					  echo "<tr>";
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>T&iacute;tulo do Evento</b></td>";
						echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $rs['titulo'] . "</td>";
					  echo "</tr>";
					}
					if (strlen($rs['ativo']) > 0){ 
					  echo "<tr>";  	  
						if ($rs['ativo'] == 1){
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Ativo</b></td>";
							echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>Sim</td>";
						}else{
						  echo "<td align='left' bgcolor='#F2F2F2' style='width:100px;'><b>Ativo</b></td>";
							echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>Não</td>";
						}
					  echo "</tr>";
					}
					if ((strlen($rs['tipo_evento'])>0) || (strlen($rs['nome_evento'])>0) || (strlen($rs['data_evento_inicio'])>0) || (strlen($rs['data_evento_final'])>0) ||(strlen($rs['local_evento'])>0) || (strlen($rs['promocao'])>0) || (strlen($rs['patrocinio'])>0) || (strlen($rs['apoio'])>0) || (strlen($rs['montagens'])>0) || (strlen($rs['tematica'])>0) || (strlen($rs['candidato'])>0) || (strlen($rs['email_evento'])>0) || (strlen($rs['link'])>7) || (strlen($rs['titulo'])>0) || (strlen($rs['ativo'])>0) || (strlen($rs['ordem'])>0)){
					 	echo "<tr>
						  <td colspan='2' bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left' height='40'></td>
						</tr>";
					}	
				}
			   echo "</tr>";
				  echo "<tr>
						  <td colspan='2' bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PE&Ccedil;ANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
																TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
						  </td>
						</tr>
				</table>";
?>