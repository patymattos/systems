<?php
include ("config.php");

$termo 	= $_POST['termo']; 
$id	=	$_POST['id'];

$query = mysql_query("UPDATE eventos SET termo ='$termo' WHERE id = '$id' ");


Header("Location: ../adm_termo.php");
?>
