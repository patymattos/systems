<?php
include 'config.php';
/* Enfim sua conex�o com o bd ... n�o me responsabilizo por m� edi��o na sua sintaxe de conex�o ... */
switch($_POST['recupera']){
default:
case "recupera":
	recupera_senha($_POST['email']); // aplicando a fun��o na conta de email enviada pelo form
	break;
}
function recupera_senha($email){ // fun��o que far� o trabalho pesado
  $sql_check = mysql_query(
  "SELECT senha, login FROM usuarios WHERE email='$email'"
  ) or die (mysql_error());
  $sql_check_num = mysql_num_rows($sql_check);
  if($sql_check_num == 0){
  echo("<script>
      alert(\"N�o cadastrado!\");
      window.location = '../lembrar_senha.php';
      </script>");

  } // fecha if
  else{
  $recupera = mysql_fetch_array($sql_check);

  $senha = $recupera[0];
  $login = $recupera[1];

  $subject = "Recuperando sua Senha!";
  $message = "
Segue sua senha para acesso ao seu painel de controle do site

   https://www.metaeventos.net

Com administra��o em:

     https://www.metaeventos.net/site/adm/


  Login: $login
  Senha: $senha

  Meta Eventos
  
  ";

  mail(

  $email, $subject, $message, "From: Meta Eventos<meta@wb.com.br>"

  );

  echo("<script>
      alert(\"Sua senha foi enviada para o seu email cadastrado!\");
      window.location = '../index.php';
      </script>");

  } // fecha else
} // fecha fun��o

?>
 