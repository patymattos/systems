<?
//Conexão ao Banco de dados local
$conexao = mysql_connect("localhost","metaeven_galeria","metawbeventos");
$db = mysql_select_db("metaeven_meta");

$simposio 		= $_POST["simposio"];
$poster			= $_POST["poster"];
$ordem 			= $_POST["ordem"];

if (strlen($simposio) > 0){
	$condicao3 = "WHERE tipo='1' ";
}
if ((strlen($poster) > 0) and (strlen($simposio) > 0)){
	$condicao3 = "";
}elseif (strlen($poster) > 0){
	$condicao3 = "WHERE tipo='0' ";
}

//consulta sql
$SQL 		= "SELECT * FROM trabalhos $condicao3 $ordem";  
$executa 	= mysql_query($SQL)or die(mysql_error());
$num 		= mysql_num_rows($executa);

// definimos o tipo de arquivo
header("Content-type: application/msword");

// Como será gravado o arquivo
header("Content-Disposition: attachment; filename=relatorio_trabalho.doc");

// montando a tabela
echo "<table style='border-top:1px solid #000;'>";
  echo "<tr>
			<td colspan='4' align='left'><b>Trabalhos<br /></b>".date('d-m-Y')."<br /><br /></td>
			<td align='center' colspan='2'><img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' align='center' border='0' width='125' /></td>
		</tr>
</table>
<table border='1'>";
		echo "<tr>";
			  echo "<td align='center' bgcolor='#F2F2F2' width='200'><b>Modalidade:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Eixo Temático:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Avaliador 1:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Avaliador 2:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Avaliador 3:</b></td>";
			  echo "<td align='center' bgcolor='#F2F2F2'><b>Status</b></td>
		</tr>";  
		for($i=0;$i<$num;$i++){
			$rs = mysql_fetch_array($executa);
			if (strlen($rs['check1'])>0){
				$check = "check1";
			}elseif (strlen($rs['check2'])>0){
				$check = "check2";
			}elseif (strlen($rs['check3'])>0){
				$check = "check3";
			}
			if (strlen($rs['autor'])>0){
					  echo "<td align='center' bgcolor='#F2F2F2'><b>Pôster</b></td>";
			}else{
					echo "<td align='center' bgcolor='#F2F2F2'><b>Simpósio Proposto</b></td>";
			}		  
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['check4']."</b></td>";
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['email_avaliador']."</b></td>";
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['email_avaliador2']."</b></td>";
					  echo "<td align='center' bgcolor='#F2F2F2'><b>".$rs['email_avaliador3']."</b></td>";
  					  if($rs['processo']==0)echo "<td align='center' bgcolor='#F2F2F2'><b>Aguardando</b></td>";
					  elseif($rs['processo']==1)echo "<td align='center' bgcolor='#F2F2F2'><b>Em Processo</b></td>";
					  elseif($rs['processo']==2)echo "<td align='center' bgcolor='#F2F2F2'><b>Aprovado</b></td>";
					  elseif($rs['processo']==3)echo "<td align='center' bgcolor='#F2F2F2'><b>Revisar</b></td>";
					  elseif($rs['processo']==4)echo "<td align='center' bgcolor='#F2F2F2'><b>Reprovado</b></td>";
					echo "</tr>";
			
		}
  echo "<tr>
   		  <td colspan='6' bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='center'><br><b> AV. NILO PEÇANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
												TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
		  </td>
		</tr>"; 
		echo "</table>"; 
?>