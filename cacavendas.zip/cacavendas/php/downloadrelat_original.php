<?
//Conexão ao Banco de dados local
$conexao = mysql_connect("localhost","metaeven_galeria","metawbeventos");
$db = mysql_select_db("metaeven_meta");

$dia =date("d");
$mes =date("m");
$ano =date("Y");
$data =$dia."-".$mes."-".$ano;
$tipo				= $_POST['tipo'];
$emailavaliador1 	= $_POST['emailavaliador1'];
$emailavaliador2 	= $_POST['emailavaliador2'];
$emailavaliador3 	= $_POST['emailavaliador3'];
$eixotematico	 	= $_POST['eixotematico'];
$status			 	= $_POST['status'];


$autor			 	= $_POST['autor'];
$autorevento	 	= $_POST['autorevento'];
$coautores		 	= $_POST['coautores'];
$comentario		 	= $_POST['comentario'];
$comentario2	 	= $_POST['comentario2'];
$comentario3	 	= $_POST['comentario3'];
$comentario4	 	= $_POST['comentario4'];
$conteudo		 	= $_POST['conteudo'];
$conteudo1		 	= $_POST['conteudo1'];
$conteudo2		 	= $_POST['conteudo2'];
$conteudo3		 	= $_POST['conteudo3'];
$conteudo4		 	= $_POST['conteudo4'];
$email			 	= $_POST['email'];
$emailavaliadorf1 	= $_POST['emailavaliadorf1'];
$emailavaliadorf2 	= $_POST['emailavaliadorf2'];
$emailavaliadorf3 	= $_POST['emailavaliadorf3'];
$eixotematico2	 	= $_POST['eixotematico2'];
$instrucoes		 	= $_POST['instrucoes'];
$id_evento		 	= $_POST['nome_evento'];
$palestra1		 	= $_POST['palestra1'];
$palestra2		 	= $_POST['palestra2'];
$palestra3		 	= $_POST['palestra3'];
$palestra4		 	= $_POST['palestra4'];
$palestrante1	 	= $_POST['palestrante1'];
$palestrante2	 	= $_POST['palestrante2'];
$palestrante3	 	= $_POST['palestrante3'];
$palestrante4		= $_POST['palestrante4'];
$palavrachave	 	= $_POST['palavrachave'];
$processo		 	= $_POST['processo'];
$tema			 	= $_POST['tema'];
$titulo			 	= $_POST['titulo'];
$ordem				= $_POST['ordem'];
	
if ($tipo == "simposio"){
	$condicao3 = "WHERE tipo='1' ";
}elseif ($tipo == "poster"){
	$condicao3 = "WHERE tipo='0' ";
}		
if (strlen($emailavaliador1) > 0){
	if (strlen($condicao3) > 0){
		$condicao3 .= "AND email_avaliador='$emailavaliador1' ";
	}else{
		$condicao3 = "WHERE email_avaliador='$emailavaliador1' ";
	}
}
if (strlen($emailavaliador2) > 0){
	if ((strlen($condicao3) > 0) || (strlen($emailavaliador1) > 0)){
		$condicao3 .= "AND email_avaliador='$emailavaliador2' ";
	}else{
		$condicao3 = "WHERE email_avaliador='$emailavaliador2' ";
	}
}
if (strlen($emailavaliador3) > 0){
	if ((strlen($condicao3) > 0) || (strlen($emailavaliador1) > 0) || (strlen($emailavaliador2) > 0)){
		$condicao3 .= "AND email_avaliador='$emailavaliador3' ";
	}else{
		$condicao3 = "WHERE email_avaliador='$emailavaliador3' ";
	}
}
if (strlen($eixotematico) > 0){
	if ((strlen($condicao3) > 0) || (strlen($emailavaliador1) > 0) || (strlen($emailavaliador2) > 0) || (strlen($emailavaliador3) > 0)){
		$condicao3 .= "AND check4='$eixotematico' ";
	}else{
		$condicao3 = "WHERE check4='$eixotematico' ";
	}
}
if (strlen($status) > 0){
	if ((strlen($condicao3) > 0) || (strlen($emailavaliador1) > 0) || (strlen($emailavaliador2) > 0) || (strlen($emailavaliador3) > 0) || (strlen($eixotematico) > 0)){
		$condicao3 .= "AND processo='$status' ";
	}else{
		$condicao3 = "WHERE processo='$status' ";
	}
}

$condicao="";
$condicao2="";
if(strlen($tipo)> 0){
  if(strlen($condicao) > 0){
		$condicao .= ", ";
  }
  $condicao .= "tipo";
}
if(strlen($id_evento)> 0){
  if(strlen($condicao) > 0){
		$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
		$condicao2 .= ", ";
  }	
  $condicao .= "id_evento";
  $condicao2 .= "Nome do Evento";
}
if(strlen($autor)> 0){
  if(strlen($condicao) > 0){
		$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){	 		
		$condicao2 .= ", ";
  }	
  $condicao .= "autor";
  $condicao2 .= "Autor";
}
if(strlen($autorevento)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "autorevento";
  $condicao2 .= "Auto Evento";
}
if(strlen($coautores)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "coautores";
  $condicao2 .= "Co-Autores";
}
if(strlen($titulo)> 0){
  if(strlen($condicao) > 0){
		$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
		$condicao2 .= ", ";
  }	
  $condicao .= "titulo";
  $condicao2 .= "T&iacute;tulo";
}
if(strlen($palavrachave)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palavrachave";
  $condicao2 .= "Palavra Chave";
}
if(strlen($conteudo)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "conteudo";
  $condicao2 .= "Conte&uacute;do";
}

if(strlen($palestra1)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestra1";
  $condicao2 .= "Palestra 1";
}
if(strlen($conteudo1)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "conteudo1";
  $condicao2 .= "Conte&uacute;do 1";
}
if(strlen($comentario)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "comentario";
  $condicao2 .= "Coment&aacute;rio";
}
		
if(strlen($palestra2)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestra2";
  $condicao2 .= "Palestra 2";
}
if(strlen($conteudo2)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "conteudo2";
  $condicao2 .= "Conte&uacute;do 2";
}
if(strlen($comentario2)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "comentario2";
  $condicao2 .= "Coment&aacute;rio 2";
}
	
if(strlen($palestra3)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestra3";
  $condicao2 .= "Palestra 3";
}
if(strlen($conteudo3)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "conteudo3";
  $condicao2 .= "Conte&uacute;do 3";
}
if(strlen($comentario3)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "comentario3";
  $condicao2 .= "Coment&aacute;rio 3";
}
		
if(strlen($palestra4)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestra4";
  $condicao2 .= "Palestra 4";
}
if(strlen($conteudo4)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }	
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "conteudo4";
  $condicao2 .= "Conte&uacute;do 4";
}
if(strlen($comentario4)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "comentario4";
  $condicao2 .= "Coment&aacute;rio 4";
}
if(strlen($email)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "email";
  $condicao2 .= "Email";
}
if(strlen($emailavaliadorf1)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "email_avaliador";
  $condicao2 .= "Email Avaliador 1";
}
if(strlen($emailavaliadorf2)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "email_avaliador2";
  $condicao2 .= "Email Avaliador 2";
}
if(strlen($emailavaliadorf3)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "email_avaliador3";
  $condicao2 .= "Email Avaliador 3";
}
if(strlen($eixotematico2)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "check4";
  $condicao2 .= "Eixo Tem&aacute;tico";
}
if(strlen($instrucoes)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "instrucoes";
  $condicao2 .= "Instru&ccedil;&otilde;es";
}

if(strlen($palestrante1)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestrante1";
  $condicao2 .= "Palestrante 1";
}  
if(strlen($palestrante2)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestrante2";
  $condicao2 .= "Palestrante 2";
}
if(strlen($palestrante3)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestrante3";
  $condicao2 .= "Palestrante 3";
}
if(strlen($palestrante4)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "palestrante4";
  $condicao2 .= "Palestrante 4";
}
if(strlen($processo)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "processo";
  $condicao2 .= "Status";
}
if(strlen($tema)> 0){
  if(strlen($condicao) > 0){
	$condicao .= ", ";
  }
  if(strlen($condicao2) > 0){
	$condicao2 .= ", ";
  }	
  $condicao .= "temasimposio";
  $condicao2 .= "Tema Simp&oacute;sio";
}
//consulta sql
$SQL 		= "SELECT $condicao FROM trabalhos $condicao3 $ordem";  
//echo $SQL;
//exit();
$executa 	= mysql_query($SQL)or die(mysql_error());
$num 		= mysql_num_rows($executa);
$condicao2 = explode(",",$condicao2);
$count = count($condicao2);
$width = ($count + 1) * 150;
// definimos o tipo de arquivo
header("Content-type: application/msexcel");

// Como será gravado o arquivo
header("Content-Disposition: attachment; filename=relatorio_trabalhos.xls");

echo "<table border='0' width=".$width." cellspacing='1' bgcolor='#000000' height='100'>
		<tr>
		  <td bgcolor='#F2F2F2' colspan=".$count." align='left'><b>TRABALHOS</b><br />";
		  echo "".$data."</td>";
		  echo "<td bgcolor='#F2F2F2'  align='right'><img src='https://www.metaeventos.net/site/adm/images/logo.png' alt='' border='0' width='125'></td>
		</tr>
</table>";
echo "<table border='1' width=".$width." cellspacing='1' bgcolor='#000000'>
	    <tr>";
			echo "<td bgcolor='#F2F2F2' align='left' valign='top'><b>Modalidade</b></td>";
			for ($i = 0; $i < $count; $i++) {
				echo "<td align='center' bgcolor='#F2F2F2'><b>".$condicao2[$i]."</b></td>";
			}	
		echo "</tr>";
		  while ($rs = mysql_fetch_array($executa)){
			//consulta tabela usuarios
			$usu 		= "SELECT * FROM eventos where id='".$id_evento."'";  
			$executausu = mysql_query($usu)or die(mysql_error());
			$fetch		= mysql_fetch_array($executausu);

			//echo "<td align='left' style='font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif;' bgcolor='#F2F2F2'>" . $i . "</td>";
			echo "<tr>";
				if ($rs['tipo'] == 0){
echo "<td bgcolor='#F2F2F2' align='center' valign='top' width='150'>P&ocirc;ster</td>";
				}else{
echo "<td align='center' bgcolor='#F2F2F2' valign='top' width='150'>Simp&oacute;sio Proposto</td>";
				}
				if(strlen($id_evento) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $fetch['nome_evento']. "</td>";
				}
				if (strlen($autor) > 0){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>".$rs['autor']."</td>";
				}
				if(strlen($autorevento) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' width='150' bgcolor='#F2F2F2' valign='top'>" . $rs['autorevento'] . "</td>";
				}
				if(strlen($coautores) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' align='left' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['coautores'] . "</td>";
				}
				if(strlen($titulo) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' width='150' align='left' bgcolor='#F2F2F2' valign='top'>" . $rs['titulo'] . "</td>";
				}
				if(strlen($palavrachave) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palavrachave'] . "</td>";
				}
				if(strlen($conteudo) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo'] . "</td>";
				}
				if(strlen($palestra1) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra1'] . "</td>";
				}
				if(strlen($conteudo1) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo1'] . "</td>";
				}
				if(strlen($comentario) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario'] . "</td>";
				}
				if(strlen($palestra2) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra2'] . "</td>";
				}
				if(strlen($conteudo2) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo2'] . "</td>";
				}
				if(strlen($comentario2) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario2'] . "</td>";
				}
				if(strlen($palestra3) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra3'] . "</td>";
				}
				if(strlen($conteudo3) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo3'] . "</td>";
				}
				if(strlen($comentario3) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario3'] . "</td>";
				}
				if(strlen($palestra4) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestra4'] . "</td>";
				}
				if(strlen($conteudo4) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['conteudo4'] . "</td>";
				}
				if(strlen($comentario4) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['comentario4'] . "</td>";
				}
				if(strlen($email) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email'] . "</td>";
				}
				if(strlen($emailavaliadorf1) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email_avaliador'] . "</td>";
				}
				if(strlen($emailavaliadorf2) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email_avaliador2'] . "</td>";
				}
				if(strlen($emailavaliadorf3) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['email_avaliador3'] . "</td>";
				}
				if(strlen($eixotematico2) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['check4'] . "</td>";
				}
				if(strlen($instrucoes) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' align='left' width='150' bgcolor='#F2F2F2' valign='top'>" . $rs['instrucoes'] . "</td>";
				}
				if(strlen($palestrante1) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante1'] . "</td>";
				}
	
				if(strlen($palestrante2) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante2'] . "</td>";
				}
		
				if(strlen($palestrante3) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante3'] . "</td>";
				}
		
				if(strlen($palestrante4) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['palestrante4'] . "</td>";
				}
				if (strlen($processo) > 0){
					  if($rs['processo']==0){
						   echo "<td align='left' bgcolor='#F2F2F2' valign='top'  width='70'><b>Aguardando</b></td>";
					  }elseif($rs['processo']==1){
						   echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><b><img src='https://www.metaeventos.net/inscricoes/imagem/ampulheta.gif' border='0' /></b></td>";
					  }elseif($rs['processo']==2){
						   echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><b><img src='https://www.metaeventos.net/inscricoes/imagem/tick.png' border='0' /></b></td>";
					  }elseif($rs['processo']==3){
						   echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><b><img src='https://www.metaeventos.net/inscricoes/imagem/revisar.gif' border='0' /></b></td>";
					  }elseif($rs['processo']==4){
						   echo "<td align='left' bgcolor='#F2F2F2' valign='top' width='70'><b><img src='https://www.metaeventos.net/inscricoes/imagem/ico_excluir.jpg' border='0' /></b></td>";
					  }
				 }
				if(strlen($tema) >0 ){
echo "<td align='left' style='font-size:10px; font-family:Verdana;text-align:justify;' bgcolor='#F2F2F2' valign='top' width='150'>" . $rs['temasimposio'] . "</td>";
				}
				echo "</tr>";
		  }
		  echo "<tr>
				  <td colspan=".($count + 1)." bgcolor='#F2F2F2' style='font-size:12px; font-family:Verdana, Arial, Helvetica, sans-serif;' align='left'><br><b> AV. NILO PEÇANHA, 50 GR 1.610 CENTRO - RIO DE JANEIRO - RJ CEP:20.044-900 BRASIL<br>
																TELS.: 2220-2097 - FAX.:(55 21) 2220-2305</b><br>
				  </td>
		</tr>  
</table> ";
?>