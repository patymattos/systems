<?php
include ("config.php");

############# EVENTOS ############################
$select_ev = "SELECT * FROM eventos WHERE ativo=1 ORDER BY data_evento_inicio DESC";
$sql_ev = mysql_query($select_ev);
$rows_ev = mysql_num_rows($sql_ev);

##################################################
?>

<table width="550" border="0" cellpadding="1" cellspacing="1" class="cor_tr">
  <form action="etiquetas.php" method="post" name="form">
      <input type="hidden" name="evento2" value="<?=$tipo_evento;?>" />
    <tr>
        <td class='titulo' colspan="4">:: Gerar Etiquetas de Participantes ::</td>
    </tr>
    <tr><td class="texto" align="center" colspan="2"><p><strong>Escolha os Filtros:</strong></p></td></tr>
    <tr>
        <td class='texto' width='347'><b>Evento</b></td>
  		<td width="196" class='texto'>
	    <select name="evento" size="1" class="texto" onChange="javascript:Atualiza();">
        	 <?php
			   if (strlen($tipo_evento) < 1){
            	echo '<option value="">---Escolha um Evento---</option>';
			   }else{
				echo '<option value="">'.substr($tipo_evento,0,50).'</option>';
			   }
			
				for ($i=0;$i<$rows_ev;$i++){
        			$event = mysql_fetch_array($sql_ev);

					echo '<option value="'.$event['nome_evento'].'">'.substr ($event['nome_evento'],0,50).'</option>';

				}
			?>
        </select>
	  	</td>
  	</tr>
    <tr>
    	<td class="texto" align="center" colspan="2"><p><strong>Selecione o(s) campo(s) para conter na etiqueta:<br />N�o colocar mais do que 4 campos.</strong></p></td>
    </tr>
	<tr>
    	<td width='347' class='texto'  colspan="4">
        	<?
//include("config.php");
	
$n_evento = $_GET['evento'];
######################################################### id = 1 sem selecionar todos ###############################################################################
if ($n_evento == "XIV International Conference on Strangeness in Quark Matter"){
    echo "<table border='0' width='350'>
		  <tr>
        	<td width='347' class='texto'>Client Code</td>
	  	 	<td class='texto'><input type='checkbox' name='id2' value='id' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'>Title</td>
	   	    <td class='texto'><input type='checkbox' name='title2' value='title' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family Name </td>
	   	    <td class='texto'><input type='checkbox' name='familyname2' value='familyname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Given Name </td>
	   	    <td class='texto'><input type='checkbox' name='givenname2' value='givenname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Name to the Bagde </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Affiliation </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Mailing Adress </td>
	   	    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
		  <tr>
	        <td width='347' class='texto'> City </td>
   		    <td class='texto'><input type='checkbox' name='city2' value='city' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Province State </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Country </td>
	        <td class='texto'><input type='checkbox' name='country2' value='country' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Zip Code </td>
	        <td class='texto'><input type='checkbox' name='zipcode2' value='zipcode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Email </td>
		    <td class='texto'><input type='checkbox' name='email2' value='email' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Phone </td>
	        <td class='texto'><input type='checkbox' name='phone2' value='phone' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Fax </td>
	        <td class='texto'><input type='checkbox' name='fax2' value='fax' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
		</table>";
######################################################### id = 406  ###############################################################################
}elseif ($n_evento == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){
    echo "<table border='0' width='350'>
	      <tr>
	        <td class='texto' width='347'> Nome para crach� </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Institui��o </td>
	   	    <td class='texto'><input type='checkbox' name='instituicao2' value='instituicao' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Especialidade </td>
	   	    <td class='texto'><input type='checkbox' name='especialidade2' value='especialidade' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Estado </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
		</table>";
######################################################### id = 4  ###############################################################################
}elseif ($n_evento == "30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE"){
    echo "<table border='0' width='350'>
	      <tr>
	        <td class='texto' width='347'>Title</td>
	   	    <td class='texto'><input type='checkbox' name='title2' value='title' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Name to the Bagde </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Affiliation </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Mailing Adress </td>
	   	    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Province State </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Country </td>
	        <td class='texto'><input type='checkbox' name='country2' value='country' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
		</table>";
#####################################################################################################################################################################
}else{
    echo "<table border='0' width='350'>
		  <tr>
        	<td width='347' class='texto'>Client Code</td>
	  	 	<td class='texto'><input type='checkbox' name='id2' value='id' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'>Title</td>
	   	    <td class='texto'><input type='checkbox' name='title2' value='title' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family Name </td>
	   	    <td class='texto'><input type='checkbox' name='familyname2' value='familyname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Middle Name </td>
	   	    <td class='texto'><input type='checkbox' name='givenname2' value='givenname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family </td>
	   	    <td class='texto'><input type='checkbox' name='family2' value='family' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Name to the Bagde </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Affiliation </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Institui��o </td>
	   	    <td class='texto'><input type='checkbox' name='instituicao2' value='instituicao'/></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> CPF </td>
	   	    <td class='texto'><input type='checkbox' name='cpf2' value='cpf' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Identidade </td>
	   	    <td class='texto'><input type='checkbox' name='identidade2' value='identidade' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Mailing Adress </td>
	   	    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
		  <tr>
	        <td width='347' class='texto'> City </td>
   		    <td class='texto'><input type='checkbox' name='city2' value='city' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Province State </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Country </td>
	        <td class='texto'><input type='checkbox' name='country2' value='country' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Zip Code </td>
	        <td class='texto'><input type='checkbox' name='zipcode2' value='zipcode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Email </td>
		    <td class='texto'><input type='checkbox' name='email2' value='email' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Especialidade </td>
	   	    <td class='texto'><input type='checkbox' name='especialidade2' value='especialidade' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Phone </td>
	        <td class='texto'><input type='checkbox' name='phone2' value='phone' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Fax </td>
	        <td class='texto'><input type='checkbox' name='fax2' value='fax' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
		</table>";
}
?>
        </td>
    </tr>
    <tr><td class="texto" align="center" colspan="2">&nbsp;</td></tr>
    <tr>
    	<td align="center" colspan="2"><input type="submit" value="Gerar Etiquetas" /></td>
    </tr>
  </form>  
</table>
