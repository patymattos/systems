<?
$email = $_GET["email"];
include("php/config.php");
mysql_query("DELETE FROM n_emails WHERE email = '$email'");
echo "<script>location.href='adm_newsletter.php'</script>";

?>
