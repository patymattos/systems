<link rel="stylesheet" type="text/css" href="css/sddm.css" >



<div class="navbar">
<br>
<!-- *********************************Start Menu****************************** -->

<div class="mainDiv" >

<div class="topItem" >PR�-VENDAS</div>        

<div class="dropMenu" ><!-- -->

	<div class="subMenu" style="display:none;">

         <div class="subItem"><a href="vendas.php">Or�amento</a></div>
         <div class="subItem"><a href="estoque_produtos.php">Estoque de Produtos</a></div>
         <div class="subItem"><a href="estoque_servicos.php">Estoque de Servi�o</a></div>

      
	</div>

</div>

</div>

<script type="text/javascript" src="js/xpmenuv21.js"></script>

</div>

<br />