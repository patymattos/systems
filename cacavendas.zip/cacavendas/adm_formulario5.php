<?php
session_start();
include"php/config.php";
	$resultado = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
	$xx = mysql_fetch_array($resultado);
	$tipo=$_GET['tipo'];
	$nome2=$_GET['nome'];
	$id_evento  = $xx['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<title>-= Meta Marketing e Eventos =-</title>
	<script type="text/javascript" src="js/funcoes.js"></script>
  <script language="javascript">
	function selecao() {
	  tipo=document.form.tipo.value;
	  if ((tipo == 'select') || (tipo == 'radio') || (tipo == 'checkbox') || (tipo == 'text') || (tipo == 'password')){
      location.href='adm_formulario2.php?tipo='+tipo;
	  }else
	  	if (tipo == 'tabela') {
		location.href='adm_formulario5.php?tipo='+tipo;
	  }	
    }
  </script>
  <script language="javascript">
	function selecao2() {
	  nome=document.form.tipo2.value;
	  selecao()
      location.href='adm_formulario5.php?tipo='+tipo+'&nome='+nome;
    }
  </script>    
</head>
<body>

<?php include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><?php include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>
		 <form action="adm_formulario55.php" method="post" name="form">
	 	  <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
	       <tr>
    	      <td align="center" bgcolor="#FFFFFF" colspan="2">
				<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" />
          	  </td>
	       </tr>
	       <tr>
              <?php
			  //se algum input tiver sido selecionado, ele aumentar� o tamanho da parte da tabela
				if($nome2!= ""){
    	          	echo '<td align="center" class="titulo" colspan="3">:: Alterar Participante ::</td>';
		     //sen�o houver nenhum, ele n�o altera o tamanho
				 }else{
          	  		echo '<td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>';
				 }	
				 ?>
           </tr>
		   <tr>
 			  <td width="296"> Escolha o tipo:</td>
	 		  <td width="505">
               <select name="tipo">
    	   	   <?php
			   //verifica se o tipo foi selecionado e mostrar� o tipo no option
				if($tipo != ""){
				  echo '<option value="'.$tipo.'">'.$tipo.'<br>';
				}else{  
			  	  echo '<option value="">-= Selecione o tipo do campo =-</option><br>';
				}
			   ?>
			  	<option value="text">text</option>
	    		<option value="password">password</option>
		    	<option value="radio">Radio</option>
		    	<option value="checkbox">Checkbox</option>
    			<option value="select">Select</option>
                <option value="tabela">Tabela</option>
			   </select>
			  </td>
              <?php
			    //se algum input tiver sido selecionado, ele mostrar� os campos para alterar e excluir
				if($nome2!= ""){
    	          echo '<td align="center">Excluir</td>';
				 }
			  ?> 
		   </tr>

		    <?php
		  	//se a verifica��o do tipo do select j� tiver sido escolhida ele verificar� se o nome do select j� foi escolhido tamb�m
 	  		if($nome2 != ""){
	  			$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo' AND nome='$nome2'");
				$x 	= mysql_fetch_array($sql);
				$nome3= $x['nome'];
	    		$num=mysql_num_rows($sql);
		    }else{  
		  		$sql   = mysql_query("SELECT * FROM formulario WHERE id_evento='$id_evento' AND tipo='$tipo'");	
	   	  	    $num2=mysql_num_rows($sql);
		  	}
			//Se o tipo tiver sido selecionado e for diferente de texto e senha, ele mostrar� os resultados
			if(($num2 != 0) or ($num != 0)){
			  echo '<tr>';
				echo '<td width="505">Select(s) j� criado(s):</td>';
                echo '<td ><select name="tipo2" onblur="selecao2()" onchange="selecao2()">';
					if($nome3!= ""){
   	 					echo '<option value="'.$nome3.'">'.$nome3.'';
					}else{  
						echo '<option value="">-= Selecione o tipo do campo =-</option>';
					}
					// faz um loop para pegar todos os atributos da array nome do select/radio/checkbox selecionado
					while ($fetch = mysql_fetch_array($sql)){
						$nome = $fetch['nome'];
		    			echo '<option value="'.$nome.'">'.$nome.'</option>';
					}
			    echo '</select>';
				//se o nome do input tiver sido selecionado, ele mostrar� os campos para editar e excluir
					if($nome3!= ""){
				echo '</td>';
				echo '<td align="center">';
   	 				echo "<a href='php/excluir_input.php?id=$nome3'><img src='images/ico_excluir.jpg' border='0'/></a>";
				echo '</td>';
					}else{
				echo '</td>';
				}					
			  echo '</tr>';


			}

	 		//se o resultado for diferente de zero, aparecer� o select com o nome desejado
			if($num != 0){
			  echo '<tr>';
			  	echo '<td width="505">Qual o T�tulo dessa tabela?</td>';
				echo '<td colspan="2"><input type="text" name="titulo_tabela" size="40">';
					echo '<select name=negrito_titulo>';
						echo '<option value=" ">-= =-</option>';
						echo '<option value="negrito">Negrito</option>';
						echo '<option value="italico">It�lico</option>';
					echo '</select>';
					echo '<select name=alinhamento_titulo>';
						echo '<option value="left">Esquerda</option>';
						echo '<option value="center">Centro</option>';
						echo '<option value="right">Direita</option>';
					echo '</select>';
				echo '</td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Fonte:</td>';
				echo '<td colspan="2"><input type="text" name="fonte_titulo" size="40" value="verdana"/></td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Tamanho da fonte:</td>';
				echo '<td colspan="2"><input type="text" name="tamanho_fonte_titulo" size="40" value="10"/></td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Tamanho da tabela:</td>';
				echo '<td colspan="2"><input type="text" name="tamanho_tabela" size="3" value="100%"/> Pode ser em pixel(100 px) ou porcentagem(100%)</td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Cor da tabela:</td>';
				echo '<td colspan="2"><input type="text" name="cor_tabela" size="10"/> Ex.: Digite a cor pelo c�digo(#000000) ou pelo nome(black)</td>';
			  echo '</tr>';
			  echo '<tr>';
			  	echo '<td width="505">Quantas colunas ter� essa tabela?</td>';
				echo '<td colspan="2"><input type="text" name="colunas_tabela" size="3" value="1">';
				echo '</td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Quantas linhas ter� essa tabela?</td>';
				echo '<td colspan="2"><input type="text" name="linhas_tabela" size="3" value="1"/></td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Tamanho da borda:</td>';
				echo '<td colspan="2"><input type="text" name="borda_tabela" size="3" value="1"/></td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Cor da borda:</td>';
				echo '<td colspan="2"><input type="text" name="cor_borda_tabela" value="" size="10"/> Ex.: Digite a cor pelo c�digo(#000000) ou pelo nome(black)</td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Cor da c�dula da tabela:</td>';
				echo '<td colspan="2"><input type="text" name="cor_cedula" size="10"/> Ex.: Digite a cor pelo c�digo(#000000) ou pelo nome(black)</td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Cellspacing:</td>';
				echo '<td colspan="2"><input type="text" name="cellspacing" size="3" value="0"/> Espa�amento entre as c�lulas (Borda)</td>';
			  echo '</tr>';
			  echo '<tr>';	
				echo '<td>Cellpadding:</td>';
				echo '<td colspan="2"><input type="text" name="cellpadding" size="3" value="0"/>Define dist�ncia entre o texto e a borda das c�lulas</td>';
			  echo '</tr>';

		    }

		    if($nome2 == ""){
				echo '<tr>';
				 echo '<td width="505">Escreva o nome do novo campo:</td>';
				 echo '<td><input type="text" name="nome_input" /> </td>';
				echo '</tr>';
		   }
		  ?>
		</table>
        <input type="hidden" name="id" value="<?=$id_evento;?>" />
       </form>
      </td>
     </tr>
  <tr>
   <td>
   		<a href="javascript:history.go(-1)">Voltar</a>
   </td>
  </tr>
    </table>
   </td>
  </tr>
 </table> 
<? 
include_once "inc_rodape.php";
echo '</body>';
echo '</html>';

?>