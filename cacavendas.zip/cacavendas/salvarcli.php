<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	$CL_COD =$_POST['C_COD'];
	
	$CL_DATA =$_POST['C_DATA'];

	$CL_NOME =$_POST['C_NOME'];

	$CL_CC =$_POST['C_CC'];

	$CL_RG =$_POST['C_RG'];

	
	$CL_END =$_POST['C_END'];
  	
	$CL_CIDADE =$_POST['C_CIDADE'];
	
	$CL_ESTADO =$_POST['C_ESTADO'];
	
	$CL_CEP =$_POST['C_CEP'];
	 	
	$CL_EMAIL =$_POST['C_EMAIL'];

	$CL_TEL =$_POST['C_TEL'];

	$CL_CEL =$_POST['C_CEL'];
 	


	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO clientes (CLI_ID,CLI_COD,CLI_DATA,CLI_NOME,CLI_CC,CLI_RG,CLI_END,CLI_CIDADE,CLI_ESTADO,CLI_CEP,CLI_EMAIL, CLI_TEL,CLI_CEL )
	VALUES ('','$CL_COD','$CL_DATA','$CL_NOME','$CL_CC','$CL_RG','$CL_END','$CL_CIDADE','$CL_ESTADO','$CL_CEP','$CL_EMAIL','$CL_TEL','$CL_CEL')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_cli.php");



?>	

 