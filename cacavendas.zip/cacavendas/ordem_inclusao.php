<?php
session_start();
include ("php/valida_sessao.php");
include"php/config.php";
	$resultado = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$_SESSION['nome_eventos']."'");
	$xx = mysql_fetch_array($resultado);
	$id_evento  = $xx['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
	<title>-= Meta Marketing e Eventos =-</title>
</head>
<body>

<?php include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><?php include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>
		 <form action="php/inc_ordem_inclusao.php" method="post" name="form">
	 	  <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
	       <tr>
    	      <td align="center" bgcolor="#FFFFFF" colspan="2">
              	<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" />
          	  </td>
	       </tr>
	       <tr>
      	  		<td align="center" class="titulo" colspan="3">:: Ordem de Inclus�o ::</td>
           </tr>
		   <tr>
 			  <td width="500" align="center" colspan="2"> 
			  </td>
		   </tr>

		    <?php
			$ordem_form		= mysql_query("SELECT * FROM ordem_formulario WHERE id_evento='$id_evento'")or die(mysql_query()); 
			$fetch_ordem	= mysql_fetch_array($ordem_form);
			$ordem			= $fetch_ordem['ordem'];
			echo '<tr>
 			  		<td width="500" align="center" colspan="3">';
					if ($ordem != ""){
						echo ' Ordem de Cadastro do Formul�rio: <textarea name="ordem" cols="70" rows="15">'.$ordem.'</textarea>';
					}else{
						echo 'N�o h� nenhuma ordem cadastrada';
					}	
			  		echo '</td>';
		    echo '</td>';
      		echo '</tr>';
			?>
		</table>
        <input type="hidden" name="id" value="<?=$id_evento;?>" />
       </form>
      </td>
     </tr>
  <tr>
   <td>
   		<a href="javascript:history.go(-1)">Voltar</a>
   </td>
  </tr>
    </table>
   </td>
  </tr>
 </table> 
<? 
include_once "inc_rodape.php";
echo '</body>';
echo '</html>';

?>