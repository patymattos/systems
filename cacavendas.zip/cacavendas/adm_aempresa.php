<?
session_start();
include ("php/valida_sessao.php");
include ("php/config.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
<script type="text/javascript" src="js/funcoes.js"></script>
<script type="text/javascript" src="js/fckeditor.js"></script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

</head>


<body>
<? include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578">
	<form action="php/inc_cad_aempresa.php" method="post" enctype="multipart/form-data" name="frm" id="frm">
	<table width="570" border="0" align="center">
      <tr>
        <td>A Empresa</td>
      </tr>
	  <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF">
		<input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
      <tr>
        <td>
		<?		
		include ("js/fckeditor.php");
		$oFCKeditor = new fckeditor('aempresa', 530, 350);
		$oFCKeditor->Width  = '100%' ;
		$oFCKeditor->Height = '400' ;
		$oFCKeditor->BasePath = 'js/';
		$oFCKeditor->ToolbarSet = 'Default' ;

		$y = mysql_query("SELECT * FROM site WHERE id= 1");
		while($x = mysql_fetch_array($y))
		{
		$id	= $x["id"];
		$aempresa	= $x["aempresa"];
		
		$oFCKeditor->Value = "$aempresa";
		}
		$oFCKeditor->Create();
		?>
        <input type="hidden" value="<?=$id?>" name="id" />
		</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
	</form>
	</td>
  </tr>
</table>
<? include_once "inc_rodape.php"; ?>
</body>
</html>
