<?php
include_once "php/config.php";
$id_pedido = $_GET['pe'];

$sql	= "DELETE FROM vendas_direta WHERE id ='$id_pedido' ";
$resultado = mysql_query($sql);

echo "<script>location.href='cad_pagamentos.php';</script>";
?>