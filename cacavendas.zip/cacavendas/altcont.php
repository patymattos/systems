<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
-->
</style>
<form name="alterarfor" action="alt_conta.php" method="post">
          <table width="564" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td colspan="2"><table width="396" border="0" align="right">
                <tr>
                  
                </tr>
              </table></td>
            </tr>
            <tr>
              <td width="154"><span class="style4">Data:</span></td>
              <td width="390"><input name="CO_DATA" <?=$P_DATA?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Refer�ncia: </span></td>
              <td><input name="CO_REF" <?=$P_REF?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Nome:</span></td>
              <td><input name="CO_NOME" type="text"  size="65" <?=$P_NOME?>></td>
            </tr>
            <tr>
              <td><span class="style4">Valor:</span></td>
              <td><input name="CO_VALOR" type="text" size="65" <?=$P_VALOR?>></td>
            </tr>
            <tr>
              <td><span class="style4">Banco:</span></td>
              <td><input name="CO_BANCO" type="text" size="65" <?=$P_BANCO?> /></td>
            </tr>
            <tr>
              <td><span class="style4">N Cheque:</span></td>
              <td><input name="CO_CHEQUE" type="text" size="65" <?=$P_CHEQUE?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Status:</span></td>
              <td><input name="CO_STATUS" type="text" size="65" <?=$P_STATUS?> /></td>
            </tr>
            <tr>
              <td><span class="style4">Observa��o:</span></td>
              <td><input name="CO_OBS" type="text" size="65" <?=$P_OBS?> /></td>
            </tr>
                       <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br><input type="hidden" name="id_produto" value="<?=$cont?>">

                                  <input name="enviar" type="image" img src="images/ico_salvar.jpg" value="enviar" border="0">

                      </div></td>

                    </tr>
  </table>
</form>
</body>
</html>