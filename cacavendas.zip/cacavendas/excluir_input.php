<?php
session_start();
include ("php/valida_sessao.php");
include ("config.php");
$id		= $_GET['id'];
$sql	= "
			DELETE FROM formulario
			WHERE nome='$id'
		  ";
$resultado = mysql_query($sql);

Header("Location: ../teste2.php");

?>