<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
 <link rel="stylesheet" type="text/css" href="css/formulario.css" />
 <link rel="stylesheet" type="text/css" href="css/layout.css" />
<link href="estilo.css" rel="stylesheet" type="text/css">
<script src="AC_RunActiveContent.js" type="text/javascript"></script> 
 <title>Meta Marketing - Calendário de Eventos</title>
</head>
<body  style=" margin: 0; padding:0; ">

<?php
include "php/config.php";

$conta = 152;
for($i=135;$i<$conta;$i++) { // Gera um loop com o destaque para as páginas

		$descricao = 'História em Fotos';
 	    $select = "UPDATE galeria SET descricao = '".$descricao."' WHERE id = '$i'";
		$sql = mysql_query($select) or die (mysql_error());
}

echo "dados inseridos";

?>
</body>
</html>