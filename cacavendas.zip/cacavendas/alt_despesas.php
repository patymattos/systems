<?php

header('Content-Type: text/html; charset=utf-8');

include_once "php/config.php";



$id_serv = $_POST['id_serv'];



$DS_TIPO 	= $_POST['D_TIPO'];

$DS_DATA	= $_POST['D_DATA'];

$DS_MOTIVO 	= $_POST['D_MOTIVO'];

$DS_VALOR 	= $_POST['D_VALOR'];

$DS_DIM 	= $_POST['D_DIM'];

$DS_CHEQ 	= $_POST['D_CHEQ'];




if($DS_TIPO != "" && $DS_DATA != "" && $DS_MOTIVO != "" && $DS_VALOR != "" && $DS_DIM != "" && $DS_CHEQ != ""){

	$up = "UPDATE despesas SET

	DV_TIPO	='$DS_TIPO',

	DV_DATA	='$DS_DATA',

	DV_MOTIVO	='$DS_MOTIVO',

	DV_VALOR	='$DS_VALOR',
	
	DV_DINHEIRO	='$DS_DIM',

	DV_CHEQUE	='$DS_CHEQ'

	WHERE DV_ID= '$id_serv'";

	$cad = mysql_query($up);

	

	echo "<script>alert('Despesa alterado com sucesso');location.href='alterar_despesas.php?tr=$id_serv'; </script>";

}

else{

	echo "<script>alert('Verifique se um dos campos abaixo não foi definido:\\n - Tipo\\n - Data\\n - Motivo\\n - Valor\\n');location.href='javascript:window.history.go(-1)'; </script>";

	exit();

}

?>