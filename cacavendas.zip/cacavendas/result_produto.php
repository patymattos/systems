<?
	include("..php/config.php");
	
	$fabi = $_GET['evento'];

  if ($fabi == "XIV International Conference on Strangeness in Quark Matter"){

   	Header("Content-type: application/xml; charset=iso-8859-1");
    echo "<table border='0' width='350'>
		  <tr>
        	<td width='347' class='texto'>Client Code</td>
	  	 	<td class='texto'><input type='checkbox' name='id2' value='id' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'>Title</td>
	   	    <td class='texto'><input type='checkbox' name='title2' value='title' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family Name </td>
	   	    <td class='texto'><input type='checkbox' name='familyname2' value='familyname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Given Name </td>
	   	    <td class='texto'><input type='checkbox' name='givenname2' value='givenname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Name to the Bagde </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Affiliation </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Mailing Adress </td>
	   	    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
		  <tr>
	        <td width='347' class='texto'> City </td>
   		    <td class='texto'><input type='checkbox' name='city2' value='city' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Province State </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Country </td>
	        <td class='texto'><input type='checkbox' name='country2' value='country' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Zip Code </td>
	        <td class='texto'><input type='checkbox' name='zipcode2' value='zipcode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Email </td>
		    <td class='texto'><input type='checkbox' name='email2' value='email' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Phone </td>
	        <td class='texto'><input type='checkbox' name='phone2' value='phone' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Fax </td>
	        <td class='texto'><input type='checkbox' name='fax2' value='fax' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Accompanying Person </td>
	        <td class='texto'><input type='checkbox' name='accompanyingperson2' value='accompanyingperson' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Letter </td>
	        <td class='texto'><input type='checkbox' name='letter2' value='letter' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Packages:</b></td>
		  </tr>
	      <tr>
      	    <td width='347' class='texto'> Profissional </td>
	        <td class='texto'><input type='checkbox' name='profissional2' value='profissional' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Student </td>
	        <td class='texto'><input type='checkbox' name='student2' value='student' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Accompanying Person </td>
	        <td class='texto'><input type='checkbox' name='accompanyingperson3' value='accompanyingperson2' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Methods of payment:</b></td>
		  </tr>
    	  <tr>
	        <td width='347' class='texto'> Payment Methods </td>
   		    <td class='texto'><input type='checkbox' name='formpagamento2' value='formpagamento' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Card </td>
   		    <td class='texto'><input type='checkbox' name='cartao2' value='cartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Name Card </td>
   		    <td class='texto'><input type='checkbox' name='namecredit2' value='namecredit' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Date of the Registration </td>
   		    <td class='texto'><input type='checkbox' name='datacartao2' value='datacartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Number Card </td>
   		    <td class='texto'><input type='checkbox' name='numcredit2' value='numcredit' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Expiration Date </td>
   		    <td class='texto'><input type='checkbox' name='expiracartao2' value='expiracartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Security Code </td>
   		    <td class='texto'><input type='checkbox' name='securitycode2' value='securitycode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Total </td>
	        <td class='texto'><input type='checkbox' name='totalescolhido2' value='totalescolhido' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
	      <tr>
      		  <td width='347' class='texto'><strong>Ordenado por:</strong></td>
			  <td class='texto'>
      			<select name='ordem' size='1' class='texto'>
            		<option value=''>---Escolha---</option>
	                <option value='id'>Client Code</option>
        	        <option value='title'>Title</option>
            	    <option value='familyname'>Family Name</option>
                	<option value='givenname'>Given Name</option>

	                <option value='nametothebagde'>Name to the Bagde</option>
    	            <option value='affiliation'>Affiliation</option>
        	        <option value='mailingadress'>Mailing Adress</option>
            	    <option value='city'>City</option>
                	<option value='provincestate'>Province State</option>					

	                <option value='country '>Country</option>
    	            <option value='zipcode'>Zip Code</option>
        	        <option value='email'>Email</option>
            	    <option value='phone'>Phone</option>
                	<option value='fax'>Fax</option>
					
	                <option value='accompanyingperson'>Accompanying Person</option>
    	            <option value='letter'>Letter</option>
	   	            <option value='' disabled='disabled'>Packages:</option>
        	        <option value='profissional'>Profissional</option>
            	    <option value='student'>Student</option>
                	<option value='accompanyingperson2'>Accompanying Person</option>
					
	   	            <option value='' disabled='disabled'>Payment Methods:</option>
	                <option value='formpagamento'>Payment Methods</option>
    	            <option value='cartao'>Card</option>
        	        <option value='namecredit'>Name Card</option>
            	    <option value='datacartao'>Date of the Registration</option>
                	<option value='numcredit'>Number Card</option>
					
	                <option value='expiracartao'>Expiration Date</option>
    	            <option value='securitycode'>Security Code</option>
        	        <option value='totalescolhido'>Total</option>
	            </select>
    	    </td>
	      </tr>
		</table>";
}elseif ($fabi == "V Congresso de Geriatria e Gerontologia do Rio de Janeiro"){

    Header("Content-type: application/xml; charset=iso-8859-1");
    echo "<table border='0' width='350'>
		  <tr>
        	<td width='347' class='texto'>C�digo do Cliente</td>
	  	 	<td class='texto'><input type='checkbox' name='id2' value='id' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'>Nome completo</td>
	   	    <td class='texto'><input type='checkbox' name='familyname2' value='familyname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Nome para crach� </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Institui��o </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Especialidade </td>
	   	    <td class='texto'><input type='checkbox' name='especialidade2' value='especialidade' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> CPF </td>
	   	    <td class='texto'><input type='checkbox' name='cpf2' value='cpf' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Identidade </td>
	   	    <td class='texto'><input type='checkbox' name='identidade2' value='identidade' /></td>
	      </tr>
		  <tr>
	        <td width='347' class='texto'> Endere�o </td>
   		    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> CEP </td>
	        <td class='texto'><input type='checkbox' name='zipcode2' value='zipcode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Cidade </td>
	        <td class='texto'><input type='checkbox' name='city2' value='city' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Estado </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Telefone </td>
		    <td class='texto'><input type='checkbox' name='phone2' value='phone' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Celular </td>
	        <td class='texto'><input type='checkbox' name='fax2' value='fax2' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> E-mail </td>
	        <td class='texto'><input type='checkbox' name='email2' value='email' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Packages:</b></td>
		  </tr>
	      <tr>
      	    <td width='347' class='texto'> N�o S�cios </td>
	        <td class='texto'><input type='checkbox' name='profissional2' value='profissional' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Estudantes de Gradua��o </td>
	        <td class='texto'><input type='checkbox' name='student2' value='student' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> S�cios Quites </td>
	        <td class='texto'><input type='checkbox' name='accompanyingperson3' value='accompanyingperson' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Residente </td>
	        <td class='texto'><input type='checkbox' name='resident2' value='residente' /></td>
	      </tr>
		  
	      <tr>
      	    <td width='347' class='texto'> Gerentologia </td>
	        <td class='texto'><input type='checkbox' name='gerentologia2' value='gerentologia' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Congnitiva </td>
	        <td class='texto'><input type='checkbox' name='congnitiva2' value='congnitiva' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Paleativos </td>
	        <td class='texto'><input type='checkbox' name='paleativos2' value='paleativos' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Incapacidade </td>
	        <td class='texto'><input type='checkbox' name='incapacidade2' value='incapacidade' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Methods of payment:</b></td>
		  </tr>
    	  <tr>
	        <td width='347' class='texto'> Forma de Pagamento </td>
   		    <td class='texto'><input type='checkbox' name='formpagamento2' value='formpagamento' /></td>
	      </tr>
 	      <tr>
      	    <td width='347' class='texto'> Total </td>
	        <td class='texto'><input type='checkbox' name='totalescolhido2' value='totalescolhido' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
	      <tr>
      		  <td width='347' class='texto'><strong>Ordenado por:</strong></td>
			  <td class='texto'>
      			<select name='ordem' size='1' class='texto'>
            		<option value=''>---Escolha---</option>
	                <option value='id'>C�digo do Cliente</option>
        	        <option value='familyname'>Nome Completo</option>
            	    <option value='nametothebagde'>Nome para Crach�</option>
                	<option value='instituicao'>Institui��o</option>
	                <option value='especialidade'>Especialidade</option>
    	            <option value='cpf'>CPF</option>
        	        <option value='identidade'>Identidade</option>
            	    <option value='mailingadress'>Endere�o</option>
                	<option value='zipcode'>CEP</option>					
	                <option value='city'>Cidade</option>
    	            <option value='provincestate'>Estado</option>
        	        <option value='phone'>Telefone</option>
            	    <option value='fax'>celular</option>
					
	   	            <option value='' disabled='disabled'>Packages:</option>
        	        <option value='profissional'>N�o S�cios</option>
            	    <option value='student'>Estudantes de Gradua��o</option>
                	<option value='accompanyingperson2'>S�cios Quites</option>
        	        <option value='residente'>residente</option>
            	    <option value='gerentologia'>gerentologia</option>
                	<option value='congnitiva'>congnitiva</option>
            	    <option value='paleativos'>paleativos</option>
                	<option value='incapacidade'>incapacidade</option>
					
	                <option value='formpagamento'>Forma de Pagamento</option>
        	        <option value='totalescolhido'>Total</option>
	            </select>
    	    </td>
	      </tr>
		</table>";
}elseif ($fabi == "Iberian-Latin-American Congress on Computational Methods in Engineering, organized by the Brazilian Association for Computational Methods in Engineering"){

    Header("Content-type: application/xml; charset=iso-8859-1");
    echo "<table border='0' width='350'>
		  <tr>
        	<td width='347' class='texto'>Client Code</td>
	  	 	<td class='texto'><input type='checkbox' name='id2' value='id' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'>Title</td>
	   	    <td class='texto'><input type='checkbox' name='title2' value='title' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family Name </td>
	   	    <td class='texto'><input type='checkbox' name='familyname2' value='familyname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Middle Name </td>
	   	    <td class='texto'><input type='checkbox' name='givenname2' value='givenname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family </td>
	   	    <td class='texto'><input type='checkbox' name='family2' value='family' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Especialidade </td>
	   	    <td class='texto'><input type='checkbox' name='especialidade2' value='especialidade2' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> CPF </td>
	   	    <td class='texto'><input type='checkbox' name='cpf2' value='cpf' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Identidade </td>
	   	    <td class='texto'><input type='checkbox' name='identidade2' value='identidade' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Name to the Bagde </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Affiliation </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Mailing Adress </td>
	   	    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
		  <tr>
	        <td width='347' class='texto'> City </td>
   		    <td class='texto'><input type='checkbox' name='city2' value='city' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Province State </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Country </td>
	        <td class='texto'><input type='checkbox' name='country2' value='country' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Zip Code </td>
	        <td class='texto'><input type='checkbox' name='zipcode2' value='zipcode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Email </td>
		    <td class='texto'><input type='checkbox' name='email2' value='email' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Phone </td>
	        <td class='texto'><input type='checkbox' name='phone2' value='phone' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Fax </td>
	        <td class='texto'><input type='checkbox' name='fax2' value='fax' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Packages:</b></td>
		  </tr>
	      <tr>
      	    <td width='347' class='texto'> Profissional </td>
	        <td class='texto'><input type='checkbox' name='profissional2' value='profissional' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Graduate Student </td>
	        <td class='texto'><input type='checkbox' name='student2' value='student' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Undergraduate Student </td>
	        <td class='texto'><input type='checkbox' name='resident2' value='residente' /></td>
	      </tr>
		  
	      <tr>
      	    <td width='347' class='texto'> Aditional Work </td>
	        <td class='texto'><input type='checkbox' name='gerentologia2' value='gerentologia' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Cilamce 2009 / Dinner </td>
	        <td class='texto'><input type='checkbox' name='congnitiva2' value='congnitiva' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Methods of payment:</b></td>
		  </tr>
    	  <tr>
	        <td width='347' class='texto'> Payment Methods </td>
   		    <td class='texto'><input type='checkbox' name='formpagamento2' value='formpagamento' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Card </td>
   		    <td class='texto'><input type='checkbox' name='cartao2' value='cartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Name Card </td>
   		    <td class='texto'><input type='checkbox' name='namecredit2' value='namecredit' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Number Card </td>
   		    <td class='texto'><input type='checkbox' name='numcredit2' value='numcredit' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Expiration Date </td>
   		    <td class='texto'><input type='checkbox' name='expiracartao2' value='expiracartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Security Code </td>
   		    <td class='texto'><input type='checkbox' name='securitycode2' value='securitycode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Total </td>
	        <td class='texto'><input type='checkbox' name='totalescolhido2' value='totalescolhido' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
	      <tr>
      		  <td width='347' class='texto'><strong>Ordenado por:</strong></td>
			  <td class='texto'>
      			<select name='ordem' size='1' class='texto'>
            		<option value=''>---Escolha---</option>
	                <option value='id'>Client Code</option>
        	        <option value='title'>Title</option>
            	    <option value='familyname'>Family Name</option>
                	<option value='givenname'>Middle Name</option>
                	<option value='family'>Family</option>
	                <option value='nametothebagde'>Name to the Bagde</option>
    	            <option value='affiliation'>Affiliation</option>
        	        <option value='mailingadress'>Mailing Adress</option>
            	    <option value='city'>City</option>
                	<option value='provincestate'>Province State</option>					
	                <option value='country '>Country</option>
    	            <option value='zipcode'>Zip Code</option>
        	        <option value='email'>Email</option>
            	    <option value='phone'>Phone</option>
                	<option value='fax'>Fax</option>
	                <option value='accompanyingperson'>Accompanying Person</option>
    	            <option value='letter'>Letter</option>
					
	   	            <option value='' disabled='disabled'>Packages:</option>
        	        <option value='profissional'>Profissional</option>
            	    <option value='student'>Graduate Student</option>
                	<option value='residente'>Undergraduate Student</option>
                	<option value='gerentologia'>Aditional Work</option>
                	<option value='congnitiva'>Cilamce 2009 / Dinner</option>
					
	   	            <option value='' disabled='disabled'>Payment Methods:</option>
	                <option value='formpagamento'>Payment Methods</option>
    	            <option value='cartao'>Card</option>
        	        <option value='namecredit'>Name Card</option>
                	<option value='numcredit'>Number Card</option>
	                <option value='expiracartao'>Expiration Date</option>
    	            <option value='securitycode'>Security Code</option>
        	        <option value='totalescolhido'>Total</option>
	            </select>
    	    </td>
	      </tr>
		</table>";
}else{
    echo "<table border='0' width='350'>
		  <tr>
        	<td width='347' class='texto'>Client Code</td>
	  	 	<td class='texto'><input type='checkbox' name='id2' value='id' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'>Title</td>
	   	    <td class='texto'><input type='checkbox' name='title2' value='title' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family Name </td>
	   	    <td class='texto'><input type='checkbox' name='familyname2' value='familyname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Middle Name </td>
	   	    <td class='texto'><input type='checkbox' name='givenname2' value='givenname' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Family </td>
	   	    <td class='texto'><input type='checkbox' name='family2' value='family' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Name to the Bagde </td>
	   	    <td class='texto'><input type='checkbox' name='nametothebagde2' value='nametothebagde' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Affiliation </td>
	   	    <td class='texto'><input type='checkbox' name='affiliation2' value='affiliation' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> CPF </td>
	   	    <td class='texto'><input type='checkbox' name='cpf2' value='cpf' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Identidade </td>
	   	    <td class='texto'><input type='checkbox' name='identidade2' value='identidade' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Mailing Adress </td>
	   	    <td class='texto'><input type='checkbox' name='mailingadress2' value='mailingadress' /></td>
	      </tr>
		  <tr>
	        <td width='347' class='texto'> City </td>
   		    <td class='texto'><input type='checkbox' name='city2' value='city' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Province State </td>
	        <td class='texto'><input type='checkbox' name='provincestate2' value='provincestate' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Country </td>
	        <td class='texto'><input type='checkbox' name='country2' value='country' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Zip Code </td>
	        <td class='texto'><input type='checkbox' name='zipcode2' value='zipcode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Email </td>
		    <td class='texto'><input type='checkbox' name='email2' value='email' /></td>
	      </tr>
	      <tr>
	        <td class='texto' width='347'> Especialidade </td>
	   	    <td class='texto'><input type='checkbox' name='especialidade2' value='especialidade' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Phone </td>
	        <td class='texto'><input type='checkbox' name='phone2' value='phone' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Fax </td>
	        <td class='texto'><input type='checkbox' name='fax2' value='fax' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Accompanying Person </td>
	        <td class='texto'><input type='checkbox' name='accompanyingperson2' value='accompanyingperson' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Letter </td>
	        <td class='texto'><input type='checkbox' name='letter2' value='letter' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Packages:</b></td>
		  </tr>
	      <tr>
      	    <td width='347' class='texto'> Profissional </td>
	        <td class='texto'><input type='checkbox' name='profissional2' value='profissional' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Student </td>
	        <td class='texto'><input type='checkbox' name='student2' value='student' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Accompanying Person </td>
	        <td class='texto'><input type='checkbox' name='accompanyingperson3' value='accompanyingperson' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Paleativos </td>
	        <td class='texto'><input type='checkbox' name='paleativos2' value='paleativos' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Incapacidade </td>
	        <td class='texto'><input type='checkbox' name='incapacidade2' value='incapacidade' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> residente </td>
	        <td class='texto'><input type='checkbox' name='resident2' value='residente' /></td>
	      </tr>
		  
	      <tr>
      	    <td width='347' class='texto'> gerentologia </td>
	        <td class='texto'><input type='checkbox' name='gerentologia2' value='gerentologia' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> congnitiva </td>
	        <td class='texto'><input type='checkbox' name='congnitiva2' value='congnitiva' /></td>
	      </tr>
		  <tr>
		  	 <td class='texto' width='347' align='left' colspan='2' height='40'><b>Methods of payment:</b></td>
		  </tr>
    	  <tr>
	        <td width='347' class='texto'> Payment Methods </td>
   		    <td class='texto'><input type='checkbox' name='formpagamento2' value='formpagamento' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Card </td>
   		    <td class='texto'><input type='checkbox' name='cartao2' value='cartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Date of the Registration </td>
   		    <td class='texto'><input type='checkbox' name='datacartao2' value='datacartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Name Card </td>
   		    <td class='texto'><input type='checkbox' name='namecredit2' value='namecredit' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Number Card </td>
   		    <td class='texto'><input type='checkbox' name='numcredit2' value='numcredit' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Expiration Date </td>
   		    <td class='texto'><input type='checkbox' name='expiracartao2' value='expiracartao' /></td>
	      </tr>
    	  <tr>
	        <td width='347' class='texto'> Security Code </td>
   		    <td class='texto'><input type='checkbox' name='securitycode2' value='securitycode' /></td>
	      </tr>
	      <tr>
      	    <td width='347' class='texto'> Total </td>
	        <td class='texto'><input type='checkbox' name='totalescolhido2' value='totalescolhido' /></td>
	      </tr>
   		  <tr><td class='texto' align='center' colspan='2'>&nbsp;</td></tr>
	      <tr>
      		  <td width='347' class='texto'><strong>Ordenado por:</strong></td>
			  <td class='texto'>
      			<select name='ordem' size='1' class='texto'>
            		<option value=''>---Escolha---</option>
	                <option value='id'>Client Code</option>
        	        <option value='title'>Title</option>
            	    <option value='familyname'>Family Name</option>
                	<option value='givenname'>Middle Name</option>
                	<option value='family'>Family</option>
	                <option value='nametothebagde'>Name to the Bagde</option>
    	            <option value='affiliation'>Affiliation</option>
        	        <option value='mailingadress'>Mailing Adress</option>
    	            <option value='cpf'>CPF</option>
        	        <option value='identidade'>Identidade</option>
            	    <option value='city'>City</option>
                	<option value='provincestate'>Province State</option>					
	                <option value='country '>Country</option>
    	            <option value='zipcode'>Zip Code</option>
        	        <option value='email'>Email</option>
            	    <option value='phone'>Phone</option>
                	<option value='fax'>Fax</option>
	                <option value='accompanyingperson'>Accompanying Person</option>
    	            <option value='letter'>Letter</option>
					
	   	            <option value='' disabled='disabled'>Packages:</option>
        	        <option value='profissional'>Profissional</option>
            	    <option value='student'>Student</option>
					<option value='accompanyingperson2'>Accompanying Person</option>
					<option value='paleativos'>Paleativos</option>
                	<option value='incapacidade'>Incapacidade</option>
                	<option value='gerentologia'>Gerentologia</option>
                	<option value='congnitiva'>Congnitiva</option>
					<option value='residente'>Residente</option>
					
	   	            <option value='' disabled='disabled'>Payment Methods:</option>
	                <option value='formpagamento'>Payment Methods</option>
    	            <option value='cartao'>Card</option>
        	        <option value='namecredit'>Name Card</option>
					<option value='namecredit'>Date of the Registration</option>
                	<option value='numcredit'>Number Card</option>
	                <option value='expiracartao'>Expiration Date</option>
    	            <option value='securitycode'>Security Code</option>
        	        <option value='totalescolhido'>Total</option>
	            </select>
    	    </td>
	      </tr>
		</table>";
}

?>