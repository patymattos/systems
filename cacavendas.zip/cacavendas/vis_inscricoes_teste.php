<? 
session_start();
include_once "php/valida_sessao.php";
include"php/config.php";

$id_inscricoes =$_GET['id_inscricoes'];

$select_inscr = "SELECT * FROM inscricoes WHERE id = '$id_inscricoes'";
$query_inscr = mysql_query($select_inscr);
$busca_inscr = mysql_fetch_array($query_inscr);
$nome_ev = $busca_inscr['nome_evento'];

$select_ev = "SELECT * FROM eventos WHERE nome_evento = '$nome_ev'";
$query_ev = mysql_query($select_ev);
$busca_ev = mysql_fetch_array($query_ev);
$id_ev = $busca_ev['id'];

$select_java = "SELECT * FROM funcao_java WHERE id_evento = '$id_ev'";
$query_java = mysql_query($select_java);
$busca_java = mysql_fetch_array($query_java);
$funcao = $busca_java['funcao'];

$select_form = "SELECT * FROM formulario WHERE id_evento = '$id_ev' AND tipo = 'tabela'";
$query_form = mysql_query($select_form);
$busca_form = mysql_fetch_array($query_form);
$formulario = $busca_form['nome_campo'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
	<script type="text/javascript" src="js/funcoes.js"></script>
	<script language="javascript" type="application/javascript">
	function barra(objeto){
		if (objeto.value.length == 2 || objeto.value.length == 5 ){
		objeto.value = objeto.value+"/";
		}
	}
	</script>
  <script language="javascript" type="text/javascript">
		<?=$funcao;?>
  </script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
</head>
<body>
<? include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td><? include "php/inc_vis_inscricoes_teste.php"; ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
	</td>
  </tr>
</table>
<? include_once "inc_rodape.php"; ?>
</body>
</html>