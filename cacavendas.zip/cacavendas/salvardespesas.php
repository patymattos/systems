<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	$DS_TIPO =$_POST['D_TIPO'];
	
	$DS_DATA =$_POST['D_DATA'];

	$DS_MOTIVO =$_POST['D_MOTIVO'];
	
	$DS_VALOR =$_POST['D_VALOR'];
	
	$DS_TOTAL =$_POST['D_TOTAL'];
	
	$DS_DINHEIRO =$_POST['D_DINHEIRO'];
	
	$DS_CHEQUE =$_POST['D_CHEQUE'];

	$DS_SALDO = ($DS_TOTAL+$$DS_DINHEIRO+$DS_CHEQUE)-DS_VALOR;


	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO despesas (DV_ID,DV_TIPO,DV_DATA,DV_MOTIVO,DV_VALOR,DV_TOTAL,DV_DINHEIRO,DV_CHEQUE,DV_SALDO)
	VALUES ('','$DS_TIPO','$DS_DATA','$DS_MOTIVO','$DS_VALOR','$DS_TOTAL','$DS_DINHEIRO','$DS_CHEQUE','$DS_SALDO')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_despesas.php");



?>	

 