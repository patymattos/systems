<?php

include_once "php/config.php";



$prod = $_GET['tr'];

$select = "SELECT * FROM produtos WHERE PRD_ID = '$prod'";

$query = mysql_query($select);

$a = mysql_fetch_array($query);



$ref = 'value="'.$a['PRD_REFERENCIA'].'"';

$ano = 'value="'.$a['PRD_ANO'].'"';

$nome = 'value="'.$a['PRD_NOME'].'"';

$desc = 'value="'.$a['PRD_DESCRICAO'].'"';

$marca = 'value="'.$a['PRD_MARCA'].'"';

$quant = 'value="'.$a['PRD_QUANTIDADE'].'"';

$venda = 'value="'.$a['PRD_VENDA'].'"';

$custo = 'value="'.$a['PRD_CUSTO'].'"';

$forn = '<option value="'.$a['PRD_FORN'].'">'.substr ($a['PRD_FORN'],0,50).'...</option>';

$pcom = 'value="'.$a['PRD_COM'].'"';

$obs = 'value="'.$a['PRD_OBS'].'"';







?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= CACA PNEUS - SISTEMA ADMINISTRATIVO =-</title>
<script type="text/javascript" src="js/funcoes.js"></script>
<script type="application/javascript" language="javascript">
<!--
function barra(objeto){
		if (objeto.value.length == 2 || objeto.value.length == 5 ){
		objeto.value = objeto.value+"/";
		}
	}
function validar(obj) { // recebe um objeto
    var s = (obj.value).replace(/\D/g,'');
    var tam=(s).length; // removendo os caracteres n�o num�ricos
    if (!(tam==11 || tam==14)){ // validando o tamanho
        alert("'"+s+"' N�o � um CPF ou um CNPJ v�lido!" ); // tamanho inv�lido
        return false;
    }
// se for CPF
    if (tam==11 ){
        if (!validaCPF(s)){ // chama a fun��o que valida o CPF
            alert("'"+s+"' N�o � um CPF v�lido!" ); // se quiser mostrar o erro
            obj.select();  // se quiser selecionar o campo em quest�o
            return false;
        }
        obj.value=maskCPF(s);    // se validou o CPF mascaramos corretamente
        return true;
    }
// se for CNPJ
    if (tam==14){
        if(!validaCNPJ(s)){ // chama a fun��o que valida o CNPJ
            alert("'"+s+"' N�o � um CNPJ v�lido!" ); // se quiser mostrar o erro
            obj.select();    // se quiser selecionar o campo enviado
            return false;
        }
    }
}
// fim da funcao validar()
// fun��o que valida CPF
// O algor�timo de valida��o de CPF � baseado em c�lculos
// para o d�gito verificador (os dois �ltimos)
// N�o entrarei em detalhes de como funciona
function validaCPF(s) {
    var c = s.substr(0,9);
    var dv = s.substr(9,2);
    var d1 = 0;
    for (var i=0; i<9; i++) {
        d1 += c.charAt(i)*(10-i);
     }
    if (d1 == 0) return false;
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(0) != d1){
        return false;
    }
    d1 *= 2;
    for (var i = 0; i < 9; i++)    {
         d1 += c.charAt(i)*(11-i);
    }
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(1) != d1){
        return false;
    }
    return true;
}
// Fun��o que valida CNPJ
// O algor�timo de valida��o de CNPJ � baseado em c�lculos
// para o d�gito verificador (os dois �ltimos)
// N�o entrarei em detalhes de como funciona
function validaCNPJ(CNPJ) {
    var a = new Array();
    var b = new Number;
    var c = [6,5,4,3,2,9,8,7,6,5,4,3,2];
    for (i=0; i<12; i++){
        a[i] = CNPJ.charAt(i);
        b += a[i] * c[i+1];
    }
    if ((x = b % 11) < 2) { a[12] = 0 } else { a[12] = 11-x }
    b = 0;
    for (y=0; y<13; y++) {
        b += (a[y] * c[y]);
    }
    if ((x = b % 11) < 2) { a[13] = 0; } else { a[13] = 11-x; }
    if ((CNPJ.charAt(12) != a[12]) || (CNPJ.charAt(13) != a[13])){
        return false;
    }
    return true;
}

    // Fun��o que permite apenas teclas num�ricas
    // Deve ser chamada no evento onKeyPress desta forma
    // return (soNums(event));
function soNums(e)
{
    if (document.all){var evt=event.keyCode;}
    else{var evt = e.charCode;}
    if (evt <20 || (evt >47 && evt<58)){return true;}
    return false;
}
//    fun��o que mascara o CPF
function maskCPF(CPF){
    return CPF.substring(0,3)+"."+CPF.substring(3,6)+"."+CPF.substring(6,9)+"-"+CPF.substring(9,11);
}
//    fun��o que mascara o CNPJ
function maskCNPJ(CNPJ){
    return CNPJ.substring(0,2)+"."+CNPJ.substring(2,5)+"."+CNPJ.substring(5,8)+"/"+CNPJ.substring(8,12)+"-"+CNPJ.substring(12,14);
} 1

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
    <style type="text/css">
<!--
.style5 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
-->
    </style>
</head>


<body bgcolor="#FAFAD2">
<? include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	<table width="575" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">
	  <tr>
        <td class="titulo">:: Altera&ccedil;&atilde;o de Produto ::</td>
      </tr>
	  <tr>
        <td><? include_once "altprod.php"; ?></td>
	  </tr>
    </table>
	</td>
  </tr>
</table>
<? include_once "inc_rodape.php"; ?>
</body>
</html>