<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>-= Meta Marketing e Eventos =-</title>
<script type="text/javascript">
	function stIE(){
		document.body.focus(); //  ie
	    window.print();
	}
</script>
</head>
	<?php
	   $ie6 = "MSIE 6.0";
	   $ie7 = "MSIE 7.0";
	   $ie8 = "MSIE 8.0";
	   if( strstr($_SERVER['HTTP_USER_AGENT'], $ie8)){
		   echo '<body style="background:url(images/certificado.jpg) no-repeat;background-position:top;">
				   <div style="text-align:justify; margin:auto; width:900px;">
					   <div id="visualiza_imp"></div>
				   </div>';
	   }elseif (( strstr($_SERVER['HTTP_USER_AGENT'], $ie7)) or ( strstr($_SERVER['HTTP_USER_AGENT'], $ie6))) {
		   echo '<body style="background:url(images/certificado.jpg) no-repeat;">
				   <div style="text-align:justify; margin:auto; width:900px;">
		   			<div id="visualiza_imp"></div>
				   </div>';
	   }else{
		   echo '<body style="background:url(images/certificado.jpg) no-repeat;background-position:top;">
				   <div style="text-align:justify; margin:auto; width:900px;">
		   				<div id="visualiza_imp"></div>
				   </div>';
	   } 
	?>
</body>
</html>
