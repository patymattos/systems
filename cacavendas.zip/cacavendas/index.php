<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= CACA PNEUS - SISTEMA ADMINISTRATIVO =-</title>

<link rel="stylesheet" type="text/css" href="css/estilo.css" />

<link rel="stylesheet" type="text/css" href="css/sddm.css" >

<style type="text/css">
<!--
.style1 {font-size: 10}
-->
</style>
</head>



<body bgcolor="#CCCCCC">
<span class="style1"></span>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0" class="tbl_fundo_branco">

<tr>

 <td width="614" valign="top">

  <form method="POST" action="php/login.php">

	<table width="400" border="0" align="center" cellpadding="5" cellspacing="2" class="texto cor_tr">

      <tr>

        <td align="center" class="titulo" colspan="2" height="30">ACESSO RESTRITO</td>

      </tr>

      <tr>

        <td align="right" width="40%">Nome de usu&aacute;rio: </td>

        <td align="left"><input name="login" type="text" id="login" /></td>

      </tr>

      <tr>

        <td align="right">Senha:</td>

        <td><input type="password" name="senha" /></td>

      </tr>

      <tr>

        <td align="center" colspan="2"><input type="submit" value="Enviar" name="enviar" /></td>

      </tr>

	  <tr>

        <td align="center" colspan="2"><a href="lembrar_senha.php">[ Esqueci a senha ]</a></td>

      </tr>

    </table>

  </form>

 </td>

</tr>
</table>



</body>

</html>

