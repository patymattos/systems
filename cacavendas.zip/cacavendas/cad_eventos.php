<? 
session_start();
include_once "php/valida_sessao.php";
include_once "php/config.php";
$select = "SELECT * FROM eventos";
$sql = mysql_query($select) or die ("Query : ".$select." : ".mysql_error());
$resultado = mysql_num_rows($sql);
$evento = ($resultado+2);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
<script type="text/javascript" src="js/funcoes.js"></script>
<script type="application/javascript" language="javascript">
	function barra(objeto){
		if (objeto.value.length == 2 || objeto.value.length == 5 ){
		objeto.value = objeto.value+"/";
		}
	}
function validar(obj) { // recebe um objeto
    var s = (obj.value).replace(/\D/g,'');
    var tam=(s).length; // removendo os caracteres n�o num�ricos
    if (!(tam==11 || tam==14)){ // validando o tamanho
        alert("'"+s+"' N�o � um CPF ou um CNPJ v�lido!" ); // tamanho inv�lido
        return false;
    }
// se for CPF
    if (tam==11 ){
        if (!validaCPF(s)){ // chama a fun��o que valida o CPF
            alert("'"+s+"' N�o � um CPF v�lido!" ); // se quiser mostrar o erro
            obj.select();  // se quiser selecionar o campo em quest�o
            return false;
        }
        obj.value=maskCPF(s);    // se validou o CPF mascaramos corretamente
        return true;
    }
// se for CNPJ
    if (tam==14){
        if(!validaCNPJ(s)){ // chama a fun��o que valida o CNPJ
            alert("'"+s+"' N�o � um CNPJ v�lido!" ); // se quiser mostrar o erro
            obj.select();    // se quiser selecionar o campo enviado
            return false;
        }
    }
}
// fim da funcao validar()
// fun��o que valida CPF
// O algor�timo de valida��o de CPF � baseado em c�lculos
// para o d�gito verificador (os dois �ltimos)
// N�o entrarei em detalhes de como funciona
function validaCPF(s) {
    var c = s.substr(0,9);
    var dv = s.substr(9,2);
    var d1 = 0;
    for (var i=0; i<9; i++) {
        d1 += c.charAt(i)*(10-i);
     }
    if (d1 == 0) return false;
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(0) != d1){
        return false;
    }
    d1 *= 2;
    for (var i = 0; i < 9; i++)    {
         d1 += c.charAt(i)*(11-i);
    }
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(1) != d1){
        return false;
    }
    return true;
}
// Fun��o que valida CNPJ
// O algor�timo de valida��o de CNPJ � baseado em c�lculos
// para o d�gito verificador (os dois �ltimos)
// N�o entrarei em detalhes de como funciona
function validaCNPJ(CNPJ) {
    var a = new Array();
    var b = new Number;
    var c = [6,5,4,3,2,9,8,7,6,5,4,3,2];
    for (i=0; i<12; i++){
        a[i] = CNPJ.charAt(i);
        b += a[i] * c[i+1];
    }
    if ((x = b % 11) < 2) { a[12] = 0 } else { a[12] = 11-x }
    b = 0;
    for (y=0; y<13; y++) {
        b += (a[y] * c[y]);
    }
    if ((x = b % 11) < 2) { a[13] = 0; } else { a[13] = 11-x; }
    if ((CNPJ.charAt(12) != a[12]) || (CNPJ.charAt(13) != a[13])){
        return false;
    }
    return true;
}

    // Fun��o que permite apenas teclas num�ricas
    // Deve ser chamada no evento onKeyPress desta forma
    // return (soNums(event));
function soNums(e)
{
    if (document.all){var evt=event.keyCode;}
    else{var evt = e.charCode;}
    if (evt <20 || (evt >47 && evt<58)){return true;}
    return false;
}
//    fun��o que mascara o CPF
function maskCPF(CPF){
    return CPF.substring(0,3)+"."+CPF.substring(3,6)+"."+CPF.substring(6,9)+"-"+CPF.substring(9,11);
}
//    fun��o que mascara o CNPJ
function maskCNPJ(CNPJ){
    return CNPJ.substring(0,2)+"."+CNPJ.substring(2,5)+"."+CNPJ.substring(5,8)+"/"+CNPJ.substring(8,12)+"-"+CNPJ.substring(12,14);
} 1
</script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
</head>


<body>
<? include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	<form action="php/inc_cad_eventos.php" method="post" id="teste"  name="frm_servico" enctype="multipart/form-data" onSubmit="return validaForm()">
	<table width="575" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /></td>
      </tr>
	  <tr>
        <td colspan="2" class="titulo">:: Cadastrar Evento ::</td>
      </tr>
	  <tr>
        <td width="296">Nome do Evento:</td>
        <td width="505"><input name="evento" type="text" id="evento" size="50" /></td>
	  </tr>
	  <tr>
        <td>Tipo do Evento:</td>
        <td><select name="tipo_evento">
          <option>-= Escolha o Tipo do Evento =-</option>
          <option value="1">EVENTOS T&Eacute;CNICOS-CIENT&Iacute;FICOS</option>
          <option value="2">ORGANIZA&Ccedil;&Otilde;ES NO EXTERIOR</option>
          <option value="3">FEIRAS E EXPOSI&Ccedil;&Otilde;ES</option>
          <option value="4">MONTAGEM DE ESTANDES</option>
          <option value="5">EVENTOS ESPORTIVOS</option>
          <option value="6">EVENTOS CULTURAIS</option>
          <option value="7">OUTRAS PRODU&Ccedil;&Otilde;ES</option>
          <option value="8">FORMATURAS</option>
          <option value="9">MARKETING POL&Iacute;TICO</option>
        </select></td>
	  </tr>
      <tr>
        <td>Data inicial do evento:</td>
        <td><input name="data_evento_inicio" type="text" id="data_evento_inicio" size="10" maxlength="10" onkeypress="barra(this)" /></td>
      </tr>
	  <tr>
        <td>Data final do evento:</td>
        <td><input name="data_evento_final" type="text" id="data_evento_final" size="10" maxlength="10" onkeypress="barra(this)" /></td>
	  </tr>
	  <tr>
        <td>Local a ser realizado o evento:</td>
        <td><input name="local_evento" type="text" id="local_evento" size="50" /></td>
	  </tr>
	  <tr>
        <td>Promo��o:</td>
        <td><input name="promocao" type="text" id="promocao" size="50" /></td>
	  </tr>
	  <tr>
        <td>Patroc�nio:</td>
        <td><input name="patrocinio" type="text" id="patrocinio" size="50" /></td>
	  </tr>
	  <tr>
        <td>Apoio:</td>
        <td><input name="apoio" type="text" id="apoio" size="50" /></td>
	  </tr>
	  <tr>
        <td>Montagens:</td>
        <td><input name="montagens" type="text" id="montagens" size="50" /></td>
	  </tr>
	  <tr>
        <td>Tem�tica:</td>
        <td><input name="tematica" type="text" id="tematica" size="50" /></td>
	  </tr>
	  <tr>
        <td>Candidato:</td>
        <td><input name="candidato" type="text" id="candidato" size="50" /></td>
	  </tr>
	  <tr>
        <td>Email do evento:</td>
        <td><input name="email_evento" type="text" id="email_evento" size="50" /></td>
	  </tr>
	  <tr>
        <td>Link:</td>
        <td><input name="link" type="text" id="link" size="50" value="https://www.metaeventos.net/inscricoes/index.php?id=<?=$evento?>" /></td>
	  </tr>
	  <tr>
        <td>Imagem do Evento (*):</td>
        <td><input name="foto_evento" type="file" id="foto_evento" />(*) dimens�o 152 X 170 px</td>
	  </tr>
	  <tr>
        <td>Imagem do Topo do Evento (*):</td>
        <td><input name="foto_topo" type="file" id="foto_topo" />(*) dimens�o 744 X 218 px</td>
	  </tr>
	  <tr>
        <td colspan="2">&nbsp;</td>
	  </tr>
      <tr>
      	<td colspan="2" align="center"><b>Preencher caso Forma de Pagamento for por meio de Boleto Banc�rio</b></td>
      </tr>
	  <tr>
        <td colspan="2">&nbsp;</td>
	  </tr>
	  <tr>
        <td>Tipo de Boleto:</td>
        <td><input type="radio" name="unibanco" id="unibanco" />Unibanco</td>
	  </tr>
	  <tr>
        <td>Nome Cedente:</td>
        <td><input type="text" name="cedente" id="cedente" size="50" /></td>
	  </tr>
	  <tr>
        <td>Ag�ncia:&nbsp;</td>
        <td><input type="text" name="agencia" id="agencia" size="6" /></td>
	  </tr>
	  <tr>
        <td>Conta:</td>
        <td><input type="text" name="conta" id="conta" size="15" />-<input type="text" name="conta_div" id="conta_div" size="2" /></td>
	  </tr>
	  <tr>
        <td>C�digo do Cliente:</td>
        <td><input type="text" name="codigo_cliente" id="codigo_cliente" /></td>
	  </tr>
	  <tr>
        <td>Carteira:</td>
        <td><input type="text" name="carteira" id="carteira" /></td>
	  </tr>
	  <tr>
        <td>Dias para pagamento:</td>
        <td><input type="text" name="diap" id="diap" size="3" />
          + dia_atual = vencimento_fatura_cliente</td>
	  </tr>
	  <tr>
        <td>Taxa bancaria:</td>
        <td><input type="text" name="txb" id="txb" value="0,00" size="10" />(adicione o valor do boleto, exemplo: "R$ 2,95")</td>
	  </tr>
	  <tr>
        <td>CPF/CNPJ:</td>
        <td><input name="cpf_cnpj" type="text" id="cpf_cnpj" onblur="validar(this)" maxlength="18" size="18"/>(digite apenas n�meros)</td>
	  </tr>
	  <tr>
        <td>Endere�o:</td>
        <td><input type="text" name="endereco" id="endereco" /></td>
	  </tr>
	  <tr>
        <td>Cidade:</td>
        <td><input type="text" name="cidade" id="cidade" />&nbsp;
        	Estado: <select name="uf">
                          <option value="" selected="selected"></option>
                          <option value="AC">AC</option>
                          <option value="AL">AL</option>
                          <option value="AM">AM</option>
                          <option value="AP">AP</option>
                          <option value="BA">BA</option>
                          <option value="CE">CE</option>
                          <option value="DF">DF</option>
                          <option value="ES">ES</option>
                          <option value="GO">GO</option>
                          <option value="MA">MA</option>
                          <option value="MG">MG</option>
                          <option value="MS">MS</option>
                          <option value="MT">MT</option>
                          <option value="PA">PA</option>
                          <option value="PB">PB</option>
                          <option value="PE">PE</option>
                          <option value="PI">PI</option>
                          <option value="PR">PR</option>
                          <option value="RJ">RJ</option>
                          <option value="RN">RN</option>
                          <option value="RO">RO</option>
                          <option value="RR">RR</option>
                          <option value="RS">RS</option>
                          <option value="SC">SC</option>
                          <option value="SE">SE</option>
                          <option value="SP">SP</option>
                          <option value="TO">TO</option>
                     </select></td>
	  </tr>

    </table>
	</form>
	</td>
  </tr>
</table>
<? include_once "inc_rodape.php"; ?>
</body>
</html>