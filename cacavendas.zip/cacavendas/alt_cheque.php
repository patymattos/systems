<?php

header('Content-Type: text/html; charset=utf-8');

include_once "php/config.php";



$id_cheq = $_POST['id_cheq'];

$CQ_DATA 	= $_POST['CH_DATA'];

$CQ_NOME 	= $_POST['CH_NOME'];

$CQ_NUM 	= $_POST['CH_NUM'];

$CQ_VALOR 	= $_POST['CH_VALOR'];

$CQ_DES 	= $_POST['CH_DES'];

$CQ_DT 	= $_POST['CH_DT'];

$CQ_DESC 	= $_POST['CH_DESC'];


if($CQ_DATA != "" && $CQ_NOME != "" && $CQ_NUM != "" && $CQ_VALOR != "" && $CQ_DES != ""){

	$up = "UPDATE cheques SET

	CHQ_DATA ='$CQ_DATA',
	
	CHQ_NOME ='$CQ_NOME',

	CHQ_NUM ='$CQ_NUM',
	
	CHQ_VALOR ='$CQ_VALOR',
	
	CHQ_DES ='$CQ_DES',
	
	CHQ_DT ='$CQ_DT',
	
	CHQ_DESC ='$CQ_DESC',

	WHERE CHQ_ID= '$id_cheq'";

	$cad = mysql_query($up);

	

	echo "<script>alert('Cheque alterado com sucesso');location.href='alterar_cheque.php?tr=$id_cheq'; </script>";

}

else{

	echo "<script>alert('Verifiqque se um dos campos abaixo não foi definido:\\n - Data\\n - Nome\\n - Número\\n - Valor\\n - Destino\\n');location.href='javascript:window.history.go(-1)'; </script>";

	exit();

}

?>