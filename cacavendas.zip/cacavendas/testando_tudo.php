<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
	<script type="text/javascript" src="js/funcoes.js"></script>
	<script language="javascript" type="application/javascript">
	function barra(objeto){
		if (objeto.value.length == 2 || objeto.value.length == 5 ){
		objeto.value = objeto.value+"/";
		}
	}
	</script>
  <script language="javascript" type="text/javascript">
		  function checar(){
	  campo1=document.form.check1;
	  campo2=document.form.check2;
	  campo3=document.form.check3;
	  campo4=document.form.check4;  
	  campo5=document.form.check5;  
	  campo6=document.form.check6; 
	  campo7=document.form.check7;  
	  campo8=document.form.check8;
	  campo9=document.form.check9;  
	  campo10=document.form.check10; 
	  campo11=document.form.check11;  
	  campo12=document.form.check12;

	  if(campo1.checked==true){
		  valor1=campo1.value;
	  }else{
		  valor1="";
	  }
	  if(campo2.checked==true){
		  valor2=campo2.value;
	  }else{
		  valor2="";
	  }
	  if(campo3.checked==true){
		  valor3=campo3.value;
	  }else{
		  valor3="";
	  }
	  if(campo4.checked==true){
		  valor4=campo4.value;
	  }else{
		  valor4="";
	  }
	  if(campo5.checked==true){
		  valor5=campo5.value;
	  }else{
		  valor5="";
	  }
	  if(campo6.checked==true){
		  valor6=campo6.value;
	  }else{
		  valor6="";
	  }
	  if(campo7.checked==true){
		  valor7=campo7.value;
	  }else{
		  valor7="";
	  }
	  if(campo8.checked==true){
		  valor8=campo8.value;
	  }else{
		  valor8="";
	  }
	  if(campo9.checked==true){
		  valor9=campo9.value;
	  }else{
		  valor9="";
	  }
	  if(campo10.checked==true){
		  valor10=campo10.value;
	  }else{
		  valor10="";
	  }
	  if(campo11.checked==true){
		  valor11=campo11.value;
	  }else{
		  valor11="";
	  }
	  if(campo12.checked==true){
		  valor12=campo12.value;
	  }else{
		  valor12="";
	  }
	  um=valor1*2/2;
	  dois=valor2*2/2;
	  tres=valor3*2/2;  
	  quatro=valor4*2/2;
	  cinco=valor5*2/2;
	  seis=valor6*2/2;
	  sete=valor7*2/2;
	  oito=valor8*2/2;
	  nove=valor9*2/2;
	  dez=valor10*2/2;
	  onze=valor11*2/2;
	  doze=valor12*2/2;

	 if(um=="" && dois=="" && tres==""&& quatro==""&& cinco==""&& seis==""&& sete==""&& oito==""&& nove==""&& dez==""&& onze==""&& doze==""){
		 document.form.totall.value="";
	 }else{
		 document.form.totall.value=um+dois+tres+quatro+cinco+seis+sete+oito+nove+dez+onze+doze;
	 }
	 if(um=="" && dois==""){
		 document.form.total1.value="";
	 }else{
		 document.form.total1.value=um+dois;
	 }
	 if(tres=="" && quatro==""){
		 document.form.total2.value="";
	 }else{
		 document.form.total2.value=tres+quatro;
	 }
	 if(cinco=="" && seis==""){
		 document.form.total3.value="";
	 }else{
		 document.form.total3.value=cinco+seis;
	 }   
	 if(sete=="" && oito==""){
		 document.form.total4.value="";
	 }else{
		 document.form.total4.value=sete+oito;
	 }
	 if(nove=="" && dez==""){
		 document.form.total5.value="";
	 }else{
		 document.form.total5.value=nove+dez;
	 }
	 if(onze=="" && doze==""){
		 document.form.total6.value="";
	 }else{
		 document.form.total6.value=onze+doze;
	 } 
  }

	function barra(objeto){
		if (objeto.value.length == 2 || objeto.value.length == 5 ){
		objeto.value = objeto.value+"/";
		}
	}

	function validar(obj) { // recebe um objeto
	    var s = (obj.value).replace(/\D/g,'');
	    var tam=(s).length; // removendo os caracteres não numéricos
	    if (!(tam==11 || tam==14)){ // validando o tamanho
	        alert("'"+s+"' N�o � um CPF ou um CNPJ v�lido!" ); // tamanho inválido
	        return false;
	    }
		// se for CPF
    	if (tam==11 ){
        	if (!validaCPF(s)){ // chama a função que valida o CPF
	            alert("'"+s+"' N�o � um CPF v�lido!" ); // se quiser mostrar o erro
	            obj.select();  // se quiser selecionar o campo em questão
	            return false;
	        }
	        obj.value=maskCPF(s);    // se validou o CPF mascaramos corretamente
	        return true;
	    }
		// se for CNPJ
	    if (tam==14){
	        if(!validaCNPJ(s)){ // chama a função que valida o CNPJ
	            alert("'"+s+"' N�o � um CNPJ v�lido!" ); // se quiser mostrar o erro
	            obj.select();    // se quiser selecionar o campo enviado
	            return false;
	        }
	    }
	}

	function validaCPF(s) {
	    var c = s.substr(0,9);
	    var dv = s.substr(9,2);
	    var d1 = 0;
	    for (var i=0; i<9; i++) {
	        d1 += c.charAt(i)*(10-i);
	    }
	    if (d1 == 0) return false;
	    d1 = 11 - (d1 % 11);
	    if (d1 > 9) d1 = 0;
	    if (dv.charAt(0) != d1){
	        return false;
	    }
	    d1 *= 2;
	    for (var i = 0; i < 9; i++)    {
	         d1 += c.charAt(i)*(11-i);
	    }
	    d1 = 11 - (d1 % 11);
	    if (d1 > 9) d1 = 0;
	    if (dv.charAt(1) != d1){
	        return false;
	    }
	    return true;
	}

	function validaCNPJ(CNPJ) {
	    var a = new Array();
	    var b = new Number;
	    var c = [6,5,4,3,2,9,8,7,6,5,4,3,2];
	    for (i=0; i<12; i++){
	        a[i] = CNPJ.charAt(i);
	        b += a[i] * c[i+1];
	    }
	    if ((x = b % 11) < 2) { 
			a[12] = 0 
		} else { 
			a[12] = 11-x 
		}
		b = 0;
		for (y=0; y<13; y++) {
	        b += (a[y] * c[y]);
	    }
	    if ((x = b % 11) < 2) { 
			a[13] = 0; 
		} else { 
			a[13] = 11-x; 
		}
	    if ((CNPJ.charAt(12) != a[12]) || (CNPJ.charAt(13) != a[13])){
	        return false;
	    }
	    return true;
	}

	function soNums(e){
	    if (document.all){
			var evt=event.keyCode;
		}else{
			var evt = e.charCode;
		}
	    if (evt <20 || (evt >47 && evt<58)){
			return true;
		}
	    return false;
	}

	function maskCPF(CPF){
	    return CPF.substring(0,3)+"."+CPF.substring(3,6)+"."+CPF.substring(6,9)+"-"+CPF.substring(9,11);
	}

	function maskCNPJ(CNPJ){
	    return CNPJ.substring(0,2)+"."+CNPJ.substring(2,5)+"."+CNPJ.substring(5,8)+"/"+CNPJ.substring(8,12)+"-"+CNPJ.substring(12,14);
	} 1

	function nu(campo){
		var digits="0123456789"
		var campo_temp 
		for (var i=0;i<campo.value.length;i++){
			campo_temp=campo.value.substring(i,i+1) 
			if (digits.indexOf(campo_temp)==-1){
				campo.value = campo.value.substring(0,i);
				break;
			}
		}
	}

	function ValRG(numero){
		 /*
		 ##  Igor Carvalho de Escobar
		 ##    www.webtutoriais.com
		 ##   Java Script Developer
		 */
		 var numero = numero.split("");
		 tamanho = numero.length;
		 vetor = new Array(tamanho);
		if(tamanho>=1){
			 vetor[0] = parseInt(numero[0]) * 2; 
		}
		if(tamanho>=2){
			 vetor[1] = parseInt(numero[1]) * 3; 
		}
		if(tamanho>=3){
			 vetor[2] = parseInt(numero[2]) * 4; 
		}
		if(tamanho>=4){
			 vetor[3] = parseInt(numero[3]) * 5; 
		}
		if(tamanho>=5){
			 vetor[4] = parseInt(numero[4]) * 6; 
		}
		if(tamanho>=6){
			 vetor[5] = parseInt(numero[5]) * 7; 
		}
		if(tamanho>=7){
			 vetor[6] = parseInt(numero[6]) * 8; 
		}
		if(tamanho>=8){
			 vetor[7] = parseInt(numero[7]) * 9; 
		}
		if(tamanho>=9){
			 vetor[8] = parseInt(numero[8]) * 100; 
		}
		total = 0;
		if(tamanho>=1){
			 total += vetor[0];
		}
		if(tamanho>=2){
			 total += vetor[1]; 
		}
		if(tamanho>=3){
			 total += vetor[2]; 
		}
		if(tamanho>=4){
			 total += vetor[3]; 
		}
		if(tamanho>=5){
			 total += vetor[4]; 
		}
		if(tamanho>=6){
			 total += vetor[5]; 
		}
		if(tamanho>=7){
			 total += vetor[6];
		}
		if(tamanho>=8){
			 total += vetor[7]; 
		}
		if(tamanho>=9){
			 total += vetor[8]; 
		}
		resto = total % 11;
		if(resto!=0){
			document.getElementById('camada').innerHTML="<font face=verdana size=2 color=red>RG Inválido!</font><br><br>";
		}
	}
  </script>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
</head>
<body>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="css/style.css" type="text/css" title="normal" media="screen, projection" />

<title>-= Meta Marketing e Eventos =-</title>
<style type="text/css">
<!--
.TOPO{
width:778px; /*LARGURA*/
height:100px; /*ALTURA*/
background-image:url(img/topo.jpg); /*IMAGEM DO FUNDO*/
background-repeat:no-repeat; /*N�O REPETIR O FUNDO*/
margin:0px auto;
text-align:
}
-->
</style>
</head>
<body>
<div id="mestre">

		<div class="TOPO">
		</div>
</div>
</body>
</html>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#ac1015"><link rel="stylesheet" type="text/css" href="css/sddm.css" >
<br />
<div class="navbar">
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >SITE</div>        

<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:inline;">
        <div class="subItem"><a href="adm_noticias.php">Noticias</a></div>
        <div class="subItem"><a href="adm_aempresa.php">A Empresa</a></div>
		<div class="subItem"><a href="#">Galeria</a></div>
        <div class="subItem"><a href="adm_pri_clientes.php">Principais Clientes</a></div>
        <div class="subItem"><a href="adm_depoimentos.php">Depoimentos</a></div>

        <div class="subItem"><a href="adm_servicos.php">Servi�os</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >EVENTOS/INSCRI��O</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
        <div class="subItem"><a href="adm_eventos.php">Administrar Eventos</a></div>

		<div class="subItem"><a href="menu_principal.php">Nome do Menu</a></div>
        <div class="subItem"><a href="adm_menu.php">Conte�do do Menu</a></div>
        <div class="subItem"><a href="adm_inscricoes.php">Adminstrar Inscri��es</a></div>
        <div class="subItem"><a href="adm_titulo.php">Titulo da Inscri��o</a></div>
		<div class="subItem"><a href="adm_termo.php">Termo de Compromisso</a></div>
		<div class="subItem"><a href="adm_formulario.php">Formulario Online</a></div>

	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem" >CERTIFICADOS</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
        <div class="subItem"><a href="adm_certificados.php">Cadastrar Certificados I.</a></div>
		<div class="subItem"><a href="adm_certificados2.php">Administrar Certificados I.</a></div>

        <div class="subItem"><a href="adm_certificados_trabalhos.php">Cadastrar Certificados T.</a></div>
		<div class="subItem"><a href="adm_certificados_trabalhos2.php">Administrar Certificados T.</a></div>
        <div class="subItem"><a href="adm_etiquetas.php">Emitir Etiquetas</a></div>
	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >

<div class="topItem" >RELAT�RIOS</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
        <div class="subItem"><a href="adm_rela_inscr.php">Relat�rio de Inscri��es</a></div>
		<div class="subItem"><a href="adm_rela_eventos.php">Relat�rio de Eventos</a></div>
        <div class="subItem"><a href="adm_rela_trab.php">Relat�rio de Trabalhos</a></div>
	</div>
</div>

</div>
<!-- *********************************End Menu****************************** -->
<br>
<!-- *********************************Start Menu****************************** -->
<div class="mainDiv" >
<div class="topItem"  >SISTEMA</div>        
<div class="dropMenu" ><!-- -->
	<div class="subMenu" style="display:none;">
		<div class="subItem"><a href="adm_usuarios.php">Usu�rios ADM</a></div>
		<div class="subItem"><a href="adm_usuarios_eventos.php">Usu�rios Eventos</a></div>
		<div class="subItem"><a href="php/sair.php">Sair</a></div>

	</div>
</div>
</div>
<!-- *********************************End Menu****************************** -->
<script type="text/javascript" src="js/xpmenuv21.js"></script>
</div>
<br /></td>
    <td width="578" valign="top">
	  <table width="570" border="0" align="center">
      <tr>
        <td>

<form name="form1" method="post" action="php/alterar_db_inscricoes.php?id_inscricoes=255" enctype="multipart/form-data">
 <input type="hidden" name="editar_eventos" value="1" />
	<input type="hidden" name="email" value="KRSIMAS@BIOF.UFRJ.BR" />
	<input type="hidden" name="nome_evento" value="V Congresso de Geriatria e Gerontologia do Rio de Janeiro" />
	 <table width="575" border="0" align="center" cellpadding="2" cellspacing="2" class="cor_tr texto">
       <tr>
	    <td align="center" bgcolor="#FFFFFF" colspan="2"><input type="image" src="img/ico_salvar.jpg" alt="Salvar" title="Salvar" /><a href="#" onClick="window.print();" style="margin-left:20px;"><input type="image" src="img/impressora.png" border="1" ></a></td>
       </tr>
       <tr>

          <td align="center" class="titulo" colspan="2">:: Alterar Participante ::</td>
       </tr>
	   <tr>
 		  <td>Id do Cliente:</td>
 		  <td>255</td>
	   </tr><tr>
		  <td>Nome Completo:</td>

		  <td><input name="familyname" value="KARLA DA ROCHA RODRIGUES SIMAS" type="text" id="familyname" size="50" /></td>
	   </tr><tr>
			<td>Nome para Crach�:</td>
			<td><input name="nametothebagde" value="KARLA SIMAS" type="text" id="nametothebadge" size="50"/></td>
	   </tr><tr>
		  <td>CPF:</td>
		  <td><input name="cpf" value="013.007.757-77" type="text" id="cpf" size="50"/></td>
		</tr><tr>

		  <td>Identidade:</td>
		  <td><input name="identidade" value="20356501" type="text" id="identidade" size="50"/></td>
		</tr><tr>
			<td>Institui��o:</td>
			<td><input name="instituicao" value="SOLLAR VIVENDAS" type="text" id="instituicao" size="50" /></td>
	    </tr>
		<tr>
			<td>Especialidade:</td>

			<td><input name="especialidade" value="ADMINISTRA��O" type="text" id="especialidade" size="50" /></td>
	    </tr><tr>
			<td>Email:</td>
			<td><input name="email_novo" value="KRSIMAS@BIOF.UFRJ.BR" type="text" id="email_novo" size="50" /></td>
	  </tr>
	  <tr>
			<td>Endere�o:</td>
			<td><input name="mailingadress" type="text" id="mailingadress" size="50" value="RUA HUMAITA  68 COB.01 HUMAITA" /></td>

	  </tr>
	  <tr>
			<td>Cidade:</td>
			<td><input name="city" type="text" id="city" size="50" value="RIO DE JANEIRO" /></td>
	  </tr>
	  <tr>
			<td>Estado:</td>
			<td><input name="provincestate" type="text" id="provincestate" size="50" value="RJ" /></td>

	  </tr><tr>
			<td>CEP:</td>
			<td><input name="zipcode" type="text" id="zipcode" size="50" value="22261001" /></td>
	   </tr>
	   <tr>
			<td>Telefone:</td>
			<td><input name="phone" type="text" id="phone" size="50" value="31-21-22663154" /></td>
	   </tr>

	   <tr>
			<td>FAX:</td>
			<td><input name="fax" type="text" id="fax" size="50" value="31-21-94877126" /></td>
	   </tr>        <table width="100%" border="1" bordercolor="" bgcolor="" cellpadding="0" style="margin-top:0px;" cellspacing="0">
         <tr>
         <td colspan="4" align="center" style="font-family:verdana; font-size:12px"; bgcolor="">
             <strong>Investimentos</strong>

            </td>
         </tr>
         <tr>
          <td width="50%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
             <strong> Categoria</strong>
            </td>
         <td width="21%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
             <strong> At� 02/10/2009</strong>

            </td>
         <td width="21%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
             <strong> No Evento</strong>
            </td>
         <td width="8%" colspan="0" align="center" style="font-family:verdana; font-size:12px";>
             <strong> Total</strong>
            </td>

         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             S�cios Quites da SBGG
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check1' value='270.00' onclick="checar()"/>R$ 270.00
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check2' value='380.00' onclick="checar()"/>R$ 380.00
            </td>

            <td align="left" style="font-family:verdana; font-size:12px";>
             <input type="button" name="total1" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             N�o S�cios
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>

             <input type='checkbox' name='check3' value='380.00' onclick="checar()"/>R$ 380.00
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check4' value='480.00' onclick="checar()"/>R$ 480.00
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>
             <input type="button" name="total2" class="valor" size="5" />
            </td>
         </tr>
         <tr>

          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
          Residentes
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check5' value='340.00' onclick="checar()"/>R$ 340.00
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check6' value='400.00' onclick="checar()"/>R$ 400.00
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>

             <input type="button" name="total3" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
          Estudantes de Gradua��o
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check7' value='200.00' onclick="checar()"/>R$ 200.00
            </td>

            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type='checkbox' name='check8' value='200.00' onclick="checar()"/>R$ 200.00
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>
             <input type="button" name="total4" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>

             Curso "Gerontologia"(*)(**)
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
            <input type="checkbox" name="check9" value="50.00" onclick="checar()" />            R$ 50.00
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
            <input type="checkbox" name="check10" value="50.00" onclick="checar()" />        
            R$ 50.00
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>


             <input type="button" name="total5" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             Oficina 01 "Avalia��o Cognitiva" (*)(**)
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             <input type="checkbox" name="check11" value="50.00" onclick="checar()" /> 
             R$ 50.00
            </td>

            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
            <input type="checkbox" name="check12" value="50" onclick="checar()" />            R$ 50.00
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>
             <input type="button" name="total6" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>

             Oficina 02 "Cuidados Paliativos" (*)(**)
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
            <input type="checkbox" name="check13" value="0" />            gratuito
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
         <input type="checkbox" name="check14" value="0"  />            gratuito
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>

             <input type="button" name="total7" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
             Encontro com Especialista "Incapacidade" (*)(**)
            </td>
            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
            <input type="checkbox" name="check15" value="50"/> 
            gratuito
            </td>

            <td align="left" colspan="0" style="font-family:verdana; font-size:12px";>
            <input type="checkbox" name="check16" value="50"  />            gratuito
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>
             <input type="button" name="total8" class="valor" size="5" />
            </td>
         </tr>
         <tr>
          <td align="left" colspan="3" style="font-family:verdana; font-size:12px";>

             <strong> Total</strong>
            </td>
            <td align="left" style="font-family:verdana; font-size:12px";>
             <input type="button" name="totall" class="valor" size="5" />
            </td>
         </tr>
        </table><br />
   <tr>

			<td align="center" colspan="2"><a href="javascript:history.go(-1)">Voltar</a></td>
	   </tr>
	 </table>
	</form></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>

    </table>
	</td>
  </tr>
</table>
<style type="text/css">
<!--
.RODAPE{
width:778px; /*LARGURA*/
height:24; /*ALTURA*/
margin:0 auto;
}
.ED_RODAPE{

text-align:center; /*ALINHADO AO CENTRO*/
color: #FFFFFF; /*COR DA FONTE*/
font-weight:bold; /*FONTE EM NEGRITO*/
}

-->
</style>
</head>
<body>
<div id="mestre">
 <div class="RODAPE">
	<table width="778" align="center" bgcolor="#ac1015">
 		<tr>

  			<td align="center">
  				<p class="ED_RODAPE"> META MARKETING E EVENTOS todos os direitos Reservados 2009</p>
            </td>
		</tr>
	</table>
</div>
</div>
</body>
</html></body>
</html>