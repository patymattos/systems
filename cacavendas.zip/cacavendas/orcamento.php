<?php

include_once "php/config.php";

$id_pre = $_POST['id_pre_venda'];



		$sql = "SELECT pv.*, c.*, f.FUN_NOME FROM pre_vendas pv, clientes c, funcionario f, produtos p WHERE  id = '$id_pre' AND pv.id_cliente = c.CLI_ID AND pv.id_vendedor = f.FUN_ID ";   

		$qr = mysql_query($sql);   

		$row = mysql_fetch_array($qr);   

		$valor_p = "";

		$valor_s = "";

		$produto_ver = "";

		$servico_ver = "";

		$mecanico_s = "";

		$borracheiro_s = "";

		

		#################

		$quant = explode("/",$row['qtde_produtos']);

		

		

		$select_me = "SELECT * FROM funcionario WHERE FUN_ID = '$row[id_mecanico]'";

		$sql_me = mysql_query($select_me);

		$b = mysql_fetch_array($sql_me);

		$nome_mecanico = $b['FUN_NOME'];

		

		$select_bor = "SELECT * FROM funcionario WHERE FUN_ID = '$row[id_borracheiro]'";

		$sql_bor = mysql_query($select_bor);

		$c = mysql_fetch_array($sql_bor);

		$nome_borracheiro = $c['FUN_NOME'];

		#################

		

		$produto_vp 	= explode("/",$row['valor_produto']);

		$cont_vp		= count($produto_vp);

		

		$servico_sv 	= explode("/",$row['valor_servico']);

		$cont_sv		= count($servico_sv);

		

		$produto_ver2 	= explode("/",$row['id_produtos']);

		$cont_ver2		= count($produto_ver2);

		

		$servico_ver2 	= explode("/",$row['id_servicos']);

		$cont_ser2		= count($servico_ver2);

		

		$mecanico_sv 	= explode("/",$row['id_mecanico']);

		$cont_mec2 		= count($mecanico_sv); 



		$borracheiro_sv	= explode("/",$row['id_borracheiro']);

		$cont_bor2 		= count($borracheiro_sv); 



		$valor_total = $valor_p + $valor_s;

		$data_final = new DateTime($row['data']);  

		$data_final = $data_final->format('d/m/Y');

		

		$dia = date("d");

		$mes = date("m");

		$ano = date("Y");

		

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>-= CACA PNEUS - SISTEMA ADMINISTRATIVO =-</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

    <script type="text/javascript">

	window.print('conteudo');

	</script>

<style type="text/css">

<!--

.style1 {

	font-family: Arial, Helvetica, sans-serif;

	font-weight: bold;

	font-size: 24px;

}

.style2 {

	font-family: Arial, Helvetica, sans-serif;

	font-size: 14px;

}

.style13 {font-size: 13px}

.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }

.style4 {font-family: Arial, Helvetica, sans-serif}

.style10 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; }

-->

</style>

</head>



<body>
<span class="style1">CACA PNEUS</span>

<hr>

<span class="style2">Estrada de Pacheco, s/n� - Lote B 2 B - Lagoinha - S�o Gon�alo<br>

RJ - Cep. 24732-570 - Tels (21) 2602-6404 / 3710-9351

</span>

<hr>  

<div align="left">

  <div align="left"></div>

  <table width="535" border="0">

    <tr>

      <td width="72"><span class="style4">Nome:</span></td>

      <td colspan="5"><b><?=$row['CLI_NOME']?></b></td>

    </tr>

    <tr>

      <td><span class="style4">Endere&ccedil;o: </span></td>

      <td colspan="5"><b><?=$row['CLI_NOME']?></b></td>

    </tr>

    <tr>

      <td><span class="style4">Carro:</span></td>

      <td width="99">&nbsp;</td>

      <td width="48"><span class="style4">Placa:</span></td>

      <td width="115">&nbsp;</td>

      <td width="41"><span class="style4">Data:</span></td>

      <td width="134"><span class="style4"><?=$dia?> / <?=$mes?>/ <?=$ano?></span></td>

    </tr>

  </table>

</div>

<div align="left"></div>

<table width="535" border="0" align="left" bordercolor="#000000" bgcolor="#000000">

  <tr bgcolor="#333333">

    <td width="59"><div align="center"><span class="style13"><span class="style29">QTD.</span></span></div></td>

    <td width="260"><div align="center"><span class="style13"><span class="style29">DISCRIMINA&Ccedil;&Atilde;O</span></span></div></td>

   	<td width="106"><div align="center"><span class="style13"><span class="style29">UNIT&Aacute;RIO (R$)</span></span></div></td>

    <td width="91"><div align="center"><span class="style13"><span class="style29">TOTAL (R$)</span></span></div></td>

  </tr>

	<?php

for($i=0;$i<($cont_ver2-1);$i++){



    $produto_ver 	= $produto_ver2[$i];

    $valor_p 		= $produto_vp[$i];

	

    

    $select 		= "SELECT * FROM produtos WHERE PRD_ID = '$produto_ver'";



    $sql 			= mysql_query($select);

    $a 				= mysql_fetch_array($sql);

    echo "<tr bgcolor='#FFFFFF'>";

    echo "<td><b>".$quant[$i]."</b></td>";

    echo "<td><b>".$a['PRD_NOME']."</b></td>";

    echo "<td><b>".($valor_p/$quant[$i])."</b></td>";

    echo "<td><b>$valor_p</b></td>";

    echo "</tr>";

    $total_p 		=  $total_p + $valor_p;

    

}

for($i=0;$i<($cont_ser2-1);$i++){

    $servico_ver 	= $servico_ver2[$i];

    $mecanico_s 	= $mecanico_sv[$i];				

    $borracheiro_s 	= $borracheiro_sv[$i];

    $valor_s 		= $servico_sv[$i];			

    

    $select 		= "SELECT * FROM servicos WHERE SER_ID = '$servico_ver'";

    $select_mec 	= "SELECT * FROM funcionario WHERE FUN_ID = '$mecanico_s'";

    $select_bor 	= "SELECT * FROM funcionario WHERE FUN_ID = '$borracheiro_s'";

    

    $sql 			= mysql_query($select);

    $sql_mec		= mysql_query($select_mec);

    $sql_bor		= mysql_query($select_bor);

    

    $a				= mysql_fetch_array($sql);

    $a_mec			= mysql_fetch_array($sql_mec);

    $a_bor			= mysql_fetch_array($sql_bor);

    

    echo "<tr bgcolor='#FFFFFF'>";

    echo "<td><b>1</b></td>";

    echo "<td><b>".$a['SER_NOME'] .' - '.$a_mec['FUN_NOME'].' - '.$a_bor['FUN_NOME']."</b></td>";

    echo "<td><b>".$valor_s."</b></td>";

    echo "<td<b>".$valor_s."</b></td>";

    echo "</tr>";

    

    $total_ser = $total_ser + $valor_s;

}

?>

</table>

<br>

<br>

<br>

<table width="535" border="0">

  <tr>

    <td width="447"><div align="right"><span class="style10">TOTAL - R$</span></div></td>

    <td width="78"><?=($total_p+$total_ser)?></td>

  </tr>

</table>

</body>

</html>

