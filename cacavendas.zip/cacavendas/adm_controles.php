<?

session_start();

include ("php/valida_sessao.php");

include ("php/config.php");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= SISTEMA ADMINISTRA��O IGREJA =-</title>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

    <style type="text/css">
<!--
.style3 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; }
.style4 {font-family: Arial, Helvetica, sans-serif}
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 10px;}
-->
    </style>
</head>

<body>

<? include_once "inc_topo.php";
$proj = $_POST['macro2'];

				$select_certo = "SELECT m_estacao FROM macro WHERE proj = '".$proj."'";

				$query = mysql_query($select_certo);

				$result = mysql_fetch_array($query);
				
				$id_proj = $result['m_estacao'];
				

?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu2.php"; ?></td>

    <td width="578">

	<form action="marco/manografia.php" method="post" enctype="multipart/form-data" name="frm" id="frm">

	<table width="570" border="0" align="center">

      <tr>

        <td class='titulo' colspan="4">Lan&ccedil;amentos:</td>
      </tr>
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF">          <table width="557" border="1">
          <tr>
            <td width="89"><div align="center"><span class="style3">DATA</span></div></td>
            <td width="237"><div align="center"><span class="style3">HIST&Oacute;RICO</span></div></td>
            <td width="104"><div align="center"><span class="style3">ENTRADA</span></div></td>
            <td width="99"><div align="center"><span class="style3">SA&Iacute;DA</span></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
          <div align="center"><strong><br />
                <span class="style4">TOTAL: 
                <input name="textfield" type="text" size="16" />
                SALDO:
                <input name="textfield2" type="text" size="16" /> 
                CAIXA:</span></strong>              <input name="textfield3" type="text" size="16" />
          </div></td>
      </tr>

      <tr>
      	<td><br />
      	  <br />
      	  <table width="551" border="0" align="center">
            <tr>
              <td width="78"><img src="img/email_icon_p.jpg" width="32" height="32" /> <span class="style8">Enviar</span></td>
              <td width="101"><span class="style8"><img src="img/Relatorio_Vendedores50x50.gif" width="32" height="32" /> Relat&oacute;rios</span></td>
              <td width="86"><img src="img/add44.png" width="31" height="30" /><span class="style8">Novo</span> </td>
              <td width="78"><img src="img/salvar.jpg" width="31" height="29" /><span class="style8">Salvar</span></td>
              <td width="86"><img src="img/icone4.gif" width="34" height="32" /><span class="style8">Localizar</span></td>
              <td width="82"><img src="img/btExcluir2.gif" width="32" height="32" /><span class="style8">Excluir</span></td>
            </tr>
          </table>      	   </td>
      </tr>

      <tr>

        <td>&nbsp;</td>
      </tr>
    </table>

	</form>

	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</body>

</html>