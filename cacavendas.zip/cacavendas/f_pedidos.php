<?php
include_once "php/config.php";

$id_pre_venda = $_POST['id_pre_venda'];

if($id_pre_venda != ""){
	$select_pre = "SELECT * FROM pre_vendas WHERE id = '$id_pre_venda'";
	$query_pre	= mysql_query($select_pre) or die ("Query - ".$select_pre." erro mysql = ".mysql_error());
	$result 	= mysql_fetch_array($query_pre);
	
	$id 			= $result['id'];
	$data 			= $result['data'];
	$id_cliente		= $result['id_cliente'];
	$id_produtos	= $result['id_produtos'];
	$qtde_produtos	= $result['qtde_produtos'];
	$valor_produtos	= $result['valor_produto'];
	$id_vendedor	= $result['id_vendedor'];
	$id_mecanico	= $result['id_mecanico'];
	$id_borracheiro	= $result['id_borracheiro'];
	$id_servicos	= $result['id_servicos'];
	$valor_servicos	= $result['valor_servico'];
	$id_usuario		= $result['id_usuario'];
	
	$cad_venda = "INSERT INTO vendas_direta(data, id_cliente, id_produtos, qtde_produtos, valor_produto, id_vendedor, id_mecanico, id_borracheiro, id_servicos, valor_servico, id_usuario, id_pre_venda) VALUE ('$data', '$id_cliente', '$id_produtos', '$qtde_produtos', '$valor_produtos', '$id_vendedor', '$id_mecanico', '$id_borracheiro', '$id_servicos', '$valor_servicos', '$id_usuario', '$id')";
	$cad = mysql_query($cad_venda) or die ("Query - ".$cad_venda." erro no cadastro mysql = ".mysql_error());
	
	$sql	= "DELETE FROM pre_vendas WHERE id ='$id'";
	$resultado = mysql_query($sql) or die ("Query - ".$cad_venda." erro no excluir mysql = ".mysql_error());
	
	header("Location: cad_vendas.php");
	
}
else{
echo "<script> alert('Não foi possivel realizar seu pedido, por favor refaça seu orçamento.');location.href='javascript:window.history.go(-1)'; </script>";
}

?>