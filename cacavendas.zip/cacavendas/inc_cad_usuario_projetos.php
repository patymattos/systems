<?
include ("config.php"); //aqui inserimos as v�riaveis da p�gina de configura��o

$ip = $_SERVER["REMOTE_ADDR"];
$ip_inicio= $ip;
$data_hora = date("y.m.d H:i:s");
$inicio=$data_hora;
#$hora = date("H:i:s");
$login = $_POST["login"];
$senha = $_POST["senha"];
$email = $_POST["email"];

################# Altera��o Narcizo #######################
$id_eventoss = $_POST["projetos"];
$id_eventos = $id_eventoss[0];

##### Novos atributos para ser cadastrado no campo novo da tabela ################

$rows= count($id_eventoss);

for($i=0;$i<$rows;$i++){
	$projetos_array .= $id_eventoss[$i].';';
}

###########################################################
$tipo = "projetos_teste/".$_POST["pasta"];


$query="SELECT * FROM usuarios_eventos WHERE login = '$login'";
#print "1. query: $query"; exit();
$pesquisar = mysql_query($query); 
//conferimos se o login escolhido j� n�o foi cadastrado
if(mysql_error() )
{
  print("*** 1. $query ***<br>");
  print "\nMysql error:" . mysql_errno()
    . " : "  . mysql_error() . "<br>";
  exit();
}
#print "2. query: $query"; exit();

$contagem = mysql_num_rows($pesquisar); //traz o resultado da consulta acima

if ( $contagem == 1 ) {
  echo("<script>
      alert(\"Usu�rio j� cadastrado\");
      window.location = '../cad_usuario_projetos.php';
      </script>");
} else {
	if($id_eventos != 'evento'){
  $cadastrar = mysql_query("INSERT INTO usuarios_eventos (id_evento, inicio, ip,
	ip_inicio, data_hora, login, senha, tipo_usuario, email, projetos_array)
    VALUES ('$id_eventos', '$inicio', '$ip', '$ip_inicio','$data_hora', '$login',
	'$senha', '$tipo', '$email', '$projetos_array')"); //insere os campos na tabela
	
	### Para funcionar no WHN o php.ini tem que esta configurado a parte upload_tmp_dir com o valor /tmp ##############
	### Aqui vai criar a pasta no diretorio projetos_teste se n�o houver essa pasta ela vai ser criada ################
	
	$diretorio = "../projetos_teste/".$tipo;
 		mkdir($diretorio);
 		chmod ($diretorio,0777);

	}
if(mysql_error() )
{
  print("*** 2. $query ***<br>");
  print "\nMysql error:" . mysql_errno()
    . " : "  . mysql_error() . "<br>";
  exit();
}

    if ( $cadastrar == 1 ) {
      echo("<script>
      alert(\"Cadastrado efetuado com sucesso\");
      window.location = '../adm_usuarios_projetos.php';
      </script>"); //se cadastrou com sucesso o usu�rio aparece essa mensagem
      } else {
  print("*** 2. $query ***<br>");
  print "\nMysql error:" . mysql_errno()
    . " : "  . mysql_error() . "<br>";

	echo("<script>
      alert(\"Ocorreu um erro no servidor\");
      window.location = '../cad_usuario_projetos.php';
      </script>");  }
  } 
?>
