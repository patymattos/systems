<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          //validar c�digo
         if (d.C_CLI.value == ""){
                   alert("O campo c�digo deve ser preenchido!");
                   d.C_CLI.focus();
                   return false;
         }
      
	  
	      //validar D_VALOR
         if (d.C_DATA.value == ""){
                   alert("O campo data deve ser preenchido!");
                   d.C_DATA.focus();
                   return false;
         }
         
		   //validar C_NOME
           if (d.C_NOME.value == ""){
                     alert("O campo motivo deve ser preenchido!");
                     d.C_NOME.focus();
                     return false;
           }
         //validar senha
         if (d.senha.value == ""){
                   alert("O campo " + d.senha.name + " deve ser preenchido!");
                   d.senha.focus();
                   return false;
         }
         //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.C_EMAIL.value.indexOf("@");
         parte2 = d.C_EMAIL.value.indexOf(".");
         parte3 = d.C_EMAIL.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo email deve ser conter um endereco eletronico!");
                   d.C_EMAIL.focus();
                   return false;
         }
         //validar C_TEL
         if (d.C_TEL.value == ""){
                   alert ("O campo telefone deve ser preenchido!");
                   d.C_TEL.focus();
                   return false;
         }
         //validar C_TEL(verificacao se contem apenas numeros)
         if (isNaN(d.C_TEL.value)){
                   alert ("O campo telefone deve conter apenas numeros!");
                   d.C_TEL.focus();
                   return false;
         }
		
         //validar C_TEL(verificacao se contem apenas numeros)
         if (isNaN(d.C_CEL.value)){
                   alert ("O campo celular deve conter apenas numeros!");
                   d.C_CEL.focus();
                   return false;
         }
         
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }




</script>
<form name="cadastro" action="salvarcli.php" method="post" onSubmit="return validaForm()">
  <table width="569" border="0">
    <tr>
      <td colspan="2"><table width="396" border="0" align="right">
        <tr>
          <td><input name="textfield11" type="text" size="60" /></td>
          <td><img src="img/icone4.gif" width="24" height="22" /></td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td width="169"><span class="style4">C&oacute;digo:</span></td>
      <td width="390"><input name="C_ID" type="text" id="C_ID2" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Data de Cadastro: </span></td>
      <td><input name="C_DATA" type="text" id="C_DATA" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Nome Completo: </span></td>
      <td><input name="C_NOME" type="text" id="C_NOME" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Endere&ccedil;o:</span></td>
      <td><input name="C_END" type="text" id="C_END" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Cidade:</span></td>
      <td><input name="C_CIDADE" type="text" id="C_CIDADE" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Estado:</span></td>
      <td><input name="C_ESTADO" type="text" id="C_ESTADO" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Cep:</span></td>
      <td><input name="C_CEP" type="text" id="C_CEP" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Email:</span></td>
      <td><input name="C_EMAIL" type="text" id="C_EMAIL" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Telefone:</span></td>
      <td><input name="C_TEL" type="text" id="C_TEL" size="65" /></td>
    </tr>
    <tr>
      <td><span class="style4">Celular:</span></td>
      <td><input name="C_CEL" type="text" id="C_CEL" size="65" /></td>
    </tr>
    <tr>
      <td colspan="2"><div align="center">
        <input name="enviar" type="image" img" src="images/ico_cadastrar.jpg" value="enviar" border="0" />
      </div></td>
    </tr>
  </table>
</form>
</body>
</html>