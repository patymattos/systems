<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>:: Cadastro de Ve�culo ::</title>
<link href="custom.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style5 {
	color: #666666;
	font-weight: bold;
}
.style5 {
	color: #FFFFFF;

	font-weight: bold;

	font-family: Geneva, Arial, Helvetica, sans-serif;
}
.style8 {font-size: 12px}
.style10 {color: #666666; font-weight: bold; font-family: Geneva, Arial, Helvetica, sans-serif; }
.style11 {color: #666666}
-->
</style>

<script language="Javascript" src="js/jquery-1.3.2.js" ></script>
<script language="Javascript" src="js/jquery.meio.mask.js" ></script>
<script language="Javascript">
	(function($){
	    
	    $(function(){
	        $('input:text').setMask();
	    });
		    
	})(jQuery);
</script>
</head>
<body >
<form method="post" action="webapp/gravaCadastro.php">

<?php if(isset($idVeiculo)) :?>
	<input type="hidden" name="id" value="<?php echo $idVeiculo; ?>" />
<?php endif ;?>

  <table width="556" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td width="556"><img src="images/top.gif" width="555" height="6"></td>
    </tr>
    <tr>
      <td><table width="94%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="388"><img src="images/logo.gif" width="556" height="58"></td>
          </tr>
      </table></td>
    </tr>
    <tr>
      <td><img src="images/top01.gif" width="555" height="24"></td>
    </tr>
    <tr>
      <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>
            <table width="72%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="231"><img src="images/pix01.gif" width="231" height="202"></td>
              <td><table width="59%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td valign="top" class="bg_slogan"><table width="97%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td height="80">&nbsp;</td>
                    </tr>

                    <tr>
                      <td class="txt_slogan01">Seja Bem Vindo ao</td>
                    </tr>
                    <tr>
                      <td class="txt_slogan">Sistema S&atilde;o Sebasti&atilde;o</td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td><img src="images/pix03.gif" width="325" height="75"></td>
                </tr>
              </table></td>
            </tr>
          </table></td>
        </tr>

      </table></td>
    </tr>
    <tr>
      <td><table  width="551" border="0" align="left" bgcolor="#E7E7E7">
        <tr>
          <td colspan="4"><div align="justify"><span class="style10"><br />
                    <span class="style8">CADASTRO DOS VEICULOS</span></span><br />
                    <br />
          </div></td>
        </tr>


		<?php if ($_GET['st'] == "0"): ?>
			<tr>
				<td colspan="4">
					<span style="color:#ff0000">
                    N&atilde;o foi poss&iacute;vel efetuar o cadastro. Verifique os dados informados.
                    <br />
                    </span>
					
				</td>
			</tr>
		<?php else : ?>
			<?php if ($_GET['st'] == "1") :?>
            <tr>
                <td colspan="4">
                    <span style="color:#0066CC">Cadastro efetuado com sucesso.
                    <br />
                    </span>
                </td>
            </tr>
            <?php endif; ?>
		<?php endif;?>


        <tr>
          <td><span class="style10">Tipo Ve&iacute;culo: </span></td>
          <td><input name="tipoVeiculo" type="text" id="nome3" value="<?php echo $row["tipoVeiculo"]?>" size="45" /></td>
          <td><span class="style10">Ano: </span></td>
          <td><input name="ano" type="text" id="integer"  value="<?php echo $row["ano"]?>"  size="40" /></td>
        </tr>
        <tr>
          <td width="70"><span class="style10">
            <label for="label">Marca:</label>
          </span></td>
          <td width="183"><input name="marca"  value="<?php echo $row["marca"]?>" type="text" id="nome4" size="45" /></td>
          <td width="90"><span class="style10">Modelo:</span></td>
          <td width="194"><input name="modelo" type="text" id="nome"  value="<?php echo $row["modelo"]?>" size="40" /></td>
        </tr>
        <tr>
          <td><span class="style10">
          <label for="label">Placa:</label>
          </span></td>
          <td><input name="placa" type="text" id="nome9"  value="<?php echo $row["placa"]?>" size="45" /></td>
          <td><span class="style10">KM:</span></td>
          <td><input name="km" type="text" id="decimal"  value="<?php echo number_format($row["km"],3,",","."); ?>"  size="40" /></td>
        </tr>
        <tr>
          <td><span class="style10">
            <label for="label">Valor:</label>
          </span></td>
          <td><input name="valorVeiculo" type="text" id="decimal"  value="<?php echo number_format($row["valorVeiculo"],2,",",".")?>" alt="decimal" size="19" /></td>
          <td><span class="style10">&Oacute;leo de motor:</span></td>
          <td><input name="dataOleoMotor" type="text" id="empresa" size="40"   value="<?php echo $row["dataOleoMotor"]?>" /></td>
        </tr>
        <tr>
          <td><span class="style10">
            <label for="label">Pneu:</label>
          </span></td> 
          <td><input name="dataPneu" type="text"   alt="integer" value="<?php echo $row["dataPneu"]?>" size="35" /></td>
          <td><span class="style10">Filtro de &Oacute;leo:</span></td>
          <td><input name="dataFiltroOleo" type="text"    value="<?php echo $row["dataFiltroOleo"]?>" size="30" /></td>
        </tr>
        <tr>
          <td><span class="style10">
            <label for="label"></label>
          Filtro de ar:</span></td>
          <td><input name="dataFiltroAr" type="text"  size="40"   value="<?php echo $row["dataFiltroAr"]?>" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td><span class="style10">Hist&oacute;rico</span></td>
          <td colspan="3"><textarea cols="55" rows="6" name="historico" id="historico"><?php echo $row["historico"]?></textarea></td>
        </tr>
        <tr>
          <td><span class="style10">Observa&ccedil;&otilde;es:</span></td>
          <td colspan="3"><textarea cols="55" rows="6" name="obs" id="obs"><?php echo $row["obs"]?></textarea></td>
        </tr>
        <tr>
          <td colspan="4">
			<div align="center">
			<img src="images/botaonovo.jpg" width="91" height="32" onclick="window.location='cadastro.php'" style="cursor:pointer">
			<img src="images/botaolocalizar.jpg" width="91" height="32" onclick="window.location='busca_cadastro.php'" style="cursor:pointer">
			<img src="images/botaosalvar.jpg" width="91" onclick="document.forms[0].submit()" height="32" style="cursor:pointer">
		</div>
			</td>
        </tr>
      </table></td>
    </tr>
    <tr>

      <td><div align="center"><a href="http://www.softwaresworld.com.br" target="_blank"><br>
            <br>
          Copyright &copy; Softwares World</a><br>
<br>
</div>
      <div align="center"></div></td>
    </tr>


    <tr>

      <td><img src="images/top.gif" width="555" height="6"></td>
    </tr>
  </table>

</form>

</body>

</html>

