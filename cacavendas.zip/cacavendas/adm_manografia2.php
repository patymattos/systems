<?

session_start();

include ("php/valida_sessao.php");

include ("php/config.php");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= True Life Geomensura =-</title>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

</head>

<body>

<? include_once "inc_topo.php";
$proj = $_POST['macro2'];

				$select_certo = "SELECT m_estacao FROM macro WHERE proj = '".$proj."'";

				$query = mysql_query($select_certo);

				$result = mysql_fetch_array($query);
				
				$id_proj = $result['m_estacao'];
				

?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu2.php"; ?></td>

    <td width="578">

	<form action="marco/manografia.php" method="post" enctype="multipart/form-data" name="frm" id="frm">

	<table width="570" border="0" align="center">

      <tr>

        <td>Selecionar Marco:</td>
      </tr>
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><select name="macro2">
            <option selected="selected">---Escolha um Marco---</option>
             <?

				$select_certo = "SELECT m_estacao FROM macro WHERE proj = '".$proj."'";
				
				$query = mysql_query($select_certo);

				while ($result = mysql_fetch_array($query)) {
				
				$id_proj = $result['m_estacao'];
				
				
				

				
				$resultado = mysql_query("SELECT m_estacao FROM macro WHERE m_estacao = '$id_proj' ORDER BY m_estacao ASC");
				
				$sql = mysql_fetch_array($resultado);

				
					echo "<option value='".$sql['m_estacao']."'>".$sql['m_estacao']."</option>'";

				
}
				
			?>
          </select> 
          <input type="hidden" name="macro" value="<?=$proj?>" /> 
                 </td>
      </tr>

      <tr>

      	<td><input name="OK" type="submit"  value="OK"/></td>
      </tr>

      <tr>

        <td>&nbsp;</td>
      </tr>
    </table>

	</form>

	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</body>

</html>