<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
           //validar D_MOTIVO
           if (d.D_MOTIVO.value == ""){
                     alert("O campo " + d.D_MOTIVO.name + " deve ser preenchido!");
                     d.D_MOTIVO.focus();
                     return false;
           }
          //validar user
         if (d.user.value == ""){
                   alert("O campo " + d.user.name + " deve ser preenchido!");
                   d.user.focus();
                   return false;
         }
         //validar senha
         if (d.senha.value == ""){
                   alert("O campo " + d.senha.name + " deve ser preenchido!");
                   d.senha.focus();
                   return false;
         }
         //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         if (d.telefone.value == ""){
                   alert ("O campo " + d.telefone.name + " deve ser preenchido!");
                   d.telefone.focus();
                   return false;
         }
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.telefone.value)){
                   alert ("O campo " + d.telefone.name + " deve conter apenas numeros!");
                   d.telefone.focus();
                   return false;
         }
         //validar data de nascimento
         erro=0;
         hoje = new Date();
         anoAtual = hoje.getFullYear();
         barras = d.D_DATA.value.split("/");
         if (barras.length == 3){
                   dia = barras[0];
                   mes = barras[1];
                   ano = barras[2];
                   resultado = (!isNaN(dia) && (dia > 0) && (dia < 32)) && (!isNaN(mes) && (mes > 0) && (mes < 13)) && (!isNaN(ano) && (ano.length == 4) && (ano <= anoAtual && ano >= 1900));
                   if (!resultado) {
                             alert("Formato de data invalido!");
                             d.D_DATA.focus();
                             return false;
                   }
         } else {
                   alert("Formato de data invalido!");
                   d.D_DATA.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="teste.php" method="post" onSubmit="return validaForm()">
          <table width="40%" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td><span class="style4">Data:</span></td>
              <td><span class="style4">
              <input name="D_DATA" type="text">
    (dd/mm/yyyy)</span></td>
            </tr>
            <tr>
              <td><span class="style4">Motivo:</span></td>
              <td><input name="D_MOTIVO" type="text"></td>
            </tr>
            <tr>
              <td><span class="style4">Valor: </span></td>
              <td><input name="D_VALOR" type="text" id="D_VALOR" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Total:</span></td>
              <td><input name="D_TOTAL" type="text" id="D_TOTAL" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Total Dinheiro: </span></td>
              <td><input name="D_DINHEIRO" type="text" id="D_DINHEIRO" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Total Cheque:</span></td>
              <td><input name="D_CHEQUE" type="text" id="D_CHEQUE" size="40" /></td>
            </tr>
                    <tr> 
                              <td colspan="2">
                                        <div align="right"> 
                                        <input name="enviar" type="submit" value="enviar">
                                        </div>
                              </td>
                    </tr>
  </table>
</form>
</body>
</html>