<html>

<style type="text/css">

<!--

.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }

.style11 {font-family: Arial, Helvetica, sans-serif}

.style12 {font-size: 14px}

-->

</style>

<form name="alterar" action="alt_produtos.php" method="post">

          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td><span class="style4">Refer&ecirc;ncia:</span></td>
              <td><input name="ref" <?=$ref?> type="text" size="40" /></td>
            </tr>

            <tr>

              <td width="115"><span class="style4">Ano:</span></td>

              <td width="415"><input name="ano" type="text" id="ano" size="40" <?=$ano?> /></td>

            </tr>

            <tr>

              <td><span class="style4">Produto/Carro: </span></td>

              <td><input name="nome" <?=$nome?> type="text" size="40" /></td>

            </tr>

            <tr>

              <td><span class="style5 style11 style12">Descri&ccedil;&atilde;o/Pot&ecirc;ncia:</span></td>

              <td><input name="desc" <?=$desc?> type="text" size="40" /></td>

            </tr>

            <tr>

              <td><span class="style5 style11 style12">Marca:</span></td>

              <td><input name="marca" <?=$marca?> type="text" size="40" /></td>

            </tr>

            <tr>

              <td><span class="style5 style11 style12">Quantidade:</span></td>

              <td><input name="quant" <?=$quant?> type="text" size="40" /></td>

            </tr>

            <tr>

              <td><span class="style5 style11 style12">Pre&ccedil;o de Custo:</span></td>

              <td><input name="custo" <?=$custo?> type="text" size="40" /></td>

            </tr>
            <tr>
              <td><span class="style5 style11 style12">% Comiss&atilde;o:</span></td>
              <td><input name="pcomissao" type="text" id="pcomissao" size="40" <?=$pcom?> /></td>
            </tr>

            <tr>

              <td><span class="style5 style11 style12">Pre&ccedil;o de Venda:</span></td>

              <td><input name="venda" <?=$venda?> type="text" size="40" /></td>

            </tr>
            <tr>
              <td><span class="style5 style11 style12">Fornecedor:</span></td>
              <td><select name="forn">
                  <?

					echo $forn;

				$resultado = mysql_query("SELECT DISTINCT FOR_NOME FROM fonecedor ORDER BY FOR_NOME ASC");



				while($sql = mysql_fetch_array($resultado))



				{



					echo "<option value='$sql[FOR_NOME]'>".substr ($sql[FOR_NOME],0,50)."...</option>'";



				}



			?>
              </select></td>
            </tr>

            <tr>

              <td><span class="style5 style11 style12">Observa&ccedil;&atilde;o:</span></td>

              <td><input name="obs" type="text" id="obs" size="40" <?=$obs?> /></td>

            </tr>

                    <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br>
                              </div></td>

                    </tr>

  </table>

</form>

</body>

</html>