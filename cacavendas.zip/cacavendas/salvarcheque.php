<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	
	$CC_DATA =$_POST['scdia'];
	$CC_DATA1 =$_POST['scmes'];
	$CC_DATA2 =$_POST['scano'];

	$CC_NOME =$_POST['CH_NOME'];

	$CC_BCO =$_POST['CH_BCO'];
	
	$CC_NUM =$_POST['CH_NUM'];
  	
	$CC_VALOR =$_POST['CH_VALOR'];
	
	$CC_DES =$_POST['CH_DES'];

	$CC_TELCLI =$_POST['CH_TELCLI'];

	
	$CC_DT =$_POST['sccdia'];
	$CC_DT1 =$_POST['sccmes'];
	$CC_DT2 =$_POST['sccano'];

	
	$CC_DESC =$_POST['CH_DESC'];


	
	

	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO cheques (CHQ_ID,CHQ_DATA,CHQ_DATA1,CHQ_DATA2,CHQ_NOME,CHQ_BCO,CHQ_NUM,CHQ_VALOR,CHQ_DES,CHQ_TELCLI,CHQ_DT,CHQ_DT1,CHQ_DT2,CHQ_DESC)
	VALUES ('','$CC_DATA','$CC_DATA1','$CC_DATA2','$CC_NOME','$CC_BCO','$CC_NUM','$CC_VALOR','$CC_DES','$CC_TELCLI','$CC_DT','$CC_DT1','$CC_DT2','$CC_DESC')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_cheques.php");



?>	

 