<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style5 {font-family: Arial, Helvetica, sans-serif}
.style9 {font-size: 14}
.style10 {font-size: 14px}
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          
         
		   //validar C_ID
           if (d.S_REF.value == ""){
                     alert("Informe  a refer�ncia do servi�o.");
                     d.S_REF.focus();
                     return false;
           }
                
         
		 //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.FU_TEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_TEL.focus();
                   return false;
         }
         
		 if (isNaN(d.FU_CEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_CEL.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvarserv.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td width="115"><span class="style4">Refer&ecirc;ncia: </span></td>
              <td width="415"><input name="S_REF" type="text" id="S_REF" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Servi&ccedil;o:</span></td>
              <td><input name="S_NOME" type="text" id="S_NOME" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">% Porcentagem:</span></td>
              <td><input name="S_PORC" type="text" id="S_PORC" <?=$CS_PORC?> size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Descri&ccedil;&atilde;o:</span></td>
              <td><input name="S_DESC" type="text" id="S_DESC" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Pre&ccedil;o:</span></td>
              <td><input name="S_CUSTO" type="text" id="S_CUSTO" size="40" /></td>
            </tr>
                    <tr> 
                              <td colspan="2">                                <div align="center">
                                  <br>
                                  <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
                      </div></td>
                    </tr>
  </table>
</form>
</body>
</html>