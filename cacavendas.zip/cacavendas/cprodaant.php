<?php
include_once "php/config.php";
?>
<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
</style>
<script>
function validaForm(){
           d = document.cadastro;
          
         
		   //validar ref
           if (d.ref.value == ""){
                     alert("Informe a refer�ncia de produto.");
                     d.ref.focus();
                     return false;
           }
         //validar nome
         if (d.nome.value == ""){
                   alert("Informe a nome de produto.");
                   d.nome.focus();
                   return false;
         }
         if (d.quant.value == ""){
                   alert("Informe a quantidade de produto.");
                   d.quant.focus();
                   return false;
         }
         
		 //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         if (d.telefone.value == ""){
                   alert ("O campo " + d.telefone.name + " deve ser preenchido!");
                   d.telefone.focus();
                   return false;
         }
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.telefone.value)){
                   alert ("O campo " + d.telefone.name + " deve conter apenas numeros!");
                   d.telefone.focus();
                   return false;
         }
         
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvarprod.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td width="115"><span class="style4">Refer&ecirc;ncia:</span></td>
              <td width="415"><input name="ref" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Produto: </span></td>
              <td><input name="nome" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">Descri&ccedil;&atilde;o:</span></td>
              <td><input name="desc" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">Marca:</span></td>
              <td><input name="marca" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">Quantidade:</span></td>
              <td><input name="quant" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">% Comiss&atilde;o:</span></td>
              <td><input name="comis" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">Pre&ccedil;o de Custo:</span></td>
              <td><input name="custo" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">Pre&ccedil;o de Venda:</span></td>
              <td><input name="venda" type="text" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style5 style11 style12">Fornecedor:</span></td>
              <td><select name="forn">
                  <?

					echo $forn;

				$resultado = mysql_query("SELECT DISTINCT FOR_NOME FROM fonecedor ORDER BY FOR_NOME ASC");



				while($sql = mysql_fetch_array($resultado))



				{



					echo "<option value='$sql[FOR_NOME]'>".substr ($sql[FOR_NOME],0,50)."...</option>'";



				}



			?>
              </select></td>
            </tr>
                    <tr> 
                              <td colspan="2">                                <div align="center">
                                  <br>
                                  <input type="image" img src="images/ico_cadastrar.jpg" value="enviar">
                      </div></td>
                    </tr>
  </table>
</form>
</body>
</html>