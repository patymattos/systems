<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style5 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
-->
</style>
</head>

<body>
<form action="salvar.php" method="post">
<table width="569" border="0">
  <tr>
    <td width="113"><span class="style5">Data:</span></td>
    <td width="446"><span class="style10">
      <input name="vec" type="text" size="40" />
      (Ex. 00/00/0000) </span></td>
  </tr>
  <tr>
    <td><span class="style5">Refer&ecirc;ncia: </span></td>
    <td><input name="ref" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5">Nome:</span></td>
    <td><input type="text" name="nome" /></td>
  </tr>
  <tr>
    <td><span class="style5">Descri&ccedil;&atilde;o:</span></td>
    <td><input name="desc" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5">Marca:</span></td>
    <td><input name="marca" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5">Quantidade:</span></td>
    <td><input name="quant" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5">Pre&ccedil;o de Custo:</span></td>
    <td><input name="custo" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5">Pre&ccedil;o de Venda:</span></td>
    <td><input name="venda" type="text" size="40" /></td>
  </tr>
  <tr>
    <td><span class="style5">Fornecedor:</span></td>
    <td><select name="forn">
        <option>FORNECEDOR1</option>
        <option>FORNECEDOR2</option>
    </select></td>
  </tr>
</table>
<br>
<input type="submit" name="Submit" value="Submit">
</form>
</body>
</html>
