<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style5 {font-family: Arial, Helvetica, sans-serif}
.style10 {font-size: 14px}
-->
</style>
<script>
function validaForm(){
           d = document.cadastro;
          
         
		   //validar C_ID
           if (d.CH_DATA.value == ""){
                     alert("Informe  a data do cheque.");
                     d.CH_DATA.focus();
                     return false;
           }
		    if (d.CH_NOME.value == ""){
                     alert("Informe o nome do cliente.");
                     d.CH_NOME.focus();
                     return false;
           }
                
         
		 //validar email
         if (d.email.value == ""){
                   alert("O campo " + d.email.name + " deve ser preenchido!");
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletr�nico)
         parte1 = d.email.value.indexOf("@");
         parte2 = d.email.value.indexOf(".");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
                   alert ("O campo " + d.email.name + " deve ser conter um endereco eletronico!");
                   d.email.focus();
                   return false;
         }
         //validar telefone
         
         //validar telefone(verificacao se contem apenas numeros)
         if (isNaN(d.FU_TEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_TEL.focus();
                   return false;
         }
         
		 if (isNaN(d.FU_CEL.value)){
                   alert ("O campo deve conter apenas numeros!");
                   d.FU_CEL.focus();
                   return false;
         }
         //validar sexo
         if (!d.sexo[0].checked && !d.sexo[1].checked) {
                   alert("Escolha o sexo!")
                   return false;
         }
         return true;
 }

</script>
<form name="cadastro" action="salvarcheque.php" method="post" onSubmit="return validaForm()">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td width="115"><span class="style4">Data:</span></td>
              <td width="415"><select name="scdia" id="scdia">
                <option>01</option>
                <option>02</option>
                <option>03</option>
                <option>04</option>
                <option>05</option>
                <option>06</option>
                <option>07</option>
                <option>08</option>
                <option>09</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
                <option>13</option>
                <option>14</option>
                <option>15</option>
                <option>16</option>
                <option>17</option>
                <option>18</option>
                <option>19</option>
                <option>20</option>
                <option>21</option>
                <option>22</option>
                <option>23</option>
                <option>24</option>
                <option>25</option>
                <option>26</option>
                <option>27</option>
                <option>28</option>
                <option>29</option>
                <option>30</option>
                <option>31</option>
              </select>
                <select name="scmes" id="scmes">
                  <option>01</option>
                  <option>02</option>
                  <option>03</option>
                  <option>04</option>
                  <option>05</option>
                  <option>06</option>
                  <option>07</option>
                  <option>08</option>
                  <option>09</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                </select>
                <select name="scano" id="scano">
                  <option>2005</option>
                  <option>2006</option>
                  <option>2007</option>
                  <option>2008</option>
                  <option>2009</option>
                  <option>2010</option>
                  <option>2011</option>
                  <option>2012</option>
                  <option>2013</option>
                  <option>2014</option>
                  <option>2015</option>
                </select>                
                </td>
            </tr>
            <tr>
              <td><span class="style4">Nome Completo: </span></td>
              <td><input name="CH_NOME" type="text" id="CH_NOME" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Banco: </span></td>
              <td><input name="CH_BCO" type="text" id="CH_BCO" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">N&uacute;mero:</span></td>
              <td><input name="CH_NUM" type="text" id="CH_NUM" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Valor:</span></td>
              <td>                <input name="CH_VALOR" type="text" id="CH_VALOR" size="40" /></td></tr>
            <tr>
              <td><span class="style4">Destino:</span></td>
              <td><input name="CH_DES" type="text" id="CH_DES" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Tel. do Cliente:</span></td>
              <td><input name="CH_TELCLI" type="text" id="CH_TELCLI" size="40" /></td>
            </tr>
            <tr>
              <td><span class="style4">Data de troca:</span></td>
              <td><select name="sccdia" id="sccdia">
                <option>01</option>
                <option>02</option>
                <option>03</option>
                <option>04</option>
                <option>05</option>
                <option>06</option>
                <option>07</option>
                <option>08</option>
                <option>09</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
                <option>13</option>
                <option>14</option>
                <option>15</option>
                <option>16</option>
                <option>17</option>
                <option>18</option>
                <option>19</option>
                <option>20</option>
                <option>21</option>
                <option>22</option>
                <option>23</option>
                <option>24</option>
                <option>25</option>
                <option>26</option>
                <option>27</option>
                <option>28</option>
                <option>29</option>
                <option>30</option>
                <option>31</option>
              </select>
                <select name="sccmes" id="select2">
                  <option>01</option>
                  <option>02</option>
                  <option>03</option>
                  <option>04</option>
                  <option>05</option>
                  <option>06</option>
                  <option>07</option>
                  <option>08</option>
                  <option>09</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                </select>
                <select name="sccano" id="select3">
                  <option>2005</option>
                  <option>2006</option>
                  <option>2007</option>
                  <option>2008</option>
                  <option>2009</option>
                  <option>2010</option>
                  <option>2011</option>
                  <option>2012</option>
                  <option>2013</option>
                  <option>2014</option>
                  <option>2015</option>
                </select></td>
            </tr>
            <tr>
              <td><span class="style4">Descri&ccedil;&atilde;o:</span></td>
              <td><input name="CH_DESC" type="text" id="CH_DESC" size="40" /></td>
            </tr>
            <tr>
              <td colspan="2"><div align="center">
                <br>
                <input name="enviar" type="image" img src="images/ico_cadastrar.jpg" value="enviar" border="0">
              </div></td>
            </tr>
  </table>
</form>
</body>
</html>