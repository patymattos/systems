<html>
<style type="text/css">
<!--
.style4 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style11 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 14px}
-->
</style>
<form name="alterarcli" action="alt_clientes.php" method="post">
          <table width="550" border="0" cellpadding="5" cellspacing="0" bordercolor="#000000">
            <tr>
              <td colspan="2"><table width="396" border="0" align="right">
                <tr>
                  
                </tr>
              </table></td>
            </tr>
            <tr>
              <td width="115"><span class="style4">C&oacute;digo:</span></td>
              <td width="415"><input name="C_COD" <?=$CL_COD?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Nome Completo: </span></td>
              <td><input name="C_NOME" <?=$CL_NOME?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">CPF/CNPJ:</span></td>
              <td><input name="C_CC" <?=$CL_CC?> type="text" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">RG:</span></td>
              <td><input name="C_RG" <?=$CL_RG?> type="text" size="65"></td>
            </tr>
            <tr>
              <td><span class="style4">Endere&ccedil;o:</span></td>
              <td><input name="C_END" <?=$CL_END?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Cidade:</span></td>
              <td><input name="C_CIDADE" <?=$CL_CIDADE?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Estado:</span></td>
              <td><input name="C_ESTADO" <?=$CL_ESTADO?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Cep:</span></td>
              <td><input name="C_CEP" <?=$CL_CEP?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Email:</span></td>
              <td><input name="C_EMAIL" <?=$CL_EMAIL?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Telefone:</span></td>
              <td><input name="C_TEL" <?=$CL_TEL?> type="text" size="65" /></td>
            </tr>
            <tr>
              <td><span class="style4">Celular:</span></td>
              <td><input name="C_CEL" <?=$CL_CEL?> type="text" size="65" /></td>
            </tr>
                       <tr> 

                              <td colspan="2">                                <div align="center">

                                  <br><input type="hidden" name="id_produto" value="<?=$cli?>">

                                  <input name="enviar" type="image" img src="images/ico_salvar.jpg" value="enviar" border="0">

                      </div></td>

                    </tr>

  </table>
</form>
</body>
</html>