<?php

header('Content-Type: text/html; charset=utf-8');

include_once "php/config.php";



$id_produto = $_POST['id_produto'];

	$FU_TIPO = $_POST['F_TIPO'];
	
	$FU_DATA = $_POST['F_DATA'];

	$FU_NOME = $_POST['F_NOME'];

	$FU_CC = $_POST['F_CC'];

	$FU_RG = $_POST['F_RG'];

	$FU_END = $_POST['F_END'];
  	
	$FU_CIDADE = $_POST['F_CIDADE'];
	
	$FU_ESTADO = $_POST['F_ESTADO'];
	
	$FU_CEP = $_POST['F_CEP'];
	 	
	$FU_EMAIL = $_POST['F_EMAIL'];

	$FU_TEL = $_POST['F_TEL'];

	$FU_CEL = $_POST['F_CEL'];



if($FU_TIPO != "" && $FU_NOME != "" && FU_CC != "" && $FU_RG != "" && $FU_TEL != ""){

	$up = "UPDATE funcionario SET

	FUN_TIPO = '$FU_TIPO',
	
	FUN_DATA = '$FU_DATA',
	
	FUN_NOME = '$FU_NOME',
	
	FUN_CC = '$FU_CC',
	
	FUN_RG = '$FU_RG',
	
	FUN_END = '$FU_END',
	
	FUN_CIDADE = '$FU_CIDADE',
	
	FUN_ESTADO = '$FU_ESTADO',
	
	FUN_CEP = '$FU_CEP',
	
	FUN_EMAIL = '$FU_EMAIL', 
	
	FUN_TEL = '$FU_TEL',
	
	FUN_CEL = '$FU_CEL'
	
	WHERE FUN_ID = '$id_produto'";
	
	$cad = mysql_query($up);

	

	echo "<script>alert('Funcionário alterado com sucesso');location.href='alterar_funcionario.php?tr=$id_produto'; </script>";

}

else{

	echo "<script>alert('Verifiqque se um dos campos abaixo não foi definido:\\n - TIPO\\n - NOME\\n - CPF/CNPJ\\n - TELEFONE\\n - CELULAR');location.href='javascript:window.history.go(-1)'; </script>";

	exit();

}

?>