<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style13 {font-size: 13px}
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 10px;}
.style11 {	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="471" border="0" align="right">
      <tr>
        <td width="118"><span class="style8"><img src="img/Relatorio_Vendedores50x50.gif" width="32" height="32" /> Relat&oacute;rios Di&aacute;rio</span></td>
        <td width="132"><span class="style8"><img src="img/Relatorio_Vendedores50x50.gif" width="32" height="32" /> Relat&oacute;rios Semanal</span></td>
        <td width="124"><span class="style8"><img src="img/Relatorio_Vendedores50x50.gif" width="32" height="32" /> Relat&oacute;rios Mensal </span></td>
        <td width="79"><span class="style8"><img src="img/imprimir.jpg" width="32" height="32" />Imprimir</span></td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="550" border="0">
      <tr>
        <td width="516" colspan="8"><span class="style13"></span>          <div align="left">
<br>              
<table width="497" border="0" align="left">
                <tr>
                  <td width="477" colspan="2" align="center" bgcolor="#FFFFFF">
                    <div align="left"><strong><span class="style3">Periodo </span><span class="style4">
                      <input name="textfield4" type="text" size="2" />
        / </span><span class="style4">
        <input name="textfield5" type="text" size="2" />
        </span><span class="style4"> /
        <input name="textfield6" type="text" size="4" />
        </span> -- <span class="style4">
        <input name="textfield42" type="text" size="2" />
        / </span><span class="style4">
        <input name="textfield52" type="text" size="2" />
        </span><span class="style4"> /
        <input name="textfield62" type="text" size="4" />
        </span>
        <input name="OK" type="submit" id="OK" value="Enviar" />
        <br />
                    </strong></div></td>
                </tr>
              </table>
              <p><br>
                <br>
              </p>
              <div align="left" class="style12 style13"><span class="style11">:: Selecione o Tipo de Relat&oacute;rio :: <br>
  ----------------------------------------------------------------------------------------------------------------------------------------</span></div>
              <table width="550" border="0">
                <tr>
                  <td><input type="checkbox" name="checkbox" value="checkbox">
                  <span class="style10">Relat&oacute;rio de Cliente</span> </td>
                  <td><input type="checkbox" name="checkbox2" value="checkbox">
                    <span class="style10">Relat&oacute;rio de Fornecedor</span></td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="checkbox3" value="checkbox">
                    <span class="style10">Relat&oacute;rio de Venda </span></td>
                  <td><input type="checkbox" name="checkbox32" value="checkbox">
                    <span class="style10">Relat&oacute;rio de Cheque de Clientes </span></td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="checkbox33" value="checkbox">
                      <span class="style10">Relat&oacute;rio de Estoque </span></td>
                  <td><input type="checkbox" name="checkbox34" value="checkbox">
                      <span class="style10">Relat&oacute;rio de Contas a Pagar</span></td>
                </tr>
                <tr>
                  <td><input type="checkbox" name="checkbox33" value="checkbox">
                    <span class="style10">Relat&oacute;rio de Comiss&atilde;o </span></td>
                  <td><input type="checkbox" name="checkbox34" value="checkbox">
                    <span class="style10">Relat&oacute;rio de Despesas/Vale</span></td>
                </tr>
              </table>
              </div>          </td>
        </tr>
    </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>
