<? 

session_start();

include "php/valida_sessao.php";

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">



<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= True Life Geomensura =-</title>

	<script type="text/javascript" src="js/funcoes.js"></script>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

</head>

<body>

<? include_once "inc_topo.php"; ?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>

    <td width="578" valign="top">

	  <table width="570" border="0" align="center">

      <tr>

        <td align="left">

        	<?php

             $ie6 = "MSIE 6.0";

			 $ie7 = "MSIE 7.0";

			 $ie8 = "MSIE 8.0";

			 if( strstr($_SERVER['HTTP_USER_AGENT'], $ie8)){

			   echo '<form action="adm_projetos.php?buscar=buscar" method="post">';

			 }elseif (( strstr($_SERVER['HTTP_USER_AGENT'], $ie7)) or ( strstr($_SERVER['HTTP_USER_AGENT'], $ie6))) {

			   echo '<form action="adm_projetos.php?buscar=buscar" method="post" style="margin:0 0 0 7px;">';

			 }else{

			   echo '<form action="adm_projetos.php?buscar=buscar" method="post">';

			 } 

             ?>

            	<input type="text" name="buscar"/> 

                <input type="submit" value="Buscar"/>            

                <a href="cad_projetos.php"><img src="img/ico_cadastrar.jpg" alt="" width="54" height="38" border="0" style="margin:10px 0 0 80px;"/></a>

            </form>    

        </td>

      </tr>

      <tr>

        <td align="left" colspan="2" >

        	<?php

			 if( strstr($_SERVER['HTTP_USER_AGENT'], $ie8)){

			   echo '<font face="Verdana, Arial, Helvetica, sans-serif" size="1">';

			 }elseif (( strstr($_SERVER['HTTP_USER_AGENT'], $ie7)) or ( strstr($_SERVER['HTTP_USER_AGENT'], $ie6))) {

			   echo '<font face="Verdana, Arial, Helvetica, sans-serif" size="1"  style="margin:0 0 0 7px;">';

			 }else{

			   echo '<font face="Verdana, Arial, Helvetica, sans-serif" size="1">';

			 } 

             ?>

       		 <b>S� poder� ficar no principal no m�ximo 6 eventos com foto.</b></font>

        </td>

      </tr>

      <tr>

        <td><? include "php/inc_adm_eventos.php"; ?></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table>

	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</body>

</html>