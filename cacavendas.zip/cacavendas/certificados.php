<? 
session_start();
include ("php/config.php");
include_once "php/valida_sessao.php";

################################ inscri��es #############################################
$dbinscricoes = mysql_query("SELECT * FROM inscricoes WHERE id = '".$_GET['id']."'");
$fetchinscricoes = mysql_fetch_array($dbinscricoes);
################################ eventos   ##############################################
$dbeventos = mysql_query("SELECT * FROM eventos WHERE nome_evento = '".$fetchinscricoes['nome_evento']."'");
$fetcheventos = mysql_fetch_array($dbeventos);
################################ certificados ###########################################
$certificados = mysql_query("SELECT * FROM certificados WHERE id_evento = '".$fetcheventos['id']."'");
$result = mysql_fetch_array($certificados);
#########################################################################################
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= Meta Marketing e Eventos =-</title>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
    <script src="js/fs.js" type="text/javascript"></script>
    <script src="js/fsprint.js" type="text/javascript"></script>
    <link href="css/imprime.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
<table cellpadding="0" cellspacing="0" border="0" style="background:url(images/certificado.jpg) no-repeat; margin-top:10px;" align="center">
	<tr>
	  <td height="605" width="900" valign="top">
        <a href="javascript:void(0)" onClick="javascript:imprime('conteudo')" style="margin-left:90%;">[ Imprimir ]</a>
          <div id="conteudo">
            <?php
               $ie6 = "MSIE 6.0";
               $ie7 = "MSIE 7.0";
               $ie8 = "MSIE 8.0";
               if( strstr($_SERVER['HTTP_USER_AGENT'], $ie8)){
                    echo '<div style="margin:auto; text-align:justify; width:900px;">';
               }elseif (( strstr($_SERVER['HTTP_USER_AGENT'], $ie7)) or ( strstr($_SERVER['HTTP_USER_AGENT'], $ie6))) {
                   echo '<div style="margin:auto; text-align:justify; width:900px;">';
               }else{
                   echo '<div style="margin:auto; text-align:justify; width:900px;">';
               } 
				$texto2 = $result['conteudo'];
				$nome_data = array('janeiro','fevereiro','mar�o','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro');
				$numero_data= array('January','February','March','April','May','June','July','August','September','October','November','December');
				$tipo_curso = "mini-curso";
				if(strlen($fetchinscricoes['gerentologia']) > 0){
					$curso = "Gerontologia";
				}
				if(strlen($fetchinscricoes['congnitiva']) > 0){
					$curso2 = "Avalia��o Cognitiva";
				}
				if(strlen($fetchinscricoes['paleativos']) > 0){
					$curso3 = "Cuidados Paleativos";
				}
				if(strlen($fetchinscricoes['incapacidade']) > 0){
					$curso4 = "Especialista e Incapacidade";
				}
				
				$data1	= date('j', strtotime($fetcheventos['data_evento_inicio']));
				$data2	= date('j', strtotime($fetcheventos['data_evento_final']));
				$data3	= str_replace($numero_data,$nome_data,date('F', strtotime($fetcheventos['data_evento_final'])));
				$data4  = date('Y', strtotime($fetcheventos['data_evento_final']));
				$data	= $data1." a ".$data2." de ".$data3." de ".$data4;
				
				$texto2 = str_replace("tipo_curso", $tipo_curso, $texto2);
				$texto2 = str_replace("nome_curso_g", $curso, $texto2);
				$texto2 = str_replace("nome_curso_c", $curso2, $texto2);
				$texto2 = str_replace("nome_curso_p", $curso3, $texto2);
				$texto2 = str_replace("nome_curso_i", $curso4, $texto2);
				$texto2 = str_replace("data_evento", $data, $texto2);
				$evento	= $fetchinscricoes['nome_evento'];
				$texto2 = str_replace("nome_evento", $evento, $texto2);
				   
				if ($fetchinscricoes['nome_evento'] == 'V Congresso de Geriatria e Gerontologia do Rio de Janeiro'){   
				$nome 	= strtoupper($fetchinscricoes['givenname']).' '.strtoupper($fetchinscricoes['familyname']);
				}
				elseif($fetchinscricoes['nome_evento'] == '30 Iberian-Latin-American Congress on Computational Methods in Engineering - CILAMCE'){
				$nome 	= strtoupper($fetchinscricoes['givenname']).' '.strtoupper($fetchinscricoes['familyname']).' '.strtoupper($fetchinscricoes['Affiliation']);
				}
				else{
				$nome 	= strtoupper($fetchinscricoes['givenname']).' '.strtoupper($fetchinscricoes['familyname']);
				}
				$texto2 = str_replace("nome_participante", $nome , $texto2);
				echo $texto2."<br><br>";
				$texto2 = str_replace($nome, "nome" , $texto2);
               ?>
               </div>
         </div>
      </td>
      </tr>
      <tr>
		<td align="center"><a href="javascript:history.go(-2)">Voltar</a></td>
	  </tr>
   </table>
</body>
</html>