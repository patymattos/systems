<?php

include_once "php/config.php";

$id_produto = $_GET['ex'];



$sql	= "UPDATE cheques SET CHQ_ATIVO = '0' WHERE CHQ_ID = '$id_produto'";

$resultado = mysql_query($sql);



echo "<script>location.href='cheques.php';</script>";

?>