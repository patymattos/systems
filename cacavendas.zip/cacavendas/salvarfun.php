<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	$FN_ID =$_POST['FU_ID'];
	
	$FN_TIPO =$_POST['FU_TIPO'];

	$FN_DATA =$_POST['FU_DATA'];

	$FN_NOME =$_POST['FU_NOME'];
	
	$FN_END =$_POST['FU_END'];
  	
	$FN_CIDADE =$_POST['FU_CIDADE'];
	
	$FN_ESTADO =$_POST['FU_ESTADO'];
	
	$FN_CEP =$_POST['FU_CEP'];
	 	
	$FN_EMAIL =$_POST['FU_EMAIL'];

	$FN_TEL =$_POST['FU_TEL'];

	$FN_CEL =$_POST['FU_CEL'];
 	


	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO funcionario (FUN_ID,FUN_TIPO,FUN_DATA,FUN_NOME,FUN_END,FUN_CIDADE,FUN_ESTADO,FUN_CEP,FUN_EMAIL, FUN_TEL,FUN_CEL )
	VALUES ('$FN_ID','$FN_TIPO','$FN_DATA','$FN_NOME','$FN_END','$FN_CIDADE','$FN_ESTADO','$FN_CEP','$FN_EMAIL','$FN_TEL','$FN_CEL')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_fun.php");



?>	

 