<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style11 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style13 {font-size: 13px}
.style16 {font-family: Arial, Helvetica, sans-serif}
.style19 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; }
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="215" border="0" align="right">
      <tr>
        <td width="98"><img src="img/imprimir.jpg" width="30" height="30" /><span class="style10"> Or&ccedil;amento</span></td>
        <td width="107"><span class="style10"><img src="img/finalizar-pedido.gif" height="30" /></span></td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="550" border="0" bgcolor="#FFFFFF">
  <tr>
    <td><table width="550" border="0">
      <tr>
        <td colspan="5"><div align="left" class="style12 style13"><span class="style11">:: CLIENTE :: <br>
          ----------------------------------------------------------------------------------------------------------------------------------------</span></div></td>
      </tr>
<form name="frmBusca" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?a=buscar" >
	  <tr>
        <td><span class="style13"><span class="style10">Telefone / Nome:</span></span></td>
        <td colspan="4"><input name="palavra" type="text" id="palavra" />
            <img src="img/icone4.gif" width="24" height="22" onclick="document.forms[0].submit()"  style="cursor:pointer"/></td>

      </tr>
</form>
<?
include_once "php/config.php";
 
// Recuperamos a a��o enviada pelo formul�rio
$a = $_GET['a'];
 
// Verificamos se a a��o � de busca
if ($a == "buscar") {
 
	// Pegamos a palavra
	$palavra = trim($_POST['palavra']);
 
	// Verificamos no banco de dados produtos equivalente a palavra digitada
	$sql = mysql_query("SELECT * FROM clientes WHERE CLI_TEL LIKE '%".$palavra."%' ORDER BY CLI_NOME");
 
	// Descobrimos o total de registros encontrados
	$numRegistros = mysql_num_rows($sql);
 


// Se houver pelo menos um registro, exibe-o
	if ($numRegistros != 0) {
		// Exibe os produtos e seus respectivos pre�os
		while ($produto = mysql_fetch_object($sql)) {
		?>
 	     <tr bgcolor="#FFFFFF">
        <td width="100"></td>
        <td width="380" height="21"><span class="style13"><span class="style10"> <? echo " Nome Completo: ".$produto->CLI_NOME. " Telefone: ".$produto->CLI_TEL;  ?> </span></span></td>
		<?  
		}
	// Se n�o houver registros
	} else {?>
 	     <tr bgcolor="#FFFFFF">
        <td width="100"></td><td width="380" height="21"><? echo "Nenhum produto foi encontrado com a palavra ".$palavra.""; ?>
	<? }
}
?>       
        <td width="56" colspan="3"><img src="img/add44.png" width="31" height="30" /></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <table width="550" border="0">
      <tr>
        <td height="35" colspan="7"><div align="left" class="style12 style13"><span class="style11">:: SERVI&Ccedil;O :: <br>
          ----------------------------------------------------------------------------------------------------------------------------------------
        </span></div></td>
      </tr>
      <tr>
        <td width="80"><span class="style13"><span class="style10">Servi&ccedil;o:</span></span></td>
        <td width="145">          <select name="sv">
          <option selected="selected">---Servi�o---</option>
          <?

				$resultado = mysql_query("SELECT DISTINCT SER_NOME FROM servicos ORDER BY SER_NOME ASC");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[SER_NOME]'>".substr ($sql[SER_NOME],0,50)."...</option>'";

				}

			?>
        </select></td>
        <td colspan="5"><span class="style13"><span class="style10">Valor:</span></span>
          <input name="textfield3" type="text" size="14"></td>
        </tr>
      <tr>
        <td><span class="style13"><span class="style10">Funcion&aacute;rios:</span></span></td>
        <td colspan="3"><span class="style13">
          <select name="fvendedor">
            <option selected="selected">---Vendedor---</option>
            <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='VENDEDOR'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FUN_NOME]'>".substr ($sql[FUN_NOME],0,50)."...</option>'";

				}

			?>
          </select>
          </span><div align="left">
          </div></td>
        <td width="122"><span class="style13">
          <select name="select">
            <option selected="selected">---Mec&acirc;nico---</option>
            <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='MEC&Acirc;NICO'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FU_NOME]'>".substr ($sql[FU_NOME],0,50)."...</option>'";

				}

			?>
          </select>
        </span></td>
        <td width="122"><span class="style13">
          <select name="select2">
            <option selected="selected">---Borracheiro---</option>
            <?

				$resultado = mysql_query("SELECT FUN_NOME FROM funcionario WHERE FUN_TIPO='BORRACHEIRO'");

				while($sql = mysql_fetch_array($resultado))

				{

					echo "<option value='$sql[FU_NOME]'>".substr ($sql[FU_NOME],0,50)."...</option>'";

				}

			?>
          </select>
        </span><span class="style13"></span></td>
        <td width="54" colspan="-2"><img src="img/add44.png" width="31" height="30" /></td>
      </tr>
    </table>    
    <p>&nbsp;</p>
    <table width="550" border="0">
      <tr>
        <td width="226" colspan="7"><div align="left" class="style12 style13"><span class="style16"><strong>:: INFORMA&Ccedil;&Otilde;ES GERAIS::</strong><br>
          ---------------------------------------------------------------------------------------------------------------------------------------                  
          <br />
        </span></div></td>
      </tr>
    </table>    
    <table width="550" border="0" align="center" bordercolor="#000000" bgcolor="#000000">
      <tr bgcolor="#333333">
        <td width="73"><span class="style13"><span class="style29">DATA</span></span></td>
        <td width="118"><span class="style13"><span class="style29">NOME</span></span></td>
        <td width="87"><span class="style13"><span class="style29">PRODUTO</span></span></td>
        <td width="45"><span class="style13"><span class="style29">QT.</span></span></td>
        <td width="80"><span class="style13"><span class="style29">SERVI&Ccedil;O</span></span></td>
        <td width="64"><span class="style13"><span class="style29">VALOR</span></span></td>
        <td width="53"><span class="style13"><span class="style29">TOTAL</span></span></td>
      </tr>
      <tr bgcolor="#FFFFFF">
        <td><span class="style13"><span class="style10">10/01/2011</span></span></td>
        <td><span class="style13"><span class="style10">Patricia Mattos</span></span></td>
        <td><span class="style13"><span class="style10">Pneu</span></span></td>
        <td><span class="style13">10</span></td>
        <td><span class="style13"><span class="style10">Troca de pneu</span></span></td>
        <td><span class="style13"><span class="style10">50,00</span></span></td>
        <td><span class="style13"><span class="style10">500,00</span></span></td>
      </tr>
    </table>
    <p>&nbsp;</p>    <p>&nbsp;</p></td>
  </tr>
</table>
<br>
</body>
</html>
