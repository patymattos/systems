<?php

include_once "php/config.php";



$cli = $_GET['tr'];

$select = "SELECT * FROM clientes WHERE CLI_ID = '$cli'";

$query = mysql_query($select);

$a = mysql_fetch_array($query);

$CL_COD = 'value="'.$a['CLI_COD'].'"';

$CL_DATA = 'value="'.$a['CLI_DATA'].'"';

$CL_NOME = 'value="'.$a['CLI_NOME'].'"';

$CL_CC = 'value="'.$a['CLI_CC'].'"';

$CL_RG = 'value="'.$a['CLI_RG'].'"';

$CL_END = 'value="'.$a['CLI_END'].'"';

$CL_CIDADE = 'value="'.$a['CLI_CIDADE'].'"';

$CL_ESTADO = 'value="'.$a['CLI_ESTADOE'].'"';

$CL_CEP = 'value="'.$a['CLI_CEP'].'"';

$CL_EMAIL = 'value="'.$a['CLI_EMAIL'].'"';

$CL_TEL = 'value="'.$a['CLI_TEL'].'"';

$CL_CEL = 'value="'.$a['CLI_CEL'].'"';

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>-= PHAXECCO - SISTEMA ADMINISTRATIVO =-</title>

<script type="text/javascript" src="js/funcoes.js"></script>

<script type="application/javascript" language="javascript">

<!--

</script>


</script>

	<link rel="stylesheet" href="css/estilo.css" type="text/css" />

    <style type="text/css">

<!--

.style5 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }

.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }

-->

    </style>

</head>





<body bgcolor="#FAFAD2">

<? include_once "inc_topo.php"; ?>

<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">

  <tr>

    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>

    <td width="578" valign="top">

	<table width="575" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">

	  <tr>

        <td class="titulo">:: Altera��o de Cliente ::</td>

      </tr>

	  <tr>

        <td><? include_once "altcli.php"; ?></td>

	  </tr>

    </table>



	</td>

  </tr>

</table>

<? include_once "inc_rodape.php"; ?>

</body>

</html>