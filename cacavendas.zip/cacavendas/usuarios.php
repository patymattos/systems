<?php

// obt�m os valores digitados
$login = $_POST["login"];
$senha = $_POST["senha"];
$email = $_POST["email"];
$id_eventos = $_POST["projetos"];
$tipo = $_POST["arquivo"];

// acesso ao banco de dados
include "config.php";

$select = "SELECT * FROM usuarios_eventos WHERE login='$login'";
$resultado	= mysql_query($select);
$linhas		= mysql_num_rows($resultado);
$x			= mysql_fetch_array($resultado);

if ($linhas==0)  // testa se a consulta retornou algum registro
{
	echo("<script>
			alert(\"Usu�rio n�o encontrado\");
			window.location = '../index2.php';
         </script>");
}
else
{
    if ($senha != mysql_result($resultado, 0, "senha")) // confere senha
	{
		echo("<script>
				alert(\"A senha est� incorreta\");
				window.location = '../index2.php';
			  </script>");
	}
	else   // usu�rio e senha corretos. Vamos criar os cookies
    {
        //setcookie("nome_usuario", $username);
        //setcookie("senha_usuario", $senha);
		
		//---- Cria sess�o, depois do login...
		session_start();
		$_SESSION['login']	= $x['login'];
		$_SESSION['projetos'] = $x['projetos'];
		##################################
		$data_hora_atual = date("y.m.d H:i:s");
		$update = "UPDATE usuarios SET data_hora = '".$data_hora_atual."' WHERE id ='".$x['id']."'";
		$agora = mysql_query($update);
        ##################################
		// direciona para a p�gina inicial dos usu�rios cadastrados
        echo("<script>
				window.location = 'cli_manografia.php';
			  </script>");
    }
}

mysql_close($con);

?>