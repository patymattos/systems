<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_autocen";  // Seu Login no mySQL 
  	$pass = "k0k9p8n7u6";  // Senha do MySql
  	$db = "swcenter_kakapneus";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	
	###############################

	# Alterando no Banco de Dados #

	###############################

	$insert = "UPDATE produtos SET PRD_ID = '', PRD_DATA = '$PD_DATA', PRD_REFERENCIA = '$PD_REFERENCIA', PRD_NOME = '$PD_NOME', PRD_DESCRICAO = '$PD_DESCRICAO', PRD_MARCA = '$PD_MARCA', PRD_QUANTIDADE = '$PD_QUANTIDADE', PRD_VENDA = '$PD_VALOR', PRD_CUSTO = '$PD_CUSTO', PRD_FORN = '$PD_FORN'";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_prod.php");



?>	

 