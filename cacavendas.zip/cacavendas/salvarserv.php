<?

	#############################

	# Conectando Banco de Dados #

	#############################

	$host = "localhost";  // Endere�o do servidor MySQL 
 	$user = "swcenter_phaxecc";  // Seu Login no mySQL 
  	$pass = "p1h2a3x4";  // Senha do MySql
  	$db = "swcenter_phaxecco";  // Nome do Banco de Dados 

	$cnx_id = mysql_connect($host, $user, $pass);
   	mysql_select_db($db);


	####################################

	# Pegando os dados com m�todo post #

	####################################

	$SV_DATA =$_POST['S_DATA'];
	
	$SV_REF =$_POST['S_REF'];

	$SV_NOME =$_POST['S_NOME'];
	
	$SV_DESC =$_POST['S_DESC'];

	$SV_PORC =$_POST['S_PORC'];
  	
	$SV_CUSTO =$_POST['S_CUSTO'];


	###############################

	# Inserindo no Banco de Dados #

	###############################

	$insert = "INSERT INTO servicos (SER_ID,SER_DATA,SER_REF,SER_NOME,SER_DESC,SER_COM,SER_CUSTO)
	VALUES ('','$SV_DATA','$SV_REF','$SV_NOME','$SV_DESC','$SV_PORC','$SV_CUSTO')";

	//echo $insert;

	$salvando = mysql_query($insert) or die(mysql_error());



Header("Location: ok_serv.php");



?>	

 