<? 
session_start();
include_once "php/valida_sessao.php";
include_once "php/config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>-= ALAMEDA PNEUS - SISTEMA ADMINISTRATIVO =-</title>
<script type="text/javascript" src="js/funcoes.js"></script>
<script type="application/javascript" language="javascript">
	function barra(objeto){
		if (objeto.value.length == 2 || objeto.value.length == 5 ){
		objeto.value = objeto.value+"/";
		}
	}
function validar(obj) { // recebe um objeto
    var s = (obj.value).replace(/\D/g,'');
    var tam=(s).length; // removendo os caracteres n�o num�ricos
    if (!(tam==11 || tam==14)){ // validando o tamanho
        alert("'"+s+"' N�o � um CPF ou um CNPJ v�lido!" ); // tamanho inv�lido
        return false;
    }
// se for CPF
    if (tam==11 ){
        if (!validaCPF(s)){ // chama a fun��o que valida o CPF
            alert("'"+s+"' N�o � um CPF v�lido!" ); // se quiser mostrar o erro
            obj.select();  // se quiser selecionar o campo em quest�o
            return false;
        }
        obj.value=maskCPF(s);    // se validou o CPF mascaramos corretamente
        return true;
    }
// se for CNPJ
    if (tam==14){
        if(!validaCNPJ(s)){ // chama a fun��o que valida o CNPJ
            alert("'"+s+"' N�o � um CNPJ v�lido!" ); // se quiser mostrar o erro
            obj.select();    // se quiser selecionar o campo enviado
            return false;
        }
    }
}
// fim da funcao validar()
// fun��o que valida CPF
// O algor�timo de valida��o de CPF � baseado em c�lculos
// para o d�gito verificador (os dois �ltimos)
// N�o entrarei em detalhes de como funciona
function validaCPF(s) {
    var c = s.substr(0,9);
    var dv = s.substr(9,2);
    var d1 = 0;
    for (var i=0; i<9; i++) {
        d1 += c.charAt(i)*(10-i);
     }
    if (d1 == 0) return false;
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(0) != d1){
        return false;
    }
    d1 *= 2;
    for (var i = 0; i < 9; i++)    {
         d1 += c.charAt(i)*(11-i);
    }
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(1) != d1){
        return false;
    }
    return true;
}
// Fun��o que valida CNPJ
// O algor�timo de valida��o de CNPJ � baseado em c�lculos
// para o d�gito verificador (os dois �ltimos)
// N�o entrarei em detalhes de como funciona
function validaCNPJ(CNPJ) {
    var a = new Array();
    var b = new Number;
    var c = [6,5,4,3,2,9,8,7,6,5,4,3,2];
    for (i=0; i<12; i++){
        a[i] = CNPJ.charAt(i);
        b += a[i] * c[i+1];
    }
    if ((x = b % 11) < 2) { a[12] = 0 } else { a[12] = 11-x }
    b = 0;
    for (y=0; y<13; y++) {
        b += (a[y] * c[y]);
    }
    if ((x = b % 11) < 2) { a[13] = 0; } else { a[13] = 11-x; }
    if ((CNPJ.charAt(12) != a[12]) || (CNPJ.charAt(13) != a[13])){
        return false;
    }
    return true;
}

    // Fun��o que permite apenas teclas num�ricas
    // Deve ser chamada no evento onKeyPress desta forma
    // return (soNums(event));
function soNums(e)
{
    if (document.all){var evt=event.keyCode;}
    else{var evt = e.charCode;}
    if (evt <20 || (evt >47 && evt<58)){return true;}
    return false;
}
//    fun��o que mascara o CPF
function maskCPF(CPF){
    return CPF.substring(0,3)+"."+CPF.substring(3,6)+"."+CPF.substring(6,9)+"-"+CPF.substring(9,11);
}
//    fun��o que mascara o CNPJ
function maskCNPJ(CNPJ){
    return CNPJ.substring(0,2)+"."+CNPJ.substring(2,5)+"."+CNPJ.substring(5,8)+"/"+CNPJ.substring(8,12)+"-"+CNPJ.substring(12,14);
} 1
</script>
	<link rel="stylesheet" href="css/estilo.css" type="text/css" />
    <style type="text/css">
<!--
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style13 {font-size: 13px}
.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
-->
    </style>
</head>


<body bgcolor="#FAFAD2">
<? include_once "inc_topo.php"; ?>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="200px" align="center" valign="top" bgcolor="#0099cc"><? include_once "inc_menu.php"; ?></td>
    <td width="578" valign="top">
	<table width="575" border="0" align="center" cellpadding="2" cellspacing="1" class="texto cor_tr">
	  <tr>
        <td class="titulo">:: Produtos ::</td>
      </tr>
	  <tr>
        <td><br />
          <table width="168" border="0" align="right">
            <tr>
              <td width="90" colspan="2"><a href="cad_pec.php"><img src="img/add44.png" width="31" height="30" border="0" style="text-decoration:none"  /><span class="style10" style="text-decoration:none; color: #000000;" >Pe&ccedil;as</span></a></td>
              </tr>
          </table>                    
          <br />
          <div align="right"></div>
          <p>&nbsp;</p>         
		    <form name="frmBusca" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?a=buscar" >

		   <table width="200" border="0">
            <tr>
              <td width="144"><input name="palavra" type="text" id="palavra" /></td>
              <td width="422"><img src="img/icone4.gif" width="24" height="22" onclick="document.forms[0].submit()"  style="cursor:pointer"/></td>
            </tr>
			</form>
<?
include_once "php/config.php";
 
// Recuperamos a a��o enviada pelo formul�rio
$a = $_GET['a'];
 
// Verificamos se a a��o � de busca
if ($a == "buscar") {
 
	// Pegamos a palavra
	$palavra = trim($_POST['palavra']);
 
	// Verificamos no banco de dados produtos equivalente a palavra digitada
	$sql = mysql_query("SELECT * FROM pecas WHERE PREF LIKE '%".$palavra."%' AND PATIVO = '1' OR PCARRO LIKE '%".$palavra."%' AND PATIVO = '1' ORDER BY PREF");
 
	// Descobrimos o total de registros encontrados
	$numRegistros = mysql_num_rows($sql);
 


// Se houver pelo menos um registro, exibe-o
	if ($numRegistros != 0) {
		// Exibe os produtos e seus respectivos pre�os
		echo'
		    <tr>
              <td colspan="2"><table width="570" border="0" align="left" bordercolor="#000000" bgcolor="#000000">
                  <tr bgcolor="#333333">
                    <td width="104"><div align="left"><span class="style13"><span class="style29">REFER&Ecirc;NCIA</span></span></div></td>
                    <td width="148"><span class="style13"><span class="style29">CARRO</span></span></td>
                    <td width="141"><span class="style13"><span class="style29">ANO</span></span></td>
                    <td width="141"><span class="style13"><span class="style29">POTENCIA</span></span></td>
                    <td width="36"><span class="style13"><span class="style29">QT.</span></span></td>
                    <td width="64"><span class="style13"><span class="style29">VALOR</span></span></td>
                    <td width="51"><span class="style13"><span class="style29">EXCLUIR</span></span></td>
              	  </tr>';
		
		while ($produto = mysql_fetch_array($sql)) {
		?>
        <tr bgcolor="#FFFFFF">
                    <td><? echo $produto['PREF']; ?></td>
                    <td><? echo $produto['PCARRO']; ?></td>
                    <td><? echo $produto['PANO']; ?></td>
                    <td><? echo $produto['PPOTENCIA']; ?></td>
                    <td align="center"><? echo $produto['PQT']; ?> </td>
                    <td align="center"><? echo number_format($produto['PVENDA'],2,",",".");  ?> </td>
                    <td><div align="center"><a href='excluir_produto.php?ex=<?=$produto['ID']?>' title="Excluir Produto"><img src='images/ico_excluir.jpg' alt='' border='0' /></a></div></td>
        </tr>
		<?  
		}
	// Se n�o houver registros
	} else {?>
 	     <tr bgcolor="#FFFFFF">
        <td></td><td colspan="2"><? echo "Produto n�o localizado. Para cadastrar clique no bot�o adicionar"; ?>
			<? }
}else{
?>  
		

		
	    <tr>
              <td colspan="2"><table width="570" border="0" align="left" bordercolor="#000000" bgcolor="#000000">
                  <tr bgcolor="#333333">
                    <td width="73"><div align="left"><span class="style13"><span class="style29">REFER&Ecirc;NCIA</span></span></div></td>
                    <td width="53"><span class="style13"><span class="style29">CARRO</span></span></td>
                    <td width="39"><span class="style13"><span class="style29">ANO</span></span></td>
                    <td width="63"><span class="style13"><span class="style29">POTENCIA</span></span></td>
                    <td width="53"><span class="style13"><span class="style29">QT.</span></span></td>
                    <td width="58"><span class="style13"><span class="style29">VALOR</span></span></td>
                    <td width="82"><span class="style13"><span class="style29">OBS.</span></span></td>
                    <td width="53"><span class="style13"><span class="style29">ALTERAR</span></span></td>
                    <td width="58"><span class="style13"><span class="style29">EXCLUIR</span></span></td>
                  </tr>
                  <?

		$sql = "SELECT ID, PREF, PCARRO, PANO,PPOTENCIA,PQT,PCUSTO,PVENDA, POBS FROM pecas WHERE PATIVO = '1' ORDER BY PREF";   
		$qr = mysql_query($sql);   
		while($row = mysql_fetch_array($qr)) {   
		
		?>
                  <tr bgcolor="#FFFFFF">
                    <td><? echo $row['PREF']; ?></td>
                    <td><? echo $row['PCARRO']; ?></td>
                    <td><? echo $row['PANO']; ?></td>
                    <td align="center"><? echo number_format($row['PPOTENCIA'],1,",","."); ?> </td>
                    <td align="center"><? echo $row['PQT']; ?> </td>
                    <td align="center"><? echo  number_format($row['PCUSTO'],2,",","."); ?> </td>
                    <td align="center"><? echo  number_format($row['PVENDA'],2,",","."); ?> </td>
				    <td align="center"><? echo $row['POBS']; ?> </td>
                    <td><div align="center"><a href='excluir_produto.php?ex=<?=$row['ID']?>' title="Excluir Produto"><img src='images/ico_excluir.jpg' alt='' border='0' /></a></div></td>
                  </tr>
                  <?
}
}
 ?>
              </table></td>
        </tr>
      </table>          </td>
  </tr>
</table>
	</td>
  </tr>
</table>
<? include_once "inc_rodape.php"; ?> 
</body>
</html>