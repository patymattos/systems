<?php 

session_start();

include_once "php/valida_sessao.php";

include_once "php/config.php";



?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>Untitled Document</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css">

<!--

.style10 {font-family: Arial, Helvetica, sans-serif; }

.style13 {font-size: 10px}

.style29 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }

.style32 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; color: #FFFFFF; }

.style34 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; color: #000000; }

-->

</style>

<script language="JavaScript" type="text/JavaScript">

<!--

function MM_jumpMenu(targ,selObj,restore){ //v3.0

  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");

  if (restore) selObj.selectedIndex=0;

}

//-->

</script>

<script language="javascript" type="text/javascript">

<!--

var win=null;

function NewWindow(mypage,myname,w,h,scroll,pos){

if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}

if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}

else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20}

settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no';

win=window.open(mypage,myname,settings);}

// -->

</script>

<script language="javascript" type="text/javascript">

function validaPrevenda() {

	if(document.add_servico.sv.value == "0") {

		alert("Selecione o Servi�o");

		document.add_servico.sv.focus();

        return false;

	};

	if(document.add_servico.valor_sv.value == "") {

		alert("Defina o valor do servi�o");

		document.add_servico.valor_sv.focus();		

        return false;		

	}

	if(document.add_servico.sv.value != "" && document.add_servico.valor_sv.value != "") {

		document.add_servico.action="add_prevenda.php";

		document.add_servico.submit();

	};

};

function validaOrcamento() {

	if(document.add_orcamento.ref_cliente.value == "") {

		alert("Selceione o Cliente");

		document.add_orcamento.ref_cliente.focus();

        return false;

	};

	if(document.add_orcamento.ref_vendedor.value == "") {

		alert("Defina o Vendedor");

		document.add_orcamento.ref_vendedor.focus();		

        return false;		

	}

	if(document.add_orcamento.ref_cliente.value != "" && document.add_orcamento.ref_vendedor.value != "") {

		document.add_orcamento.action="add_prevenda.php";

		document.add_orcamento.submit();

	};

};

function validaVendedor() {

	if(document.add_funcionario.vendedor.value == "") {

		alert("Selceione o Vendedor");

		document.add_funcionario.vendedor.focus();

        return false;

	};

	if(document.add_funcionario.vendedor.value != "") {

		document.add_funcionario.action="add_prevenda.php";

		document.add_funcionario.submit();

	};

};

</script>

</head>



<body bgcolor="#FFFFFF">

<table width="550" border="0" bgcolor="#FFFFFF">

  <tr>

    <td><!--<table width="215" border="0" align="right">

      <tr>

        <td width="98"><span class="style10">&nbsp;</span></td>

        <td width="107"><span class="style10"><a href="#"><img src="img/finalizar-pedido.gif" height="30" border="0" /></a></span></td>

      </tr>

    </table>-->&nbsp;</td>

  </tr>

</table>

<br>

<table width="550" border="0" bordercolor="#333333" bgcolor="#FFFFFF">

  <tr>

    <td colspan="4" bgcolor="#000000"><span class="style12 style13"><span class="style32">: CLIENTE :: </span></span></td>

  </tr>

  <form name="frmBusca" method="post" action="<?php echo $_SERVER['file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/PHP_SELF'] ?>?a=buscar" >

  <tr>



    <td width="99"><span class="style13"><span class="style10">Telefone / Nome:</span></span></td>

    <td width="144"><input name="palavra" type="text" id="palavra" /></td>

    <td width="230" colspan="2"><img src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/icone4.gif" width="24" height="22" onclick="document.forms[0].submit()"  style="cursor:pointer"/></td>

  </tr>

</form>

<?php

include_once "php/config.php";

 

// Recuperamos a a��o enviada pelo formul�rio

$a = $_GET['a'];

 

// Verificamos se a a��o � de busca

if ($a == "buscar") {

 

	// Pegamos a palavra

	$palavra = trim($_POST['palavra']);

 

	// Verificamos no banco de dados produtos equivalente a palavra digitada

	$sql = mysql_query("SELECT * FROM clientes WHERE CLI_TEL LIKE '%".$palavra."%' OR CLI_NOME LIKE '%".$palavra."%' ORDER BY CLI_NOME");

 

	// Descobrimos o total de registros encontrados

	$numRegistros = mysql_num_rows($sql);

// Se houver pelo menos um registro, exibe-o

	if ($numRegistros != 0) {

		// Exibe os produtos e seus respectivos pre�os

        echo '<form action="add_prevenda.php" name="add_cliente" enctype="multipart/form-data" method="post">';

		while ($produto = mysql_fetch_object($sql)) {

		

		?>

 	    <tr bgcolor="#FFFFFF">

            <td align="right"><input type="radio" name="cliente" value="<?=$produto->CLI_ID?>" ></td>

        	<td colspan="3" align="left"><span class="style13"><span class="style10"><? echo " Nome Completo: <b>".$produto->CLI_NOME. "</b> Telefone: <b>".$produto->CLI_TEL."</b>";  ?> </span></span></td>

        </tr>

		<?php

		}

		echo "<tr><td colspan='4'>&nbsp;</td></tr>";

		echo "<tr><td colspan='4' align='center' ><input type='submit' value='Definir Cliente'></td></tr>"; 

        echo "</form>";

	// Se n�o houver registros

	} else {?>

 	     <tr bgcolor="#FFFFFF">

        <td></td><td colspan="3"><?php echo "Cliente n�o localizado. Para cadastrar clique no bot�o adicionar -->"; ?>

		<td><a href="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/cad_clientes.php" target="_blank"><img src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/add44.png" width="31" height="30" border="0" /></a></td>

			<?php }

}



else{

	if($_SESSION['pre_cliente'] != ""){

		$select = "SELECT CLI_NOME, CLI_TEL FROM clientes WHERE CLI_ID = '".$_SESSION['ref_cliente']."'";

		$query = mysql_query($select);

		$result = mysql_fetch_array($query);

		echo "<tr><td colspan='4'>&nbsp;</td></tr>";

		echo '<tr><td colspan="4" align="left"><span class="style13"><span class="style10">Nome Completo: <b>'.$result['CLI_NOME'].'</b> Telefone: <b>'.$result['CLI_TEL'].'</b></span></span></td></tr>';

	}       

  }

?>

</table>

<br>

<table width="550" border="0">

  <tr bordercolor="#000000" bgcolor="#000000">

    <td colspan="9"><span class="style12 style13"><span class="style32">:: PRODUTO :: </span></span></td>

  </tr>

   <form name="frmBusca2" method="post" action="<?php echo $_SERVER['file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/PHP_SELF'] ?>?b=buscar2" >



  <tr>

    <td width="79"><span class="style13"><span class="style10">Refer&ecirc;ncia:</span></span></td>

    <td colspan="8"><input name="palavra2" type="text" id="palavra2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/icone4.gif" width="24" height="22" onclick="document.frmBusca2.submit()"  style="cursor:pointer"/></td>

  </form>

<?php

 

// Recuperamos a a��o enviada pelo formul�rio

$b = $_GET['b'];

 

// Verificamos se a a��o � de busca

if ($b == "buscar2") {

 

	// Pegamos a palavra

	$palavra2 = trim($_POST['palavra2']);

 

	// Verificamos no banco de dados produtos equivalente a palavra digitada

	$sql = mysql_query("SELECT * FROM produtos WHERE PRD_REFERENCIA LIKE '%".$palavra2."%' AND PRD_ATIVO = '1' ORDER BY PRD_DATA");

 

	// Descobrimos o total de registros encontrados

	$numRegistros = mysql_num_rows($sql);

 





// Se houver pelo menos um registro, exibe-o

	if ($numRegistros != 0) {

	$i = 0;

		// Exibe os produtos e seus respectivos pre�os

        echo '<form action="add_prevenda.php" name="add_produto" enctype="multipart/form-data" method="post">';

		while ($produto2 = mysql_fetch_object($sql)) {

		$i++;

		$nome_produto = "produto".$i;

		$incremento = "incremento".$i;

		$qt = "qt".$i;

		$valor = "valor".$i;

		//echo 'valor => '.$valor;

		?>

 	     <tr bgcolor="#FFFFFF">

        <td align="right"><input type="checkbox" name="<?=$nome_produto?>" value="<?=$produto2->PRD_ID?>"><input type="hidden" name="<?=$incremento?>" value="<?=$i?>"></td>

        <td colspan="3" style="font-size:9px;"><span class="style13"><span class="style10"> <? echo "Ref.: <b>".$produto2->PRD_REFERENCIA. "</b> / Prod.: <b>".$produto2->PRD_NOME. "</b> / Qtde.: <b>".$produto2->PRD_QUANTIDADE."</b>";  ?> </span></span></td>

		<td width="17" style="font-size:9px;"><span class="style13"><span class="style10">Qt:&nbsp;&nbsp;<input name="<?=$qt?>" type="text" size="5"></span></span></td>

    	<td width="37" colspan="4" style="font-size:9px;"><span class="style13">Valor(R$): <input name="<?=$valor?>" type="text" size="5"></span></td>

		<?  

		}

		$total = $i;

		echo "<tr><td colspan='8'><input type='hidden' name='total_produtos' value='$total'>&nbsp;</td></tr>";

		echo "<tr><td colspan='8' align='center' ><input type='submit' value='Definir Produtos'></td></tr>"; 

        echo "</form>";

	// Se n�o houver registros

	} else {?>

 	     <tr bgcolor="#FFFFFF">

        <td></td><td colspan="7"><? echo "Produto n�o localizado. Consulte o Estoque."; ?>

		<td colspan="2"><a href="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/cad_produtos.php" target="_blank"><img src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/add44.png" width="31" height="30" border="0" /></a></td>

  		<? }

}

?>       





</table>

<br>

<table width="550" border="0">

<form name="add_servico" enctype="multipart/form-data" method="post">

  <tr bordercolor="#000000" bgcolor="#000000">

    <td colspan="5"><span class="style12 style13"><span class="style32">:: SERVI&Ccedil;O :: </span></span></td>

  </tr>
  <tr>
    <td width="44"><span class="style13"><span class="style10">Carro:</span></span></td>
    <td width="111" align="left"><input name="carro_sv" type="text" id="carro_sv" size="15"></td>
    <td width="147" align='center' ><div align="left"><span class="style13"><span class="style10">Placa: 
      <input name="placa_sv" type="text" id="placa_sv" size="12">
    </span></span></div></td>
    <td width="115">Valor(R$):
      <input type="text" name="valor_sv" size="5"></td>
    <td width="111">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style13"><span class="style10">Servi&ccedil;o:</span></span></td>
    <td align="left"><select name="sv">
        <option selected="selected" value="0">---Servi&ccedil;o---</option>
        <?



				$resultado = mysql_query("SELECT DISTINCT SER_NOME, SER_ID FROM servicos WHERE SER_ATIVO = '1' ORDER BY SER_NOME ASC");



				while($sql = mysql_fetch_array($resultado))



				{



					echo "<option value='$sql[SER_ID]'>".substr ($sql[SER_NOME],0,50)."...</option>'";



				}



			?>
    </select></td>
    <td align='center' >
      <select name="mecanico">
        <option value="0">---Mec&acirc;nico---</option>
        <?



				$resultado1 = mysql_query("SELECT FUN_NOME, FUN_ID FROM funcionario WHERE FUN_TIPO='MEC&Acirc;NICO'");



				while($sql1 = mysql_fetch_array($resultado1))



				{



					echo "<option value='$sql1[FUN_ID]'>".substr ($sql1[FUN_NOME],0,50)."...</option>";



				}



			?>
      </select>
    </td>
    <td>
      <select name="borracheiro">
        <option value="0">---Borracheiro---</option>
        <?



				$resultado2 = mysql_query("SELECT FUN_NOME, FUN_ID FROM funcionario WHERE FUN_TIPO='BORRACHEIRO'");



				while($sql2 = mysql_fetch_array($resultado2))



				{



					echo "<option value='$sql2[FUN_ID]'>".substr ($sql2[FUN_NOME],0,50)."...</option>";



				}



			?>
      </select>
    </td>
    <td>&nbsp;</td>
  </tr>

  <tr>
    <td colspan='5' align='center' >&nbsp;</td>
  </tr>
  <tr><td colspan='5' align='center' ><input type='submit' value='Definir Servi�os' onClick="return validaPrevenda();"></td></tr>

</form>

</table>

<br />

<table width="550" border="0">

<form name="add_funcionario" enctype="multipart/form-data" method="post">

  <tr bordercolor="#000000" bgcolor="#000000">

    <td colspan="5"><span class="style12 style13"><span class="style32">:: FUNCION&Aacute;RIOS :: </span></span></td>

  </tr>

  <tr>

    <td><span class="style13"><span class="style10">Funcion&aacute;rios</span></span>:</td>

    <td><span class="style13">

      <select name="vendedor">

        <option value="">---Vendedor---</option>

        <?



				$resultado = mysql_query("SELECT FUN_NOME, FUN_ID FROM funcionario WHERE FUN_TIPO='VENDEDOR'");



				while($sql = mysql_fetch_array($resultado))



				{



					echo "<option value='$sql[FUN_ID]'>".substr ($sql[FUN_NOME],0,50)."...</option>";



				}



			?>

      </select>

    </span></td>

  </tr>

  <tr><td colspan='5' align='center' ></td></tr>

  <tr><td colspan='5' align='center' ><input type='submit' value='Definir Funcion�rios' onClick="return validaVendedor();"></td></tr>

  </form>

  <tr>

    <td colspan="5">&nbsp;</td>

  </tr>

</table>

<br>

<br>

<table width="550" border="0">

	<tr>

    	<td align="center">

        	<form name="add_orcamento" enctype="multipart/form-data" method="post">

            	<input type="hidden" name="add_orcamento2" value="1">

            	<input type="hidden" name="ref_cliente" value="<?=$_SESSION['ref_cliente']?>">

                <input type="hidden" name="ref_produtos" value="<?=$_SESSION['ref_produtos']?>">

                <input type="hidden" name="ref_qtde" value="<?=$_SESSION['ref_qtde']?>">

                <input type="hidden" name="ref_valor" value="<?=$_SESSION['ref_valor']?>">

                <input type="hidden" name="ref_servico" value="<?=$_SESSION['ref_servico']?>">

                <input type="hidden" name="ref_valor_sv" value="<?=$_SESSION['ref_valor_sv']?>">

                <input type="hidden" name="ref_vendedor" value="<?=$_SESSION['ref_vendedor']?>">

                <input type="hidden" name="ref_mecanico" value="<?=$_SESSION['ref_mecanico']?>">

                <input type="hidden" name="ref_borracheiro" value="<?=$_SESSION['ref_borracheiro']?>">

            	<input type="submit" value="GERAR OR�AMENTO FINAL" onClick="return validaOrcamento();">

            </form>

        </td>

    </tr>

</table>

<table width="550" border="0">

  <tr>

    <td bgcolor="#FFFFFF"><span class="style12 style13"><span class="style34">:: INFORMA&Ccedil;&Otilde;ES GERAIS::<br>

      -------------------------------------------------------------------------------------------------------------------------------------------------------------------

    </span></span></td>

  </tr>

  <tr>

    <td><table width="550" border="0" align="center" bordercolor="#000000" bgcolor="#000000">

      <tr bgcolor="#333333">

        <td><span class="style13"><span class="style29">DATA</span></span></td>

        <td><span class="style13"><span class="style29">NOME</span></span></td>

        <td><span class="style13"><span class="style29">VENDENDOR</span></span></td>

        <td><span class="style13"><span class="style29">TOTAL</span></span></td>

        <td><span class="style13"><span class="style29">OR�AMENTO</span></span></td>

        <td><span class="style13"><span class="style29">F.PEDIDO</span></span></td>

        <td><span class="style13"><span class="style29">EXCLUIR</span></span></td>        

      </tr>

	  <?

	  	$select = "SELECT * FROM pre_vendas";

		$query = mysql_query($select);

		$rows = mysql_num_rows($query);

		if($rows>0){



		$sql = "SELECT pv.id_cliente, pv.id, pv.valor_produto, pv.valor_servico, pv.data, pv.id_vendedor, c.CLI_NOME, f.FUN_NOME FROM pre_vendas pv, clientes c, funcionario f WHERE pv.id_cliente = c.CLI_ID AND pv.id_vendedor = f.FUN_ID AND pv.id_usuario = '$_SESSION[id_usuario]' ";   

		$qr = mysql_query($sql);   

		while($row = mysql_fetch_array($qr)) {   

		$valor_p = "";

		$valor_s = "";

		

		$produto_vp = explode("/",$row['valor_produto']);

		$cont_vp	= count($produto_vp);

		for($i=0;$i<($cont_vp-1);$i++){

			$valor_p = $valor_p + $produto_vp[$i];

			//echo $valor_p;

			//echo "<br>";

		}

		

		$servico_sv = explode("/",$row['valor_servico']);

		$cont_sv	= count($servico_sv);

		for($i=0;$i<($cont_sv-1);$i++){

			$valor_s = $valor_s + $servico_sv[$i]; 

		}



		$valor_total = $valor_p + $valor_s;

		$data_final = new DateTime($row['data']);  

		$data_final = $data_final->format('d/m/Y');

		

		?>

     <tr bgcolor="#FFFFFF">

      <td><? echo $data_final; ?></td>

      <td><? echo $row['CLI_NOME']; ?></td>

      <td><? echo $row['FUN_NOME']; ?></td>

      <td><? echo $valor_total; ?></td>

      <td align="center" width="30"><form action="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/orcamento.php" method="post" enctype="multipart/form-data"><input type="hidden" name="id_pre_venda" value="<?=$row['id']?>"><input type="image" src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/imprimir.jpg" width="30" height="30" /></form></td>

      <td align="center" width="30"><form action="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/f_pedidos.php" method="post" enctype="multipart/form-data"><input type="hidden" name="id_pre_venda" value="<?=$row['id']?>"><input type="image" src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/finalizar-pedido.gif" height="30" /></form></td>

      <td align="center"><form action="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/excluir_orcamento.php" method="post" enctype="multipart/form-data"><input type="hidden" name="id_pre_venda" value="<?=$row['id']?>"><input type="image" src="file:///C|/Documents%20and%20Settings/SW%20CENTER/Configura&#231;&#245;es%20locais/Temp/fz3temp-1/img/ico_excluir.jpg" /></form></td>



   </tr>

   <?

   }

}

else{

 ?>

     <tr bgcolor="#FFFFFF"><td colspan="7" align="center">N�o h� or�amentos para validar</td></tr>

<?php

}

?>

    </table>

    <blockquote>&nbsp;</blockquote></td>

  </tr>

</table>

<br>

</body>

</html>

