<?
session_start();
include ("php/valida_sessao.php");
include"config.php";

$id					= $_POST['id'];
$idd				= $_POST['idd'];
$nome_campo			= $_POST['nome'];
$nome3				= $_POST['nome3'];
$tipo				= $_POST['tipo'];
$size				= $_POST['size'];
$maxlength			= $_POST['maxlength'];
$nome_campo_input	= $_POST['nome_campo_input'];
$nome_input			= $_POST['nome_input'];

/*echo "id = ".$id."<br>";
echo "idd = ".$idd."<br>";
echo "nome_campo = ".$nome_campo."<br>";
echo "nome3 = ".$nome3."<br>";
echo "tipo = ".$tipo."<br>";
echo "size = ".$size."<br>";
echo "maxlength = ".$maxlength."<br>";
exit();*/

if(($tipo != "text") and ($tipo != "password")){
	$query	= "UPDATE formulario SET
	nome_campo_input	= '$nome_campo_input', 
	nome_campo			= '$nome_campo',
	nome				= '$nome3'
	WHERE id	= '$idd'";
	$result	= mysql_query($query);
}else{
	$query	= "UPDATE formulario SET 
	nome_campo		= '$nome_campo',
	nome			= '$nome_input',
	size			= '$size',
	maxlength		= '$maxlength'
	WHERE id	= '$idd'";
	$result	= mysql_query($query);
}
Header("Location: ../adm_formulario2.php");
	
?>