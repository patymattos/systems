﻿<script>



    var i = 0;



    $(document).ready(function(){
 
	

        $('#telres').mask('(99)9999-9999?9');
		

 $('#cel').mask('(99)9999-9999?9');



 $('#fax').mask('(99)9999-9999');



 $('#data').mask('99/99/9999');

 $('#data_batismo').mask('99/99/9999');

 $('#data_emissao').mask('99/99/9999');

 $('#data_validade').mask('99/99/9999');





     



       $('#end_cep' ).mask('99999-999');  

      



        



        $.validator.setDefaults({



            //            submitHandler: function() { alert("submitted!"); },



            highlight: function(input) {



                $(input).addClass("ui-state-error");



            },



            unhighlight: function(input) {



                $(input).removeClass("ui-state-error");



            }



        });



        



        var validator =   $("#form").validate({



            submitHandler: function(form) {



                //obtendo dados de localiza��o



              



                dados = $('#form').serialize();



                $.ajax({



                    url: '<?php echo $acao; ?>',



                    type: "POST",



                    dataType: "text",



                    async:false,



                    



                    error: function(xhr, err, thrownError){



                        alert(xhr + "\n" + err+"\n" +thrownError);



                    },



                    data:dados,



                    success: function (data) {



                                              



                        alert(data);        



                         location.href = "<?php echo site_url(); ?>/cadastros/contatos/";



                    }







                });



            },



            rules: {


                data:{

                    required:true

                },

               veiculo:{

                    required:true
                },
		nsituacao:{

                    required:true
                },
				
				qtproduto:{

                    required:true
                },
				cod_tipo_venda:{

                    required:true
                },
				
				



		  
			tipoproduto:{

                    required:true

                }
            } ,



            messages:{

                data:{

                    required:"Campo Obrigatório"


                } ,


                veiculo:{

                    required:"Campo Obrigatório"

                },
		nsituacao:{

                    required:"Campo Obrigatório"

                },

				qtproduto:{

                    required:"Campo Obrigatório"

                },
				
				cod_tipo_venda:{

                    required:"Campo Obrigatório"

                },

              
                tipoproduto:{

		 required:"Campo Obrigatório"



             }



            }
     



        });




        $('.cancelar').click(function(){



            validator.resetForm();//remove as mensagens de erro



            $('input, select').removeClass("ui-state-error"); // remove a cor avermelhada dos campos com erro



        });



        



    });



    /**



     * M�todo que adciona as emails



     */



    function addEmail(){



    



        if($('#email').val() != ''){



            



            var id = $('#email').val();



            id = id.replace("@","");



            id = id.replace(".","");



            $('#htmlemail').append("<div id='"+id+"' > <input type=radio name=emailprincipal  id=emailprincipal value='"+$('#email').val()+"'  />Email Principal <input type='hidden' name='tipos[]'  value='"+$('#tipo').val()+"' readonly=true> <input type='text' name='email[]' class='email'  value='"+$('#email').val()+"' readonly=true> <img onclick='javascript:deletar(\""+id+"\")' src=<?php echo base_url('images/excluir.png'); ?> /></div>");



           



        



            



            $('#email').val('') ;



            $('#email').focus() ;







            if($('#htmlemail').html()!= ""){



                $('#email').removeClass('required');



            }



           



        }



        



        


    



        return false;



    }



    



    



    /**



     * M�todo que adciona as telefones



     */



    function addTelefone(){



    



        if($('#telefone').val() != ''){



            var id = $('#telefone').val();



            id = id.replace("(","");



            id = id.replace(")","");



            $('#htmltelefone').append("<div id='"+id+"' ><input type=checkbox name=ind_ocult_tel[]  id=ind_ocult_tel value='"+$('#telefone').val()+"'  />Ocultar Telefone &nbsp; <input type=radio name=telprincipal  id=telprincipal value='"+$('#telefone').val()+"'  />Telefone Principal &nbsp; <input type='hidden' name='tipostel[]'  value='"+$('#tipotel').val()+"' readonly=true> <input type='text' name='telefone[]'  value='"+$('#telefone').val()+"' readonly=true> <img onclick='javascript:deletar(\""+id+"\")' src=<?php echo base_url('images/excluir.png'); ?> /></div>");



           



         



            $('#telefone').val('') ;



            $('#telefone').focus() ;



            



            if($('#htmltelefone').html()!= ""){



                $('#telefone').removeClass('required');



            }



        



     







           



        }



  



        return false;



    }



    



    



    



    function deletar(id){



    



          







        $('#'+ id).remove();



        if($('#htmltelefone').html()== ""){



            $('#telefone').addClass('required');



        }



        










    }



    



    



</script>
<script type="text/javascript" src="//code.jquery.com/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(function(){
$(".search_keyword").keyup(function() 
{ 
	var search_keyword_value = $(this).val();
	var dataString = 'search_keyword='+ search_keyword_value;
	if(search_keyword_value!='')
	{
		$.ajax({
			type: "POST",
			url: "http://www.esdr.com.br/dibran/search.php",
			data: dataString,
			cache: false,
			success: function(html)
			{
				$("#result").html(html).show();
			}
		});
	}
	return false;    
});

$("#result").live("click",function(e){
	var $clicked = $(e.target);
	var $name = $clicked.find('.nom_contato').html();	
	var decoded = $("<div/>").html($name).text();
	$('#search_keyword_id').val(decoded);
});
$(document).live("click", function(e) { 
	var $clicked = $(e.target);
	if (! $clicked.hasClass("search_keyword")){
		$("#result").fadeOut(); 
	}
});
$('#search_keyword_id').click(function(){
	$("#result").fadeIn();
});
});
</script>
 
<script>
function ChamarLink() { 
       var url='';

		var selects = document.veiculo.options.text
;
		//var selects = document.getElementById('select');

				//alert( selects );

		for( var i = 0; i < selects.length; i++ )
		{
			if( selects[i].name=='veiculo[]' )
				url +=	document.getElementById("veiculo[]").options[document.getElementById("veiculo[]").selectedIndex].text;
		//var selects = document.getElementById('select');
		}
		alert( url );
    }

function duplicarCampos(){
	
	
	var clone = document.getElementById('origem').cloneNode(true);

	var destino = document.getElementById('destino');
	destino.appendChild (clone);
	var camposClonados = clone.getElementsByTagName('qtproduto');
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
	
	
}
function removerCampos(id){
	var node1 = document.getElementById('destino');
	node1.removeChild(node1.childNodes[0]);
}


</script>

     <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />







<div >



    <div id="miolo"> 






        <div style="clear: both"></div>



                            <legend><font color='white'><b>ATENDIMENTO - Venda<b></font></legend>

                           

                     






        <div >


            <form name="form" id="form" autocomplete="off" method="post" action="<?php echo $acao; ?>">



                <fieldset><input type="hidden" name="cod_seq_contat" id="cod_seq_contat" size="30" value="<?php echo isset($cod_seq_contat) ? $cod_seq_contat : ''; ?>">


<input type="hidden" name="ind_status" id="ind_status" size="30" value="1">


                    <table class="verdana11comum" style="width: 95%" >



                       



                         <tr>



                            <td>



                                <label class="verdana11comum"><br>Entrada/Saída:</label>    



                            <td>             <br>             <input type="hidden" value="<?php echo @$cod_seq_categ; ?>" id="cod_seq_categ" name="cod_seq_categ" value='59'  >
<select id='cod_tipo_venda' name='cod_tipo_venda'>
  <option value="<?php echo( ( @$cod_tipo_venda == 41 ) ? '41' : '' ); ?><?php echo( ( @$cod_tipo_venda == 42 ) ? '42' : '' ); ?>"><?php echo( ( @$cod_tipo_venda == 41 ) ? 'ENTRADA' : '' ); ?><?php echo( ( @$cod_tipo_venda == 42 ) ? 'SAIDA' : '' ); ?></option>

  <option value="41">ENTRADA</option>
  <option value="42">SAIDA</option>
  
</select></td>



                            </td>







                            <td>



                                <label class="verdana11comum"><br>Nome:</label>                      



                            <td> 
<br>


                                <input type="text" value="<?php echo utf8_decode(@$nom_contato); ?>" name="nome" class="nomeauto" id="nome"  size="35" >
										<input type="text" class="search_keyword" id="search_keyword_id" placeholder="Country Search" />

								</td>


								<div id="outputbox">
        <p id="outputcontent"></p>
      </div>





                            </td>



                            <td>



                                <label class="verdana11comum"><br>Telefone:</label>                      



                            <td>
<br>


                               



                                <input type="text" value="<?php echo isset($telres) ? $telres : ''; ?>" id="telres" name="telres" size="14" ></td>







                            </td>



                            <td >

<br>

                                <label class="verdana11comum">Valor       <img src="http://www.esdr.com.br/dibran/assets/images/iconedinheiro.jpg" width="20"  height="20" >
:</label>    



                            



                            <td >

<br>

                                <input type="text" id="valor_dinheiro" name="valor_dinheiro" value="<?php echo utf8_decode(@$valor_dinheiro); ?>" size="10">



                            </td> </td>

  <td >

<br>

                                <label class="verdana11comum">Valor <img src="http://www.esdr.com.br/dibran/assets/images/icone3.png" width="20"  height="20">:</label>    



                            



                            <td >

<br>

                                <input type="text" id="valor_cartao" name="valor_cartao" value="<?php echo utf8_decode(@$valor_cartao); ?>" size="10">



                            </td> </td>


                        </tr>



                        <tr>



                            <td>



                                <label class="verdana11comum"><br>Tipo Produto:</label>                   



                            <td  class="required">

<br>
                                 <select name="tipoproduto"  required="required" id="tipoproduto" >
  <option value="<?php echo( ( @$tipoproduto == 1 ) ? '1' : '' ); ?><?php echo( ( @$tipoproduto == 2 ) ? '2' : '' ); ?><?php echo( ( @$tipoproduto == 3 ) ? '3' : '' ); ?>"><?php echo( ( @$cod_tipo_venda == 1 ) ? 'PEÇAS' : '' ); ?><?php echo( ( @$cod_tipo_venda == 2 ) ? 'OUTROS' : '' ); ?><?php echo( ( @$tipoproduto == 2 ) ? '2' : '' ); ?><?php echo( ( @$cod_tipo_venda == 3 ) ? 'TATTOO' : '' ); ?></option>
<option value="1">PEÇAS</option>
<option value="2">OUTROS</option>
<option value="3">TATTOO</option>

</select>
 </td>







                            </td>



                            <td>



                                <label class="verdana11comum"><br>Descriminação:</label>    



                            <td>      <br>                          <input type="text" value="<?php echo isset($descriminacao) ? $descriminacao : ''; ?>" id="descriminacao" name="descriminacao" size="35" ></td>



                            </td>



                            <td>



                                <label class="verdana11comum"><br>Serviço:</label>                      



                            <td>

<br>
                                <input type="text" value="<?php echo isset($servico) ? $servico : ''; ?>" id="servico" name="servico" size="14" ></td>







                            </td> <td>



                                <label class="verdana11comum"><br>Artista:</label>
								
								<td> <br><input type="text" value="<?php echo isset($responsavel) ? $responsavel : ''; ?>" id="responsavel" name="responsavel" size="18" >                        </td>





                        </tr>



                     





                        


                 






                        <tr>
						                         <tr>



                          






                            <td>



                                <label class="verdana11comum"><br>Produtos/Qtde:</label>                      



                            <td colspan="4"> 
<br>
								<?php if(@$qtproduto<>""): ?>
								
								<?php $arrayv =  explode(";", $produtovendido);
foreach ($arrayv as $xv) {
echo "                                <input type='text' value='{$xv}' size='14' >
<br />";

}?>
								<?php
								
$array =  explode(";", $qtproduto);
foreach ($array as $x) {
echo "                                <input type='text' readonly='true' value='{$x}' size='14' >
<br />";
}
                                
								?>
                       <input type="hidden" value="<?php echo isset($qtproduto) ? $qtproduto : ''; ?>" id="qtproduto" name="qtproduto[]" size="14" >

								
								</td>
								<?php else: ?>
								<div id="origem">
								<?php echo $veiculo; ?>
                                <input type="text" value="<?php echo isset($qtproduto) ? $qtproduto : ''; ?>" id="qtproduto" name="qtproduto[]" size="14" >
								<img  src="http://www.esdr.com.br/dibran/assets/imagens/add.png" width="20" height="20" style="cursor: pointer;" onclick="duplicarCampos();">
								<img  src="http://www.esdr.com.br/dibran/assets/imagens/excluir.png" width="19" height="19"  style="cursor: pointer;" onclick="removerCampos(this);">
								</div>
								<div id="destino">
	</div>


                               </td>







                            </td>



                            <td>



                                <label class="verdana11comum"><br></label>                      



                            <td>
<br>


                               


								
								</td>

								<?php endif; ?>







                            </td>



                            <td >

<br>

                                <label class="verdana11comum"></label>    



                            



                            <td >

<br>

                             

                            </td> </td>



                        </tr>





                            <td class="verdana11comum" colspan="3">



                                



                                <?php 



                                 if (@$telefone['nom_usu_incl'] <> $this->session->userdata('nom_usuario') and $this->session->userdata('ind_nivel_acesso') <> 1) {



                                                    $desabilitado = "disabled=true";



                                                } else {



                                                    $desabilitado = "";



                                                }



                                ?>

<br>

                                <button id="cadastrar" <?php echo $desabilitado; ?> class="novo">Salvar</button>



                                <button type="reset" id="cancelar" class="cancelar">Cancelar</button>



                            </td>



                        </tr>





                        <tr>



                            <td colspan="3">



                                <div class="error">



                                </div>



                            </td>



                        </tr>











                    </table>



                </fieldset>



            </form>



        </div>



        <div style="clear: both"> &nbsp;</div>



        <div  >



            <a href="javascript:history.go(-1)"><button id="voltar" class="voltar verdana11comum"><label class="verdana11comum">Voltar</label></button></a>



        </div>



        <div style="clear: both"> &nbsp;</div>







     


        



       



        



       







    </div>







</div>