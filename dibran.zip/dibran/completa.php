<?php


$hostname = "localhost";
$user = "esdrcom_sys2017";
$pass = "4eaO_]q)ofm8";
$basedados = "esdrcom_sysadm";
$connect = mysql_connect($hostname,$user,$pass) or die ("Impossível estabelecer conexão com o servidor de banco de dados");
mysql_select_db($basedados) or die ("Impossivel estabelecer conexão com o banco de dados");
 
//busca valor digitado no campo autocomplete "$_GET['term']
$text = mysql_real_escape_string($_GET['term']);
$query = "SELECT * FROM CONTATO WHERE nom_contato LIKE '%$text%' ORDER BY nom_contato ASC";
$result = mysql_query($query);
//formata o resultado para JSON
$json = '[';
$first = true;
while($row = mysql_fetch_array($result))
{
  if (!$first) { $json .=  ','; } else { $first = false; }
  $json .= '{"value":"'.utf8_encode($row['nom_contato']).'","data":"'.$row['telres'].'"}';
  //  $json .= '{"value":"'.utf8_encode($row['nom_contato']).'"}';


}
$json .= ']';
 
echo $json;
?>

